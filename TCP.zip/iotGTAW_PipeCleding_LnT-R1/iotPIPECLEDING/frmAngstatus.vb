﻿Public Class frmAngstatus
    Dim tx As String = ""
    Dim rx As String = ""
    Dim y As Double = 0.0
    Dim y1 As Double = 0.0

    Dim errno As Integer = 0

    Private Sub frmAngstatus_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '' Dim testDialog As New frmAngstatus

        Me.WindowState = FormWindowState.Maximized
        Wrkb1.Visible = False
        '  Analogread()
        Timer1.Enabled = True
        Timer2.Enabled = True

    End Sub
    Private Sub frmAngstatus_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Panel1.Left = (Me.Width - Panel1.Width) / 4
        Panel1.Top = (Me.Height - Panel1.Height) / 2
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Timer1.Enabled = False
        Me.Close()

    End Sub


    Public Sub Analogread2()
        Try
            errno = 0
            Dim y As Integer
            Dim y1 As Double
            Dim plcinstrg As String = ""
            If isConnection = True Then

                '''''////////////  Read Analog In 1  ///////////////////////
                ''''y = 0.0
                ''''y1 = 0
                ''''plcinstrg = ""

                ''''plcinstrg = txComRX("03 03 03 E8 00 02 45 99", 50)
                ''''Dim x1() As String = plcinstrg.Split(" "c)
                ''''If x1.Count >= 8 Then
                ''''    If x1(6) = "03" And x1(7) = "03" Then
                ''''        y = Convert.ToInt32(x1(9) & x1(10))
                ''''        lblAI1.Text = (y / 10).ToString()

                ''''        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                ''''        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                ''''    End If
                ''''End If

                '''''////////////  Read Analog In 2  ///////////////////////
                ''''y = 0.0
                ''''y1 = 0
                ''''plcinstrg = ""

                ''''plcinstrg = txComRX("03 03 03 E8 00 02 45 99", 50)
                ''''Dim x2() As String = plcinstrg.Split(" "c)
                ''''If x2.Count >= 8 Then
                ''''    If x2(6) = "03" And x2(7) = "03" Then
                ''''        y = Convert.ToInt32(x2(9) & x2(10))
                ''''        lblAI2.Text = (y / 10).ToString()

                ''''        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                ''''        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                ''''    End If
                ''''End If

                '''''////////////  Read Analog In 3  ///////////////////////
                ''''y = 0.0
                ''''y1 = 0
                ''''plcinstrg = ""

                ''''plcinstrg = txComRX("03 03 03 E8 00 02 45 99", 50)
                ''''Dim x3() As String = plcinstrg.Split(" "c)
                ''''If x3.Count >= 8 Then
                ''''    If x3(6) = "03" And x3(7) = "03" Then
                ''''        y = Convert.ToInt32(x3(9) & x3(10))
                ''''        lblAI3.Text = (y / 10).ToString()

                ''''        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                ''''        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                ''''    End If
                ''''End If

                '''''////////////  Read Analog In 4  ///////////////////////
                ''''y = 0.0
                ''''y1 = 0
                ''''plcinstrg = ""

                ''''plcinstrg = txComRX("03 03 03 E8 00 02 45 99", 50)
                ''''Dim x4() As String = plcinstrg.Split(" "c)
                ''''If x4.Count >= 8 Then
                ''''    If x4(6) = "03" And x1(7) = "03" Then
                ''''        y = Convert.ToInt32(x1(9) & x1(10))
                ''''        lblAI1.Text = (y / 10).ToString()

                ''''        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                ''''        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                ''''    End If
                ''''End If

                '''''////////////  Read Analog In 5  ///////////////////////
                ''''y = 0.0
                ''''y1 = 0
                ''''plcinstrg = ""

                ''''plcinstrg = txComRX("03 03 03 E8 00 02 45 99", 50)
                ''''Dim x1() As String = plcinstrg.Split(" "c)
                ''''If x1.Count >= 8 Then
                ''''    If x1(6) = "03" And x1(7) = "03" Then
                ''''        y = Convert.ToInt32(x1(9) & x1(10))
                ''''        lblAI1.Text = (y / 10).ToString()

                ''''        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                ''''        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                ''''    End If
                ''''End If

                '''''////////////  Read Analog In 6  ///////////////////////
                ''''y = 0.0
                ''''y1 = 0
                ''''plcinstrg = ""

                ''''plcinstrg = txComRX("03 03 03 E8 00 02 45 99", 50)
                ''''Dim x1() As String = plcinstrg.Split(" "c)
                ''''If x1.Count >= 8 Then
                ''''    If x1(6) = "03" And x1(7) = "03" Then
                ''''        y = Convert.ToInt32(x1(9) & x1(10))
                ''''        lblAI1.Text = (y / 10).ToString()

                ''''        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                ''''        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                ''''    End If
                ''''End If

                '''''////////////  Read Analog In 7  ///////////////////////
                ''''y = 0.0
                ''''y1 = 0
                ''''plcinstrg = ""

                ''''plcinstrg = txComRX("03 03 03 E8 00 02 45 99", 50)
                ''''Dim x1() As String = plcinstrg.Split(" "c)
                ''''If x1.Count >= 8 Then
                ''''    If x1(6) = "03" And x1(7) = "03" Then
                ''''        y = Convert.ToInt32(x1(9) & x1(10))
                ''''        lblAI1.Text = (y / 10).ToString()

                ''''        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                ''''        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                ''''    End If
                ''''End If

                '''''////////////  Read Analog In 8  ///////////////////////
                ''''y = 0.0
                ''''y1 = 0
                ''''plcinstrg = ""

                ''''plcinstrg = txComRX("03 03 03 E8 00 02 45 99", 50)
                ''''Dim x1() As String = plcinstrg.Split(" "c)
                ''''If x1.Count >= 8 Then
                ''''    If x1(6) = "03" And x1(7) = "03" Then
                ''''        y = Convert.ToInt32(x1(9) & x1(10))
                ''''        lblAI1.Text = (y / 10).ToString()

                ''''        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                ''''        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                ''''    End If
                ''''End If

                '////////////////////  Read Scalling Factor ///

                '//// Read Input scale 1  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 EA 00 04", 100)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(6) = "02" And x1(7) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gMinScaleAi1 = (y / 10)
                        txtAiMinScale1.Text = gMinScaleAi1.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x1(15) & x1(16) & x1(13) & x1(14), 16)
                        gMaxScalleAi1 = (y / 10)
                        txtAiMaxScale1.Text = gMaxScalleAi1.ToString()

                        errno = 1
                    End If
                Else
                End If

                '//// Read Input scale 2  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 F4 00 04", 120)
                Dim x2() As String = plcinstrg.Split(" "c)
                If x2.Count >= 8 Then
                    If x2(6) = "02" And x2(7) = "03" Then
                        y = Convert.ToInt32(x2(11) & x2(12) & x2(9) & x2(10), 16)
                        gMinScaleAi2 = (y / 10)
                        txtAiMinScale2.Text = gMinScaleAi2.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x2(15) & x2(16) & x2(13) & x2(14), 16)
                        gMaxScalleAi2 = (y / 10)
                        txtAiMaxScale2.Text = gMaxScalleAi2.ToString()

                        errno = 2
                    End If
                Else
                End If

                '//// Read Input scale 3  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 FE 00 04", 140)
                Dim x3() As String = plcinstrg.Split(" "c)
                If x3.Count >= 8 Then
                    If x3(6) = "02" And x3(7) = "03" Then
                        y = Convert.ToInt32(x3(11) & x3(12) & x3(9) & x3(10), 16)
                        gMinScaleAi3 = (y / 10)
                        txtAiMinScale3.Text = gMinScaleAi3.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x3(15) & x3(16) & x3(13) & x3(14), 16)
                        gMaxScalleAi3 = (y / 10)
                        txtAiMaxScale3.Text = gMaxScalleAi3.ToString()

                        errno = 3
                    End If
                Else
                End If


                '//// Read Input scale 4  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 08 00 04", 140)
                Dim x4() As String = plcinstrg.Split(" "c)
                If x4.Count >= 8 Then
                    If x4(6) = "02" And x4(7) = "03" Then
                        y = Convert.ToInt32(x4(11) & x4(12) & x4(9) & x4(10), 16)
                        gMinScaleAi4 = (y / 10)
                        txtAiMinScale4.Text = gMinScaleAi4.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x4(15) & x4(16) & x4(13) & x4(14), 16)
                        gMaxScalleAi4 = (y / 10)
                        txtAiMaxScale4.Text = gMaxScalleAi4.ToString()
                        errno = 4
                    End If
                Else
                End If

                '//// Read Input scale 5  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 12 00 04", 140)
                Dim x5() As String = plcinstrg.Split(" "c)
                If x5.Count >= 8 Then
                    If x5(6) = "02" And x5(7) = "03" Then
                        y = Convert.ToInt32(x5(11) & x5(12) & x5(9) & x5(10), 16)
                        gMinScaleAi5 = (y / 10)
                        txtAiMinScale5.Text = gMinScaleAi5.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x5(15) & x5(16) & x5(13) & x5(14), 16)
                        gMaxScalleAi5 = (y / 10)
                        txtAiMaxScale5.Text = gMaxScalleAi5.ToString()

                        errno = 5
                    End If
                Else
                End If

                '//// Read Input scale 6  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 1C 00 04", 140)
                Dim x6() As String = plcinstrg.Split(" "c)
                If x6.Count >= 8 Then
                    If x6(6) = "02" And x6(7) = "03" Then
                        y = Convert.ToInt32(x6(11) & x6(13) & x6(9) & x6(10), 16)
                        gMinScaleAi6 = (y / 10)
                        txtAiMinScale6.Text = gMinScaleAi6.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x6(15) & x6(16) & x6(13) & x6(14), 16)
                        gMaxScalleAi6 = (y / 10)
                        txtAiMaxScale6.Text = gMaxScalleAi6.ToString()
                        errno = 6
                    End If
                Else
                End If

                '//// Read Input scale 7  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 26 00 04", 140)
                Dim x7() As String = plcinstrg.Split(" "c)
                If x7.Count >= 8 Then
                    If x7(6) = "02" And x7(7) = "03" Then
                        y = Convert.ToInt32(x7(11) & x7(12) & x7(9) & x7(10), 16)
                        gMinScaleAi7 = (y / 10)
                        txtAiMinScale7.Text = gMinScaleAi7.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x7(15) & x7(16) & x7(13) & x7(14), 16)
                        gMaxScalleAi7 = (y / 10)
                        txtAiMaxScale7.Text = gMaxScalleAi7.ToString()

                        errno = 7
                    End If
                Else
                End If

                '//// Read Input scale 8  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 30 00 04", 140)
                Dim x8() As String = plcinstrg.Split(" "c)
                If x8.Count >= 8 Then
                    If x8(6) = "02" And x8(7) = "03" Then
                        y = Convert.ToInt32(x8(11) & x8(12) & x8(9) & x8(10), 16)
                        gMinScaleAi8 = (y / 10)
                        txtAiMinScale8.Text = gMinScaleAi8.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x8(15) & x8(16) & x8(13) & x8(14), 16)
                        gMaxScalleAi8 = (y / 10)
                        txtAiMaxScale8.Text = gMaxScalleAi8.ToString()

                        errno = 8
                    End If
                Else
                End If

                '//// Read Output scale 1  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 4E 00 04", 140)
                Dim x9() As String = plcinstrg.Split(" "c)
                If x9.Count >= 8 Then
                    If x9(6) = "02" And x9(7) = "03" Then
                        y = Convert.ToInt32(x9(11) & x9(12) & x9(9) & x9(10), 16)
                        gMinScalleAo1 = (y / 10)
                        txtAOMinScale1.Text = gMinScalleAo1.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x9(15) & x9(16) & x9(13) & x9(14), 16)
                        gMaxScalleAo1 = (y / 10)
                        txtAOMaxScale1.Text = gMaxScalleAo1.ToString

                        errno = 9
                    End If
                Else
                End If


                '//// Read Output scale 2  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 58 00 04", 140)
                Dim x10() As String = plcinstrg.Split(" "c)
                If x10.Count >= 8 Then
                    If x10(6) = "02" And x10(7) = "03" Then
                        y = Convert.ToInt32(x10(11) & x10(12) & x10(9) & x10(10), 16)
                        gMinScalleAo2 = (y / 10)
                        txtAOMinScale2.Text = gMinScalleAo2.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x10(15) & x10(16) & x10(13) & x10(14), 16)
                        gMaxScalleAo2 = (y / 10)
                        txtAOMaxScale2.Text = gMaxScalleAo2.ToString

                        errno = 10
                    End If
                Else
                End If

                '//// Read Output scale 3  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 62 00 04", 140)
                Dim x11() As String = plcinstrg.Split(" "c)
                If x11.Count >= 8 Then
                    If x11(6) = "02" And x11(7) = "03" Then
                        y = Convert.ToInt32(x11(11) & x11(12) & x11(9) & x11(10), 16)
                        gMinScalleAo3 = (y / 10)
                        txtAOMinScale3.Text = gMinScalleAo3.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x11(15) & x11(16) & x11(13) & x11(14), 16)
                        gMaxScalleAo3 = (y / 10)
                        txtAOMaxScale3.Text = gMaxScalleAo3.ToString
                        errno = 11
                    End If
                Else
                End If

                '//// Read Output scale 4  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 6C 00 04", 140)
                Dim x12() As String = plcinstrg.Split(" "c)
                If x12.Count >= 8 Then
                    If x12(6) = "02" And x12(7) = "03" Then
                        y = Convert.ToInt32(x12(11) & x12(12) & x12(9) & x12(10), 16)
                        gMinScalleAo4 = (y / 10)
                        txtAOMinScale4.Text = gMinScalleAo4.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x12(15) & x12(16) & x12(13) & x12(14), 16)
                        gMaxScalleAo4 = (y / 10)
                        txtAOMaxScale4.Text = gMaxScalleAo4.ToString

                        errno = 12
                    End If
                Else
                End If

                '//// Read Output scale 5  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 76 00 04", 140)
                Dim x13() As String = plcinstrg.Split(" "c)
                If x13.Count >= 8 Then
                    If x13(6) = "02" And x13(7) = "03" Then
                        y = Convert.ToInt32(x13(11) & x13(12) & x13(9) & x13(10), 16)
                        gMinScalleAo5 = (y / 10)
                        txtAOMinScale5.Text = gMinScalleAo5.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x13(15) & x13(16) & x13(13) & x13(14), 16)
                        gMaxScalleAo5 = (y / 10)
                        txtAOMaxScale5.Text = gMaxScalleAo5.ToString

                        errno = 13
                    End If
                Else
                End If


                '//// Read Output scale 6  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 80 00 04", 140)
                Dim x14() As String = plcinstrg.Split(" "c)
                If x14.Count >= 8 Then
                    If x14(6) = "02" And x14(7) = "03" Then
                        y = Convert.ToInt32(x14(11) & x14(12) & x14(9) & x14(10), 16)
                        gMinScalleAo6 = (y / 10)
                        txtAOMinScale6.Text = gMinScalleAo6.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x14(15) & x14(16) & x14(13) & x14(14), 16)
                        gMaxScalleAo6 = (y / 10)
                        txtAOMaxScale6.Text = gMaxScalleAo6.ToString

                        errno = 14
                    End If
                Else
                End If


                '//// Read Output scale 7  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 8A 00 04", 140)
                Dim x15() As String = plcinstrg.Split(" "c)
                If x15.Count >= 8 Then
                    If x15(6) = "02" And x15(7) = "03" Then
                        y = Convert.ToInt32(x15(11) & x15(12) & x15(9) & x15(10), 16)
                        gMinScalleAo7 = (y / 10)
                        txtAOMinScale7.Text = gMinScalleAo7.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x15(15) & x15(16) & x15(13) & x15(14), 16)
                        gMaxScalleAo7 = (y / 10)
                        txtAOMaxScale7.Text = gMaxScalleAo7.ToString

                        errno = 15
                    End If
                Else
                End If

                '//// Read Output scale 8  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 94 00 04", 140)
                Dim x16() As String = plcinstrg.Split(" "c)
                If x16.Count >= 8 Then
                    If x16(6) = "02" And x16(7) = "03" Then
                        y = Convert.ToInt32(x16(11) & x16(12) & x16(9) & x16(10), 16)
                        gMinScalleAo8 = (y / 10)
                        txtAOMinScale8.Text = gMinScalleAo8.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x16(15) & x16(16) & x16(13) & x16(14), 16)
                        gMaxScalleAo8 = (y / 10)
                        txtAOMaxScale8.Text = gMaxScalleAo8.ToString

                        errno = 16
                    End If
                Else
                End If



            End If
        Catch ex As Exception
            Dim result1 As String = MessageBoxEx.Show("Error from Analog Input/Output Read, Error : " + ex.Message.ToString() + errno.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString

            ' MessageBox.Show("Error from Analog Input/Output Read, Error : " + ex.Message.ToString() + errno.ToString())
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        ''''''''''''''''''''''''    ANALOG INPUT  VALUE  ''''''''''''''''''''''''''''''''

        Me.lblAI1.Text = gGTAWCurr.ToString()
        Me.lblAI2.Text = gGTAWVol.ToString()
        Me.lblAI3.Text = gGTAWCurr2.ToString()
        Me.lblAI4.Text = gGTAWVol2.ToString()
        Me.lblAI5.Text = gGTAWgasflow.ToString()
        Me.lblAI6.Text = gGTAWgasflow2.ToString()
        Me.lblAI7.Text = gGTAWjobtemp.ToString()
        Me.lblAI8.Text = gAi8.ToString()


        ''''''''''  ANALOG OUTPUT  VALUE   ''''''''''''''''''''''''''''''''

        Me.lblAO1.Text = gAo1.ToString()
        Me.lblAO2.Text = gAo2.ToString()
        Me.lblAO3.Text = gAo3.ToString()
        Me.lblAO4.Text = gAo4.ToString()
        Me.lblAO5.Text = gAo5.ToString()
        Me.lblAO6.Text = gAo6.ToString()
        Me.lblAO7.Text = gAo7.ToString()
        Me.lblAO8.Text = gAo8.ToString()




    End Sub


    Private Sub txtAiMinScale1_gotfocus(sender As Object, e As EventArgs) Handles txtAiMinScale1.Click
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMinScale1
    End Sub

    Private Sub txtAiMinScale1_TextChanged(sender As Object, e As EventArgs) Handles txtAiMinScale1.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMinScale1.TextLength
        Dim st As String = ""

        st = txtAiMinScale1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMinScale1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMinScale1.Text += ii(ht)
                    Next
                    If txtAiMinScale1.Text <> "-" Then

                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMinScale1.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021003EA000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    gMinScaleAi1 =   txtAiMinScale1.Text 
                            'Else
                            '  txtAiMinScale1.Text = gMinScaleAi1
                            'End If
                            Threading.Thread.Sleep(500)
                            '''''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 EA 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScaleAi1 = (y / 10)
                                    txtAiMinScale1.Text = gMinScaleAi1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAiMinScale1.Text = gMinScaleAi1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMinScale1.Text = gMinScaleAi1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If
    End Sub
    Private Sub txtAiMinScale2_gotfocus(sender As Object, e As EventArgs) Handles txtAiMinScale2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMinScale2
    End Sub
    Private Sub txtAiMinScale2_TextChanged(sender As Object, e As EventArgs) Handles txtAiMinScale2.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMinScale2.TextLength
        Dim st As String = ""

        st = txtAiMinScale2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMinScale2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMinScale2.Text += ii(ht)
                    Next
                    If txtAiMinScale2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMinScale2.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021003F4000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    gMinScaleAi2 =   txtAiMinScale2.Text 
                            'Else
                            '  txtAiMinScale2.Text = gMinScaleAi2
                            'End If
                            Threading.Thread.Sleep(500)
                            '''''''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 F4 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScaleAi2 = (y / 10)
                                    txtAiMinScale2.Text = gMinScaleAi2.ToString()
                                End If
                            End If


                        End If
                    Else
                        txtAiMinScale2.Text = gMinScaleAi2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMinScale2.Text = gMinScaleAi2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If
    End Sub
    Private Sub txtAiMinScale3_gotfocus(sender As Object, e As EventArgs) Handles txtAiMinScale3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMinScale3
    End Sub
    Private Sub txtAiMinScale3_TextChanged(sender As Object, e As EventArgs) Handles txtAiMinScale3.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMinScale3.TextLength
        Dim st As String = ""

        st = txtAiMinScale3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMinScale3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMinScale3.Text += ii(ht)
                    Next
                    If txtAiMinScale3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMinScale3.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021003FE000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    gMinScaleAi3 =   txtAiMinScale3.Text 
                            'Else
                            '  txtAiMinScale3.Text = gMinScaleAi3
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 FE 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScaleAi3 = (y / 10)
                                    txtAiMinScale3.Text = gMinScaleAi3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAiMinScale3.Text = gMinScaleAi3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMinScale3.Text = gMinScaleAi3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If
    End Sub
    Private Sub txtAiMinScale4_gotfocus(sender As Object, e As EventArgs) Handles txtAiMinScale4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMinScale4
    End Sub
    Private Sub txtAiMinScale4_TextChanged(sender As Object, e As EventArgs) Handles txtAiMinScale4.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMinScale4.TextLength
        Dim st As String = ""

        st = txtAiMinScale4.Text
        Dim ii() As Char = st.ToCharArray
        ''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMinScale4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMinScale4.Text += ii(ht)
                    Next
                    If txtAiMinScale4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMinScale4.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100408000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    gMinScaleAi4 =   txtAiMinScale4.Text 
                            'Else
                            '  txtAiMinScale4.Text = gMinScaleAi4
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 08 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScaleAi4 = (y / 10)
                                    txtAiMinScale4.Text = gMinScaleAi4.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAiMinScale4.Text = gMinScaleAi4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMinScale4.Text = gMinScaleAi4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAiMinScale5_gotfocus(sender As Object, e As EventArgs) Handles txtAiMinScale5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMinScale5
    End Sub
    Private Sub txtAiMinScale5_TextChanged(sender As Object, e As EventArgs) Handles txtAiMinScale5.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMinScale5.TextLength
        Dim st As String = ""

        st = txtAiMinScale5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMinScale5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMinScale5.Text += ii(ht)
                    Next
                    If txtAiMinScale5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMinScale5.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100412000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    gMinScaleAi5 =   txtAiMinScale5.Text 
                            'Else
                            '  txtAiMinScale5.Text = gMinScaleAi5
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 12 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScaleAi5 = (y / 10)
                                    txtAiMinScale5.Text = gMinScaleAi5.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAiMinScale5.Text = gMinScaleAi5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMinScale5.Text = gMinScaleAi5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If
    End Sub
    Private Sub txtAiMinScale6_gotfocus(sender As Object, e As EventArgs) Handles txtAiMinScale6.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMinScale6
    End Sub
    Private Sub txtAiMinScale6_TextChanged(sender As Object, e As EventArgs) Handles txtAiMinScale6.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMinScale6.TextLength
        Dim st As String = ""

        st = txtAiMinScale6.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMinScale6.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMinScale6.Text += ii(ht)
                    Next
                    If txtAiMinScale6.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMinScale6.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210041C000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    gMinScaleAi6 =   txtAiMinScale6.Text 
                            'Else
                            '  txtAiMinScale6.Text = gMinScaleAi6
                            'End If
                            Threading.Thread.Sleep(500)
                            '' '/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 1C 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScaleAi6 = (y / 10)
                                    txtAiMinScale6.Text = gMinScaleAi6.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAiMinScale6.Text = gMinScaleAi6.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMinScale6.Text = gMinScaleAi6.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAiMinScale7_gotfocus(sender As Object, e As EventArgs) Handles txtAiMinScale7.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMinScale7
    End Sub
    Private Sub txtAiMinScale7_TextChanged(sender As Object, e As EventArgs) Handles txtAiMinScale7.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMinScale7.TextLength
        Dim st As String = ""

        st = txtAiMinScale7.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMinScale7.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMinScale7.Text += ii(ht)
                    Next
                    If txtAiMinScale7.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMinScale7.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100426000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    gMinScaleAi7 =   txtAiMinScale7.Text 
                            'Else
                            '  txtAiMinScale7.Text = gMinScaleAi7
                            'End If
                            Threading.Thread.Sleep(500)
                            '' '/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 26 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScaleAi7 = (y / 10)
                                    txtAiMinScale7.Text = gMinScaleAi7.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAiMinScale7.Text = gMinScaleAi7.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMinScale7.Text = gMinScaleAi7.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAiMinScale8_gotfocus(sender As Object, e As EventArgs) Handles txtAiMinScale8.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMinScale8
    End Sub
    Private Sub txtAiMinScale8_TextChanged(sender As Object, e As EventArgs) Handles txtAiMinScale8.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMinScale8.TextLength
        Dim st As String = ""

        st = txtAiMinScale8.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMinScale8.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMinScale8.Text += ii(ht)
                    Next
                    If txtAiMinScale8.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMinScale8.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100430000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    gMinScaleAi8 =   txtAiMinScale8.Text 
                            'Else
                            '  txtAiMinScale8.Text = gMinScaleAi8
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 30 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScaleAi8 = (y / 10)
                                    txtAiMinScale8.Text = gMinScaleAi8.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAiMinScale8.Text = gMinScaleAi8.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMinScale8.Text = gMinScaleAi8.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAiMaxScale1_gotfocus(sender As Object, e As EventArgs) Handles txtAiMaxScale1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMaxScale1
    End Sub
    Private Sub txtAiMaxScale1_TextChanged(sender As Object, e As EventArgs) Handles txtAiMaxScale1.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMaxScale1.TextLength
        Dim st As String = ""

        st = txtAiMaxScale1.Text
        Dim ii() As Char = st.ToCharArray
        ''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMaxScale1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMaxScale1.Text += ii(ht)
                    Next
                    If txtAiMaxScale1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMaxScale1.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021003EC000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 EC 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAi1 = (y / 10)
                                    txtAiMaxScale1.Text = gMaxScalleAi1.ToString()
                                End If
                            End If


                        End If
                    Else
                        txtAiMaxScale1.Text = gMaxScalleAi1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMaxScale1.Text = gMaxScalleAi1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAiMaxScale2_gotfocus(sender As Object, e As EventArgs) Handles txtAiMaxScale2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMaxScale2
    End Sub
    Private Sub txtAiMaxScale2_TextChanged(sender As Object, e As EventArgs) Handles txtAiMaxScale2.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMaxScale2.TextLength
        Dim st As String = ""

        st = txtAiMaxScale2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMaxScale2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMaxScale2.Text += ii(ht)
                    Next
                    If txtAiMaxScale2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMaxScale2.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021003F6000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 F6 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAi2 = (y / 10)
                                    txtAiMaxScale2.Text = gMaxScalleAi2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAiMaxScale2.Text = gMaxScalleAi2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMaxScale2.Text = gMaxScalleAi2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAiMaxScale3_gotfocus(sender As Object, e As EventArgs) Handles txtAiMaxScale3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMaxScale3
    End Sub
    Private Sub txtAiMaxScale3_TextChanged(sender As Object, e As EventArgs) Handles txtAiMaxScale3.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMaxScale3.TextLength
        Dim st As String = ""

        st = txtAiMaxScale3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMaxScale3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMaxScale3.Text += ii(ht)
                    Next
                    If txtAiMaxScale3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMaxScale3.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100400000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 00 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAi3 = (y / 10)
                                    txtAiMaxScale3.Text = gMaxScalleAi3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAiMaxScale3.Text = gMaxScalleAi3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMaxScale3.Text = gMaxScalleAi3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAiMaxScale4_gotfocus(sender As Object, e As EventArgs) Handles txtAiMaxScale4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMaxScale4
    End Sub
    Private Sub txtAiMaxScale4_TextChanged(sender As Object, e As EventArgs) Handles txtAiMaxScale4.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMaxScale4.TextLength
        Dim st As String = ""

        st = txtAiMaxScale4.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMaxScale4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMaxScale4.Text += ii(ht)
                    Next
                    If txtAiMaxScale4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMaxScale4.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210040A000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 0A 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAi4 = (y / 10)
                                    txtAiMaxScale4.Text = gMaxScalleAi4.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAiMaxScale4.Text = gMaxScalleAi4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMaxScale4.Text = gMaxScalleAi4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAiMaxScale5_gotfocus(sender As Object, e As EventArgs) Handles txtAiMaxScale5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMaxScale5
    End Sub
    Private Sub txtAiMaxScale5_TextChanged(sender As Object, e As EventArgs) Handles txtAiMaxScale5.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMaxScale5.TextLength
        Dim st As String = ""

        st = txtAiMaxScale5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMaxScale5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMaxScale5.Text += ii(ht)
                    Next
                    If txtAiMaxScale5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMaxScale5.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100414000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 14 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAi5 = (y / 10)
                                    txtAiMaxScale5.Text = gMaxScalleAi5.ToString()
                                End If
                            End If
                        End If
                    Else
                        txtAiMaxScale5.Text = gMaxScalleAi5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMaxScale5.Text = gMaxScalleAi5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAiMaxScale6_gotfocus(sender As Object, e As EventArgs) Handles txtAiMaxScale6.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMaxScale6
    End Sub
    Private Sub txtAiMaxScale6_TextChanged(sender As Object, e As EventArgs) Handles txtAiMaxScale6.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMaxScale6.TextLength
        Dim st As String = ""

        st = txtAiMaxScale6.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMaxScale6.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMaxScale6.Text += ii(ht)
                    Next
                    If txtAiMaxScale6.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMaxScale6.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210041E000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 1E 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAi6 = (y / 10)
                                    txtAiMaxScale6.Text = gMaxScalleAi6.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAiMaxScale6.Text = gMaxScalleAi6.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMaxScale6.Text = gMaxScalleAi6.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAiMaxScale7_gotfocus(sender As Object, e As EventArgs) Handles txtAiMaxScale7.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMaxScale7
    End Sub
    Private Sub txtAiMaxScale7_TextChanged(sender As Object, e As EventArgs) Handles txtAiMaxScale7.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMaxScale7.TextLength
        Dim st As String = ""

        st = txtAiMaxScale7.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMaxScale7.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMaxScale7.Text += ii(ht)
                    Next
                    If txtAiMaxScale7.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMaxScale7.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100428000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 28 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAi7 = (y / 10)
                                    txtAiMaxScale7.Text = gMaxScalleAi7.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAiMaxScale7.Text = gMaxScalleAi7.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMaxScale7.Text = gMaxScalleAi7.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAiMaxScale8_gotfocus(sender As Object, e As EventArgs) Handles txtAiMaxScale8.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAiMaxScale8
    End Sub
    Private Sub txtAiMaxScale8_TextChanged(sender As Object, e As EventArgs) Handles txtAiMaxScale8.TextChanged
        Dim arr As Integer = 0
        arr = txtAiMaxScale8.TextLength
        Dim st As String = ""

        st = txtAiMaxScale8.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAiMaxScale8.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAiMaxScale8.Text += ii(ht)
                    Next
                    If txtAiMaxScale8.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAiMaxScale8.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100432000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 32 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAi8 = (y / 10)
                                    txtAiMaxScale8.Text = gMaxScalleAi8.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAiMaxScale8.Text = gMaxScalleAi8.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAiMaxScale8.Text = gMaxScalleAi8.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMinScale1_gotfocus(sender As Object, e As EventArgs) Handles txtAOMinScale1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMinScale1
    End Sub
    Private Sub txtAOMinScale1_TextChanged(sender As Object, e As EventArgs) Handles txtAOMinScale1.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMinScale1.TextLength
        Dim st As String = ""

        st = txtAOMinScale1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMinScale1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMinScale1.Text += ii(ht)
                    Next
                    If txtAOMinScale1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMinScale1.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210044E000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 4E 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScalleAo1 = (y / 10)
                                    txtAOMinScale1.Text = gMinScalleAo1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMinScale1.Text = gMinScalleAo1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMinScale1.Text = gMinScalleAo1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMinScale2_gotfocus(sender As Object, e As EventArgs) Handles txtAOMinScale2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMinScale2
    End Sub
    Private Sub txtAOMinScale2_TextChanged(sender As Object, e As EventArgs) Handles txtAOMinScale2.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMinScale2.TextLength
        Dim st As String = ""

        st = txtAOMinScale2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMinScale2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMinScale2.Text += ii(ht)
                    Next
                    If txtAOMinScale2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMinScale2.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100458000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 58 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScalleAo2 = (y / 10)
                                    txtAOMinScale2.Text = gMinScalleAo2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMinScale2.Text = gMinScalleAo2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMinScale2.Text = gMinScalleAo2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMinScale3_gotfocus(sender As Object, e As EventArgs) Handles txtAOMinScale3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMinScale3
    End Sub
    Private Sub txtAOMinScale3_TextChanged(sender As Object, e As EventArgs) Handles txtAOMinScale3.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMinScale3.TextLength
        Dim st As String = ""

        st = txtAOMinScale3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMinScale3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMinScale3.Text += ii(ht)
                    Next
                    If txtAOMinScale3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMinScale3.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100462000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 62 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScalleAo3 = (y / 10)
                                    txtAOMinScale3.Text = gMinScalleAo3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMinScale3.Text = gMinScalleAo3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMinScale3.Text = gMinScalleAo3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMinScale4_gotfocus(sender As Object, e As EventArgs) Handles txtAOMinScale4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMinScale4
    End Sub
    Private Sub txtAOMinScale4_TextChanged(sender As Object, e As EventArgs) Handles txtAOMinScale4.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMinScale4.TextLength
        Dim st As String = ""

        st = txtAOMinScale4.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMinScale4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMinScale4.Text += ii(ht)
                    Next
                    If txtAOMinScale4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMinScale4.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210046C000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 6C 00", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScalleAo4 = (y / 10)
                                    txtAOMinScale4.Text = gMinScalleAo4.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMinScale4.Text = gMinScalleAo4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMinScale4.Text = gMinScalleAo4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMinScale5_gotfocus(sender As Object, e As EventArgs) Handles txtAOMinScale5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMinScale5
    End Sub
    Private Sub txtAOMinScale5_TextChanged(sender As Object, e As EventArgs) Handles txtAOMinScale5.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMinScale5.TextLength
        Dim st As String = ""

        st = txtAOMinScale5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMinScale5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMinScale5.Text += ii(ht)
                    Next
                    If txtAOMinScale5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMinScale5.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100476000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length = 24 Then
                            '   gMinScalleAo5  =  txtAOMinScale5.Text
                            'Else
                            '    txtAOMinScale5.Text = gMinScalleAo5                            '    
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 76 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScalleAo5 = (y / 10)
                                    txtAOMinScale5.Text = gMinScalleAo5.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMinScale5.Text = gMinScalleAo5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMinScale5.Text = gMinScalleAo5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMinScale6_gotfocus(sender As Object, e As EventArgs) Handles txtAOMinScale6.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMinScale6
    End Sub
    Private Sub txtAOMinScale6_TextChanged(sender As Object, e As EventArgs) Handles txtAOMinScale6.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMinScale6.TextLength
        Dim st As String = ""

        st = txtAOMinScale6.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMinScale6.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMinScale6.Text += ii(ht)
                    Next
                    If txtAOMinScale6.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMinScale6.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100480000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 80 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScalleAo6 = (y / 10)
                                    txtAOMinScale6.Text = gMinScalleAo6.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMinScale6.Text = gMinScalleAo6.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMinScale6.Text = gMinScalleAo6.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMinScale7_gotfocus(sender As Object, e As EventArgs) Handles txtAOMinScale7.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMinScale7
    End Sub
    Private Sub txtAOMinScale7_TextChanged(sender As Object, e As EventArgs) Handles txtAOMinScale7.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMinScale7.TextLength
        Dim st As String = ""

        st = txtAOMinScale7.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMinScale7.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMinScale7.Text += ii(ht)
                    Next
                    If txtAOMinScale7.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMinScale7.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210048A000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 8A 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScalleAo7 = (y / 10)
                                    txtAOMinScale7.Text = gMinScalleAo7.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMinScale7.Text = gMinScalleAo7.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMinScale7.Text = gMinScalleAo7.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMinScale8_gotfocus(sender As Object, e As EventArgs) Handles txtAOMinScale8.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMinScale8
    End Sub
    Private Sub txtAOMinScale8_TextChanged(sender As Object, e As EventArgs) Handles txtAOMinScale8.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMinScale8.TextLength
        Dim st As String = ""

        st = txtAOMinScale8.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMinScale8.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMinScale8.Text += ii(ht)
                    Next
                    If txtAOMinScale8.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMinScale8.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100494000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 94 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMinScalleAo8 = (y / 10)
                                    txtAOMinScale8.Text = gMinScalleAo8.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMinScale8.Text = gMinScalleAo8.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMinScale8.Text = gMinScalleAo8.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMaxScale1_gotfocus(sender As Object, e As EventArgs) Handles txtAOMaxScale1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMaxScale1
    End Sub
    Private Sub txtAOMaxScale1_TextChanged(sender As Object, e As EventArgs) Handles txtAOMaxScale1.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMaxScale1.TextLength
        Dim st As String = ""

        st = txtAOMaxScale1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMaxScale1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMaxScale1.Text += ii(ht)
                    Next
                    If txtAOMaxScale1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMaxScale1.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100450000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 50 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAo1 = (y / 10)
                                    txtAOMaxScale1.Text = gMaxScalleAo1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMaxScale1.Text = gMaxScalleAo1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMaxScale1.Text = gMaxScalleAo1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMaxScale2_gotfocus(sender As Object, e As EventArgs) Handles txtAOMaxScale2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMaxScale2
    End Sub
    Private Sub txtAOMaxScale2_TextChanged(sender As Object, e As EventArgs) Handles txtAOMaxScale2.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMaxScale2.TextLength
        Dim st As String = ""

        st = txtAOMaxScale2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMaxScale2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMaxScale2.Text += ii(ht)
                    Next
                    If txtAOMaxScale2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMaxScale2.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210045A000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 5A 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAo2 = (y / 10)
                                    txtAOMaxScale2.Text = gMaxScalleAo2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMaxScale2.Text = gMaxScalleAo2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMaxScale2.Text = gMaxScalleAo2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMaxScale3_gotfocus(sender As Object, e As EventArgs) Handles txtAOMaxScale3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMaxScale3
    End Sub
    Private Sub txtAOMaxScale3_TextChanged(sender As Object, e As EventArgs) Handles txtAOMaxScale3.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMaxScale3.TextLength
        Dim st As String = ""

        st = txtAOMaxScale3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMaxScale3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMaxScale3.Text += ii(ht)
                    Next
                    If txtAOMaxScale3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMaxScale3.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100464000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 64 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAo3 = (y / 10)
                                    txtAOMaxScale3.Text = gMaxScalleAo3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMaxScale3.Text = gMaxScalleAo3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMaxScale3.Text = gMaxScalleAo3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMaxScale4_gotfocus(sender As Object, e As EventArgs) Handles txtAOMaxScale4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMaxScale4
    End Sub
    Private Sub txtAOMaxScale4_TextChanged(sender As Object, e As EventArgs) Handles txtAOMaxScale4.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMaxScale4.TextLength
        Dim st As String = ""

        st = txtAOMaxScale4.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMaxScale4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMaxScale4.Text += ii(ht)
                    Next
                    If txtAOMaxScale4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMaxScale4.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210046E000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 6E 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAo4 = (y / 10)
                                    txtAOMaxScale4.Text = gMaxScalleAo4.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMaxScale4.Text = gMaxScalleAo4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMaxScale4.Text = gMaxScalleAo4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMaxScale5_gotfocus(sender As Object, e As EventArgs) Handles txtAOMaxScale5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMaxScale5
    End Sub
    Private Sub txtAOMaxScale5_TextChanged(sender As Object, e As EventArgs) Handles txtAOMaxScale5.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMaxScale5.TextLength
        Dim st As String = ""

        st = txtAOMaxScale5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMaxScale5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMaxScale5.Text += ii(ht)
                    Next
                    If txtAOMaxScale5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMaxScale5.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100478000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 78 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAo5 = (y / 10)
                                    txtAOMaxScale5.Text = gMaxScalleAo5.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMaxScale5.Text = gMaxScalleAo5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMaxScale5.Text = gMaxScalleAo5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMaxScale6_gotfocus(sender As Object, e As EventArgs) Handles txtAOMaxScale6.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMaxScale6
    End Sub
    Private Sub txtAOMaxScale6_TextChanged(sender As Object, e As EventArgs) Handles txtAOMaxScale6.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMaxScale6.TextLength
        Dim st As String = ""

        st = txtAOMaxScale6.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMaxScale6.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMaxScale6.Text += ii(ht)
                    Next
                    If txtAOMaxScale6.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMaxScale6.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100482000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 82 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAo6 = (y / 10)
                                    txtAOMaxScale6.Text = gMaxScalleAo6.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMaxScale6.Text = gMaxScalleAo6.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMaxScale6.Text = gMaxScalleAo6.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMaxScale7_gotfocus(sender As Object, e As EventArgs) Handles txtAOMaxScale7.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMaxScale7
    End Sub
    Private Sub txtAOMaxScale7_TextChanged(sender As Object, e As EventArgs) Handles txtAOMaxScale7.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMaxScale7.TextLength
        Dim st As String = ""

        st = txtAOMaxScale7.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMaxScale7.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMaxScale7.Text += ii(ht)
                    Next
                    If txtAOMaxScale7.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMaxScale7.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210048C000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 8C 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAo7 = (y / 10)
                                    txtAOMaxScale7.Text = gMaxScalleAo7.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMaxScale7.Text = gMaxScalleAo7.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMaxScale7.Text = gMaxScalleAo7.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAOMaxScale8_gotfocus(sender As Object, e As EventArgs) Handles txtAOMaxScale8.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAOMaxScale8
    End Sub
    Private Sub txtAOMaxScale8_TextChanged(sender As Object, e As EventArgs) Handles txtAOMaxScale8.TextChanged
        Dim arr As Integer = 0
        arr = txtAOMaxScale8.TextLength
        Dim st As String = ""

        st = txtAOMaxScale8.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAOMaxScale8.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAOMaxScale8.Text += ii(ht)
                    Next
                    If txtAOMaxScale8.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAOMaxScale8.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100496000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 04 96 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gMaxScalleAo8 = (y / 10)
                                    txtAOMaxScale8.Text = gMaxScalleAo8.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAOMaxScale8.Text = gMaxScalleAo8.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAOMaxScale8.Text = gMaxScalleAo8.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Analogread2()
        Timer2.Enabled = False
    End Sub

    Private Sub Label22_Click(sender As Object, e As EventArgs) Handles Label22.Click

    End Sub
End Class