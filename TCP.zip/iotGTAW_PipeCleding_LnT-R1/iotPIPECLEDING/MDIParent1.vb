﻿Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports System.Data.OleDb
Imports System.Data
Imports System.Threading
Public Class MDIParent1
    Private m_ChildFormNumber As Integer
    Dim proc As Process
    Dim tx As String = ""
    Dim rx As String = ""
    Dim objThread1 As CallBackThread

    Dim paraArray() As String = getRatio("P2AI1")   'ESSC Voltage
    Dim paraArray1() As String = getRatio("P2AI2")  'ESSC Current
    Dim paraArray2() As String = getRatio("P2AI3")  'SMAW Current
    Dim paraArray3() As String = getRatio("P2AI4")  'SMAW Current

    Dim paraArray4() As String = getRatio("P3AI1")  'Flux Temp
    Dim paraArray5() As String = getRatio("P3AI2")  'Flux Weight
    Dim paraArray6() As String = getRatio("P3AI4")  'Depth
    Dim paraArray7() As String = getRatio("P3AI5")  'Job Temp
    Dim paraArray8() As String = getRatio("MCLEFT")  'MCLEFT
    Dim paraArray9() As String = getRatio("MCRIGHT")  'MCRIGHT

    Dim tejas As Integer = 0
    Dim green As Color = Color.LightGreen
    Dim colorarr() As Color = {Color.Silver, Color.Green}


    Private Sub COMSTART()
        Try
            'Dim dr As OleDbDataReader
            'dr = objCon.ExecuteDataReader("select * from device ", CommandType.Text)

            'While dr.Read
            '    gComTX = dr("comportTX")
            '    gComRX = dr("comportRX")
            '    gSpeed = dr("speed")
            '    gParaPass = dr("parapass")
            'End While

            Using objCon As New dbClass
                Using dt As DataTable = objCon.ExecuteDataTable("select * from device ", CommandType.Text)
                    For Each row As DataRow In dt.Rows
                        gComTX = row("comporttx")
                        gComRX = row("comportRX")
                        gSpeed = row("speed")
                        gParaPass = row("parapass")
                        gMachineIP = row("machineIP")
                    Next
                End Using
            End Using

            miComPort = CInt(gComTX)
            miComPortRX = CInt(gComRX)
            lblStatus.Text = miComPort
            lblStatusRX.Text = miComPortRX
            txtBaudrate = gSpeed

            'Dim x As Integer = 0

            If isComOpen Then
                lblStatus.BackColor = Color.Green
            Else
                miComPort = CInt(gComTX)
                txtBaudrate = gSpeed
                comOpen()
                If isComOpen Then
                    lblStatus.BackColor = Color.Green
                Else
                    lblStatus.BackColor = Color.Red
                End If
            End If
            If isComOpenRX Then
                lblStatusRX.BackColor = Color.Green
            Else
                miComPortRX = CInt(gComRX)
                txtBaudrate = gSpeed
                comOpenRX()
                If isComOpenRX Then
                    lblStatusRX.BackColor = Color.Green
                Else
                    lblStatusRX.BackColor = Color.Red
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error in COMSTART method of MDIParent module, Error : " + ex.Message.ToString())
        End Try

    End Sub
    Private Sub MDIParent1_Activated(sender As Object, e As System.EventArgs) Handles MyBase.Activated
        Me.WindowState = FormWindowState.Maximized
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        Me.ControlBox = False
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.ShowIcon = False
        Me.Text = ""
        Me.Dock = DockStyle.Fill


        If gLogin = True Then
            btnConsum.Enabled = True
            btnWPS.Enabled = True
            btnWNote.Enabled = True
            btnBatch.Enabled = True
        Else
            btnConsum.Enabled = False
            btnWPS.Enabled = False
            btnWNote.Enabled = False
            btnBatch.Enabled = False
        End If

        BtnAux.Enabled = True
        btnMentry.Enabled = True
        btnDiag.Enabled = True
    End Sub

    Private Sub MDIParent1_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If gLogin = False Then
            If objThread1 IsNot Nothing Then objThread1.Dispose()

            If isComOpen Then
                closeCom()
            End If
            If isComOpenRX Then
                closeComRX()
            End If
            'closeLog()
            End
        Else
            Dim result As String = MessageBoxEx.Show("Kindly Log Off before closing application.", "Application Close", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
            'MessageBox.Show("Kindly logout before closing application.")
            e.Cancel = True
        End If
    End Sub
    Private Sub MDIParent1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        'Restricting application to be opened twice
        Dim count As Integer = 0
        For Each p As Process In Process.GetProcessesByName("iotPIPECLEDING")
            count = count + 1
        Next

        If count > 1 Then
            MessageBox.Show("Application is already open.")
            End
        End If

        Me.WindowState = FormWindowState.Maximized
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        Me.ControlBox = False
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.ShowIcon = False
        Me.Text = ""
        Me.Dock = DockStyle.Fill

        'MessageBox.Show(Format(Now(), "yyyy-MM-dd HH:mm:ss.ffff"))

        'openLog()
        getPara()
        COMSTART()
        TcpConnection()
        'plcctrlon()
        ' resetCtrl()


        gWeldingStart = False
        gLocalDataSync = False

        'Timer1.Enabled = True
        lblTime.Text = Format(Now, "dd-MM-yyyy HH:mm:ss")

        'Checking Network Connectivity
        Using myservice As New SQLDB()
            If myservice.checkNetworkConnectivity() Then
                lblNetworkConnectivity.BackColor = Color.Green
            Else
                lblNetworkConnectivity.BackColor = Color.Red
            End If
        End Using

        objSC1.WindowState = FormWindowState.Maximized
        objSC1.TopLevel = True
        objSC1.Dock = DockStyle.Fill
        objSC1.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        objSC1.ControlBox = False
        objSC1.MaximizeBox = False
        objSC1.MinimizeBox = False
        objSC1.ShowIcon = False
        objSC1.Icon = Nothing
        objSC1.MdiParent = Me
        objSC1.Show()

        'If isConnection = True Then
        '    'HEAD A OFF STRING
        '    tx = ""
        '    rx = ""
        '    tx = "02 05 00 D8 00 00 4D C2"
        '    rx = txComA(tx, 10)
        '    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)

        '    objSC1.btnWELDA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldoff
        '    objSC1.Refresh()
        '    objSC1.btnWELDA.Tag = 0

        '    'HEAD B OFF STRING
        '    tx = ""
        '    rx = ""
        '    tx = "02 05 00 E2 00 00 6D CF"
        '    rx = txComA(tx, 10)
        '    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
        '    objSC1.btnWELDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldoff
        '    objSC1.Refresh()
        '    objSC1.btnWELDB.Tag = 0

        'End If

        'Dim x As String = ComputeCrc("16 03 00 00 00 08")
        'Constructing Thread 1
        objThread1 = New CallBackThread(Me, AddressOf ThreadMethod1, AddressOf CallBackMethod1)
        ''Starting Thread 1
        objThread1.Start()

        tParalog.Interval = gParaLogInt * 1000
        tParalog.Enabled = True
        '' tParalog.Start()

        btnJobData.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        btnMain.Image = Global.iotPIPECLEDING.My.Resources.btngreen
    End Sub
    ''Check for nirav sir 
    Private Sub tParalog_Tick(sender As System.Object, e As System.EventArgs) Handles tParalog.Tick
        Try
            If gLogin Then
                objSC1.lblLocalDataPushStatus.Text = "Data Logging"
                objSC1.lblLocalDataPushStatus.Visible = True
                objSC1.Refresh()

                Dim logcur As Double = 0.0
                Dim logvolt As Double = 0.0
                Dim logcur2 As Double = 0.0
                Dim logvolt2 As Double = 0.0

                logcur = gGTAWCurr
                logvolt = gGTAWVol
                logcur2 = gGTAWCurr2
                logvolt2 = gGTAWVol2

                If gGTAWCurr > gWCMax Or gGTAWCurr < gWCMin Then
                    SaveAbnLog(1, gGTAWCurr, gWCMin, gWCMax)
                End If

                If gGTAWVol > gWVMax Or gGTAWVol < gWVMin Then
                    SaveAbnLog(2, gGTAWVol, gWVMin, gWVMax)
                End If

                '' If TRCON = True Then
                If gGTAWTravelSpeed > gGTAWTRSMax Or gWeldingSpeed < gGTAWTRSMin Then
                    SaveAbnLog(3, gWeldingSpeed, gGTAWTRSMin, gGTAWTRSMax)
                End If
                '' End If

                If gGTAWjobtemp > gJTMax Or gGTAWjobtemp < gJTMin Then
                    SaveAbnLog(4, gGTAWjobtemp, gJTMin, gJTMax)
                End If

                If gGTAWgasflow > gGFMax Or gGTAWgasflow < gGFMin Then
                    SaveAbnLog(5, gGTAWgasflow, gGFMin, gGFMax)
                End If

                If gGTAWwirefeed > gWFmax Or gGTAWwirefeed < gWFmin Then
                    SaveAbnLog(6, gGTAWwirefeed, gWFmin, gWFmax)
                End If

                SaveParaLog(logcur, logcur2, logvolt, logvolt2, gGTAWTravelSpeed, gconsItem,
                                   gConsBatch, gFluxItem, gFluxBatch, gGTAWjobtemp,
                                  gGTAWgasflow, gGTAWgasflow2, gGTAWwirefeed, gGTAWwirefeed2, gSportNo, gGrind, gGrindFillupvalue, gdepth)

                objSC1.lblLocalDataPushStatus.Text = ""
                objSC1.lblLocalDataPushStatus.Visible = False
                objSC1.Refresh()

            End If

            objSC1.lblLocalDataCount.Text = LocalDataCount().ToString()

            SaveLocalDataCountLog(Convert.ToDouble(objSC1.lblLocalDataCount.Text), objSC1.lblLastBuildDate.Text)

            'Upload local data in Auto
            'Logic - When welding is off
            'Timings - At two lunch breaks (11:00 AM to 11:30 AM, 07:30 PM to 08:00 PM)
            Dim format As String = "yyyy-MM-dd HH:mm:ss"

            If IOTDBConnectivity Then
                If Convert.ToDouble(objSC1.lblLocalDataCount.Text) > 0 Then
                    If gWeldingStart = False Then
                        If DateTime.Parse(DateTime.Now).Ticks >= DateTime.Parse(DateTime.Now.ToString(format).Substring(0, 10) & " 06:30:00").Ticks AndAlso DateTime.Parse(DateTime.Now).Ticks < DateTime.Parse(DateTime.Now.ToString(format).Substring(0, 10) & " 07:00:00").Ticks Then
                            objSC1.lblLocalDataPushStatus.Text = "Local data is being pushed onto server, Please wait for some time."
                            objSC1.lblLocalDataPushStatus.Visible = True
                            objSC1.Refresh()
                            objSC1.pBar.Visible = True
                            DataSync(objSC1.pBar, 1) '1 is Auto
                            objSC1.pBar.Visible = False
                            objSC1.lblLocalDataPushStatus.Text = ""
                            objSC1.lblLocalDataPushStatus.Visible = False
                            objSC1.Refresh()
                        ElseIf DateTime.Parse(DateTime.Now).Ticks >= DateTime.Parse(DateTime.Now.ToString(format).Substring(0, 10) & " 11:00:00").Ticks AndAlso DateTime.Parse(DateTime.Now).Ticks < DateTime.Parse(DateTime.Now.ToString(format).Substring(0, 10) & " 11:30:00").Ticks Then
                            objSC1.lblLocalDataPushStatus.Text = "Local data is being pushed onto server, Please wait for some time."
                            objSC1.lblLocalDataPushStatus.Visible = True
                            objSC1.Refresh()
                            objSC1.pBar.Visible = True
                            DataSync(objSC1.pBar, 1) '1 is Auto
                            objSC1.pBar.Visible = False
                            objSC1.lblLocalDataPushStatus.Text = ""
                            objSC1.lblLocalDataPushStatus.Visible = False
                            objSC1.Refresh()
                        ElseIf DateTime.Parse(DateTime.Now).Ticks >= DateTime.Parse(DateTime.Now.ToString(format).Substring(0, 10) & " 19:30:00").Ticks AndAlso DateTime.Parse(DateTime.Now).Ticks < DateTime.Parse(DateTime.Now.ToString(format).Substring(0, 10) & " 08:00:00").Ticks Then
                            objSC1.lblLocalDataPushStatus.Text = "Local data is being pushed onto server, Please wait for some time."
                            objSC1.lblLocalDataPushStatus.Visible = True
                            objSC1.Refresh()
                            objSC1.pBar.Visible = True
                            DataSync(objSC1.pBar, 1) '1 is Auto
                            objSC1.pBar.Visible = False
                            objSC1.lblLocalDataPushStatus.Text = ""
                            objSC1.lblLocalDataPushStatus.Visible = False
                            objSC1.Refresh()
                        End If
                    End If
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Data logging error : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub ThreadMethod1()
        'P2AI1 - ESSC VOLT
        'P2AI2 - ESSC CUR
        'P2AI3 - SMAW VOLT
        'P2AI4 - SMAW CUR
        'P1AI1 - SUFACE
        'P1AI2 - DRIFT
        'PIAO1 -SPEED
        'P3AI1 - FLUX TEMP
        'P3AI2 - FLUX WEIGHT
        'P3AI3 - FRU WEIGHT
        'P3AI4 - DEPTH
        'P3AI5 - JOB TEMP
        Try
            Dim y As Double = 0.0

            Dim y1 As Double = 0.0
            'Dim ESSCcurrent As Double = 0
            'Dim ESSCvoltage As Double = 0 '' 230 + Math.Round(20 * Rnd(), 3)
            'Dim SMAWcurrent As Double = 0
            'Dim SMAWvoltage As Double = 0 '' 230 + Math.Round(20 * Rnd(), 3)
            Dim Auxinstrg As String = ""
            Dim TRSinstrg As String = ""
            Dim Driftinstrg As String = ""
            Dim plcinstrg As String = ""
            Dim fruwght As Double = 0
            Dim depth As Double = 0.0

            Dim P1 As String = "0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0"
            Dim P2 As String = "0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0"
            Dim p3 As String = "0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0"
            Dim p4 As String = "0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0"
            Dim p5 As String = "0:0:0:0:0:0:0:0:0:0:0:0:0:0:0"
            Dim p6 As String = "0:0:0:0:0:0:0:0:0:0:0:0:0:0:0"
            Dim p7 As String = "0:0:0:0:0:0:0:0:0:0"

            Dim p8 As String = "0:0:0:0:0"
            Dim p9 As String = "0:0:0:0:0:0:0:0:0:0"
            tcpClient.ReceiveTimeout = 5000
            tcpClient.SendTimeout = 3000
            Do While 1
                Try

                    If isConnection = True Then

                        'Tcp Programm
                        ' Do a simple write.


                        ''''''''''''''''''''  FAULT STATUS DISPLAY   ''''''''''''''''''''''''''''''''''''''

                        plcinstrg = ""
                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 01 00 64 00 0F", 80)
                        Dim x5() As String = plcinstrg.Split(" "c)
                        If x5.Count >= 4 Then
                            If x5(6) = "03" And x5(7) = "01" Then

                                Dim bin As String = ReverseString(Hex2Bin(x5(10) & x5(9)))
                                Dim digits5() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                                p5 = digits5(0) & ":" & digits5(1) & ":" & digits5(2) & ":" & digits5(3) & ":" & digits5(4) & ":" & digits5(5) & ":" & digits5(6) & ":" & digits5(7) & ":" & digits5(8) & ":" & digits5(9) & ":" & digits5(10) & ":" & digits5(11) & ":" & digits5(12) & ":" & digits5(13) & ":" & digits5(14)
                                tejas = 5
                            End If
                        End If

                        plcinstrg = ""
                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 01 00 73 00 0F", 80)
                        Dim x6() As String = plcinstrg.Split(" "c)
                        If x6.Count >= 4 Then
                            If x6(6) = "03" And x6(7) = "01" Then

                                Dim bin As String = ReverseString(Hex2Bin(x6(10) & x6(9)))
                                Dim digits6() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                                p6 = digits6(0) & ":" & digits6(1) & ":" & digits6(2) & ":" & digits6(3) & ":" & digits6(4) & ":" & digits6(5) & ":" & digits6(6) & ":" & digits6(7) & ":" & digits6(8) & ":" & digits6(9) & ":" & digits6(10) & ":" & digits6(11) & ":" & digits6(12) & ":" & digits6(13) & ":" & digits6(14)
                                tejas = 6
                            End If
                        End If

                        '' MsgBox(BigEndianHexToSingle("436A3333").ToString())


                        '' MessageBox.Show("data= " + data.ToString())

                        '/////////////////////////////////////  ALARMS /LIMITS-DISPLAY  ///////////////////////////////////////////////// 

                        plcinstrg = ""
                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 01 00 14 00 0A", 50)
                        Dim x7() As String = plcinstrg.Split(" "c)
                        If x7.Count >= 4 Then
                            If x7(6) = "03" And x7(7) = "01" Then

                                Dim bin As String = ReverseString(Hex2Bin(x7(10) & x7(9)))
                                Dim digits7() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                                p7 = digits7(0) & ":" & digits7(1) & ":" & digits7(2) & ":" & digits7(3) & ":" & digits7(4) & ":" & digits7(5) & ":" & digits7(6) & ":" & digits7(7) & ":" & digits7(8) & ":" & digits7(9)
                                tejas = 7
                            End If
                        End If

                        ''//////////////////////   Main Screen /////////////////////////////
                        ''///////////////////////////   Read Current  //////////////////////
                        ''///////////////////////////   AI1  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""
                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 03 E8 00 02", 50)
                        'Dim x12() As String = plcinstrg.Split(" "c)
                        'If x12.Count >= 8 Then
                        '    If x12(6) = "03" And x12(7) = "03" Then
                        '        y = Convert.ToInt32(x12(11) & x12(12) & x12(9) & x12(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gGTAWCurr = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 13
                        '    End If
                        'End If

                        ''///////////////////////////   AI2  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 03 F2 00 02", 50)
                        'Dim x13() As String = plcinstrg.Split(" "c)
                        'If x13.Count >= 4 Then
                        '    If x13(6) = "03" And x13(7) = "03" Then
                        '        y = Convert.ToInt32(x13(11) & x13(12) & x13(9) & x13(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gGTAWVol = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 14
                        '    End If
                        'End If


                        ''///////////////////////////   AI3  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 03 FC 00 02", 50)
                        'Dim x14() As String = plcinstrg.Split(" "c)
                        'If x14.Count >= 4 Then
                        '    If x14(6) = "03" And x14(7) = "03" Then
                        '        y = Convert.ToInt32(x14(11) & x14(12) & x14(9) & x14(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gGTAWCurr2 = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 15
                        '    End If
                        'End If

                        ''///////////////////////////   AI4  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 04 06 00 02", 50)
                        'Dim x15() As String = plcinstrg.Split(" "c)
                        'If x15.Count >= 4 Then
                        '    If x15(6) = "03" And x15(7) = "03" Then
                        '        y = Convert.ToInt32(x15(11) & x15(12) & x15(9) & x15(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gGTAWVol2 = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 16
                        '    End If
                        'End If



                        '''///////////////////////////   AI5  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 04 10 00 02", 50)
                        'Dim x16() As String = plcinstrg.Split(" "c)
                        'If x16.Count >= 4 Then
                        '    If x16(6) = "03" And x16(7) = "03" Then
                        '        y = Convert.ToInt32(x16(11) & x16(12) & x16(9) & x16(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gGTAWgasflow = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 17
                        '    End If
                        'End If

                        '''///////////////////////////   AI6  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 04 1A 00 02", 50)
                        'Dim x17() As String = plcinstrg.Split(" "c)
                        'If x17.Count >= 4 Then
                        '    If x17(6) = "03" And x17(7) = "03" Then
                        '        y = Convert.ToInt32(x17(11) & x17(12) & x17(9) & x17(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gGTAWgasflow2 = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 18
                        '    End If
                        'End If

                        '''///////////////////////////   AI7  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 04 24 00 02", 50)
                        'Dim x18() As String = plcinstrg.Split(" "c)
                        'If x18.Count >= 4 Then
                        '    If x18(6) = "03" And x18(7) = "03" Then
                        '        y = Convert.ToInt32(x18(11) & x18(12) & x18(9) & x18(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gGTAWjobtemp = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 19
                        '    End If
                        'End If

                        ''///////////////////////////   AI8  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 04 2E 00 02", 50)
                        'Dim x19() As String = plcinstrg.Split(" "c)
                        'If x19.Count >= 4 Then
                        '    If x19(6) = "03" And x19(7) = "03" Then
                        '        y = Convert.ToInt32(x19(11) & x19(12) & x19(9) & x19(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gAi8 = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 20
                        '    End If
                        'End If

                        ''///////////////////////////   TRAVEL SPEED  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 01 D6 00 02", 50)
                        'Dim x42() As String = plcinstrg.Split(" "c)
                        'If x42.Count >= 4 Then
                        '    If x42(6) = "03" And x42(7) = "03" Then
                        '        y = Convert.ToInt32(x42(11) & x42(12) & x42(9) & x42(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gGTAWTravelSpeed = (y / 100)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 40
                        '    End If
                        'End If
                        ''///////////////   WireFeed Read 1 /////////////////// 
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""
                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 01 E4 00 02", 50)
                        'Dim x40() As String = plcinstrg.Split(" "c)
                        'If x40.Count >= 4 Then
                        '    If x40(6) = "03" And x40(7) = "03" Then
                        '        y = Convert.ToInt32(x40(11) & x40(12) & x40(9) & x40(10), 16)
                        '        gGTAWwirefeed = (y / 10)

                        '    End If
                        'End If

                        ''///////////////   WireFeed Read 2 /////////////////// 
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""
                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 01 EE 00 02", 50)
                        'Dim x41() As String = plcinstrg.Split(" "c)
                        'If x41.Count >= 4 Then
                        '    If x41(6) = "03" And x41(7) = "03" Then
                        '        y = Convert.ToInt32(x41(11) & x41(12) & x41(9) & x41(10), 16)
                        '        gGTAWwirefeed2 = (y / 10)

                        '    End If
                        'End If
                        '/////////////////////////////////////  PROCESS MONITORING BITS  ///////////////////////////////////////////////// 

                        plcinstrg = ""
                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 01 00 33 00 05", 50)
                        Dim x8() As String = plcinstrg.Split(" "c)
                        If x8.Count >= 4 Then
                            If x8(6) = "03" And x8(7) = "01" Then

                                Dim bin As String = ReverseString(Hex2Bin(x8(10) & x8(9)))
                                Dim digits8() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                                p8 = digits8(0) & ":" & digits8(1) & ":" & digits8(2) & ":" & digits8(3) & ":" & digits8(4)
                                tejas = 8

                                If digits8(0) = 1 Then
                                    If pmb1tag = 0 Then
                                        pmb1tag = 1
                                        gWeldingStart = True

                                        objSC1.lblpmb1.Image = Global.iotPIPECLEDING.My.Resources.pmb1
                                        objcontrols.lblpmb1.Image = Global.iotPIPECLEDING.My.Resources.pmb1S

                                        ''////// Disable button
                                        objSC1.btntag1.Enabled = False
                                        objSC1.btntag2.Enabled = False
                                        objSC1.btndryweldrun.Enabled = False
                                        objJobData.btnNozzPipeIDOL.Enabled = False
                                        'objJobData.btnFlangeOL.Enabled = False
                                        ' objJobData.btnBackfaceOL.Enabled = False
                                        'objJobData.btnBeadShiFWDREW.Enabled = False
                                        'objJobData.btnBeadShiDirINOUT.Enabled = False
                                        'objJobData.btnBeadShiDirFWDREV.Enabled = False
                                        objJobData.btnLinearCirculae.Enabled = False
                                        objJobData.btnStepONOFF.Enabled = False
                                        objJobData.btnSpiralONOFF.Enabled = False
                                        'objJobData.btnSagitaONOFF.Enabled = False
                                        objSC1.btnstart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.startOn
                                        objSC1.btnstop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stopE
                                        objcontrols.btnWeldStart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.startOn
                                        objcontrols.btnWeldStop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stopE


                                    End If
                                Else
                                    If pmb1tag = 1 Then
                                        pmb1tag = 0
                                        gWeldingStart = False

                                        objSC1.lblpmb1.Image = Global.iotPIPECLEDING.My.Resources.pmb1gray
                                        objcontrols.lblpmb1.Image = Global.iotPIPECLEDING.My.Resources.pmb1SG

                                        '/////   Enable button
                                        objSC1.btntag1.Enabled = True
                                        objSC1.btntag2.Enabled = True
                                        objSC1.btndryweldrun.Enabled = True
                                        objJobData.btnNozzPipeIDOL.Enabled = True
                                        'objJobData.btnFlangeOL.Enabled = True
                                        ' objJobData.btnBackfaceOL.Enabled = True
                                        objJobData.btnBeadShiFWDREW.Enabled = True
                                        ' objJobData.btnBeadShiDirINOUT.Enabled = True
                                        'objJobData.btnBeadShiDirFWDREV.Enabled = True
                                        objJobData.btnLinearCirculae.Enabled = True
                                        objJobData.btnStepONOFF.Enabled = True
                                        objJobData.btnSpiralONOFF.Enabled = True
                                        'objJobData.btnSagitaONOFF.Enabled = True
                                        objSC1.btnstop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stopD
                                        objSC1.btnstart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.startE
                                        objcontrols.btnWeldStop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stopD
                                        objcontrols.btnWeldStart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.startE


                                    End If
                                End If

                                If digits8(4) = 1 Then
                                    pmb5tag = 1
                                End If
                            End If
                        End If

                        ''''  ///  Check last weld position done //////////
                        If pmb5tag = 1 Then
                            pmb5tag = 0
                            plcinstrg = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 01 02 26 00 03", 50)
                            Dim x4() As String = plcinstrg.Split(" "c)
                            If x4.Count >= 4 Then
                                If x4(6) = "02" And x4(7) = "01" Then
                                    Dim bin As String = ReverseString(Hex2Bin(x4(10) & x4(9)))
                                    Dim digits13() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))

                                    ''''''''' check condition
                                    If digits13(0) = 1 Then
                                        objSC1.btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldrun
                                        objSC1.btndryweldrun.Tag = 1
                                    Else
                                        objSC1.btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dryrun
                                        objSC1.btndryweldrun.Tag = 0
                                    End If

                                    ''''''''' check condition
                                    If digits13(1) = 1 Then
                                        objSC1.btntag1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag1
                                        objSC1.btntag1.Tag = 1
                                    Else
                                        objSC1.btntag1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag1G
                                        objSC1.btntag1.Tag = 0
                                    End If

                                    ''''''''' check condition
                                    If digits13(2) = 1 Then
                                        objSC1.btntag2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag2
                                        objSC1.btntag2.Tag = 1
                                    Else
                                        objSC1.btntag2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag2G
                                        objSC1.btntag2.Tag = 0
                                    End If

                                    tejas = 36
                                End If
                            End If

                        End If
                        '//////////////// plc status  //////////////////////////
                        '/////////////////  Healthy //////////////
                        plcinstrg = ""
                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 01 01 2C 00 01", 50)
                        Dim x9() As String = plcinstrg.Split(" "c)
                        If x9.Count >= 4 Then
                            If x9(6) = "03" And x9(7) = "01" Then
                                Dim bin As String = ReverseString(Hex2Bin(x9(10) & x9(9)))
                                Dim digits9() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                                ghealthy = digits9(0)
                                tejas = 9
                                If ghealthy = 1 Then
                                    objSC1.LblHealthy.Image = Global.iotPIPECLEDING.My.Resources.hgreen
                                    objcontrols.LblHealthy.Image = Global.iotPIPECLEDING.My.Resources.hgreen
                                    lblH.BackColor = Color.LimeGreen

                                Else
                                    objSC1.LblHealthy.Image = Global.iotPIPECLEDING.My.Resources.hgray
                                    objcontrols.LblHealthy.Image = Global.iotPIPECLEDING.My.Resources.hgray
                                    lblH.BackColor = Color.DarkGray
                                End If

                            End If
                        End If


                        '////////////////////////  Fault //////////////////
                        plcinstrg = ""
                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 01 00 03 00 01", 50)
                        Dim x10() As String = plcinstrg.Split(" "c)
                        If x10.Count >= 4 Then
                            If x10(6) = "03" And x10(7) = "01" Then
                                Dim bin As String = ReverseString(Hex2Bin(x10(10) & x10(9)))
                                Dim digits10() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                                gFAULT = digits10(0)
                                tejas = 10
                                If gFAULT = 1 Then

                                    objSC1.lblfaulty.Image = Global.iotPIPECLEDING.My.Resources.fR
                                    objcontrols.lblfaulty.Image = Global.iotPIPECLEDING.My.Resources.fR
                                    '  objDiag.lblFault.Image = Global.iotHORIZONTALOL.My.Resources.fault
                                    lblF.BackColor = Color.Red
                                Else
                                    ' objDiag.lblFault.Image = Global.iotHORIZONTALOL.My.Resources.faultG
                                    objcontrols.lblfaulty.Image = Global.iotPIPECLEDING.My.Resources.fG
                                    objSC1.lblfaulty.Image = Global.iotPIPECLEDING.My.Resources.fG
                                    lblF.BackColor = Color.DarkGray

                                End If

                            End If
                        End If



                        '///////////////////////  Alarm //////////////////////
                        plcinstrg = ""
                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 01 00 05 00 01", 50)
                        Dim x11() As String = plcinstrg.Split(" "c)
                        If x11.Count >= 4 Then
                            If x11(6) = "03" And x11(7) = "01" Then
                                Dim bin As String = ReverseString(Hex2Bin(x11(10) & x11(9)))
                                Dim digits11() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                                gALARM = digits11(0)
                                tejas = 11
                                If gALARM = 1 Then
                                    objSC1.lblalarm.Image = Global.iotPIPECLEDING.My.Resources.lorg
                                    objcontrols.lblalarm.Image = Global.iotPIPECLEDING.My.Resources.lorg
                                    lblL.BackColor = Color.DarkOrange
                                Else
                                    objSC1.lblalarm.Image = Global.iotPIPECLEDING.My.Resources.lgray
                                    objcontrols.lblalarm.Image = Global.iotPIPECLEDING.My.Resources.lgray
                                    lblL.BackColor = Color.DarkGray
                                End If

                            End If
                        End If


                        '///////////////////////  Auto/Manual //////////////////////
                        plcinstrg = ""
                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 01 01 2E 00 01", 50)
                        Dim x34() As String = plcinstrg.Split(" "c)
                        If x34.Count >= 4 Then
                            If x34(6) = "03" And x34(7) = "01" Then
                                Dim bin As String = ReverseString(Hex2Bin(x34(10) & x34(9)))
                                Dim digits12() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                                gAutoON = digits12(0)
                                tejas = 12
                                '///////////////////////  Auto/Manual //////////////////////
                                If gAutoON = 1 Then
                                    objSC1.lblAuto.Image = Global.iotPIPECLEDING.My.Resources.AY
                                    objcontrols.lblAuto.Image = Global.iotPIPECLEDING.My.Resources.AY
                                    lblA.BackColor = Color.Yellow
                                Else
                                    objSC1.lblAuto.Image = Global.iotPIPECLEDING.My.Resources.AG
                                    objcontrols.lblAuto.Image = Global.iotPIPECLEDING.My.Resources.AG
                                    lblA.BackColor = Color.DarkGray
                                End If

                            End If
                        End If




                        ''///////////////////////////   AO 1  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 04 4C 00 02", 50)
                        'Dim x26() As String = plcinstrg.Split(" "c)
                        'If x26.Count >= 4 Then
                        '    If x26(6) = "03" And x26(7) = "03" Then
                        '        y = Convert.ToInt32(x26(11) & x26(12) & x26(9) & x26(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gAo1 = (y / 10)

                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 21
                        '    End If
                        'End If

                        ''///////////////////////////   AO 2  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 04 56 00 02", 50)
                        'Dim x27() As String = plcinstrg.Split(" "c)
                        'If x27.Count >= 4 Then
                        '    If x27(6) = "03" And x27(7) = "03" Then
                        '        y = Convert.ToInt32(x27(11) & x27(12) & x27(9) & x27(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gAo2 = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 22
                        '    End If
                        'End If


                        ''///////////////////////////   AO 3  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 04 60 00 02", 50)
                        'Dim x28() As String = plcinstrg.Split(" "c)
                        'If x28.Count >= 4 Then
                        '    If x28(6) = "03" And x28(7) = "03" Then
                        '        y = Convert.ToInt32(x28(11) & x28(12) & x28(9) & x28(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gAo3 = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 23
                        '    End If
                        'End If

                        '''///////////////////////////   AO 4  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 04 6A 00 02", 50)
                        'Dim x29() As String = plcinstrg.Split(" "c)
                        'If x29.Count >= 4 Then
                        '    If x29(6) = "03" And x15(7) = "03" Then
                        '        y = Convert.ToInt32(x29(11) & x29(12) & x29(9) & x29(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gAo4 = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 24
                        '    End If
                        'End If



                        '''///////////////////////////   AO 5  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 04 74 00 02", 50)
                        'Dim x30() As String = plcinstrg.Split(" "c)
                        'If x30.Count >= 4 Then
                        '    If x30(6) = "03" And x30(7) = "03" Then
                        '        y = Convert.ToInt32(x30(11) & x30(12) & x30(9) & x30(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gAo5 = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 25
                        '    End If
                        'End If

                        '''///////////////////////////   AO 6  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 04 7E 00 02", 50)
                        'Dim x31() As String = plcinstrg.Split(" "c)
                        'If x31.Count >= 4 Then
                        '    If x31(6) = "03" And x31(7) = "03" Then
                        '        y = Convert.ToInt32(x31(11) & x31(12) & x31(9) & x31(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gAo6 = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 26
                        '    End If
                        'End If

                        '''///////////////////////////   AO 7  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 04 88 00 02", 50)
                        'Dim x32() As String = plcinstrg.Split(" "c)
                        'If x32.Count >= 4 Then
                        '    If x32(6) = "03" And x32(7) = "03" Then
                        '        y = Convert.ToInt32(x32(11) & x32(12) & x32(9) & x32(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gAo7 = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 27
                        '    End If
                        'End If

                        '''///////////////////////////   AO 8  //////////////////////
                        'y = 0
                        'y1 = 0
                        'plcinstrg = ""

                        'plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 04 92 00 02", 50)
                        'Dim x33() As String = plcinstrg.Split(" "c)
                        'If x33.Count >= 4 Then
                        '    If x33(6) = "03" And x33(7) = "03" Then
                        '        y = Convert.ToInt32(x33(11) & x33(12) & x33(9) & x33(10), 16)
                        '        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        '        gAo8 = (y / 10)
                        '        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        '        tejas = 28
                        '    End If
                        'End If





                        '///////////////////////////   Speed/ Position Axis 1  //////////////////////
                        y = 0
                        y1 = 0
                        plcinstrg = ""

                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 02 C2 00 04", 80)
                        Dim x20() As String = plcinstrg.Split(" "c)
                        If x20.Count >= 4 Then
                            If x20(6) = "03" And x20(7) = "03" Then
                                y = Convert.ToInt32(x20(11) & x20(12) & x20(9) & x20(10), 16)
                                gSpeedDisplayAxis1 = (y / 100)
                                y = 0
                                y = Convert.ToInt32(x20(15) & x20(16) & x20(13) & x20(14), 16)
                                gPositionAxis1 = (y / 100)
                                ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                                ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                                tejas = 29
                            End If
                        End If

                        '///////////////////////////   Speed/ Position Axis 2  //////////////////////
                        y = 0
                        y1 = 0
                        plcinstrg = ""

                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 02 CC 00 04", 80)
                        Dim x21() As String = plcinstrg.Split(" "c)
                        If x21.Count >= 4 Then
                            If x21(6) = "03" And x21(7) = "03" Then
                                y = Convert.ToInt32(x21(11) & x21(12) & x21(9) & x21(10), 16)
                                gSpeedDisplayAxis2 = (y / 100)
                                y = 0
                                y = Convert.ToInt32(x21(15) & x21(16) & x21(13) & x21(14), 16)
                                gPositionAxis2 = (y / 100)
                                ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                                ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                                tejas = 30
                            End If
                        End If

                        '///////////////////////////   Speed/ Position Axis 3  //////////////////////
                        y = 0
                        y1 = 0
                        plcinstrg = ""

                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 02 D6 00 04", 80)
                        Dim x22() As String = plcinstrg.Split(" "c)
                        If x22.Count >= 4 Then
                            If x22(6) = "03" And x22(7) = "03" Then
                                y = Convert.ToInt32(x22(11) & x22(12) & x22(9) & x22(10), 16)
                                gSpeedDisplayAxis3 = (y / 100)
                                y = 0
                                y = Convert.ToInt32(x22(15) & x22(16) & x22(13) & x22(14), 16)
                                gPositionAxis3 = (y / 100)
                                ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                                ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                                tejas = 31
                            End If
                        End If

                        '///////////////////////////   Speed/ Position Axis 4  //////////////////////
                        y = 0
                        y1 = 0
                        plcinstrg = ""

                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 02 E0 00 04", 80)
                        Dim x23() As String = plcinstrg.Split(" "c)
                        If x23.Count >= 4 Then
                            If x23(6) = "03" And x23(7) = "03" Then
                                y = Convert.ToInt32(x23(11) & x23(12) & x23(9) & x23(10), 16)
                                gSpeedDisplayAxis4 = (y / 100)
                                y = 0
                                y = Convert.ToInt32(x23(15) & x23(16) & x23(13) & x23(14), 16)
                                gPositionAxis4 = (y / 100)
                                ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                                ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                                tejas = 32
                            End If
                        End If

                        '///////////////////////////   Speed/ Position Axis 5  //////////////////////
                        y = 0
                        y1 = 0
                        plcinstrg = ""

                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 02 EA 00 04", 80)
                        Dim x24() As String = plcinstrg.Split(" "c)
                        If x24.Count >= 4 Then
                            If x24(6) = "03" And x24(7) = "03" Then
                                y = Convert.ToInt32(x24(11) & x24(12) & x24(9) & x24(10), 16)
                                gSpeedDisplayAxis5 = (y / 100)
                                y = 0
                                y = Convert.ToInt32(x24(15) & x24(16) & x24(13) & x24(14), 16)
                                gPositionAxis5 = (y / 100)
                                ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                                ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                                tejas = 33
                            End If
                        End If


                        '///////////////////////////    Position Last Weld  Axis  //////////////////////
                        y = 0
                        y1 = 0
                        plcinstrg = ""

                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 01 C2 00 0A", 100)
                        Dim x25() As String = plcinstrg.Split(" "c)
                        If x25.Count >= 4 Then
                            If x25(6) = "03" And x25(7) = "03" Then
                                y = Convert.ToInt32(x25(11) & x25(12) & x25(9) & x25(10), 16)
                                gLastWeldPositionAxis1 = (y / 100)
                                y = 0
                                y = Convert.ToInt32(x25(15) & x25(16) & x25(13) & x25(14), 16)
                                gLastWeldPositionAxis2 = (y / 100)

                                y = 0
                                y = Convert.ToInt32(x25(19) & x25(20) & x25(17) & x25(18), 16)
                                gLastWeldPositionAxis3 = (y / 100)

                                y = 0
                                y = Convert.ToInt32(x25(23) & x25(24) & x25(21) & x25(22), 16)
                                gLastWeldPositionAxis4 = (y / 100)
                                y = 0
                                y = Convert.ToInt32(x25(27) & x25(28) & x25(25) & x25(26), 16)
                                gLastWeldPositionAxis5 = (y / 100)
                                ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                                ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                                tejas = 34
                            End If
                        End If

                        '////////////// Servo Fault Codes /////////////////
                        y = 0
                        y1 = 0

                        plcinstrg = ""

                        plcinstrg = TCPComRX("00 00 00 00 00 06 03 03 00 64 00 0A", 100)
                        Dim x35() As String = plcinstrg.Split(" "c)
                        If x35.Count >= 4 Then
                            If x35(6) = "03" And x35(7) = "03" Then
                                Dim lblfc1 As String = ""
                                gErrorCodeSA1 = (plcinstrg.Substring(15, 2) & (plcinstrg.Substring(18, 2)))

                                gErrorCodeSA2 = (plcinstrg.Substring(27, 2) & (plcinstrg.Substring(30, 2)))

                                gErrorCodeSA3 = (plcinstrg.Substring(39, 2) & (plcinstrg.Substring(42, 2)))

                                gErrorCodeSA4 = (plcinstrg.Substring(51, 2) & (plcinstrg.Substring(54, 2)))

                                gErrorCodeSA5 = (plcinstrg.Substring(63, 2) & (plcinstrg.Substring(66, 2)))


                                tejas = 35
                            End If
                        End If

                    Else
                        '    Dim result1 As String = TcpErrorMessageBox.Show("Error in TcpConnection method , Error : " + "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 3, "").ToString
                        TcpConnection()
                    End If

                Catch ex As Exception
                    ''    Dim result1 As String = MessageBoxEx.Show("Data Not Received : " + ex.Message.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString
                    ''  MessageBox.Show("hii")
                    '' TcpConnection()
                End Try

                'READING FROM COM PORT 3



                'writeLog("------------ Thread End ---------------")

                objThread1.UpdateUI(P1, P2, p3, p4, p5, p6, p7, p8, p9, Auxinstrg, TRSinstrg, Driftinstrg, plcinstrg)
                Threading.Thread.Sleep(500)
            Loop
        Catch ex As Exception

            MessageBox.Show("Error from ThreadMethod1() method of MDIParent1, Error : " + ex.Message.ToString() + tejas.ToString())
            objThread1.Dispose()
            Thread.Sleep(1000)
            objThread1.Start()

        End Try
    End Sub

    Private Sub CallBackMethod1(ByVal P1 As String, ByVal P2 As String, ByVal P3 As String, ByVal P4 As String, ByVal p5 As String, ByVal p6 As String, ByVal p7 As String, ByVal p8 As String, ByVal p9 As String, ByVal Auxinstrg As String, ByVal TRSinstrg As String, ByVal Driftinstrg As String, ByVal plcinstrg As String)

        'Input String Writing
        'objSC1.lblAuxinstr.Text = Auxinstrg
        'objSC1.lblTRCinstr.Text = TRSinstrg
        'objSC1.lblDriftinstr.Text = Driftinstrg
        'objSC1.lblplcinstr.Text = plcinstrg

        '' //// IMPORTANT   ///////
        gGrind = 0
        gGrindFillupvalue = 0


        '-------------------------  SC1 Screen ----------------------------------
        ''display step movement

        If gstepmovement = 1 Then


        Else


        End If


        '///////////////   Update Screen Time  /////////////////////////////
        lblTime.Text = Format(Now, "dd-MM-yyyy HH:mm:ss").ToString()

        '/////////////////////////////   Check Network Connectivity  //////////////////////////
        Using myservice As New SQLDB()
            If myservice.checkNetworkConnectivity() Then
                lblNetworkConnectivity.BackColor = Color.Green
            Else
                lblNetworkConnectivity.BackColor = Color.Red
            End If
        End Using

        '//////////////////////////  Main screen Analog //////////////////////////
        objSC1.lblCurrent.Text = gGTAWCurr.ToString()
        objSC1.lblVoltage.Text = gGTAWVol.ToString()
        objSC1.lblCurrent2.Text = gGTAWCurr2.ToString()
        objSC1.lblVoltage2.Text = gGTAWVol2.ToString()
        objSC1.lblGASFLOW.Text = gGTAWgasflow.ToString()
        objSC1.lblGasflow2.Text = gGTAWgasflow2.ToString()
        objSC1.lblJobTemp2.Text = gGTAWjobtemp.ToString()
        objSC1.LblTRAVELSPEED.Text = gGTAWTravelSpeed.ToString()
        objSC1.lblAi8.Text = gAi8.ToString()

        '//////////////   Axis speed value ////////////////////
        objSC1.lblXSPEED.Text = gSpeedDisplayAxis1.ToString()
        ' objSC1.lblYSPEED.Text = gSpeedDisplayAxis2.ToString()
        objSC1.lblTSPEED.Text = gSpeedDisplayAxis3.ToString()
        objSC1.lblASPEED.Text = gSpeedDisplayAxis4.ToString()
        objSC1.lblRSPEED.Text = gSpeedDisplayAxis5.ToString()

        '///////////////  Axis Position value /////////////////
        objSC1.lblXPOS.Text = gPositionAxis1.ToString()
        ' objSC1.lblYPOS.Text = gPositionAxis2.ToString()
        objSC1.lblTPOS.Text = gPositionAxis3.ToString()
        objSC1.lblAPOS.Text = gPositionAxis4.ToString()
        objSC1.lblRPOS.Text = gPositionAxis5.ToString()


        '//////////////////  Axis Last Position  /////////////////////////////
        objSC1.lblXLASTPOS.Text = gLastWeldPositionAxis1.ToString()
        ' objSC1.lblYLASTPOS.Text = gLastWeldPositionAxis2.ToString()
        objSC1.lblTLASTPOS.Text = gLastWeldPositionAxis3.ToString()
        objSC1.lblALASTPOS.Text = gLastWeldPositionAxis4.ToString()
        objSC1.lblRLASTPOS.Text = gLastWeldPositionAxis5.ToString()


        '//////////// Frm Controls Analog Read ////////////////////////////

        objcontrols.lblCurrent.Text = gGTAWCurr.ToString()
        objcontrols.lblVoltage.Text = gGTAWVol.ToString()
        objcontrols.lblCurrent2.Text = gGTAWCurr2.ToString()
        objcontrols.lblVoltage2.Text = gGTAWVol2.ToString()
        objcontrols.lblGASFLOW.Text = gGTAWgasflow.ToString()
        objcontrols.lblGasflow2.Text = gGTAWgasflow2.ToString()
        objcontrols.lblJobtemp.Text = gGTAWjobtemp.ToString()
        objcontrols.LblTRAVELSPEED.Text = gGTAWTravelSpeed.ToString()
        objcontrols.lblAi8.Text = gAi8.ToString()


        '//////////////   Axis speed value ////////////////////
        objcontrols.lblXSPEED.Text = gSpeedDisplayAxis1.ToString()
        'objcontrols.lblYSPEED.Text = gSpeedDisplayAxis2.ToString()
        objcontrols.lblTSPEED.Text = gSpeedDisplayAxis3.ToString()
        objcontrols.lblASPEED.Text = gSpeedDisplayAxis4.ToString()
        objcontrols.lblRSPEED.Text = gSpeedDisplayAxis5.ToString()

        '///////////////  Axis Position value /////////////////
        objcontrols.lblXPOS.Text = gPositionAxis1.ToString()
        'objcontrols.lblYPOS.Text = gPositionAxis2.ToString()
        objcontrols.lblTPOS.Text = gPositionAxis3.ToString()
        objcontrols.lblAPOS.Text = gPositionAxis4.ToString()
        objcontrols.lblRPOS.Text = gPositionAxis5.ToString()

        '//////////////////  Axis Last Position  /////////////////////////////
        objcontrols.lblXLASTPOS.Text = gLastWeldPositionAxis1.ToString()
        'objcontrols.lblYLASTPOS.Text = gLastWeldPositionAxis2.ToString()
        objcontrols.lblTLASTPOS.Text = gLastWeldPositionAxis3.ToString()
        objcontrols.lblALASTPOS.Text = gLastWeldPositionAxis4.ToString()
        objcontrols.lblRLASTPOS.Text = gLastWeldPositionAxis5.ToString()

        '-----------  Diagnosis Screen ---------------------

        '//////////// DIGITAL INPUT //////////////

        'Dim P() As String = P1.Split(":"c)
        'Dim Q() As String = P2.Split(":"c)

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        'gDi1 = P(0)
        'gDi2 = P(1)
        'gDi3 = P(2)
        'gDi4 = P(3)
        'gDi5 = P(4)
        'gDi6 = P(5)
        'gDi7 = P(6)
        'gDi8 = P(7)
        'gDi9 = P(8)
        'gDi10 = P(9)
        'gDi11 = P(10)
        'gDi12 = P(11)
        'gDi13 = P(12)
        'gDi14 = P(13)
        'gDi15 = P(14)
        'gDi16 = P(15)

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        'gDi17 = Q(0)
        'gDi18 = Q(1)
        'gDi19 = Q(2)
        'gDi20 = Q(3)
        'gDi21 = Q(4)
        'gDi22 = Q(5)
        'gDi23 = Q(6)
        'gDi24 = Q(7)
        'gDi25 = Q(8)
        'gDi26 = Q(9)
        'gDi27 = Q(10)
        'gDi28 = Q(11)
        'gDi29 = Q(12)
        'gDi30 = Q(13)
        'gDi31 = Q(14)
        'gDi32 = Q(15)

        ''////////////////   Display value  ///////////////////////////

        'objdigstatus.lblDi1.BackColor = colorarr(gDi1)
        'objdigstatus.lblDi2.BackColor = colorarr(gDi2)
        'objdigstatus.lblDi3.BackColor = colorarr(gDi3)
        'objdigstatus.lblDi4.BackColor = colorarr(gDi4)
        'objdigstatus.lblDi5.BackColor = colorarr(gDi5)
        'objdigstatus.lblDi6.BackColor = colorarr(gDi6)
        'objdigstatus.lblDi7.BackColor = colorarr(gDi7)
        'objdigstatus.lblDi8.BackColor = colorarr(gDi8)
        'objdigstatus.lblDi9.BackColor = colorarr(gDi9)
        'objdigstatus.lblDi10.BackColor = colorarr(gDi10)
        'objdigstatus.lblDi11.BackColor = colorarr(gDi11)
        'objdigstatus.lblDi12.BackColor = colorarr(gDi12)
        'objdigstatus.lblDi13.BackColor = colorarr(gDi13)
        'objdigstatus.lblDi14.BackColor = colorarr(gDi14)
        'objdigstatus.lblDi15.BackColor = colorarr(gDi15)
        'objdigstatus.lblDi16.BackColor = colorarr(gDi16)
        'objdigstatus.lblDi17.BackColor = colorarr(gDi17)
        'objdigstatus.lblDi18.BackColor = colorarr(gDi18)
        'objdigstatus.lblDi19.BackColor = colorarr(gDi19)
        'objdigstatus.lblDi20.BackColor = colorarr(gDi20)
        'objdigstatus.lblDi21.BackColor = colorarr(gDi21)
        'objdigstatus.lblDi22.BackColor = colorarr(gDi22)
        'objdigstatus.lblDi23.BackColor = colorarr(gDi23)
        'objdigstatus.lblDi24.BackColor = colorarr(gDi24)
        'objdigstatus.lblDi25.BackColor = colorarr(gDi25)
        'objdigstatus.lblDi26.BackColor = colorarr(gDi26)
        'objdigstatus.lblDi27.BackColor = colorarr(gDi27)
        'objdigstatus.lblDi28.BackColor = colorarr(gDi28)
        'objdigstatus.lblDi29.BackColor = colorarr(gDi29)
        'objdigstatus.lblDi30.BackColor = colorarr(gDi30)
        'objdigstatus.lblDi31.BackColor = colorarr(gDi31)
        'objdigstatus.lblDi32.BackColor = colorarr(gDi32)



        ''//////////// DIGITAL OUTPUT //////////////

        'Dim R() As String = P3.Split(":"c)
        'Dim S() As String = P4.Split(":"c)

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        'gDo1 = R(0)
        'gDo2 = R(1)
        'gDo3 = R(2)
        'gDo4 = R(3)
        'gDo5 = R(4)
        'gDo6 = R(5)
        'gDo7 = R(6)
        'gDo8 = R(7)
        'gDo9 = R(8)
        'gDo10 = R(9)
        'gDo11 = R(10)
        'gDo12 = R(11)
        'gDo13 = R(12)
        'gDo14 = R(13)
        'gDo15 = R(14)
        'gDo16 = R(15)

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        'gDo17 = S(0)
        'gDo18 = S(1)
        'gDo19 = S(2)
        'gDo20 = S(3)
        'gDo21 = S(4)
        'gDo22 = S(5)
        'gDo23 = S(6)
        'gDo24 = S(7)
        'gDo25 = S(8)
        'gDo26 = S(9)
        'gDo27 = S(10)
        'gDo28 = S(11)
        'gDo29 = S(12)
        'gDo30 = S(13)
        'gDo31 = S(14)
        'gDo32 = S(15)

        ''////////////////   Display Status  ///////////////////////////

        'objdigstatus.lblDO1.BackColor = colorarr(gDo1)
        'objdigstatus.lblDO2.BackColor = colorarr(gDo2)
        'objdigstatus.lblDO3.BackColor = colorarr(gDo3)
        'objdigstatus.lblDO4.BackColor = colorarr(gDo4)
        'objdigstatus.lblDO5.BackColor = colorarr(gDo5)
        'objdigstatus.lblDO6.BackColor = colorarr(gDo6)
        'objdigstatus.lblDO7.BackColor = colorarr(gDo7)
        'objdigstatus.lblDO8.BackColor = colorarr(gDo8)
        'objdigstatus.lblDO9.BackColor = colorarr(gDo9)
        'objdigstatus.lblDO10.BackColor = colorarr(gDo10)
        'objdigstatus.lblDO11.BackColor = colorarr(gDo11)
        'objdigstatus.lblDO12.BackColor = colorarr(gDo12)
        'objdigstatus.lblDO13.BackColor = colorarr(gDo13)
        'objdigstatus.lblDO14.BackColor = colorarr(gDo14)
        'objdigstatus.lblDO15.BackColor = colorarr(gDo15)
        'objdigstatus.lblDO16.BackColor = colorarr(gDo16)
        'objdigstatus.lblDO17.BackColor = colorarr(gDo17)
        'objdigstatus.lblDO18.BackColor = colorarr(gDo18)
        'objdigstatus.lblDO19.BackColor = colorarr(gDo19)
        'objdigstatus.lblDO20.BackColor = colorarr(gDo20)
        'objdigstatus.lblDO21.BackColor = colorarr(gDo21)
        'objdigstatus.lblDO22.BackColor = colorarr(gDo22)
        'objdigstatus.lblDO23.BackColor = colorarr(gDo23)
        'objdigstatus.lblDO24.BackColor = colorarr(gDo24)
        'objdigstatus.lblDO25.BackColor = colorarr(gDo25)
        'objdigstatus.lblDO26.BackColor = colorarr(gDo26)
        'objdigstatus.lblDO27.BackColor = colorarr(gDo27)
        'objdigstatus.lblDO28.BackColor = colorarr(gDo28)
        'objdigstatus.lblDO29.BackColor = colorarr(gDo29)
        'objdigstatus.lblDO30.BackColor = colorarr(gDo30)
        'objdigstatus.lblDO31.BackColor = colorarr(gDo31)
        'objdigstatus.lblDO32.BackColor = colorarr(gDo32)


        '//////////// FAULT STATUS DISPLAY //////////////

        Dim T() As String = p5.Split(":"c)
        Dim U() As String = p6.Split(":"c)

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        gFault1 = T(0)
        gFault2 = T(1)
        gFault3 = T(2)
        gFault4 = T(3)
        gFault5 = T(4)
        gFault6 = T(5)
        gFault7 = T(6)
        gFault8 = T(7)
        gFault9 = T(8)
        gFault10 = T(9)
        gFault11 = T(10)
        gFault12 = T(11)
        gFault13 = T(12)
        gFault14 = T(13)
        gFault15 = T(14)
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        gFault16 = U(0)
        gFault17 = U(1)
        gFault18 = U(2)
        gFault19 = U(3)
        gFault20 = U(4)
        gFault21 = U(5)
        gFault22 = U(6)
        gFault23 = U(7)
        gFault24 = U(8)
        gFault25 = U(9)
        gFault26 = U(10)
        gFault27 = U(11)
        gFault28 = U(12)
        gFault29 = U(13)
        gFault30 = U(14)

        '////////////////   Display Fault Status  ///////////////////////////

        'objDiag.lblF1.BackColor = colorarr(gFault1)
        'objDiag.lblF2.BackColor = colorarr(gFault2)
        'objDiag.lblF3.BackColor = colorarr(gFault3)
        'objDiag.lblF4.BackColor = colorarr(gFault4)
        'objDiag.lblF5.BackColor = colorarr(gFault5)
        'objDiag.lblF6.BackColor = colorarr(gFault6)
        'objDiag.lblF7.BackColor = colorarr(gFault7)
        'objDiag.lblF8.BackColor = colorarr(gFault8)
        'objDiag.lblF9.BackColor = colorarr(gFault9)
        'objDiag.lblF10.BackColor = colorarr(gFault10)
        'objDiag.lblF11.BackColor = colorarr(gFault11)
        'objDiag.lblF12.BackColor = colorarr(gFault12)
        'objDiag.lblF13.BackColor = colorarr(gFault13)
        'objDiag.lblF14.BackColor = colorarr(gFault14)
        'objDiag.lblF15.BackColor = colorarr(gFault15)
        'objDiag.lblF16.BackColor = colorarr(gFault16)
        'objDiag.lblF17.BackColor = colorarr(gFault17)
        'objDiag.lblF18.BackColor = colorarr(gFault18)
        'objDiag.lblF19.BackColor = colorarr(gFault19)
        'objDiag.lblF20.BackColor = colorarr(gFault20)
        'objDiag.lblF21.BackColor = colorarr(gFault21)
        'objDiag.lblF22.BackColor = colorarr(gFault22)
        'objDiag.lblF23.BackColor = colorarr(gFault23)
        'objDiag.lblF24.BackColor = colorarr(gFault24)
        'objDiag.lblF25.BackColor = colorarr(gFault25)
        'objDiag.lblF26.BackColor = colorarr(gFault26)
        'objDiag.lblF27.BackColor = colorarr(gFault27)
        'objDiag.lblF28.BackColor = colorarr(gFault28)
        'objDiag.lblF29.BackColor = colorarr(gFault29)
        'objDiag.lblF30.BackColor = colorarr(gFault30)


        '/////////////////      ALARMS /LIMITS-DISPLAYS      //////////////

        Dim V() As String = p7.Split(":"c)

        ''''''''''''''''''''''''''''''''''''''''''''''''''''
        gFLIimitAxis1 = V(0)
        gRLimitAxis1 = V(1)
        gFLIimitAxis2 = V(2)
        gRLimitAxis2 = V(3)
        gFLIimitAxis3 = V(4)
        gRLimitAxis3 = V(5)
        gFLIimitAxis4 = V(6)
        gRLimitAxis4 = V(7)
        gFLIimitAxis5 = V(8)
        gRLimitAxis5 = V(9)

        '//////////////////////////  Display   ///////////////////////////////

        'objDiag.lblXrevlimit.BackColor = colorarr(gRLimitAxis1)
        'objDiag.lblYreviimit.BackColor = colorarr(gRLimitAxis2)
        'objDiag.lblTrevlimit.BackColor = colorarr(gRLimitAxis3)
        'objDiag.lblArevlimit.BackColor = colorarr(gRLimitAxis4)
        'objDiag.lblRrevlimit.BackColor = colorarr(gRLimitAxis5)


        'objDiag.lblXfwdlimit.BackColor = colorarr(gFLIimitAxis1)
        'objDiag.lblYfwdlimit.BackColor = colorarr(gFLIimitAxis2)
        'objDiag.lblTfwdlimit.BackColor = colorarr(gFLIimitAxis3)
        'objDiag.lblAfwdlimit.BackColor = colorarr(gFLIimitAxis4)
        'objDiag.lblRfwdlimit.BackColor = colorarr(gFLIimitAxis5)



        ''////////////////////////   Process MONITORING BITS     //////////////////////////

        Dim W() As String = p8.Split(":"c)

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        gPmb1 = W(0)
        gPmb2 = W(1)
        gPmb3 = W(2)
        gPmb4 = W(3)
        gPmb5 = W(4)

        '----------------------------------------------------------------------------
        If gPmb1 = 1 Then
            objSC1.lblpmb1.Image = Global.iotPIPECLEDING.My.Resources.pmb1
            objcontrols.lblpmb1.Image = Global.iotPIPECLEDING.My.Resources.pmb1S
        Else
            objSC1.lblpmb1.Image = Global.iotPIPECLEDING.My.Resources.pmb1gray
            objcontrols.lblpmb1.Image = Global.iotPIPECLEDING.My.Resources.pmb1SG
        End If

        If gPmb2 = 1 Then
            objSC1.lblpmb2.Image = Global.iotPIPECLEDING.My.Resources.pmb2
            objcontrols.lblpmb2.Image = Global.iotPIPECLEDING.My.Resources.pmb2S
        Else
            objSC1.lblpmb2.Image = Global.iotPIPECLEDING.My.Resources.pmb2gray
            objcontrols.lblpmb2.Image = Global.iotPIPECLEDING.My.Resources.pmb2SG
        End If

        If gPmb3 = 1 Then
            objSC1.lblpmb3.Image = Global.iotPIPECLEDING.My.Resources.pmb3
            objcontrols.lblpmb3.Image = Global.iotPIPECLEDING.My.Resources.pmb3S
        Else
            objSC1.lblpmb3.Image = Global.iotPIPECLEDING.My.Resources.pmb3gray
            objcontrols.lblpmb3.Image = Global.iotPIPECLEDING.My.Resources.pmb3SG
        End If

        If gPmb4 = 1 Then
            objSC1.lblpmb4.Image = Global.iotPIPECLEDING.My.Resources.pmb4
            objcontrols.lblpmb4.Image = Global.iotPIPECLEDING.My.Resources.pmb4S
        Else
            objSC1.lblpmb4.Image = Global.iotPIPECLEDING.My.Resources.pmb4gray
            objcontrols.lblpmb4.Image = Global.iotPIPECLEDING.My.Resources.pmb4SG
        End If

        If gPmb5 = 1 Then
            objSC1.lblpmb5.Image = Global.iotPIPECLEDING.My.Resources.pmb5
            objcontrols.lblpmb5.Image = Global.iotPIPECLEDING.My.Resources.pmb5S
        Else
            objSC1.lblpmb5.Image = Global.iotPIPECLEDING.My.Resources.pmb5gray
            objcontrols.lblpmb5.Image = Global.iotPIPECLEDING.My.Resources.pmb5SG
        End If


        '/////////////////////////////////////////////////////////////////

        ' IF dRIVE trip or anti drift detect then power off the welding change 16/03/2018 5:26 pm
        If gAntDFT = 1 Then
            gclick = 2
            gdisable = 2
            ghome = 2
            gstop = 1
            If gsetstop = 0 Then
                gsetstop = 1
            End If

            TRCON = False

        End If

    End Sub

    Private Sub ESSCstop()

        setControl()



        If gstart = 1 Then
            If gsetstop = 1 Then
                SaveArcLog(2)
                gsetstop = 2
            End If
        End If
        'objSC1.RectangleShape66.BorderColor = Color.DarkSalmon '???
    End Sub

    Private Sub setControl()
        objSC1.txtwname.Text = gwelder_nm
        objSC1.txtpsno.Text = gpsno
        objSC1.txtPass.Text = gPass
        objSC1.txtlayer.Text = glayer

        If gLogin = True Then
            objSC1.btnpassup.Enabled = True
            objSC1.btnpassdn.Enabled = True
            objSC1.btnpassok.Enabled = True
            objSC1.btnpassup.BackgroundImage = Global.iotPIPECLEDING.My.Resources.upE
            objSC1.btnpassdn.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dnE
            objSC1.btnpassok.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
            objSC1.btnLogin.Enabled = False
            objSC1.btnLogin.BackColor = System.Drawing.Color.Gray
            objSC1.btnLogout.Enabled = True
            objSC1.btnLogout.BackColor = System.Drawing.Color.SkyBlue
        End If

        objSC1.PanelTRC.Enabled = True
        objSC1.panelPara.Enabled = True
    End Sub


    Private Sub BtnAux_Click(sender As System.Object, e As System.EventArgs) Handles BtnAux.Click
        If gAux = False Then
            gDiag = False
            frmDiag.Timer1.Enabled = False
            objAux.TopLevel = False
            objAux.Dock = DockStyle.Fill
            objAux.FormBorderStyle = Windows.Forms.FormBorderStyle.None
            objAux.ControlBox = False
            objAux.Text = ""
            objAux.WindowState = FormWindowState.Maximized
            objAux.MdiParent = Me
            objAux.Show()
            objJobData.Hide()
            objcontrols.Hide()
            btnPara.Image = Global.iotPIPECLEDING.My.Resources.btnorg

            btnJobData.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnControls.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btngreen
            btnMain.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnDiag.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            gAux = True



        Else
            gDiag = False
            frmDiag.Timer1.Enabled = False
            objAux.Show()
            objJobData.Hide()
            objcontrols.Hide()
            btnJobData.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnControls.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btngreen
            btnMain.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnDiag.Image = Global.iotPIPECLEDING.My.Resources.btnorg

        End If

    End Sub

    Private Sub btnjobdata_Click(sender As System.Object, e As System.EventArgs) Handles btnJobData.Click
        If gJOBDATA = False Then
            gDiag = False
            frmDiag.Timer1.Enabled = False
            objJobData.TopLevel = False
            objJobData.Dock = DockStyle.Fill
            objJobData.FormBorderStyle = Windows.Forms.FormBorderStyle.None
            objJobData.ControlBox = False
            objJobData.Text = ""
            objJobData.WindowState = FormWindowState.Maximized
            objJobData.MdiParent = Me
            objJobData.Show()
            objcontrols.Hide()
            objAux.Hide()
            btnPara.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnJobData.Image = Global.iotPIPECLEDING.My.Resources.btngreen
            btnControls.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnMain.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnDiag.Image = Global.iotPIPECLEDING.My.Resources.btnorg

            gJOBDATA = True
        Else
            gDiag = False
            frmDiag.Timer1.Enabled = False
            objJobData.Show()
            objcontrols.Hide()
            objAux.Hide()
            btnJobData.Image = Global.iotPIPECLEDING.My.Resources.btngreen
            btnControls.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnMain.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnDiag.Image = Global.iotPIPECLEDING.My.Resources.btnorg

        End If
    End Sub
    Private Sub btnWPS_Click(sender As System.Object, e As System.EventArgs) Handles btnWPS.Click
        BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        btnMain.Image = Global.iotPIPECLEDING.My.Resources.btnorg

        'Check IOT DB Connectivity
        Using myservice As New SQLDB()
            IOTDBConnectivity = myservice.checkIOTDBConnectivity()
        End Using

        If IOTDBConnectivity Then
            Dim obj As New frmwds
            obj.TopLevel = False
            obj.Dock = DockStyle.Fill
            obj.FormBorderStyle = Windows.Forms.FormBorderStyle.None
            obj.ControlBox = False
            obj.Text = ""
            obj.WindowState = FormWindowState.Maximized
            obj.MdiParent = Me
            obj.Show()
        Else
            MessageBoxEx.Show("Network is not available.", "WDS", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString()
        End If

    End Sub

    Private Sub btnConsum_Click(sender As System.Object, e As System.EventArgs) Handles btnConsum.Click
        BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        btnMain.Image = Global.iotPIPECLEDING.My.Resources.btnorg

        'Check ERPLN DB Connectivity
        Using myservice As New SQLDB()
            ERPLNDBConnectivity = myservice.checkERPLNDBConnectivity()
        End Using

        If ERPLNDBConnectivity Then
            Dim obj As New frmConsum
            obj.TopLevel = False
            obj.Dock = DockStyle.Fill
            obj.FormBorderStyle = Windows.Forms.FormBorderStyle.None
            obj.ControlBox = False
            obj.Text = ""
            obj.WindowState = FormWindowState.Maximized
            obj.MdiParent = Me
            obj.Show()
        Else
            MessageBoxEx.Show("Network is not available.", "Consumable", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString()
        End If
    End Sub

    Private Sub btnMentry_Click(sender As System.Object, e As System.EventArgs) Handles btnMentry.Click

        If gLogin = True Then
            Dim arg As String = gpsno & " " & """" & gwelder_nm & """" & " " & """" & gstation & """"
            proc = Process.Start(gMentry, arg)
        Else
            proc = Process.Start(gMentry)
        End If
    End Sub

    Private Sub btnDiag_Click(sender As System.Object, e As System.EventArgs) Handles btnDiag.Click
        If gDiag = False Then

            btnJobData.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnMain.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnDiag.Image = Global.iotPIPECLEDING.My.Resources.btngreen
            Dim obj As New frmDiag
            obj.TopLevel = False
            obj.Dock = DockStyle.Fill
            obj.FormBorderStyle = Windows.Forms.FormBorderStyle.None
            obj.ControlBox = False
            obj.Text = ""
            obj.WindowState = FormWindowState.Maximized
            obj.MdiParent = Me
            obj.Show()
            gDiag = True
        Else
            MessageBox.Show("Frame is Allready Open")

        End If
    End Sub

    Private Sub btnPara_Click(sender As System.Object, e As System.EventArgs) Handles btnPara.Click
        btnJobData.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        btnMain.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        btnDiag.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        btnPara.Image = Global.iotPIPECLEDING.My.Resources.btngreen
        Dim testDialog As New frmParaPass

        ' Show testDialog as a modal dialog and determine if DialogResult = OK.
        If testDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
            ' Read the contents of testDialog's TextBox.
            If testDialog.txtPass.Text = "" Then
            Else
                If (testDialog.txtPass.Text = gParaPass) Then
                    Dim obj As New frmPara
                    obj.TopLevel = False
                    obj.Dock = DockStyle.Fill
                    obj.FormBorderStyle = Windows.Forms.FormBorderStyle.None
                    obj.ControlBox = False
                    obj.Text = ""
                    obj.WindowState = FormWindowState.Maximized
                    obj.MdiParent = Me
                    obj.Show()
                Else
                    Dim result As String = MessageBoxEx.Show("Invalid Password ", "Para Setting", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
                End If
            End If
        End If
        testDialog.Dispose()

    End Sub

    Private Sub btnMain_Click(sender As System.Object, e As System.EventArgs) Handles btnMain.Click
        gDiag = False
        frmDiag.Timer1.Enabled = False
        Dim frm As Form
        Dim i As Integer = 0
        Dim HIDEFRM As String = ""
        Dim cnt As Integer = My.Application.OpenForms.Count
        Dim CLOSEFRM(cnt) As String
        btnJobData.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        btnControls.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        btnDiag.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        btnPara.Image = Global.iotPIPECLEDING.My.Resources.btnorg

        btnMain.Image = Global.iotPIPECLEDING.My.Resources.btngreen

        objSC1.Togdataread()
        objSC1.Lblread()

        Try
            'For Each frm In Me.MdiChildren
            'If Not frm Is FrmSC1 Then frmEssc.Show()
            ' Next

            For Each frm In My.Application.OpenForms
                ''MessageBox.Show(frm.Name)
                If frm.Name = "MDIParent1" Or frm.Name = "FrmSC1" Then
                    objSC1.Show()
                ElseIf frm.Name = "frmAux" Then
                    HIDEFRM = frm.Name
                ElseIf frm.Name = "frmjobdata" Then
                    HIDEFRM = frm.Name
                ElseIf frm.Name = "frmcontrols" Then
                    HIDEFRM = frm.Name
                Else
                    CLOSEFRM(i) = frm.Name
                    i = i + 1
                End If
            Next
            Dim x As Integer = 0
            For x = 0 To i
                If CLOSEFRM(x) <> "" Then
                    Dim myForm As Form = Application.OpenForms(CLOSEFRM(x))
                    myForm.Close()

                End If
            Next
            If HIDEFRM <> "" Then
                Dim myForm As Form = Application.OpenForms(HIDEFRM)
                myForm.Hide()
                objJobData.Hide()
                objcontrols.Hide()
                objAux.Hide()

            End If

        Catch ex As Exception
            MessageBox.Show("Error in btnMain_Click method of MDIParent module, Error : " + ex.Message.ToString())
        End Try
        FrmSC1.Activate()
    End Sub

    'Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs)
    '    Timer1.Enabled = False
    '    Try
    '        Dim time As Date = Date.Now
    '        Dim currhour As Integer
    '        Dim currminute As Integer
    '        Dim ReportHour As Integer
    '        Dim ReportMinute As Integer
    '        currhour = time.Hour
    '        currminute = time.Minute
    '        ReportHour = 8
    '        ReportMinute = 0
    '        If currhour = ReportHour AndAlso currminute = ReportMinute Then
    '            ' DataSync(ProgressBar1)
    '        End If
    '    Catch ex As Exception
    '        'writeLog(ex.Message)
    '    End Try
    '    Timer1.Enabled = True
    '    lblTime.Text = Format(Now, "dd-MM-yyyy HH:mm")
    'End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles btnWNote.Click
        BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        btnMain.Image = Global.iotPIPECLEDING.My.Resources.btnorg

        'Check ERPLN DB Connectivity
        Using myservice As New SQLDB()
            ERPLNDBConnectivity = myservice.checkERPLNDBConnectivity()
        End Using

        If ERPLNDBConnectivity Then
            Dim obj As New frmWNote
            obj.TopLevel = False
            obj.Dock = DockStyle.Fill
            obj.FormBorderStyle = Windows.Forms.FormBorderStyle.None
            obj.ControlBox = False
            obj.Text = ""
            obj.WindowState = FormWindowState.Maximized
            obj.MdiParent = Me
            obj.Show()
        Else
            MessageBoxEx.Show("Network is not available.", "Welding Note", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString()
        End If
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles btnBatch.Click
        BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btnorg
        btnMain.Image = Global.iotPIPECLEDING.My.Resources.btnorg

        'Check ERPLN DB Connectivity
        Using myservice As New SQLDB()
            ERPLNDBConnectivity = myservice.checkERPLNDBConnectivity()
        End Using

        If ERPLNDBConnectivity Then
            Dim obj As New frmBatch
            obj.TopLevel = False
            obj.Dock = DockStyle.Fill
            obj.FormBorderStyle = Windows.Forms.FormBorderStyle.None
            obj.ControlBox = False
            obj.Text = ""
            obj.WindowState = FormWindowState.Maximized
            obj.MdiParent = Me
            obj.Show()
        Else
            MessageBoxEx.Show("Network is not available.", "Allowed Batch", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString()
        End If

    End Sub

    Private Sub BtnControl_Click(sender As Object, e As EventArgs) Handles btnControls.Click
        If gcontrols = False Then
            gDiag = False
            frmDiag.Timer1.Enabled = False
            objcontrols.TopLevel = False
            objcontrols.Dock = DockStyle.Fill
            objcontrols.FormBorderStyle = Windows.Forms.FormBorderStyle.None
            objcontrols.ControlBox = False
            objcontrols.Text = ""
            objcontrols.WindowState = FormWindowState.Maximized
            objcontrols.MdiParent = Me
            objcontrols.Show()
            objJobData.Hide()
            objAux.Hide()
            btnPara.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnControls.Image = Global.iotPIPECLEDING.My.Resources.btngreen
            BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnJobData.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnMain.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnDiag.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            gcontrols = True

        Else
            gDiag = False
            frmDiag.Timer1.Enabled = False
            objcontrols.Show()
            objJobData.Hide()
            objAux.Hide()
            btnControls.Image = Global.iotPIPECLEDING.My.Resources.btngreen
            BtnAux.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnJobData.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnMain.Image = Global.iotPIPECLEDING.My.Resources.btnorg
            btnDiag.Image = Global.iotPIPECLEDING.My.Resources.btnorg

        End If
    End Sub
End Class




