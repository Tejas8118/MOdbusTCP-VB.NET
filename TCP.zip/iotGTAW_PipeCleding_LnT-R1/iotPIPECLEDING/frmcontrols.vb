﻿Imports System.Data
Imports System.Data.OleDb
Imports System.Threading
Imports System.Net.HttpWebRequest
Imports System.Net
Imports System.Text
Imports System.Net.WebRequestMethods
Imports System.IO
Imports System.Configuration


Public Class frmcontrols
    Dim tx As String = ""
    Dim rx As String = ""
    Dim rs As New Resizer

    Dim plcinstrg As String = ""
    Dim digits1() As Integer
    Dim digits2() As Integer
    Dim digits3() As Integer
    Dim digits4() As Integer
    Dim digits5() As Integer
    Dim digits6() As Integer
    Dim digits7() As Integer
    Dim digits8() As Integer
    Dim digits9() As Integer
    Dim digits10() As Integer
    Dim errno As Integer = 0

    Private Sub frmcontrols_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ''   rs.FindAllControls(Me)
        Me.WindowState = FormWindowState.Maximized


    End Sub
    Private Sub Frmcontrols_Activated(sender As Object, e As System.EventArgs) Handles Me.Activated
        '//////////// Togle Read Function //////////////
        Togleread()
    End Sub

    ''Private Sub FrmSC1_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
    ''    '' Me.Text = ""
    ''    Me.WindowState = FormWindowState.Maximized
    ''    Me.Dock = DockStyle.Fill
    ''    Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
    ''    Me.ControlBox = False
    ''    Me.MaximizeBox = False
    ''    Me.MinimizeBox = False
    ''    Me.ShowIcon = False
    ''    Me.Icon = Nothing
    ''End Sub

    Public Sub Togleread()
        Try
            errno = 0
            If isConnection = True Then
                '//////////////   Slow/Rapid ////////////////
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 00 0B 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 4 Then
                    If x1(6) = "02" And x1(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x1(10) & x1(9)))
                        digits1 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 1
                        '///////////////// check condition  //////////////////////
                        If digits1(0) = 1 Then
                            btnRapid.BackColor = Color.LimeGreen
                            btnslow.BackColor = Color.Orange
                        End If

                        If digits1(1) = 1 Then
                            btnslow.BackColor = Color.LimeGreen
                            btnRapid.BackColor = Color.Orange
                        End If

                    End If
                End If



                '//////////////   Head A / Head B ////////////////
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 00 D8 00 02", 50)
                Dim x2() As String = plcinstrg.Split(" "c)
                If x2.Count >= 4 Then
                    If x2(6) = "02" And x2(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x2(10) & x2(9)))
                        digits2 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 2
                        '///////////////// check condition  //////////////////////
                        If digits2(0) = 1 Then
                            btnHeadAONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.headAON
                            btnHeadAONOFF.Tag = 1
                        Else
                            btnHeadAONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.headAOFF
                            btnHeadAONOFF.Tag = 0
                        End If

                        'If digits2(1) = 1 Then
                        '    btnHeadBONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.headBON
                        '    btnHeadBONOFF.Tag = 1
                        'Else
                        '    btnHeadBONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.headBOFF
                        '    btnHeadBONOFF.Tag = 0
                        'End If

                    End If
                End If




                '//////////////   Power Source ON/OFF ////////////////
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 00 C8 00 02", 50)
                Dim x3() As String = plcinstrg.Split(" "c)
                If x3.Count >= 4 Then
                    If x3(6) = "02" And x3(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x3(10) & x3(9)))
                        digits3 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 3
                        '///////////////// check condition  //////////////////////
                        If digits3(0) = 1 Then
                            btnWCPSON.BackgroundImage = Global.iotPIPECLEDING.My.Resources.psON
                        Else
                            btnWCPSON.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pson1
                        End If

                        If digits3(1) = 1 Then

                            btnWCPSOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.psOFF
                        Else
                            btnWCPSOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.psoff1
                        End If

                    End If
                End If



                '//////////////  Read Resume ON/Off ////////////////
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 00 8C 00 01", 50)
                Dim x4() As String = plcinstrg.Split(" "c)
                If x4.Count >= 4 Then
                    If x4(6) = "02" And x4(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x4(10) & x4(9)))
                        digits4 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 4
                        '///////////////// check condition  //////////////////////
                        If digits4(0) = 1 Then
                            btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resumeg
                        Else
                            btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resumeb
                        End If

                    End If
                End If



                '////////////////////
            End If
        Catch ex As Exception
            Dim result1 As String = MessageBoxEx.Show("Error in FrmControls Analog read Method : " + ex.Message.ToString() + errno.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString

            'MessageBox.Show("Error in FrmControls  Toogle read Method : " + ex.Message.ToString() + errno.ToString())
        End Try
    End Sub

    'Private Sub btnHeadAONOFF_Click(sender As Object, e As EventArgs) Handles btnHeadAONOFF.Click
    '    If gLogin = False Then
    '        Dim result1 As String = MessageBoxEx.Show("Please Login...", "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
    '    Else
    '        If e Is EventArgs.Empty Then
    '        Else
    '            If btnHeadAONOFF.Tag = 0 Then

    '                btnHeadAONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.headAON
    '                btnHeadAONOFF.Tag = 1
    '                If isConnection = True Then
    '                    tx = ""
    '                    rx = ""

    '                    tx = "00 00 00 00 00 06 02 05 00 D8 FF 00"
    '                    rx = TCPComA(tx, 10)
    '                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
    '                End If
    '                If rx.Count > 8 Then

    '                End If
    '            Else
    '                btnHeadAONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.headAOFF
    '                btnHeadAONOFF.Tag = 0
    '                If isConnection = True Then
    '                    tx = ""
    '                    rx = ""

    '                    tx = "00 00 00 00 00 06 02 05 00 D8 00 00"
    '                    rx = TCPComA(tx, 10)
    '                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
    '                End If
    '                If rx.Count > 8 Then

    '                End If
    '            End If

    '        End If
    '    End If
    'End Sub

    'Private Sub btnHeadBONOFF_Click(sender As Object, e As EventArgs) Handles btnHeadBONOFF.Click
    '    If e Is EventArgs.Empty Then
    '    Else
    '        If btnHeadBONOFF.Tag = 0 Then
    '            btnHeadBONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.headBON
    '            btnHeadBONOFF.Tag = 1
    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""

    '                tx = "00 00 00 00 00 06 02 05 00 E2 FF 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 8 Then

    '            End If
    '        Else
    '            btnHeadBONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.headBOFF
    '            btnHeadBONOFF.Tag = 0
    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""

    '                tx = "00 00 00 00 00 06 02 05 00 E2 00 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 8 Then

    '            End If
    '        End If

    '    End If
    'End Sub

    Private Sub btnWeldStart_GotFocus(sender As Object, e As EventArgs) Handles btnWeldStart.GotFocus
        'btnWeldStart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.startOn
        'Thread.Sleep(1500)
        'btnWeldStart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.startE
    End Sub

    Private Sub btnWeldStart_Click(sender As Object, e As EventArgs) Handles btnWeldStart.Click
        Try

            If isConnection = True Then
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 CA FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                'Thread.Sleep(300)
                'tx = ""
                'rx = ""
                'tx = "02 05 00 CA FF 00 AC 37"
                'rx = TCPComA(tx, 10)
                btnWeldStart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.startOn
                btnWeldStop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stopE

                Thread.Sleep(500)

                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 CA 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                'Thread.Sleep(300)
                'tx = ""
                'rx = ""
                'tx = "00 00 00 00 00 06 02 05 00 CA 00 00"
                'rx = TCPComA(tx, 10)



            End If

            Timer1.Interval = 10000
            Timer1.Enabled = True

        Catch ex As Exception
            MessageBox.Show("Error in RS485 Communivation : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub btnWeldStop_GotFocus(sender As Object, e As EventArgs) Handles btnWeldStop.GotFocus
        'btnWeldStop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stopD
        'Thread.Sleep(1500)
        'btnWeldStop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stopE
    End Sub

    Private Sub btnWeldStop_Click(sender As Object, e As EventArgs) Handles btnWeldStop.Click
        Try

            If isConnection = True Then
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 CB FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                Thread.Sleep(300)
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 CB FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                Thread.Sleep(700)

                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 CB 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                Thread.Sleep(300)
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 CB 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                btnWeldStop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stopD
                btnWeldStart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.startE

            End If
            If rx.Count > 8 Then

            End If
        Catch ex As Exception
            MessageBox.Show("Error in RS485 Communivation : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub btnWCPSON_Click(sender As Object, e As EventArgs) Handles btnWCPSON.Click

        Try

            If isConnection = True Then
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 C9 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                Thread.Sleep(300)
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 C9 00 00"
                rx = TCPComA(tx, 10)

                Thread.Sleep(500)
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 C8 FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                btnWCPSOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.psoff1
                btnWCPSON.BackgroundImage = Global.iotPIPECLEDING.My.Resources.psON
            End If
        Catch ex As Exception
            MessageBox.Show("Error in RS485 Communivation : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub btnWCPSOFF_Click(sender As Object, e As EventArgs) Handles btnWCPSOFF.Click
        Try


            If isConnection = True Then
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 C8 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                Thread.Sleep(400)
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 C8 00 00"
                rx = TCPComA(tx, 10)

                Thread.Sleep(800)
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 C9 FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                btnWCPSOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.psOFF
                btnWCPSON.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pson1
            End If
        Catch ex As Exception
            MessageBox.Show("Error in RS485 Communivation : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub btnRapid_Click(sender As Object, e As EventArgs) Handles btnRapid.Click
        Try

            If isConnection = True Then
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 0C 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                Thread.Sleep(700)

                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 0B FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                btnRapid.BackColor = Color.LimeGreen
                btnslow.BackColor = Color.Orange
            End If
        Catch ex As Exception
            MessageBox.Show("Error in RS485 Communivation : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub btnslow_Click(sender As Object, e As EventArgs) Handles btnslow.Click
        Try

            If isConnection = True Then
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 0B 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                Thread.Sleep(700)
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 0C FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                btnslow.BackColor = Color.LimeGreen
                btnRapid.BackColor = Color.Orange

            End If
        Catch ex As Exception
            MessageBox.Show("Error in RS485 Communivation : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub btncw_Click(sender As Object, e As EventArgs) Handles btncw.Click
        If e Is EventArgs.Empty Then
        Else
            If btncw.Tag = 0 Then
                btncw.BackgroundImage = Global.iotPIPECLEDING.My.Resources.cw1
                btnccw.Enabled = False
                btncw.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 9E FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            Else
                btncw.BackgroundImage = Global.iotPIPECLEDING.My.Resources.cw
                btnccw.Enabled = True
                btncw.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 9E 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If
    End Sub

    Private Sub btnccw_Click(sender As Object, e As EventArgs) Handles btnccw.Click
        If e Is EventArgs.Empty Then
        Else
            If btnccw.Tag = 0 Then
                btnccw.BackgroundImage = Global.iotPIPECLEDING.My.Resources.ccw1
                btncw.Enabled = False
                btnccw.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 9F FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            Else
                btnccw.BackgroundImage = Global.iotPIPECLEDING.My.Resources.ccw
                btncw.Enabled = True
                btnccw.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 9F 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If
    End Sub

    Private Sub btnstop_Click(sender As Object, e As EventArgs) Handles btnstop.Click
        Try

            btncw.Enabled = True
            btnccw.Enabled = True
            btncw.BackgroundImage = Global.iotPIPECLEDING.My.Resources.cw
            btnccw.BackgroundImage = Global.iotPIPECLEDING.My.Resources.ccw
            If isConnection = True Then
                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 00 9E 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                Thread.Sleep(400)
                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 00 9F 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)


            End If
        Catch ex As Exception
            MessageBox.Show("Error in Stop button / RS485 Communivation : " + ex.Message.ToString())
        End Try

    End Sub

    Private Sub btnresume_Click(sender As Object, e As EventArgs) Handles btnresume.Click
        If e Is EventArgs.Empty Then
        Else
            If btnresume.Tag = 0 Then

                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 8C FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
                btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resumeg
                btnresume.Tag = 1
            Else

                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 8C 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
                btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resumeb

                btnresume.Tag = 0
            End If

        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        '//////////////  Read Resume ON/Off ////////////////
        plcinstrg = ""
        plcinstrg = TCPComA("00 00 00 00 00 06 02 01 00 8C 00 01", 50)
        Dim x5() As String = plcinstrg.Split(" "c)
        If x5.Count >= 4 Then
            If x5(6) = "02" And x5(7) = "01" Then
                Dim bin As String = ReverseString(Hex2Bin(x5(10) & x5(9)))
                digits9 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                errno = 3
            End If
        End If

        '///////////////// check condition  //////////////////////
        If digits9(0) = 1 Then
            btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resumeg
        Else
            btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resumeb
        End If
        Timer1.Enabled = False
    End Sub


End Class