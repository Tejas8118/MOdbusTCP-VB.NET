﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmcontrols
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ElementHost4 = New System.Windows.Forms.Integration.ElementHost()
        Me.UserControl51 = New iotPIPECLEDING.UserControl5()
        Me.ElementHost3 = New System.Windows.Forms.Integration.ElementHost()
        Me.UserControl21 = New iotPIPECLEDING.UserControl2()
        Me.btnccw = New System.Windows.Forms.Button()
        Me.btncw = New System.Windows.Forms.Button()
        Me.btnRapid = New System.Windows.Forms.Button()
        Me.btnslow = New System.Windows.Forms.Button()
        Me.btnstop = New System.Windows.Forms.Button()
        Me.panelPara = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblAi8 = New System.Windows.Forms.TextBox()
        Me.lblCurrent = New System.Windows.Forms.TextBox()
        Me.lblGasflow2 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblJobtemp = New System.Windows.Forms.TextBox()
        Me.txtTRC1speed = New System.Windows.Forms.Label()
        Me.LblTRAVELSPEED = New System.Windows.Forms.TextBox()
        Me.lblVoltage2 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.lblGASFLOW = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblVoltage = New System.Windows.Forms.TextBox()
        Me.lblCurrent2 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.PanelAxisPosition = New System.Windows.Forms.Panel()
        Me.lblXSPEED = New System.Windows.Forms.TextBox()
        Me.lblpmb4 = New System.Windows.Forms.Label()
        Me.lblpmb1 = New System.Windows.Forms.Label()
        Me.lblpmb5 = New System.Windows.Forms.Label()
        Me.lblpmb3 = New System.Windows.Forms.Label()
        Me.lblRPOS = New System.Windows.Forms.TextBox()
        Me.lblAPOS = New System.Windows.Forms.TextBox()
        Me.lblpmb2 = New System.Windows.Forms.Label()
        Me.lblTPOS = New System.Windows.Forms.TextBox()
        Me.lblALASTPOS = New System.Windows.Forms.TextBox()
        Me.lblTLASTPOS = New System.Windows.Forms.TextBox()
        Me.lblalarm = New System.Windows.Forms.Label()
        Me.lblRLASTPOS = New System.Windows.Forms.TextBox()
        Me.lblfaulty = New System.Windows.Forms.Label()
        Me.lblRSPEED = New System.Windows.Forms.TextBox()
        Me.lblAuto = New System.Windows.Forms.Label()
        Me.lblASPEED = New System.Windows.Forms.TextBox()
        Me.LblHealthy = New System.Windows.Forms.Label()
        Me.lblXPOS = New System.Windows.Forms.TextBox()
        Me.lblXLASTPOS = New System.Windows.Forms.TextBox()
        Me.lblTSPEED = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.ElementHost8 = New System.Windows.Forms.Integration.ElementHost()
        Me.GastestB1 = New iotPIPECLEDING.GastestB()
        Me.ElementHost2 = New System.Windows.Forms.Integration.ElementHost()
        Me.WireoutB1 = New iotPIPECLEDING.WireoutB()
        Me.ElementHost1 = New System.Windows.Forms.Integration.ElementHost()
        Me.WireinB1 = New iotPIPECLEDING.WireinB()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ElementHost7 = New System.Windows.Forms.Integration.ElementHost()
        Me.UserControl101 = New iotPIPECLEDING.UserControl10()
        Me.ElementHost6 = New System.Windows.Forms.Integration.ElementHost()
        Me.UserControl91 = New iotPIPECLEDING.UserControl9()
        Me.ElementHost5 = New System.Windows.Forms.Integration.ElementHost()
        Me.UserControl82 = New iotPIPECLEDING.UserControl8()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnWCPSOFF = New System.Windows.Forms.Button()
        Me.btnWCPSON = New System.Windows.Forms.Button()
        Me.btnHeadAONOFF = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnresume = New System.Windows.Forms.Button()
        Me.btnWeldStart = New System.Windows.Forms.Button()
        Me.btnWeldStop = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        Me.panelPara.SuspendLayout()
        Me.PanelAxisPosition.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.ElementHost4)
        Me.Panel1.Controls.Add(Me.ElementHost3)
        Me.Panel1.Controls.Add(Me.btnccw)
        Me.Panel1.Controls.Add(Me.btncw)
        Me.Panel1.Controls.Add(Me.btnRapid)
        Me.Panel1.Controls.Add(Me.btnslow)
        Me.Panel1.Controls.Add(Me.btnstop)
        Me.Panel1.Location = New System.Drawing.Point(846, 34)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(426, 732)
        Me.Panel1.TabIndex = 0
        '
        'ElementHost4
        '
        Me.ElementHost4.Location = New System.Drawing.Point(20, 592)
        Me.ElementHost4.Name = "ElementHost4"
        Me.ElementHost4.Size = New System.Drawing.Size(373, 125)
        Me.ElementHost4.TabIndex = 78
        Me.ElementHost4.Text = "ElementHost4"
        Me.ElementHost4.Child = Me.UserControl51
        '
        'ElementHost3
        '
        Me.ElementHost3.Location = New System.Drawing.Point(18, 243)
        Me.ElementHost3.Name = "ElementHost3"
        Me.ElementHost3.Size = New System.Drawing.Size(374, 330)
        Me.ElementHost3.TabIndex = 77
        Me.ElementHost3.Text = "ElementHost3"
        Me.ElementHost3.Child = Me.UserControl21
        '
        'btnccw
        '
        Me.btnccw.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnccw.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.ccw
        Me.btnccw.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnccw.FlatAppearance.BorderSize = 0
        Me.btnccw.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnccw.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnccw.Location = New System.Drawing.Point(286, 24)
        Me.btnccw.Name = "btnccw"
        Me.btnccw.Size = New System.Drawing.Size(97, 91)
        Me.btnccw.TabIndex = 76
        Me.btnccw.UseVisualStyleBackColor = False
        '
        'btncw
        '
        Me.btncw.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btncw.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.cw
        Me.btncw.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btncw.FlatAppearance.BorderSize = 0
        Me.btncw.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncw.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncw.Location = New System.Drawing.Point(15, 31)
        Me.btncw.Name = "btncw"
        Me.btncw.Size = New System.Drawing.Size(97, 91)
        Me.btncw.TabIndex = 75
        Me.btncw.UseVisualStyleBackColor = False
        '
        'btnRapid
        '
        Me.btnRapid.BackColor = System.Drawing.Color.Orange
        Me.btnRapid.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRapid.Location = New System.Drawing.Point(258, 161)
        Me.btnRapid.Name = "btnRapid"
        Me.btnRapid.Size = New System.Drawing.Size(130, 61)
        Me.btnRapid.TabIndex = 73
        Me.btnRapid.Text = "Rapid"
        Me.btnRapid.UseVisualStyleBackColor = False
        '
        'btnslow
        '
        Me.btnslow.BackColor = System.Drawing.Color.Orange
        Me.btnslow.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnslow.Location = New System.Drawing.Point(22, 161)
        Me.btnslow.Name = "btnslow"
        Me.btnslow.Size = New System.Drawing.Size(130, 61)
        Me.btnslow.TabIndex = 72
        Me.btnslow.Text = "Slow"
        Me.btnslow.UseVisualStyleBackColor = False
        '
        'btnstop
        '
        Me.btnstop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.stopE
        Me.btnstop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnstop.FlatAppearance.BorderSize = 0
        Me.btnstop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnstop.Location = New System.Drawing.Point(145, 26)
        Me.btnstop.Name = "btnstop"
        Me.btnstop.Size = New System.Drawing.Size(116, 95)
        Me.btnstop.TabIndex = 71
        Me.btnstop.UseVisualStyleBackColor = True
        '
        'panelPara
        '
        Me.panelPara.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.panelPara.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panelPara.Controls.Add(Me.Label2)
        Me.panelPara.Controls.Add(Me.lblAi8)
        Me.panelPara.Controls.Add(Me.lblCurrent)
        Me.panelPara.Controls.Add(Me.lblGasflow2)
        Me.panelPara.Controls.Add(Me.Label3)
        Me.panelPara.Controls.Add(Me.lblJobtemp)
        Me.panelPara.Controls.Add(Me.txtTRC1speed)
        Me.panelPara.Controls.Add(Me.LblTRAVELSPEED)
        Me.panelPara.Controls.Add(Me.lblVoltage2)
        Me.panelPara.Controls.Add(Me.Label22)
        Me.panelPara.Controls.Add(Me.lblGASFLOW)
        Me.panelPara.Controls.Add(Me.Label17)
        Me.panelPara.Controls.Add(Me.Label1)
        Me.panelPara.Controls.Add(Me.Label12)
        Me.panelPara.Controls.Add(Me.lblVoltage)
        Me.panelPara.Controls.Add(Me.lblCurrent2)
        Me.panelPara.Controls.Add(Me.Label7)
        Me.panelPara.Controls.Add(Me.Label8)
        Me.panelPara.Controls.Add(Me.Label9)
        Me.panelPara.Location = New System.Drawing.Point(14, 34)
        Me.panelPara.Margin = New System.Windows.Forms.Padding(6)
        Me.panelPara.Name = "panelPara"
        Me.panelPara.Size = New System.Drawing.Size(271, 390)
        Me.panelPara.TabIndex = 11
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label2.Location = New System.Drawing.Point(20, 318)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(117, 22)
        Me.Label2.TabIndex = 51
        Me.Label2.Text = "SPARE"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAi8
        '
        Me.lblAi8.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAi8.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAi8.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAi8.Location = New System.Drawing.Point(150, 313)
        Me.lblAi8.Margin = New System.Windows.Forms.Padding(2)
        Me.lblAi8.Name = "lblAi8"
        Me.lblAi8.Size = New System.Drawing.Size(93, 32)
        Me.lblAi8.TabIndex = 50
        Me.lblAi8.Text = "0000.0"
        '
        'lblCurrent
        '
        Me.lblCurrent.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblCurrent.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrent.ForeColor = System.Drawing.SystemColors.Info
        Me.lblCurrent.Location = New System.Drawing.Point(150, 44)
        Me.lblCurrent.Margin = New System.Windows.Forms.Padding(2)
        Me.lblCurrent.Name = "lblCurrent"
        Me.lblCurrent.Size = New System.Drawing.Size(93, 32)
        Me.lblCurrent.TabIndex = 48
        Me.lblCurrent.Text = "0000.0"
        '
        'lblGasflow2
        '
        Me.lblGasflow2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblGasflow2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGasflow2.ForeColor = System.Drawing.SystemColors.Info
        Me.lblGasflow2.Location = New System.Drawing.Point(151, 239)
        Me.lblGasflow2.Name = "lblGasflow2"
        Me.lblGasflow2.Size = New System.Drawing.Size(93, 31)
        Me.lblGasflow2.TabIndex = 47
        Me.lblGasflow2.Text = "0000.0"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label3.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Label3.Location = New System.Drawing.Point(14, 242)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(111, 22)
        Me.Label3.TabIndex = 46
        Me.Label3.Text = "GAS FLOW-2"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblJobtemp
        '
        Me.lblJobtemp.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblJobtemp.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJobtemp.ForeColor = System.Drawing.SystemColors.Info
        Me.lblJobtemp.Location = New System.Drawing.Point(150, 276)
        Me.lblJobtemp.Margin = New System.Windows.Forms.Padding(2)
        Me.lblJobtemp.Name = "lblJobtemp"
        Me.lblJobtemp.Size = New System.Drawing.Size(93, 32)
        Me.lblJobtemp.TabIndex = 45
        Me.lblJobtemp.Text = "0000.0"
        '
        'txtTRC1speed
        '
        Me.txtTRC1speed.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRC1speed.ForeColor = System.Drawing.Color.DarkBlue
        Me.txtTRC1speed.Location = New System.Drawing.Point(13, 357)
        Me.txtTRC1speed.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.txtTRC1speed.Name = "txtTRC1speed"
        Me.txtTRC1speed.Size = New System.Drawing.Size(112, 17)
        Me.txtTRC1speed.TabIndex = 44
        Me.txtTRC1speed.Text = "TRAVEL SPEED"
        Me.txtTRC1speed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblTRAVELSPEED
        '
        Me.LblTRAVELSPEED.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.LblTRAVELSPEED.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTRAVELSPEED.ForeColor = System.Drawing.SystemColors.Info
        Me.LblTRAVELSPEED.Location = New System.Drawing.Point(150, 349)
        Me.LblTRAVELSPEED.Margin = New System.Windows.Forms.Padding(2)
        Me.LblTRAVELSPEED.Name = "LblTRAVELSPEED"
        Me.LblTRAVELSPEED.Size = New System.Drawing.Size(93, 32)
        Me.LblTRAVELSPEED.TabIndex = 43
        Me.LblTRAVELSPEED.Text = "0000.0"
        '
        'lblVoltage2
        '
        Me.lblVoltage2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblVoltage2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVoltage2.ForeColor = System.Drawing.SystemColors.Info
        Me.lblVoltage2.Location = New System.Drawing.Point(151, 159)
        Me.lblVoltage2.Margin = New System.Windows.Forms.Padding(2)
        Me.lblVoltage2.Name = "lblVoltage2"
        Me.lblVoltage2.Size = New System.Drawing.Size(93, 32)
        Me.lblVoltage2.TabIndex = 42
        Me.lblVoltage2.Text = "0000.0"
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label22.Location = New System.Drawing.Point(20, 159)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(92, 29)
        Me.Label22.TabIndex = 41
        Me.Label22.Text = "VOLTAGE-2"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGASFLOW
        '
        Me.lblGASFLOW.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblGASFLOW.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGASFLOW.ForeColor = System.Drawing.SystemColors.Info
        Me.lblGASFLOW.Location = New System.Drawing.Point(151, 198)
        Me.lblGASFLOW.Margin = New System.Windows.Forms.Padding(2)
        Me.lblGASFLOW.Name = "lblGASFLOW"
        Me.lblGASFLOW.Size = New System.Drawing.Size(93, 32)
        Me.lblGASFLOW.TabIndex = 40
        Me.lblGASFLOW.Text = "0000.0"
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label17.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label17.Location = New System.Drawing.Point(14, 282)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(111, 22)
        Me.Label17.TabIndex = 37
        Me.Label17.Text = "JOB TEMP"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Label1.Location = New System.Drawing.Point(17, 203)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(111, 22)
        Me.Label1.TabIndex = 39
        Me.Label1.Text = "GAS FLOW-1"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.SkyBlue
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label12.Location = New System.Drawing.Point(-1, -1)
        Me.Label12.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(260, 35)
        Me.Label12.TabIndex = 15
        Me.Label12.Text = "Parameters"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblVoltage
        '
        Me.lblVoltage.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblVoltage.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVoltage.ForeColor = System.Drawing.SystemColors.Info
        Me.lblVoltage.Location = New System.Drawing.Point(151, 82)
        Me.lblVoltage.Margin = New System.Windows.Forms.Padding(2)
        Me.lblVoltage.Name = "lblVoltage"
        Me.lblVoltage.Size = New System.Drawing.Size(93, 32)
        Me.lblVoltage.TabIndex = 33
        Me.lblVoltage.Text = "0000.0"
        '
        'lblCurrent2
        '
        Me.lblCurrent2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblCurrent2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrent2.ForeColor = System.Drawing.SystemColors.Info
        Me.lblCurrent2.Location = New System.Drawing.Point(151, 121)
        Me.lblCurrent2.Margin = New System.Windows.Forms.Padding(2)
        Me.lblCurrent2.Name = "lblCurrent2"
        Me.lblCurrent2.Size = New System.Drawing.Size(93, 32)
        Me.lblCurrent2.TabIndex = 32
        Me.lblCurrent2.Text = "0000.0"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label7.Location = New System.Drawing.Point(17, 89)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(92, 22)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "VOLTAGE-1"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label8.Location = New System.Drawing.Point(20, 128)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(92, 22)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "CURRENT-2"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label9.Location = New System.Drawing.Point(17, 47)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(92, 22)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "CURRENT-1"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PanelAxisPosition
        '
        Me.PanelAxisPosition.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PanelAxisPosition.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PanelAxisPosition.Controls.Add(Me.lblXSPEED)
        Me.PanelAxisPosition.Controls.Add(Me.lblpmb4)
        Me.PanelAxisPosition.Controls.Add(Me.lblpmb1)
        Me.PanelAxisPosition.Controls.Add(Me.lblpmb5)
        Me.PanelAxisPosition.Controls.Add(Me.lblpmb3)
        Me.PanelAxisPosition.Controls.Add(Me.lblRPOS)
        Me.PanelAxisPosition.Controls.Add(Me.lblAPOS)
        Me.PanelAxisPosition.Controls.Add(Me.lblpmb2)
        Me.PanelAxisPosition.Controls.Add(Me.lblTPOS)
        Me.PanelAxisPosition.Controls.Add(Me.lblALASTPOS)
        Me.PanelAxisPosition.Controls.Add(Me.lblTLASTPOS)
        Me.PanelAxisPosition.Controls.Add(Me.lblalarm)
        Me.PanelAxisPosition.Controls.Add(Me.lblRLASTPOS)
        Me.PanelAxisPosition.Controls.Add(Me.lblfaulty)
        Me.PanelAxisPosition.Controls.Add(Me.lblRSPEED)
        Me.PanelAxisPosition.Controls.Add(Me.lblAuto)
        Me.PanelAxisPosition.Controls.Add(Me.lblASPEED)
        Me.PanelAxisPosition.Controls.Add(Me.LblHealthy)
        Me.PanelAxisPosition.Controls.Add(Me.lblXPOS)
        Me.PanelAxisPosition.Controls.Add(Me.lblXLASTPOS)
        Me.PanelAxisPosition.Controls.Add(Me.lblTSPEED)
        Me.PanelAxisPosition.Controls.Add(Me.Label19)
        Me.PanelAxisPosition.Controls.Add(Me.Label16)
        Me.PanelAxisPosition.Controls.Add(Me.Label15)
        Me.PanelAxisPosition.Controls.Add(Me.Label13)
        Me.PanelAxisPosition.Controls.Add(Me.Label11)
        Me.PanelAxisPosition.Controls.Add(Me.Label6)
        Me.PanelAxisPosition.Controls.Add(Me.Label5)
        Me.PanelAxisPosition.Controls.Add(Me.Label4)
        Me.PanelAxisPosition.Location = New System.Drawing.Point(291, 34)
        Me.PanelAxisPosition.Margin = New System.Windows.Forms.Padding(6)
        Me.PanelAxisPosition.Name = "PanelAxisPosition"
        Me.PanelAxisPosition.Size = New System.Drawing.Size(547, 390)
        Me.PanelAxisPosition.TabIndex = 13
        '
        'lblXSPEED
        '
        Me.lblXSPEED.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblXSPEED.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblXSPEED.ForeColor = System.Drawing.SystemColors.Info
        Me.lblXSPEED.Location = New System.Drawing.Point(99, 76)
        Me.lblXSPEED.Name = "lblXSPEED"
        Me.lblXSPEED.Size = New System.Drawing.Size(93, 31)
        Me.lblXSPEED.TabIndex = 47
        Me.lblXSPEED.Text = "0000.0"
        '
        'lblpmb4
        '
        Me.lblpmb4.Image = Global.iotPIPECLEDING.My.Resources.Resources.pmb4SG
        Me.lblpmb4.Location = New System.Drawing.Point(419, 320)
        Me.lblpmb4.Name = "lblpmb4"
        Me.lblpmb4.Size = New System.Drawing.Size(52, 52)
        Me.lblpmb4.TabIndex = 29
        '
        'lblpmb1
        '
        Me.lblpmb1.Image = Global.iotPIPECLEDING.My.Resources.Resources.pmb1SG
        Me.lblpmb1.Location = New System.Drawing.Point(236, 280)
        Me.lblpmb1.Name = "lblpmb1"
        Me.lblpmb1.Size = New System.Drawing.Size(52, 52)
        Me.lblpmb1.TabIndex = 30
        '
        'lblpmb5
        '
        Me.lblpmb5.Image = Global.iotPIPECLEDING.My.Resources.Resources.pmb5SG
        Me.lblpmb5.Location = New System.Drawing.Point(482, 296)
        Me.lblpmb5.Name = "lblpmb5"
        Me.lblpmb5.Size = New System.Drawing.Size(52, 52)
        Me.lblpmb5.TabIndex = 27
        '
        'lblpmb3
        '
        Me.lblpmb3.Image = Global.iotPIPECLEDING.My.Resources.Resources.pmb3SG
        Me.lblpmb3.Location = New System.Drawing.Point(353, 287)
        Me.lblpmb3.Name = "lblpmb3"
        Me.lblpmb3.Size = New System.Drawing.Size(52, 52)
        Me.lblpmb3.TabIndex = 28
        '
        'lblRPOS
        '
        Me.lblRPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblRPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblRPOS.Location = New System.Drawing.Point(246, 235)
        Me.lblRPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblRPOS.Name = "lblRPOS"
        Me.lblRPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblRPOS.TabIndex = 46
        Me.lblRPOS.Text = "0000.0"
        '
        'lblAPOS
        '
        Me.lblAPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAPOS.Location = New System.Drawing.Point(247, 184)
        Me.lblAPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblAPOS.Name = "lblAPOS"
        Me.lblAPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblAPOS.TabIndex = 45
        Me.lblAPOS.Text = "0000.0"
        '
        'lblpmb2
        '
        Me.lblpmb2.Image = Global.iotPIPECLEDING.My.Resources.Resources.pmb2SG
        Me.lblpmb2.Location = New System.Drawing.Point(290, 312)
        Me.lblpmb2.Name = "lblpmb2"
        Me.lblpmb2.Size = New System.Drawing.Size(52, 52)
        Me.lblpmb2.TabIndex = 26
        '
        'lblTPOS
        '
        Me.lblTPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblTPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblTPOS.Location = New System.Drawing.Point(247, 130)
        Me.lblTPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblTPOS.Name = "lblTPOS"
        Me.lblTPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblTPOS.TabIndex = 44
        Me.lblTPOS.Text = "0000.0"
        '
        'lblALASTPOS
        '
        Me.lblALASTPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblALASTPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblALASTPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblALASTPOS.Location = New System.Drawing.Point(398, 184)
        Me.lblALASTPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblALASTPOS.Name = "lblALASTPOS"
        Me.lblALASTPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblALASTPOS.TabIndex = 43
        Me.lblALASTPOS.Text = "0000.0"
        '
        'lblTLASTPOS
        '
        Me.lblTLASTPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblTLASTPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTLASTPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblTLASTPOS.Location = New System.Drawing.Point(398, 130)
        Me.lblTLASTPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblTLASTPOS.Name = "lblTLASTPOS"
        Me.lblTLASTPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblTLASTPOS.TabIndex = 42
        Me.lblTLASTPOS.Text = "0000.0"
        '
        'lblalarm
        '
        Me.lblalarm.Image = Global.iotPIPECLEDING.My.Resources.Resources.lgray
        Me.lblalarm.Location = New System.Drawing.Point(177, 310)
        Me.lblalarm.Name = "lblalarm"
        Me.lblalarm.Size = New System.Drawing.Size(55, 56)
        Me.lblalarm.TabIndex = 25
        '
        'lblRLASTPOS
        '
        Me.lblRLASTPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblRLASTPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRLASTPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblRLASTPOS.Location = New System.Drawing.Point(396, 235)
        Me.lblRLASTPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblRLASTPOS.Name = "lblRLASTPOS"
        Me.lblRLASTPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblRLASTPOS.TabIndex = 41
        Me.lblRLASTPOS.Text = "0000.0"
        '
        'lblfaulty
        '
        Me.lblfaulty.Image = Global.iotPIPECLEDING.My.Resources.Resources.fG
        Me.lblfaulty.Location = New System.Drawing.Point(116, 281)
        Me.lblfaulty.Name = "lblfaulty"
        Me.lblfaulty.Size = New System.Drawing.Size(55, 56)
        Me.lblfaulty.TabIndex = 24
        '
        'lblRSPEED
        '
        Me.lblRSPEED.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblRSPEED.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRSPEED.ForeColor = System.Drawing.SystemColors.Info
        Me.lblRSPEED.Location = New System.Drawing.Point(99, 235)
        Me.lblRSPEED.Margin = New System.Windows.Forms.Padding(2)
        Me.lblRSPEED.Name = "lblRSPEED"
        Me.lblRSPEED.Size = New System.Drawing.Size(93, 32)
        Me.lblRSPEED.TabIndex = 40
        Me.lblRSPEED.Text = "0000.0"
        '
        'lblAuto
        '
        Me.lblAuto.Image = Global.iotPIPECLEDING.My.Resources.Resources.AG
        Me.lblAuto.Location = New System.Drawing.Point(57, 281)
        Me.lblAuto.Name = "lblAuto"
        Me.lblAuto.Size = New System.Drawing.Size(55, 58)
        Me.lblAuto.TabIndex = 23
        '
        'lblASPEED
        '
        Me.lblASPEED.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblASPEED.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblASPEED.ForeColor = System.Drawing.SystemColors.Info
        Me.lblASPEED.Location = New System.Drawing.Point(99, 184)
        Me.lblASPEED.Margin = New System.Windows.Forms.Padding(2)
        Me.lblASPEED.Name = "lblASPEED"
        Me.lblASPEED.Size = New System.Drawing.Size(93, 32)
        Me.lblASPEED.TabIndex = 39
        Me.lblASPEED.Text = "0000.0"
        '
        'LblHealthy
        '
        Me.LblHealthy.Image = Global.iotPIPECLEDING.My.Resources.Resources.hgray
        Me.LblHealthy.Location = New System.Drawing.Point(2, 310)
        Me.LblHealthy.Name = "LblHealthy"
        Me.LblHealthy.Size = New System.Drawing.Size(54, 52)
        Me.LblHealthy.TabIndex = 22
        '
        'lblXPOS
        '
        Me.lblXPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblXPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblXPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblXPOS.Location = New System.Drawing.Point(249, 69)
        Me.lblXPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblXPOS.Name = "lblXPOS"
        Me.lblXPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblXPOS.TabIndex = 38
        Me.lblXPOS.Text = "0000.0"
        '
        'lblXLASTPOS
        '
        Me.lblXLASTPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblXLASTPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblXLASTPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblXLASTPOS.Location = New System.Drawing.Point(398, 69)
        Me.lblXLASTPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblXLASTPOS.Name = "lblXLASTPOS"
        Me.lblXLASTPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblXLASTPOS.TabIndex = 37
        Me.lblXLASTPOS.Text = "0000.0"
        '
        'lblTSPEED
        '
        Me.lblTSPEED.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblTSPEED.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTSPEED.ForeColor = System.Drawing.SystemColors.Info
        Me.lblTSPEED.Location = New System.Drawing.Point(99, 130)
        Me.lblTSPEED.Margin = New System.Windows.Forms.Padding(2)
        Me.lblTSPEED.Name = "lblTSPEED"
        Me.lblTSPEED.Size = New System.Drawing.Size(93, 32)
        Me.lblTSPEED.TabIndex = 34
        Me.lblTSPEED.Text = "0000.0"
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label19.Location = New System.Drawing.Point(395, 44)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(82, 24)
        Me.Label19.TabIndex = 14
        Me.Label19.Text = "LAST POS."
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label16.Location = New System.Drawing.Point(255, 43)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(77, 22)
        Me.Label16.TabIndex = 13
        Me.Label16.Text = "POSITION"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label15.Location = New System.Drawing.Point(116, 40)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(55, 24)
        Me.Label15.TabIndex = 12
        Me.Label15.Text = "SPEED"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label13.Location = New System.Drawing.Point(15, 243)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(54, 18)
        Me.Label13.TabIndex = 11
        Me.Label13.Text = "R-AXIS"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label11.Location = New System.Drawing.Point(15, 194)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(54, 18)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "A-AXIS"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label6.Location = New System.Drawing.Point(15, 138)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 18)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "T-AXIS"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label5.Location = New System.Drawing.Point(15, 76)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 18)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "X-AXIS"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.SkyBlue
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(-1, 0)
        Me.Label4.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(547, 35)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Axis  Position & Status Monitoring"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.ElementHost8)
        Me.Panel2.Controls.Add(Me.ElementHost2)
        Me.Panel2.Controls.Add(Me.ElementHost1)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.ElementHost7)
        Me.Panel2.Controls.Add(Me.ElementHost6)
        Me.Panel2.Controls.Add(Me.ElementHost5)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.btnWCPSOFF)
        Me.Panel2.Controls.Add(Me.btnWCPSON)
        Me.Panel2.Controls.Add(Me.btnHeadAONOFF)
        Me.Panel2.Location = New System.Drawing.Point(14, 433)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(641, 333)
        Me.Panel2.TabIndex = 14
        '
        'ElementHost8
        '
        Me.ElementHost8.Location = New System.Drawing.Point(374, 180)
        Me.ElementHost8.Name = "ElementHost8"
        Me.ElementHost8.Size = New System.Drawing.Size(116, 121)
        Me.ElementHost8.TabIndex = 90
        Me.ElementHost8.Text = "ElementHost8"
        Me.ElementHost8.Child = Me.GastestB1
        '
        'ElementHost2
        '
        Me.ElementHost2.Location = New System.Drawing.Point(509, 180)
        Me.ElementHost2.Name = "ElementHost2"
        Me.ElementHost2.Size = New System.Drawing.Size(116, 121)
        Me.ElementHost2.TabIndex = 89
        Me.ElementHost2.Text = "ElementHost2"
        Me.ElementHost2.Child = Me.WireoutB1
        '
        'ElementHost1
        '
        Me.ElementHost1.Location = New System.Drawing.Point(236, 180)
        Me.ElementHost1.Name = "ElementHost1"
        Me.ElementHost1.Size = New System.Drawing.Size(116, 121)
        Me.ElementHost1.TabIndex = 88
        Me.ElementHost1.Text = "ElementHost1"
        Me.ElementHost1.Child = Me.WireinB1
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(129, 225)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(86, 28)
        Me.Label10.TabIndex = 87
        Me.Label10.Text = "HEAD-B"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ElementHost7
        '
        Me.ElementHost7.Location = New System.Drawing.Point(509, 39)
        Me.ElementHost7.Name = "ElementHost7"
        Me.ElementHost7.Size = New System.Drawing.Size(116, 121)
        Me.ElementHost7.TabIndex = 86
        Me.ElementHost7.Text = "ElementHost7"
        Me.ElementHost7.Child = Me.UserControl101
        '
        'ElementHost6
        '
        Me.ElementHost6.Location = New System.Drawing.Point(236, 39)
        Me.ElementHost6.Name = "ElementHost6"
        Me.ElementHost6.Size = New System.Drawing.Size(116, 121)
        Me.ElementHost6.TabIndex = 82
        Me.ElementHost6.Text = "ElementHost6"
        Me.ElementHost6.Child = Me.UserControl91
        '
        'ElementHost5
        '
        Me.ElementHost5.Location = New System.Drawing.Point(374, 39)
        Me.ElementHost5.Name = "ElementHost5"
        Me.ElementHost5.Size = New System.Drawing.Size(116, 121)
        Me.ElementHost5.TabIndex = 81
        Me.ElementHost5.Text = "ElementHost5"
        Me.ElementHost5.Child = Me.UserControl82
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(133, 86)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(82, 28)
        Me.Label14.TabIndex = 79
        Me.Label14.Text = "HEAD-A"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnWCPSOFF
        '
        Me.btnWCPSOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.psoff1
        Me.btnWCPSOFF.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnWCPSOFF.FlatAppearance.BorderSize = 0
        Me.btnWCPSOFF.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWCPSOFF.Location = New System.Drawing.Point(15, 214)
        Me.btnWCPSOFF.Name = "btnWCPSOFF"
        Me.btnWCPSOFF.Size = New System.Drawing.Size(101, 96)
        Me.btnWCPSOFF.TabIndex = 78
        Me.btnWCPSOFF.UseVisualStyleBackColor = True
        '
        'btnWCPSON
        '
        Me.btnWCPSON.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnWCPSON.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.pson1
        Me.btnWCPSON.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnWCPSON.FlatAppearance.BorderSize = 0
        Me.btnWCPSON.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWCPSON.Location = New System.Drawing.Point(15, 19)
        Me.btnWCPSON.Name = "btnWCPSON"
        Me.btnWCPSON.Size = New System.Drawing.Size(101, 96)
        Me.btnWCPSON.TabIndex = 77
        Me.btnWCPSON.UseVisualStyleBackColor = False
        '
        'btnHeadAONOFF
        '
        Me.btnHeadAONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.headAOFF
        Me.btnHeadAONOFF.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnHeadAONOFF.FlatAppearance.BorderSize = 0
        Me.btnHeadAONOFF.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHeadAONOFF.Location = New System.Drawing.Point(132, 10)
        Me.btnHeadAONOFF.Name = "btnHeadAONOFF"
        Me.btnHeadAONOFF.Size = New System.Drawing.Size(44, 40)
        Me.btnHeadAONOFF.TabIndex = 74
        Me.btnHeadAONOFF.UseVisualStyleBackColor = True
        Me.btnHeadAONOFF.Visible = False
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.btnresume)
        Me.Panel3.Controls.Add(Me.btnWeldStart)
        Me.Panel3.Controls.Add(Me.btnWeldStop)
        Me.Panel3.Location = New System.Drawing.Point(661, 433)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(177, 333)
        Me.Panel3.TabIndex = 15
        '
        'btnresume
        '
        Me.btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.resumeb
        Me.btnresume.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnresume.FlatAppearance.BorderSize = 0
        Me.btnresume.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnresume.Location = New System.Drawing.Point(40, 219)
        Me.btnresume.Name = "btnresume"
        Me.btnresume.Size = New System.Drawing.Size(95, 90)
        Me.btnresume.TabIndex = 74
        Me.btnresume.UseVisualStyleBackColor = True
        '
        'btnWeldStart
        '
        Me.btnWeldStart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.startE
        Me.btnWeldStart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnWeldStart.FlatAppearance.BorderSize = 0
        Me.btnWeldStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWeldStart.Location = New System.Drawing.Point(29, 7)
        Me.btnWeldStart.Name = "btnWeldStart"
        Me.btnWeldStart.Size = New System.Drawing.Size(116, 95)
        Me.btnWeldStart.TabIndex = 73
        Me.btnWeldStart.UseVisualStyleBackColor = True
        '
        'btnWeldStop
        '
        Me.btnWeldStop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.stopE
        Me.btnWeldStop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnWeldStop.FlatAppearance.BorderSize = 0
        Me.btnWeldStop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWeldStop.Location = New System.Drawing.Point(29, 112)
        Me.btnWeldStop.Name = "btnWeldStop"
        Me.btnWeldStop.Size = New System.Drawing.Size(116, 95)
        Me.btnWeldStop.TabIndex = 72
        Me.btnWeldStop.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        '
        'frmcontrols
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(1280, 770)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.PanelAxisPosition)
        Me.Controls.Add(Me.panelPara)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmcontrols"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "  "
        Me.Panel1.ResumeLayout(False)
        Me.panelPara.ResumeLayout(False)
        Me.panelPara.PerformLayout()
        Me.PanelAxisPosition.ResumeLayout(False)
        Me.PanelAxisPosition.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents panelPara As Panel
    Friend WithEvents lblGasflow2 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lblJobtemp As TextBox
    Friend WithEvents txtTRC1speed As Label
    Friend WithEvents LblTRAVELSPEED As TextBox
    Friend WithEvents lblVoltage2 As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents lblGASFLOW As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents lblVoltage As TextBox
    Friend WithEvents lblCurrent2 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents PanelAxisPosition As Panel
    Friend WithEvents lblRPOS As TextBox
    Friend WithEvents lblAPOS As TextBox
    Friend WithEvents lblTPOS As TextBox
    Friend WithEvents lblALASTPOS As TextBox
    Friend WithEvents lblTLASTPOS As TextBox
    Friend WithEvents lblRLASTPOS As TextBox
    Friend WithEvents lblRSPEED As TextBox
    Friend WithEvents lblASPEED As TextBox
    Friend WithEvents lblXPOS As TextBox
    Friend WithEvents lblXLASTPOS As TextBox
    Friend WithEvents lblTSPEED As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents btnstop As Button
    Friend WithEvents btnRapid As Button
    Friend WithEvents btnslow As Button
    Friend WithEvents lblpmb1 As Label
    Friend WithEvents lblpmb4 As Label
    Friend WithEvents lblpmb3 As Label
    Friend WithEvents lblpmb5 As Label
    Friend WithEvents lblpmb2 As Label
    Friend WithEvents lblalarm As Label
    Friend WithEvents lblfaulty As Label
    Friend WithEvents lblAuto As Label
    Friend WithEvents LblHealthy As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents btnWeldStart As Button
    Friend WithEvents btnWeldStop As Button
    Friend WithEvents btnHeadAONOFF As Button
    Friend WithEvents btnWCPSOFF As Button
    Friend WithEvents btnWCPSON As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents lblCurrent As TextBox
    Friend WithEvents lblXSPEED As TextBox
    Friend UserControl81 As UserControl8
    Friend WithEvents ElementHost5 As Integration.ElementHost
    Friend UserControl82 As UserControl8
    Friend WithEvents ElementHost6 As Integration.ElementHost
    Friend UserControl91 As UserControl9
    Friend WithEvents ElementHost7 As Integration.ElementHost
    Friend UserControl101 As UserControl10
    Friend WithEvents btnccw As Button
    Friend WithEvents btncw As Button
    Friend WithEvents btnresume As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label10 As Label
    Friend WithEvents ElementHost1 As Integration.ElementHost
    Friend WireinB1 As WireinB
    Friend WithEvents ElementHost2 As Integration.ElementHost
    Friend WireoutB1 As WireoutB
    Friend WithEvents ElementHost8 As Integration.ElementHost
    Friend GastestB1 As GastestB
    Friend WithEvents ElementHost3 As Integration.ElementHost
    Friend UserControl21 As UserControl2
    Friend WithEvents ElementHost4 As Integration.ElementHost
    Friend UserControl51 As UserControl5
    Friend WithEvents Label2 As Label
    Friend WithEvents lblAi8 As TextBox
End Class
