﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDiag
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.btnSetup = New System.Windows.Forms.Button()
        Me.pnlTR = New System.Windows.Forms.Panel()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.lblSpare = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.lblTRTravelSpeed = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lblAngFluxWeight = New System.Windows.Forms.Label()
        Me.lblAngTrSpeed = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.lblAngAntiDriftTrip = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblAngCurrent = New System.Windows.Forms.Label()
        Me.lblAngVoltage = New System.Windows.Forms.Label()
        Me.lblAngJobTemp = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.lblAngFluxTemp = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblrdsa4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.lblTrolOn = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.lblFluxOvenOn = New System.Windows.Forms.Label()
        Me.lblFluxFill = New System.Windows.Forms.Label()
        Me.lblMagnetOn = New System.Windows.Forms.Label()
        Me.lblWinchOn = New System.Windows.Forms.Label()
        Me.lblIRHeatSysOn = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.lblFluxRecOn = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.lblHeadCollOn = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.lblTrControlOn = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.lblproxip = New System.Windows.Forms.Label()
        Me.lblalmsa3 = New System.Windows.Forms.Label()
        Me.lblmanauto = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.lbltrconfb = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.lblSONEM2SA4 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.lblrdsa3 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.lblST1SA5 = New System.Windows.Forms.Label()
        Me.lblEsscPSOff = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.lblFumeExtOn = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.lblHeadLampOn = New System.Windows.Forms.Label()
        Me.lblWeldStart = New System.Windows.Forms.Label()
        Me.lblalmsa4 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.lblemeron = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.lblWeldStop = New System.Windows.Forms.Label()
        Me.lblTRCWFWDRot = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.lblTRCCWREWRot = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.lblTRStartPB = New System.Windows.Forms.Label()
        Me.lblrdsa5 = New System.Windows.Forms.Label()
        Me.lblEsscPSOn = New System.Windows.Forms.Label()
        Me.lblSONEM2SA5 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.lblalmsa5 = New System.Windows.Forms.Label()
        Me.lblResetSA = New System.Windows.Forms.Label()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.lblFluxFunnDn = New System.Windows.Forms.Label()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.lblStripDn = New System.Windows.Forms.Label()
        Me.lblTREmerg = New System.Windows.Forms.Label()
        Me.lblStripUp = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.lblSONEM2SA2 = New System.Windows.Forms.Label()
        Me.lblSONEM2SA3 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.lblFluxFunnUp = New System.Windows.Forms.Label()
        Me.lblSONEM2SA1 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.lblDirSa4 = New System.Windows.Forms.Label()
        Me.lblFaultLamp = New System.Windows.Forms.Label()
        Me.lblAutoOnLamp = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.lblrdsa1 = New System.Windows.Forms.Label()
        Me.lblalmsa2 = New System.Windows.Forms.Label()
        Me.lblalmsa1 = New System.Windows.Forms.Label()
        Me.lblrdsa2 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.DIOy5 = New System.Windows.Forms.Label()
        Me.DIOy4 = New System.Windows.Forms.Label()
        Me.DIOy3 = New System.Windows.Forms.Label()
        Me.DIOy2 = New System.Windows.Forms.Label()
        Me.DIOy1 = New System.Windows.Forms.Label()
        Me.DIOy0 = New System.Windows.Forms.Label()
        Me.lblPulseSa1 = New System.Windows.Forms.Label()
        Me.lblPulseSa2 = New System.Windows.Forms.Label()
        Me.lblPulseSa3 = New System.Windows.Forms.Label()
        Me.lblPulseSa4 = New System.Windows.Forms.Label()
        Me.lblDirSa1 = New System.Windows.Forms.Label()
        Me.lblDirSa2 = New System.Windows.Forms.Label()
        Me.lblDirSa3 = New System.Windows.Forms.Label()
        Me.lblantdftrip = New System.Windows.Forms.Label()
        Me.DIOx7 = New System.Windows.Forms.Label()
        Me.DIOx6 = New System.Windows.Forms.Label()
        Me.DIOx5 = New System.Windows.Forms.Label()
        Me.DIOx4 = New System.Windows.Forms.Label()
        Me.DIOx3 = New System.Windows.Forms.Label()
        Me.DIOx2 = New System.Windows.Forms.Label()
        Me.DIOx1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblbpts = New System.Windows.Forms.Label()
        Me.lblapxas = New System.Windows.Forms.Label()
        Me.lblapts = New System.Windows.Forms.Label()
        Me.lblbpxas = New System.Windows.Forms.Label()
        Me.lblapyas = New System.Windows.Forms.Label()
        Me.lblbpyas = New System.Windows.Forms.Label()
        Me.lblapcs = New System.Windows.Forms.Label()
        Me.lblbpcs = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.btnangstatus = New System.Windows.Forms.Button()
        Me.Panel6.SuspendLayout()
        Me.pnlTR.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Panel6.Controls.Add(Me.btnangstatus)
        Me.Panel6.Controls.Add(Me.btnSetup)
        Me.Panel6.Controls.Add(Me.pnlTR)
        Me.Panel6.Controls.Add(Me.Button1)
        Me.Panel6.Location = New System.Drawing.Point(11, 11)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(1066, 642)
        Me.Panel6.TabIndex = 0
        '
        'btnSetup
        '
        Me.btnSetup.BackgroundImage = Global.iotESSC.My.Resources.Resources.btnblue
        Me.btnSetup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnSetup.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSetup.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSetup.Location = New System.Drawing.Point(860, 603)
        Me.btnSetup.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSetup.Name = "btnSetup"
        Me.btnSetup.Size = New System.Drawing.Size(91, 31)
        Me.btnSetup.TabIndex = 14
        Me.btnSetup.Text = "Setup"
        Me.btnSetup.UseVisualStyleBackColor = True
        '
        'pnlTR
        '
        Me.pnlTR.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.pnlTR.Controls.Add(Me.Label25)
        Me.pnlTR.Controls.Add(Me.lblSpare)
        Me.pnlTR.Controls.Add(Me.Label27)
        Me.pnlTR.Controls.Add(Me.lblTRTravelSpeed)
        Me.pnlTR.Controls.Add(Me.Label18)
        Me.pnlTR.Controls.Add(Me.Label19)
        Me.pnlTR.Controls.Add(Me.lblAngFluxWeight)
        Me.pnlTR.Controls.Add(Me.lblAngTrSpeed)
        Me.pnlTR.Controls.Add(Me.Label23)
        Me.pnlTR.Controls.Add(Me.lblAngAntiDriftTrip)
        Me.pnlTR.Controls.Add(Me.Label8)
        Me.pnlTR.Controls.Add(Me.Label9)
        Me.pnlTR.Controls.Add(Me.Label10)
        Me.pnlTR.Controls.Add(Me.lblAngCurrent)
        Me.pnlTR.Controls.Add(Me.lblAngVoltage)
        Me.pnlTR.Controls.Add(Me.lblAngJobTemp)
        Me.pnlTR.Controls.Add(Me.Label14)
        Me.pnlTR.Controls.Add(Me.lblAngFluxTemp)
        Me.pnlTR.Controls.Add(Me.Label7)
        Me.pnlTR.Controls.Add(Me.Label6)
        Me.pnlTR.Controls.Add(Me.Label5)
        Me.pnlTR.Controls.Add(Me.lblrdsa4)
        Me.pnlTR.Controls.Add(Me.Label3)
        Me.pnlTR.Controls.Add(Me.Label112)
        Me.pnlTR.Controls.Add(Me.lblTrolOn)
        Me.pnlTR.Controls.Add(Me.Label2)
        Me.pnlTR.Controls.Add(Me.Label37)
        Me.pnlTR.Controls.Add(Me.Label38)
        Me.pnlTR.Controls.Add(Me.Label39)
        Me.pnlTR.Controls.Add(Me.Label40)
        Me.pnlTR.Controls.Add(Me.lblFluxOvenOn)
        Me.pnlTR.Controls.Add(Me.lblFluxFill)
        Me.pnlTR.Controls.Add(Me.lblMagnetOn)
        Me.pnlTR.Controls.Add(Me.lblWinchOn)
        Me.pnlTR.Controls.Add(Me.lblIRHeatSysOn)
        Me.pnlTR.Controls.Add(Me.Label88)
        Me.pnlTR.Controls.Add(Me.lblFluxRecOn)
        Me.pnlTR.Controls.Add(Me.Label90)
        Me.pnlTR.Controls.Add(Me.lblHeadCollOn)
        Me.pnlTR.Controls.Add(Me.Label73)
        Me.pnlTR.Controls.Add(Me.Label103)
        Me.pnlTR.Controls.Add(Me.Label74)
        Me.pnlTR.Controls.Add(Me.Label104)
        Me.pnlTR.Controls.Add(Me.Label75)
        Me.pnlTR.Controls.Add(Me.Label105)
        Me.pnlTR.Controls.Add(Me.Label76)
        Me.pnlTR.Controls.Add(Me.lblTrControlOn)
        Me.pnlTR.Controls.Add(Me.Label77)
        Me.pnlTR.Controls.Add(Me.lblproxip)
        Me.pnlTR.Controls.Add(Me.lblalmsa3)
        Me.pnlTR.Controls.Add(Me.lblmanauto)
        Me.pnlTR.Controls.Add(Me.Label32)
        Me.pnlTR.Controls.Add(Me.lbltrconfb)
        Me.pnlTR.Controls.Add(Me.Label33)
        Me.pnlTR.Controls.Add(Me.lblSONEM2SA4)
        Me.pnlTR.Controls.Add(Me.Label43)
        Me.pnlTR.Controls.Add(Me.Label35)
        Me.pnlTR.Controls.Add(Me.Label44)
        Me.pnlTR.Controls.Add(Me.lblrdsa3)
        Me.pnlTR.Controls.Add(Me.Label45)
        Me.pnlTR.Controls.Add(Me.Label46)
        Me.pnlTR.Controls.Add(Me.lblST1SA5)
        Me.pnlTR.Controls.Add(Me.lblEsscPSOff)
        Me.pnlTR.Controls.Add(Me.Label78)
        Me.pnlTR.Controls.Add(Me.lblFumeExtOn)
        Me.pnlTR.Controls.Add(Me.Label47)
        Me.pnlTR.Controls.Add(Me.lblHeadLampOn)
        Me.pnlTR.Controls.Add(Me.lblWeldStart)
        Me.pnlTR.Controls.Add(Me.lblalmsa4)
        Me.pnlTR.Controls.Add(Me.Label48)
        Me.pnlTR.Controls.Add(Me.lblemeron)
        Me.pnlTR.Controls.Add(Me.Label49)
        Me.pnlTR.Controls.Add(Me.Label55)
        Me.pnlTR.Controls.Add(Me.lblWeldStop)
        Me.pnlTR.Controls.Add(Me.lblTRCWFWDRot)
        Me.pnlTR.Controls.Add(Me.Label79)
        Me.pnlTR.Controls.Add(Me.lblTRCCWREWRot)
        Me.pnlTR.Controls.Add(Me.Label107)
        Me.pnlTR.Controls.Add(Me.lblTRStartPB)
        Me.pnlTR.Controls.Add(Me.lblrdsa5)
        Me.pnlTR.Controls.Add(Me.lblEsscPSOn)
        Me.pnlTR.Controls.Add(Me.lblSONEM2SA5)
        Me.pnlTR.Controls.Add(Me.Label16)
        Me.pnlTR.Controls.Add(Me.Label52)
        Me.pnlTR.Controls.Add(Me.lblalmsa5)
        Me.pnlTR.Controls.Add(Me.lblResetSA)
        Me.pnlTR.Controls.Add(Me.Label108)
        Me.pnlTR.Controls.Add(Me.Label106)
        Me.pnlTR.Controls.Add(Me.lblFluxFunnDn)
        Me.pnlTR.Controls.Add(Me.Label110)
        Me.pnlTR.Controls.Add(Me.lblStripDn)
        Me.pnlTR.Controls.Add(Me.lblTREmerg)
        Me.pnlTR.Controls.Add(Me.lblStripUp)
        Me.pnlTR.Controls.Add(Me.Label53)
        Me.pnlTR.Controls.Add(Me.Label56)
        Me.pnlTR.Controls.Add(Me.Label57)
        Me.pnlTR.Controls.Add(Me.lblSONEM2SA2)
        Me.pnlTR.Controls.Add(Me.lblSONEM2SA3)
        Me.pnlTR.Controls.Add(Me.Label51)
        Me.pnlTR.Controls.Add(Me.lblFluxFunnUp)
        Me.pnlTR.Controls.Add(Me.lblSONEM2SA1)
        Me.pnlTR.Controls.Add(Me.Label66)
        Me.pnlTR.Controls.Add(Me.Label68)
        Me.pnlTR.Controls.Add(Me.Label71)
        Me.pnlTR.Controls.Add(Me.lblDirSa4)
        Me.pnlTR.Controls.Add(Me.lblFaultLamp)
        Me.pnlTR.Controls.Add(Me.lblAutoOnLamp)
        Me.pnlTR.Controls.Add(Me.Label80)
        Me.pnlTR.Controls.Add(Me.Label83)
        Me.pnlTR.Controls.Add(Me.Label84)
        Me.pnlTR.Controls.Add(Me.Label85)
        Me.pnlTR.Controls.Add(Me.lblrdsa1)
        Me.pnlTR.Controls.Add(Me.lblalmsa2)
        Me.pnlTR.Controls.Add(Me.lblalmsa1)
        Me.pnlTR.Controls.Add(Me.lblrdsa2)
        Me.pnlTR.Controls.Add(Me.Label36)
        Me.pnlTR.Controls.Add(Me.Label34)
        Me.pnlTR.Controls.Add(Me.DIOy5)
        Me.pnlTR.Controls.Add(Me.DIOy4)
        Me.pnlTR.Controls.Add(Me.DIOy3)
        Me.pnlTR.Controls.Add(Me.DIOy2)
        Me.pnlTR.Controls.Add(Me.DIOy1)
        Me.pnlTR.Controls.Add(Me.DIOy0)
        Me.pnlTR.Controls.Add(Me.lblPulseSa1)
        Me.pnlTR.Controls.Add(Me.lblPulseSa2)
        Me.pnlTR.Controls.Add(Me.lblPulseSa3)
        Me.pnlTR.Controls.Add(Me.lblPulseSa4)
        Me.pnlTR.Controls.Add(Me.lblDirSa1)
        Me.pnlTR.Controls.Add(Me.lblDirSa2)
        Me.pnlTR.Controls.Add(Me.lblDirSa3)
        Me.pnlTR.Controls.Add(Me.lblantdftrip)
        Me.pnlTR.Controls.Add(Me.DIOx7)
        Me.pnlTR.Controls.Add(Me.DIOx6)
        Me.pnlTR.Controls.Add(Me.DIOx5)
        Me.pnlTR.Controls.Add(Me.DIOx4)
        Me.pnlTR.Controls.Add(Me.DIOx3)
        Me.pnlTR.Controls.Add(Me.DIOx2)
        Me.pnlTR.Controls.Add(Me.DIOx1)
        Me.pnlTR.Controls.Add(Me.Label4)
        Me.pnlTR.Controls.Add(Me.lblbpts)
        Me.pnlTR.Controls.Add(Me.lblapxas)
        Me.pnlTR.Controls.Add(Me.lblapts)
        Me.pnlTR.Controls.Add(Me.lblbpxas)
        Me.pnlTR.Controls.Add(Me.lblapyas)
        Me.pnlTR.Controls.Add(Me.lblbpyas)
        Me.pnlTR.Controls.Add(Me.lblapcs)
        Me.pnlTR.Controls.Add(Me.lblbpcs)
        Me.pnlTR.Controls.Add(Me.Label1)
        Me.pnlTR.Location = New System.Drawing.Point(5, 6)
        Me.pnlTR.Margin = New System.Windows.Forms.Padding(2)
        Me.pnlTR.Name = "pnlTR"
        Me.pnlTR.Size = New System.Drawing.Size(1044, 591)
        Me.pnlTR.TabIndex = 10
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(780, 540)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(82, 19)
        Me.Label25.TabIndex = 237
        Me.Label25.Text = "Spare"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSpare
        '
        Me.lblSpare.AutoEllipsis = True
        Me.lblSpare.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblSpare.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSpare.Location = New System.Drawing.Point(690, 541)
        Me.lblSpare.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSpare.Name = "lblSpare"
        Me.lblSpare.Size = New System.Drawing.Size(66, 19)
        Me.lblSpare.TabIndex = 236
        Me.lblSpare.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(780, 496)
        Me.Label27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(142, 19)
        Me.Label27.TabIndex = 235
        Me.Label27.Text = "T/R Travel Speed"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTRTravelSpeed
        '
        Me.lblTRTravelSpeed.AutoEllipsis = True
        Me.lblTRTravelSpeed.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblTRTravelSpeed.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTRTravelSpeed.Location = New System.Drawing.Point(690, 497)
        Me.lblTRTravelSpeed.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTRTravelSpeed.Name = "lblTRTravelSpeed"
        Me.lblTRTravelSpeed.Size = New System.Drawing.Size(66, 19)
        Me.lblTRTravelSpeed.TabIndex = 234
        Me.lblTRTravelSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(400, 519)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(143, 18)
        Me.Label18.TabIndex = 230
        Me.Label18.Text = "Tr Speed"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(400, 479)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(143, 18)
        Me.Label19.TabIndex = 229
        Me.Label19.Text = "Essc Flux Weight"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAngFluxWeight
        '
        Me.lblAngFluxWeight.AutoEllipsis = True
        Me.lblAngFluxWeight.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblAngFluxWeight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAngFluxWeight.Location = New System.Drawing.Point(321, 478)
        Me.lblAngFluxWeight.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAngFluxWeight.Name = "lblAngFluxWeight"
        Me.lblAngFluxWeight.Size = New System.Drawing.Size(66, 19)
        Me.lblAngFluxWeight.TabIndex = 227
        Me.lblAngFluxWeight.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAngTrSpeed
        '
        Me.lblAngTrSpeed.AutoEllipsis = True
        Me.lblAngTrSpeed.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblAngTrSpeed.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAngTrSpeed.Location = New System.Drawing.Point(321, 518)
        Me.lblAngTrSpeed.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAngTrSpeed.Name = "lblAngTrSpeed"
        Me.lblAngTrSpeed.Size = New System.Drawing.Size(66, 19)
        Me.lblAngTrSpeed.TabIndex = 228
        Me.lblAngTrSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label23
        '
        Me.Label23.AutoEllipsis = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(400, 554)
        Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(143, 18)
        Me.Label23.TabIndex = 233
        Me.Label23.Text = "Anti Drift Trip"
        '
        'lblAngAntiDriftTrip
        '
        Me.lblAngAntiDriftTrip.AutoEllipsis = True
        Me.lblAngAntiDriftTrip.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblAngAntiDriftTrip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAngAntiDriftTrip.Location = New System.Drawing.Point(321, 554)
        Me.lblAngAntiDriftTrip.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAngAntiDriftTrip.Name = "lblAngAntiDriftTrip"
        Me.lblAngAntiDriftTrip.Size = New System.Drawing.Size(66, 19)
        Me.lblAngAntiDriftTrip.TabIndex = 232
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(110, 525)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(143, 18)
        Me.Label8.TabIndex = 223
        Me.Label8.Text = "Essc Job Temp"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(110, 497)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(143, 18)
        Me.Label9.TabIndex = 222
        Me.Label9.Text = "Essc Voltage"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(110, 469)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(143, 18)
        Me.Label10.TabIndex = 221
        Me.Label10.Text = "Essc Current"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAngCurrent
        '
        Me.lblAngCurrent.AutoEllipsis = True
        Me.lblAngCurrent.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblAngCurrent.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAngCurrent.Location = New System.Drawing.Point(40, 469)
        Me.lblAngCurrent.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAngCurrent.Name = "lblAngCurrent"
        Me.lblAngCurrent.Size = New System.Drawing.Size(66, 19)
        Me.lblAngCurrent.TabIndex = 219
        Me.lblAngCurrent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAngVoltage
        '
        Me.lblAngVoltage.AutoEllipsis = True
        Me.lblAngVoltage.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblAngVoltage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAngVoltage.Location = New System.Drawing.Point(40, 497)
        Me.lblAngVoltage.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAngVoltage.Name = "lblAngVoltage"
        Me.lblAngVoltage.Size = New System.Drawing.Size(66, 19)
        Me.lblAngVoltage.TabIndex = 220
        Me.lblAngVoltage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAngJobTemp
        '
        Me.lblAngJobTemp.AutoEllipsis = True
        Me.lblAngJobTemp.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblAngJobTemp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAngJobTemp.Location = New System.Drawing.Point(40, 525)
        Me.lblAngJobTemp.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAngJobTemp.Name = "lblAngJobTemp"
        Me.lblAngJobTemp.Size = New System.Drawing.Size(66, 19)
        Me.lblAngJobTemp.TabIndex = 218
        Me.lblAngJobTemp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label14
        '
        Me.Label14.AutoEllipsis = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(110, 553)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(143, 18)
        Me.Label14.TabIndex = 225
        Me.Label14.Text = "Essc Flux Temp"
        '
        'lblAngFluxTemp
        '
        Me.lblAngFluxTemp.AutoEllipsis = True
        Me.lblAngFluxTemp.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblAngFluxTemp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAngFluxTemp.Location = New System.Drawing.Point(40, 553)
        Me.lblAngFluxTemp.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAngFluxTemp.Name = "lblAngFluxTemp"
        Me.lblAngFluxTemp.Size = New System.Drawing.Size(66, 19)
        Me.lblAngFluxTemp.TabIndex = 224
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(428, 0)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(614, 24)
        Me.Label7.TabIndex = 217
        Me.Label7.Text = "Digital Output Status"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(592, 438)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(450, 24)
        Me.Label6.TabIndex = 216
        Me.Label6.Text = "Analog Output Status"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(2, 438)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(586, 24)
        Me.Label5.TabIndex = 215
        Me.Label5.Text = "Analog Input Status"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblrdsa4
        '
        Me.lblrdsa4.AutoEllipsis = True
        Me.lblrdsa4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblrdsa4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblrdsa4.Location = New System.Drawing.Point(240, 120)
        Me.lblrdsa4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblrdsa4.Name = "lblrdsa4"
        Me.lblrdsa4.Size = New System.Drawing.Size(16, 19)
        Me.lblrdsa4.TabIndex = 214
        Me.lblrdsa4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(261, 120)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(143, 18)
        Me.Label3.TabIndex = 213
        Me.Label3.Text = "RD SA-4"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label112
        '
        Me.Label112.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label112.Location = New System.Drawing.Point(832, 400)
        Me.Label112.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(174, 19)
        Me.Label112.TabIndex = 210
        Me.Label112.Text = "Turning Roller On"
        Me.Label112.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTrolOn
        '
        Me.lblTrolOn.AutoEllipsis = True
        Me.lblTrolOn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblTrolOn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTrolOn.Location = New System.Drawing.Point(810, 400)
        Me.lblTrolOn.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTrolOn.Name = "lblTrolOn"
        Me.lblTrolOn.Size = New System.Drawing.Size(17, 19)
        Me.lblTrolOn.TabIndex = 209
        Me.lblTrolOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(832, 373)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(174, 19)
        Me.Label2.TabIndex = 208
        Me.Label2.Text = "IR Heating System On"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label37
        '
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(832, 345)
        Me.Label37.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(174, 19)
        Me.Label37.TabIndex = 207
        Me.Label37.Text = "Winch On"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label38
        '
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(832, 316)
        Me.Label38.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(174, 19)
        Me.Label38.TabIndex = 206
        Me.Label38.Text = "Magnet On"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label39
        '
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(832, 288)
        Me.Label39.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(174, 19)
        Me.Label39.TabIndex = 205
        Me.Label39.Text = "Flux Fill"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label40
        '
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(832, 260)
        Me.Label40.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(174, 19)
        Me.Label40.TabIndex = 204
        Me.Label40.Text = "Flux Oven On"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFluxOvenOn
        '
        Me.lblFluxOvenOn.AutoEllipsis = True
        Me.lblFluxOvenOn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblFluxOvenOn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFluxOvenOn.Location = New System.Drawing.Point(810, 260)
        Me.lblFluxOvenOn.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFluxOvenOn.Name = "lblFluxOvenOn"
        Me.lblFluxOvenOn.Size = New System.Drawing.Size(17, 19)
        Me.lblFluxOvenOn.TabIndex = 200
        Me.lblFluxOvenOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFluxFill
        '
        Me.lblFluxFill.AutoEllipsis = True
        Me.lblFluxFill.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblFluxFill.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFluxFill.Location = New System.Drawing.Point(810, 288)
        Me.lblFluxFill.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFluxFill.Name = "lblFluxFill"
        Me.lblFluxFill.Size = New System.Drawing.Size(17, 19)
        Me.lblFluxFill.TabIndex = 202
        Me.lblFluxFill.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblMagnetOn
        '
        Me.lblMagnetOn.AutoEllipsis = True
        Me.lblMagnetOn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblMagnetOn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblMagnetOn.Location = New System.Drawing.Point(810, 316)
        Me.lblMagnetOn.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblMagnetOn.Name = "lblMagnetOn"
        Me.lblMagnetOn.Size = New System.Drawing.Size(17, 19)
        Me.lblMagnetOn.TabIndex = 199
        Me.lblMagnetOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblWinchOn
        '
        Me.lblWinchOn.AutoEllipsis = True
        Me.lblWinchOn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblWinchOn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblWinchOn.Location = New System.Drawing.Point(810, 345)
        Me.lblWinchOn.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblWinchOn.Name = "lblWinchOn"
        Me.lblWinchOn.Size = New System.Drawing.Size(17, 19)
        Me.lblWinchOn.TabIndex = 201
        Me.lblWinchOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblIRHeatSysOn
        '
        Me.lblIRHeatSysOn.AutoEllipsis = True
        Me.lblIRHeatSysOn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblIRHeatSysOn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblIRHeatSysOn.Location = New System.Drawing.Point(810, 373)
        Me.lblIRHeatSysOn.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblIRHeatSysOn.Name = "lblIRHeatSysOn"
        Me.lblIRHeatSysOn.Size = New System.Drawing.Size(17, 19)
        Me.lblIRHeatSysOn.TabIndex = 203
        Me.lblIRHeatSysOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label88
        '
        Me.Label88.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.Location = New System.Drawing.Point(832, 232)
        Me.Label88.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(174, 19)
        Me.Label88.TabIndex = 198
        Me.Label88.Text = "Flux Recovery On"
        Me.Label88.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFluxRecOn
        '
        Me.lblFluxRecOn.AutoEllipsis = True
        Me.lblFluxRecOn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblFluxRecOn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFluxRecOn.Location = New System.Drawing.Point(810, 232)
        Me.lblFluxRecOn.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFluxRecOn.Name = "lblFluxRecOn"
        Me.lblFluxRecOn.Size = New System.Drawing.Size(17, 19)
        Me.lblFluxRecOn.TabIndex = 197
        Me.lblFluxRecOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label90
        '
        Me.Label90.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label90.Location = New System.Drawing.Point(832, 204)
        Me.Label90.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(174, 19)
        Me.Label90.TabIndex = 196
        Me.Label90.Text = "Head Coolling On"
        Me.Label90.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblHeadCollOn
        '
        Me.lblHeadCollOn.AutoEllipsis = True
        Me.lblHeadCollOn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblHeadCollOn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHeadCollOn.Location = New System.Drawing.Point(810, 204)
        Me.lblHeadCollOn.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblHeadCollOn.Name = "lblHeadCollOn"
        Me.lblHeadCollOn.Size = New System.Drawing.Size(17, 19)
        Me.lblHeadCollOn.TabIndex = 195
        Me.lblHeadCollOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label73
        '
        Me.Label73.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.Location = New System.Drawing.Point(261, 64)
        Me.Label73.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(143, 18)
        Me.Label73.TabIndex = 60
        Me.Label73.Text = "RD SA-3"
        Me.Label73.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label103
        '
        Me.Label103.AutoEllipsis = True
        Me.Label103.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label103.Location = New System.Drawing.Point(645, 316)
        Me.Label103.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(131, 19)
        Me.Label103.TabIndex = 152
        Me.Label103.Text = "Strip Dn"
        '
        'Label74
        '
        Me.Label74.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.Location = New System.Drawing.Point(645, 36)
        Me.Label74.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(131, 19)
        Me.Label74.TabIndex = 59
        Me.Label74.Text = "SON + EM2 SA-4"
        Me.Label74.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label104
        '
        Me.Label104.AutoEllipsis = True
        Me.Label104.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.Location = New System.Drawing.Point(261, 36)
        Me.Label104.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(143, 18)
        Me.Label104.TabIndex = 151
        Me.Label104.Text = "ALM SA-3"
        '
        'Label75
        '
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.Location = New System.Drawing.Point(261, 288)
        Me.Label75.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(143, 18)
        Me.Label75.TabIndex = 58
        Me.Label75.Text = "T/R Control On Fb"
        Me.Label75.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label105
        '
        Me.Label105.AutoEllipsis = True
        Me.Label105.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label105.Location = New System.Drawing.Point(645, 204)
        Me.Label105.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(131, 19)
        Me.Label105.TabIndex = 150
        Me.Label105.Text = "T/R Control On"
        '
        'Label76
        '
        Me.Label76.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(261, 260)
        Me.Label76.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(143, 18)
        Me.Label76.TabIndex = 57
        Me.Label76.Text = "Manual/Auto"
        Me.Label76.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTrControlOn
        '
        Me.lblTrControlOn.AutoEllipsis = True
        Me.lblTrControlOn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblTrControlOn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTrControlOn.Location = New System.Drawing.Point(622, 204)
        Me.lblTrControlOn.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTrControlOn.Name = "lblTrControlOn"
        Me.lblTrControlOn.Size = New System.Drawing.Size(17, 19)
        Me.lblTrControlOn.TabIndex = 147
        '
        'Label77
        '
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(261, 232)
        Me.Label77.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(143, 18)
        Me.Label77.TabIndex = 56
        Me.Label77.Text = "Proximity I/P"
        Me.Label77.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblproxip
        '
        Me.lblproxip.AutoEllipsis = True
        Me.lblproxip.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblproxip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblproxip.Location = New System.Drawing.Point(240, 232)
        Me.lblproxip.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblproxip.Name = "lblproxip"
        Me.lblproxip.Size = New System.Drawing.Size(17, 19)
        Me.lblproxip.TabIndex = 52
        Me.lblproxip.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblalmsa3
        '
        Me.lblalmsa3.AutoEllipsis = True
        Me.lblalmsa3.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblalmsa3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblalmsa3.Location = New System.Drawing.Point(240, 36)
        Me.lblalmsa3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblalmsa3.Name = "lblalmsa3"
        Me.lblalmsa3.Size = New System.Drawing.Size(17, 19)
        Me.lblalmsa3.TabIndex = 148
        '
        'lblmanauto
        '
        Me.lblmanauto.AutoEllipsis = True
        Me.lblmanauto.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblmanauto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblmanauto.Location = New System.Drawing.Point(240, 260)
        Me.lblmanauto.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblmanauto.Name = "lblmanauto"
        Me.lblmanauto.Size = New System.Drawing.Size(17, 19)
        Me.lblmanauto.TabIndex = 54
        Me.lblmanauto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label32
        '
        Me.Label32.AutoEllipsis = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(645, 260)
        Me.Label32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(131, 19)
        Me.Label32.TabIndex = 146
        Me.Label32.Text = "Weld Stop"
        '
        'lbltrconfb
        '
        Me.lbltrconfb.AutoEllipsis = True
        Me.lbltrconfb.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lbltrconfb.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbltrconfb.Location = New System.Drawing.Point(240, 288)
        Me.lbltrconfb.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbltrconfb.Name = "lbltrconfb"
        Me.lbltrconfb.Size = New System.Drawing.Size(17, 19)
        Me.lbltrconfb.TabIndex = 51
        Me.lbltrconfb.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label33
        '
        Me.Label33.AutoEllipsis = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(645, 232)
        Me.Label33.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(131, 19)
        Me.Label33.TabIndex = 145
        Me.Label33.Text = "Weld Start"
        '
        'lblSONEM2SA4
        '
        Me.lblSONEM2SA4.AutoEllipsis = True
        Me.lblSONEM2SA4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblSONEM2SA4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSONEM2SA4.Location = New System.Drawing.Point(622, 36)
        Me.lblSONEM2SA4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSONEM2SA4.Name = "lblSONEM2SA4"
        Me.lblSONEM2SA4.Size = New System.Drawing.Size(17, 19)
        Me.lblSONEM2SA4.TabIndex = 53
        Me.lblSONEM2SA4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label43
        '
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(261, 92)
        Me.Label43.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(143, 18)
        Me.Label43.TabIndex = 59
        Me.Label43.Text = "ALM SA-4"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label35
        '
        Me.Label35.AutoEllipsis = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(645, 176)
        Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(131, 19)
        Me.Label35.TabIndex = 144
        Me.Label35.Text = "ST1 SA-5"
        '
        'Label44
        '
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(831, 176)
        Me.Label44.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(143, 19)
        Me.Label44.TabIndex = 58
        Me.Label44.Text = "Head Lamp On"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblrdsa3
        '
        Me.lblrdsa3.AutoEllipsis = True
        Me.lblrdsa3.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblrdsa3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblrdsa3.Location = New System.Drawing.Point(240, 64)
        Me.lblrdsa3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblrdsa3.Name = "lblrdsa3"
        Me.lblrdsa3.Size = New System.Drawing.Size(17, 19)
        Me.lblrdsa3.TabIndex = 55
        Me.lblrdsa3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label45
        '
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(832, 148)
        Me.Label45.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(174, 19)
        Me.Label45.TabIndex = 57
        Me.Label45.Text = "Fume ExtractionON"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label46
        '
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(832, 120)
        Me.Label46.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(174, 19)
        Me.Label46.TabIndex = 56
        Me.Label46.Text = "ESSC P/S OFF"
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblST1SA5
        '
        Me.lblST1SA5.AutoEllipsis = True
        Me.lblST1SA5.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblST1SA5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblST1SA5.Location = New System.Drawing.Point(622, 176)
        Me.lblST1SA5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblST1SA5.Name = "lblST1SA5"
        Me.lblST1SA5.Size = New System.Drawing.Size(17, 19)
        Me.lblST1SA5.TabIndex = 141
        '
        'lblEsscPSOff
        '
        Me.lblEsscPSOff.AutoEllipsis = True
        Me.lblEsscPSOff.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEsscPSOff.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEsscPSOff.Location = New System.Drawing.Point(810, 120)
        Me.lblEsscPSOff.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEsscPSOff.Name = "lblEsscPSOff"
        Me.lblEsscPSOff.Size = New System.Drawing.Size(17, 19)
        Me.lblEsscPSOff.TabIndex = 50
        Me.lblEsscPSOff.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label78
        '
        Me.Label78.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.Location = New System.Drawing.Point(261, 204)
        Me.Label78.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(143, 18)
        Me.Label78.TabIndex = 50
        Me.Label78.Text = "Emergancy On"
        Me.Label78.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFumeExtOn
        '
        Me.lblFumeExtOn.AutoEllipsis = True
        Me.lblFumeExtOn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblFumeExtOn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFumeExtOn.Location = New System.Drawing.Point(810, 148)
        Me.lblFumeExtOn.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFumeExtOn.Name = "lblFumeExtOn"
        Me.lblFumeExtOn.Size = New System.Drawing.Size(17, 19)
        Me.lblFumeExtOn.TabIndex = 46
        Me.lblFumeExtOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label47
        '
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(832, 92)
        Me.Label47.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(174, 19)
        Me.Label47.TabIndex = 55
        Me.Label47.Text = "ESSC P/S ON"
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblHeadLampOn
        '
        Me.lblHeadLampOn.AutoEllipsis = True
        Me.lblHeadLampOn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblHeadLampOn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHeadLampOn.Location = New System.Drawing.Point(811, 176)
        Me.lblHeadLampOn.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblHeadLampOn.Name = "lblHeadLampOn"
        Me.lblHeadLampOn.Size = New System.Drawing.Size(16, 19)
        Me.lblHeadLampOn.TabIndex = 48
        Me.lblHeadLampOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblWeldStart
        '
        Me.lblWeldStart.AutoEllipsis = True
        Me.lblWeldStart.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblWeldStart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblWeldStart.Location = New System.Drawing.Point(622, 232)
        Me.lblWeldStart.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblWeldStart.Name = "lblWeldStart"
        Me.lblWeldStart.Size = New System.Drawing.Size(17, 19)
        Me.lblWeldStart.TabIndex = 142
        '
        'lblalmsa4
        '
        Me.lblalmsa4.AutoEllipsis = True
        Me.lblalmsa4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblalmsa4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblalmsa4.Location = New System.Drawing.Point(240, 92)
        Me.lblalmsa4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblalmsa4.Name = "lblalmsa4"
        Me.lblalmsa4.Size = New System.Drawing.Size(16, 19)
        Me.lblalmsa4.TabIndex = 51
        Me.lblalmsa4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label48
        '
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(832, 64)
        Me.Label48.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(186, 19)
        Me.Label48.TabIndex = 54
        Me.Label48.Text = "T/R CCW/REW Rotation"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblemeron
        '
        Me.lblemeron.AutoEllipsis = True
        Me.lblemeron.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblemeron.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblemeron.Location = New System.Drawing.Point(240, 204)
        Me.lblemeron.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblemeron.Name = "lblemeron"
        Me.lblemeron.Size = New System.Drawing.Size(17, 19)
        Me.lblemeron.TabIndex = 49
        Me.lblemeron.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label49
        '
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(832, 36)
        Me.Label49.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(174, 19)
        Me.Label49.TabIndex = 53
        Me.Label49.Text = "T/R CW/FWD Rotation"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label55
        '
        Me.Label55.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(645, 373)
        Me.Label55.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(131, 19)
        Me.Label55.TabIndex = 52
        Me.Label55.Text = "T/R Start PB"
        Me.Label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblWeldStop
        '
        Me.lblWeldStop.AutoEllipsis = True
        Me.lblWeldStop.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblWeldStop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblWeldStop.Location = New System.Drawing.Point(622, 260)
        Me.lblWeldStop.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblWeldStop.Name = "lblWeldStop"
        Me.lblWeldStop.Size = New System.Drawing.Size(17, 19)
        Me.lblWeldStop.TabIndex = 143
        '
        'lblTRCWFWDRot
        '
        Me.lblTRCWFWDRot.AutoEllipsis = True
        Me.lblTRCWFWDRot.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblTRCWFWDRot.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTRCWFWDRot.Location = New System.Drawing.Point(810, 36)
        Me.lblTRCWFWDRot.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTRCWFWDRot.Name = "lblTRCWFWDRot"
        Me.lblTRCWFWDRot.Size = New System.Drawing.Size(17, 19)
        Me.lblTRCWFWDRot.TabIndex = 45
        Me.lblTRCWFWDRot.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label79
        '
        Me.Label79.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(261, 176)
        Me.Label79.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(143, 18)
        Me.Label79.TabIndex = 48
        Me.Label79.Text = "RD SA-5"
        Me.Label79.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTRCCWREWRot
        '
        Me.lblTRCCWREWRot.AutoEllipsis = True
        Me.lblTRCCWREWRot.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblTRCCWREWRot.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTRCCWREWRot.Location = New System.Drawing.Point(810, 64)
        Me.lblTRCCWREWRot.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTRCCWREWRot.Name = "lblTRCCWREWRot"
        Me.lblTRCCWREWRot.Size = New System.Drawing.Size(17, 19)
        Me.lblTRCCWREWRot.TabIndex = 49
        Me.lblTRCCWREWRot.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label107
        '
        Me.Label107.AutoEllipsis = True
        Me.Label107.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label107.Location = New System.Drawing.Point(645, 64)
        Me.Label107.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(131, 19)
        Me.Label107.TabIndex = 140
        Me.Label107.Text = "SON + EM2 SA-5"
        '
        'lblTRStartPB
        '
        Me.lblTRStartPB.AutoEllipsis = True
        Me.lblTRStartPB.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblTRStartPB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTRStartPB.Location = New System.Drawing.Point(622, 373)
        Me.lblTRStartPB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTRStartPB.Name = "lblTRStartPB"
        Me.lblTRStartPB.Size = New System.Drawing.Size(17, 19)
        Me.lblTRStartPB.TabIndex = 44
        Me.lblTRStartPB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblrdsa5
        '
        Me.lblrdsa5.AutoEllipsis = True
        Me.lblrdsa5.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblrdsa5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblrdsa5.Location = New System.Drawing.Point(240, 176)
        Me.lblrdsa5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblrdsa5.Name = "lblrdsa5"
        Me.lblrdsa5.Size = New System.Drawing.Size(17, 19)
        Me.lblrdsa5.TabIndex = 47
        Me.lblrdsa5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblEsscPSOn
        '
        Me.lblEsscPSOn.AutoEllipsis = True
        Me.lblEsscPSOn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEsscPSOn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEsscPSOn.Location = New System.Drawing.Point(810, 92)
        Me.lblEsscPSOn.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEsscPSOn.Name = "lblEsscPSOn"
        Me.lblEsscPSOn.Size = New System.Drawing.Size(17, 19)
        Me.lblEsscPSOn.TabIndex = 47
        Me.lblEsscPSOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSONEM2SA5
        '
        Me.lblSONEM2SA5.AutoEllipsis = True
        Me.lblSONEM2SA5.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblSONEM2SA5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSONEM2SA5.Location = New System.Drawing.Point(622, 64)
        Me.lblSONEM2SA5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSONEM2SA5.Name = "lblSONEM2SA5"
        Me.lblSONEM2SA5.Size = New System.Drawing.Size(17, 19)
        Me.lblSONEM2SA5.TabIndex = 139
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(261, 148)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(143, 18)
        Me.Label16.TabIndex = 46
        Me.Label16.Text = "ALM SA-5"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label52
        '
        Me.Label52.AutoEllipsis = True
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(645, 92)
        Me.Label52.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(131, 19)
        Me.Label52.TabIndex = 138
        Me.Label52.Text = "Reset SA 1-5"
        '
        'lblalmsa5
        '
        Me.lblalmsa5.AutoEllipsis = True
        Me.lblalmsa5.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblalmsa5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblalmsa5.Location = New System.Drawing.Point(240, 148)
        Me.lblalmsa5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblalmsa5.Name = "lblalmsa5"
        Me.lblalmsa5.Size = New System.Drawing.Size(17, 19)
        Me.lblalmsa5.TabIndex = 45
        Me.lblalmsa5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblResetSA
        '
        Me.lblResetSA.AutoEllipsis = True
        Me.lblResetSA.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblResetSA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblResetSA.Location = New System.Drawing.Point(622, 92)
        Me.lblResetSA.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblResetSA.Name = "lblResetSA"
        Me.lblResetSA.Size = New System.Drawing.Size(17, 19)
        Me.lblResetSA.TabIndex = 137
        '
        'Label108
        '
        Me.Label108.AutoEllipsis = True
        Me.Label108.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label108.Location = New System.Drawing.Point(645, 345)
        Me.Label108.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(131, 19)
        Me.Label108.TabIndex = 136
        Me.Label108.Text = "T/R Emergency"
        '
        'Label106
        '
        Me.Label106.AutoEllipsis = True
        Me.Label106.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.Location = New System.Drawing.Point(645, 148)
        Me.Label106.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(131, 19)
        Me.Label106.TabIndex = 116
        Me.Label106.Text = "Flux Funnel Dn"
        '
        'lblFluxFunnDn
        '
        Me.lblFluxFunnDn.AutoEllipsis = True
        Me.lblFluxFunnDn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblFluxFunnDn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFluxFunnDn.Location = New System.Drawing.Point(622, 148)
        Me.lblFluxFunnDn.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFluxFunnDn.Name = "lblFluxFunnDn"
        Me.lblFluxFunnDn.Size = New System.Drawing.Size(17, 19)
        Me.lblFluxFunnDn.TabIndex = 108
        '
        'Label110
        '
        Me.Label110.AutoEllipsis = True
        Me.Label110.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label110.Location = New System.Drawing.Point(645, 288)
        Me.Label110.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(131, 19)
        Me.Label110.TabIndex = 134
        Me.Label110.Text = "Strip Up"
        '
        'lblStripDn
        '
        Me.lblStripDn.AutoEllipsis = True
        Me.lblStripDn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblStripDn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStripDn.Location = New System.Drawing.Point(622, 316)
        Me.lblStripDn.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblStripDn.Name = "lblStripDn"
        Me.lblStripDn.Size = New System.Drawing.Size(17, 19)
        Me.lblStripDn.TabIndex = 131
        '
        'lblTREmerg
        '
        Me.lblTREmerg.AutoEllipsis = True
        Me.lblTREmerg.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblTREmerg.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTREmerg.Location = New System.Drawing.Point(622, 345)
        Me.lblTREmerg.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTREmerg.Name = "lblTREmerg"
        Me.lblTREmerg.Size = New System.Drawing.Size(17, 19)
        Me.lblTREmerg.TabIndex = 133
        '
        'lblStripUp
        '
        Me.lblStripUp.AutoEllipsis = True
        Me.lblStripUp.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblStripUp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStripUp.Location = New System.Drawing.Point(622, 288)
        Me.lblStripUp.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblStripUp.Name = "lblStripUp"
        Me.lblStripUp.Size = New System.Drawing.Size(17, 19)
        Me.lblStripUp.TabIndex = 132
        '
        'Label53
        '
        Me.Label53.AutoEllipsis = True
        Me.Label53.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.Location = New System.Drawing.Point(470, 373)
        Me.Label53.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(131, 19)
        Me.Label53.TabIndex = 130
        Me.Label53.Text = "SON + EM2 SA-3"
        '
        'Label56
        '
        Me.Label56.AutoEllipsis = True
        Me.Label56.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(470, 345)
        Me.Label56.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(131, 19)
        Me.Label56.TabIndex = 129
        Me.Label56.Text = "SON + EM2 SA-2"
        '
        'Label57
        '
        Me.Label57.AutoEllipsis = True
        Me.Label57.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.Location = New System.Drawing.Point(470, 316)
        Me.Label57.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(131, 19)
        Me.Label57.TabIndex = 128
        Me.Label57.Text = "SON + EM2 SA-1"
        '
        'lblSONEM2SA2
        '
        Me.lblSONEM2SA2.AutoEllipsis = True
        Me.lblSONEM2SA2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblSONEM2SA2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSONEM2SA2.Location = New System.Drawing.Point(447, 345)
        Me.lblSONEM2SA2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSONEM2SA2.Name = "lblSONEM2SA2"
        Me.lblSONEM2SA2.Size = New System.Drawing.Size(17, 19)
        Me.lblSONEM2SA2.TabIndex = 125
        '
        'lblSONEM2SA3
        '
        Me.lblSONEM2SA3.AutoEllipsis = True
        Me.lblSONEM2SA3.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblSONEM2SA3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSONEM2SA3.Location = New System.Drawing.Point(447, 373)
        Me.lblSONEM2SA3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSONEM2SA3.Name = "lblSONEM2SA3"
        Me.lblSONEM2SA3.Size = New System.Drawing.Size(17, 19)
        Me.lblSONEM2SA3.TabIndex = 127
        '
        'Label51
        '
        Me.Label51.AutoEllipsis = True
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(645, 120)
        Me.Label51.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(131, 19)
        Me.Label51.TabIndex = 87
        Me.Label51.Text = "Flux Funnel Up"
        '
        'lblFluxFunnUp
        '
        Me.lblFluxFunnUp.AutoEllipsis = True
        Me.lblFluxFunnUp.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblFluxFunnUp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFluxFunnUp.Location = New System.Drawing.Point(622, 120)
        Me.lblFluxFunnUp.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFluxFunnUp.Name = "lblFluxFunnUp"
        Me.lblFluxFunnUp.Size = New System.Drawing.Size(17, 19)
        Me.lblFluxFunnUp.TabIndex = 79
        '
        'lblSONEM2SA1
        '
        Me.lblSONEM2SA1.AutoEllipsis = True
        Me.lblSONEM2SA1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblSONEM2SA1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSONEM2SA1.Location = New System.Drawing.Point(447, 316)
        Me.lblSONEM2SA1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSONEM2SA1.Name = "lblSONEM2SA1"
        Me.lblSONEM2SA1.Size = New System.Drawing.Size(17, 19)
        Me.lblSONEM2SA1.TabIndex = 126
        '
        'Label66
        '
        Me.Label66.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(470, 288)
        Me.Label66.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(131, 19)
        Me.Label66.TabIndex = 124
        Me.Label66.Text = "Auto On Lamp"
        Me.Label66.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label68
        '
        Me.Label68.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.Location = New System.Drawing.Point(470, 260)
        Me.Label68.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(142, 19)
        Me.Label68.TabIndex = 123
        Me.Label68.Text = "Fault Lamp"
        Me.Label68.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label71
        '
        Me.Label71.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label71.Location = New System.Drawing.Point(470, 232)
        Me.Label71.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(131, 19)
        Me.Label71.TabIndex = 122
        Me.Label71.Text = "Direction SA-4"
        Me.Label71.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDirSa4
        '
        Me.lblDirSa4.AutoEllipsis = True
        Me.lblDirSa4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDirSa4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDirSa4.Location = New System.Drawing.Point(447, 232)
        Me.lblDirSa4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDirSa4.Name = "lblDirSa4"
        Me.lblDirSa4.Size = New System.Drawing.Size(17, 19)
        Me.lblDirSa4.TabIndex = 119
        Me.lblDirSa4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFaultLamp
        '
        Me.lblFaultLamp.AutoEllipsis = True
        Me.lblFaultLamp.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblFaultLamp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFaultLamp.Location = New System.Drawing.Point(447, 260)
        Me.lblFaultLamp.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFaultLamp.Name = "lblFaultLamp"
        Me.lblFaultLamp.Size = New System.Drawing.Size(17, 19)
        Me.lblFaultLamp.TabIndex = 120
        Me.lblFaultLamp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAutoOnLamp
        '
        Me.lblAutoOnLamp.AutoEllipsis = True
        Me.lblAutoOnLamp.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblAutoOnLamp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAutoOnLamp.Location = New System.Drawing.Point(447, 288)
        Me.lblAutoOnLamp.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAutoOnLamp.Name = "lblAutoOnLamp"
        Me.lblAutoOnLamp.Size = New System.Drawing.Size(17, 19)
        Me.lblAutoOnLamp.TabIndex = 121
        Me.lblAutoOnLamp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label80
        '
        Me.Label80.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(33, 344)
        Me.Label80.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(179, 19)
        Me.Label80.TabIndex = 110
        Me.Label80.Text = "RD SA-2"
        Me.Label80.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label83
        '
        Me.Label83.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(33, 316)
        Me.Label83.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(179, 19)
        Me.Label83.TabIndex = 109
        Me.Label83.Text = "ALM SA-2"
        Me.Label83.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label84
        '
        Me.Label84.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(37, 288)
        Me.Label84.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(179, 19)
        Me.Label84.TabIndex = 108
        Me.Label84.Text = "RD SA-1"
        Me.Label84.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label85
        '
        Me.Label85.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(37, 260)
        Me.Label85.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(179, 19)
        Me.Label85.TabIndex = 107
        Me.Label85.Text = "ALM SA-1"
        Me.Label85.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblrdsa1
        '
        Me.lblrdsa1.AutoEllipsis = True
        Me.lblrdsa1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblrdsa1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblrdsa1.Location = New System.Drawing.Point(13, 288)
        Me.lblrdsa1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblrdsa1.Name = "lblrdsa1"
        Me.lblrdsa1.Size = New System.Drawing.Size(17, 19)
        Me.lblrdsa1.TabIndex = 104
        Me.lblrdsa1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblalmsa2
        '
        Me.lblalmsa2.AutoEllipsis = True
        Me.lblalmsa2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblalmsa2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblalmsa2.Location = New System.Drawing.Point(13, 316)
        Me.lblalmsa2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblalmsa2.Name = "lblalmsa2"
        Me.lblalmsa2.Size = New System.Drawing.Size(17, 19)
        Me.lblalmsa2.TabIndex = 106
        Me.lblalmsa2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblalmsa1
        '
        Me.lblalmsa1.AutoEllipsis = True
        Me.lblalmsa1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblalmsa1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblalmsa1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblalmsa1.Location = New System.Drawing.Point(13, 260)
        Me.lblalmsa1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblalmsa1.Name = "lblalmsa1"
        Me.lblalmsa1.Size = New System.Drawing.Size(17, 19)
        Me.lblalmsa1.TabIndex = 103
        Me.lblalmsa1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblrdsa2
        '
        Me.lblrdsa2.AutoEllipsis = True
        Me.lblrdsa2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblrdsa2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblrdsa2.Location = New System.Drawing.Point(13, 344)
        Me.lblrdsa2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblrdsa2.Name = "lblrdsa2"
        Me.lblrdsa2.Size = New System.Drawing.Size(17, 19)
        Me.lblrdsa2.TabIndex = 105
        Me.lblrdsa2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label36
        '
        Me.Label36.AutoEllipsis = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(470, 204)
        Me.Label36.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(131, 19)
        Me.Label36.TabIndex = 90
        Me.Label36.Text = "Direction SA-3"
        '
        'Label34
        '
        Me.Label34.AutoEllipsis = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(470, 176)
        Me.Label34.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(131, 19)
        Me.Label34.TabIndex = 89
        Me.Label34.Text = "Direction SA-2"
        '
        'DIOy5
        '
        Me.DIOy5.AutoEllipsis = True
        Me.DIOy5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOy5.Location = New System.Drawing.Point(470, 148)
        Me.DIOy5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOy5.Name = "DIOy5"
        Me.DIOy5.Size = New System.Drawing.Size(131, 19)
        Me.DIOy5.TabIndex = 88
        Me.DIOy5.Text = "Direction SA-1"
        '
        'DIOy4
        '
        Me.DIOy4.AutoEllipsis = True
        Me.DIOy4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOy4.Location = New System.Drawing.Point(470, 120)
        Me.DIOy4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOy4.Name = "DIOy4"
        Me.DIOy4.Size = New System.Drawing.Size(131, 19)
        Me.DIOy4.TabIndex = 87
        Me.DIOy4.Text = "Pulse SA-4"
        '
        'DIOy3
        '
        Me.DIOy3.AutoEllipsis = True
        Me.DIOy3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOy3.Location = New System.Drawing.Point(470, 92)
        Me.DIOy3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOy3.Name = "DIOy3"
        Me.DIOy3.Size = New System.Drawing.Size(131, 19)
        Me.DIOy3.TabIndex = 86
        Me.DIOy3.Text = "Pulse SA-3"
        '
        'DIOy2
        '
        Me.DIOy2.AutoEllipsis = True
        Me.DIOy2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOy2.Location = New System.Drawing.Point(470, 64)
        Me.DIOy2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOy2.Name = "DIOy2"
        Me.DIOy2.Size = New System.Drawing.Size(131, 19)
        Me.DIOy2.TabIndex = 85
        Me.DIOy2.Text = "Pulse SA-2"
        '
        'DIOy1
        '
        Me.DIOy1.AutoEllipsis = True
        Me.DIOy1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOy1.Location = New System.Drawing.Point(470, 36)
        Me.DIOy1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOy1.Name = "DIOy1"
        Me.DIOy1.Size = New System.Drawing.Size(131, 19)
        Me.DIOy1.TabIndex = 84
        Me.DIOy1.Text = "Pulse SA-1"
        '
        'DIOy0
        '
        Me.DIOy0.AutoEllipsis = True
        Me.DIOy0.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOy0.Location = New System.Drawing.Point(261, 316)
        Me.DIOy0.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOy0.Name = "DIOy0"
        Me.DIOy0.Size = New System.Drawing.Size(143, 18)
        Me.DIOy0.TabIndex = 83
        Me.DIOy0.Text = "Anti Drift Trip"
        '
        'lblPulseSa1
        '
        Me.lblPulseSa1.AutoEllipsis = True
        Me.lblPulseSa1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblPulseSa1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPulseSa1.Location = New System.Drawing.Point(447, 36)
        Me.lblPulseSa1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblPulseSa1.Name = "lblPulseSa1"
        Me.lblPulseSa1.Size = New System.Drawing.Size(17, 19)
        Me.lblPulseSa1.TabIndex = 75
        '
        'lblPulseSa2
        '
        Me.lblPulseSa2.AutoEllipsis = True
        Me.lblPulseSa2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblPulseSa2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPulseSa2.Location = New System.Drawing.Point(447, 64)
        Me.lblPulseSa2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblPulseSa2.Name = "lblPulseSa2"
        Me.lblPulseSa2.Size = New System.Drawing.Size(17, 19)
        Me.lblPulseSa2.TabIndex = 77
        '
        'lblPulseSa3
        '
        Me.lblPulseSa3.AutoEllipsis = True
        Me.lblPulseSa3.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblPulseSa3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPulseSa3.Location = New System.Drawing.Point(447, 92)
        Me.lblPulseSa3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblPulseSa3.Name = "lblPulseSa3"
        Me.lblPulseSa3.Size = New System.Drawing.Size(17, 19)
        Me.lblPulseSa3.TabIndex = 78
        '
        'lblPulseSa4
        '
        Me.lblPulseSa4.AutoEllipsis = True
        Me.lblPulseSa4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblPulseSa4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPulseSa4.Location = New System.Drawing.Point(447, 120)
        Me.lblPulseSa4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblPulseSa4.Name = "lblPulseSa4"
        Me.lblPulseSa4.Size = New System.Drawing.Size(17, 19)
        Me.lblPulseSa4.TabIndex = 79
        '
        'lblDirSa1
        '
        Me.lblDirSa1.AutoEllipsis = True
        Me.lblDirSa1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDirSa1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDirSa1.Location = New System.Drawing.Point(447, 148)
        Me.lblDirSa1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDirSa1.Name = "lblDirSa1"
        Me.lblDirSa1.Size = New System.Drawing.Size(17, 19)
        Me.lblDirSa1.TabIndex = 80
        '
        'lblDirSa2
        '
        Me.lblDirSa2.AutoEllipsis = True
        Me.lblDirSa2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDirSa2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDirSa2.Location = New System.Drawing.Point(447, 176)
        Me.lblDirSa2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDirSa2.Name = "lblDirSa2"
        Me.lblDirSa2.Size = New System.Drawing.Size(17, 19)
        Me.lblDirSa2.TabIndex = 81
        '
        'lblDirSa3
        '
        Me.lblDirSa3.AutoEllipsis = True
        Me.lblDirSa3.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDirSa3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDirSa3.Location = New System.Drawing.Point(447, 204)
        Me.lblDirSa3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDirSa3.Name = "lblDirSa3"
        Me.lblDirSa3.Size = New System.Drawing.Size(17, 19)
        Me.lblDirSa3.TabIndex = 82
        '
        'lblantdftrip
        '
        Me.lblantdftrip.AutoEllipsis = True
        Me.lblantdftrip.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblantdftrip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblantdftrip.Location = New System.Drawing.Point(240, 316)
        Me.lblantdftrip.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblantdftrip.Name = "lblantdftrip"
        Me.lblantdftrip.Size = New System.Drawing.Size(17, 19)
        Me.lblantdftrip.TabIndex = 76
        '
        'DIOx7
        '
        Me.DIOx7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx7.Location = New System.Drawing.Point(37, 232)
        Me.DIOx7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx7.Name = "DIOx7"
        Me.DIOx7.Size = New System.Drawing.Size(179, 19)
        Me.DIOx7.TabIndex = 74
        Me.DIOx7.Text = "B-Phase C.Slide Servo"
        Me.DIOx7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx6
        '
        Me.DIOx6.Cursor = System.Windows.Forms.Cursors.Default
        Me.DIOx6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx6.Location = New System.Drawing.Point(37, 204)
        Me.DIOx6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx6.Name = "DIOx6"
        Me.DIOx6.Size = New System.Drawing.Size(179, 19)
        Me.DIOx6.TabIndex = 73
        Me.DIOx6.Text = "A-Phase C.Slide Servo"
        Me.DIOx6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx5
        '
        Me.DIOx5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx5.Location = New System.Drawing.Point(37, 176)
        Me.DIOx5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx5.Name = "DIOx5"
        Me.DIOx5.Size = New System.Drawing.Size(179, 19)
        Me.DIOx5.TabIndex = 72
        Me.DIOx5.Text = "B-Phase Y-Axis Servo"
        Me.DIOx5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx4
        '
        Me.DIOx4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx4.Location = New System.Drawing.Point(37, 148)
        Me.DIOx4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx4.Name = "DIOx4"
        Me.DIOx4.Size = New System.Drawing.Size(179, 19)
        Me.DIOx4.TabIndex = 71
        Me.DIOx4.Text = "A-Phase Y-Axis Servo"
        Me.DIOx4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx3
        '
        Me.DIOx3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx3.Location = New System.Drawing.Point(37, 120)
        Me.DIOx3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx3.Name = "DIOx3"
        Me.DIOx3.Size = New System.Drawing.Size(179, 19)
        Me.DIOx3.TabIndex = 70
        Me.DIOx3.Text = "B-Phase X-Axis Servo"
        Me.DIOx3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx2
        '
        Me.DIOx2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx2.Location = New System.Drawing.Point(37, 92)
        Me.DIOx2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx2.Name = "DIOx2"
        Me.DIOx2.Size = New System.Drawing.Size(179, 19)
        Me.DIOx2.TabIndex = 69
        Me.DIOx2.Text = "A-Phase X-Axis Servo"
        Me.DIOx2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx1
        '
        Me.DIOx1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx1.Location = New System.Drawing.Point(37, 64)
        Me.DIOx1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx1.Name = "DIOx1"
        Me.DIOx1.Size = New System.Drawing.Size(179, 19)
        Me.DIOx1.TabIndex = 68
        Me.DIOx1.Text = "B-Phase Trolley Servo"
        Me.DIOx1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(34, 36)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(179, 19)
        Me.Label4.TabIndex = 67
        Me.Label4.Text = "X0-A-Phase Trolley Servo"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblbpts
        '
        Me.lblbpts.AutoEllipsis = True
        Me.lblbpts.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblbpts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblbpts.Location = New System.Drawing.Point(13, 64)
        Me.lblbpts.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblbpts.Name = "lblbpts"
        Me.lblbpts.Size = New System.Drawing.Size(17, 19)
        Me.lblbpts.TabIndex = 60
        Me.lblbpts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblapxas
        '
        Me.lblapxas.AutoEllipsis = True
        Me.lblapxas.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblapxas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblapxas.Location = New System.Drawing.Point(13, 92)
        Me.lblapxas.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblapxas.Name = "lblapxas"
        Me.lblapxas.Size = New System.Drawing.Size(17, 19)
        Me.lblapxas.TabIndex = 64
        Me.lblapxas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblapts
        '
        Me.lblapts.AutoEllipsis = True
        Me.lblapts.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblapts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblapts.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblapts.Location = New System.Drawing.Point(13, 36)
        Me.lblapts.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblapts.Name = "lblapts"
        Me.lblapts.Size = New System.Drawing.Size(17, 19)
        Me.lblapts.TabIndex = 59
        Me.lblapts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblbpxas
        '
        Me.lblbpxas.AutoEllipsis = True
        Me.lblbpxas.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblbpxas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblbpxas.Location = New System.Drawing.Point(13, 120)
        Me.lblbpxas.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblbpxas.Name = "lblbpxas"
        Me.lblbpxas.Size = New System.Drawing.Size(17, 19)
        Me.lblbpxas.TabIndex = 62
        Me.lblbpxas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblapyas
        '
        Me.lblapyas.AutoEllipsis = True
        Me.lblapyas.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblapyas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblapyas.Location = New System.Drawing.Point(13, 148)
        Me.lblapyas.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblapyas.Name = "lblapyas"
        Me.lblapyas.Size = New System.Drawing.Size(17, 19)
        Me.lblapyas.TabIndex = 65
        Me.lblapyas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblbpyas
        '
        Me.lblbpyas.AutoEllipsis = True
        Me.lblbpyas.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblbpyas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblbpyas.Location = New System.Drawing.Point(13, 176)
        Me.lblbpyas.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblbpyas.Name = "lblbpyas"
        Me.lblbpyas.Size = New System.Drawing.Size(17, 19)
        Me.lblbpyas.TabIndex = 61
        Me.lblbpyas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblapcs
        '
        Me.lblapcs.AutoEllipsis = True
        Me.lblapcs.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblapcs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblapcs.Location = New System.Drawing.Point(13, 204)
        Me.lblapcs.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblapcs.Name = "lblapcs"
        Me.lblapcs.Size = New System.Drawing.Size(17, 19)
        Me.lblapcs.TabIndex = 63
        Me.lblapcs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblbpcs
        '
        Me.lblbpcs.AutoEllipsis = True
        Me.lblbpcs.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblbpcs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblbpcs.Location = New System.Drawing.Point(13, 232)
        Me.lblbpcs.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblbpcs.Name = "lblbpcs"
        Me.lblbpcs.Size = New System.Drawing.Size(17, 19)
        Me.lblbpcs.TabIndex = 66
        Me.lblbpcs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(2, 0)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(422, 24)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Digital Input Status"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Button1
        '
        Me.Button1.BackgroundImage = Global.iotESSC.My.Resources.Resources.btnblue
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Location = New System.Drawing.Point(956, 602)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(91, 31)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'btnangstatus
        '
        Me.btnangstatus.BackgroundImage = Global.iotESSC.My.Resources.Resources.btnblue
        Me.btnangstatus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnangstatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnangstatus.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnangstatus.Location = New System.Drawing.Point(717, 603)
        Me.btnangstatus.Margin = New System.Windows.Forms.Padding(2)
        Me.btnangstatus.Name = "btnangstatus"
        Me.btnangstatus.Size = New System.Drawing.Size(130, 31)
        Me.btnangstatus.TabIndex = 15
        Me.btnangstatus.Text = "Analog Status"
        Me.btnangstatus.UseVisualStyleBackColor = True
        '
        'frmDiag
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1078, 651)
        Me.Controls.Add(Me.Panel6)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmDiag"
        Me.Text = "frmDiag"
        Me.Panel6.ResumeLayout(False)
        Me.pnlTR.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents btnSetup As System.Windows.Forms.Button
    Friend WithEvents pnlTR As Panel
    Friend WithEvents Label112 As Label
    Friend WithEvents lblTrolOn As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents lblFluxOvenOn As Label
    Friend WithEvents lblFluxFill As Label
    Friend WithEvents lblMagnetOn As Label
    Friend WithEvents lblWinchOn As Label
    Friend WithEvents lblIRHeatSysOn As Label
    Friend WithEvents Label88 As Label
    Friend WithEvents lblFluxRecOn As Label
    Friend WithEvents Label90 As Label
    Friend WithEvents lblHeadCollOn As Label
    Friend WithEvents Label73 As Label
    Friend WithEvents Label103 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Label104 As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents Label105 As Label
    Friend WithEvents Label76 As Label
    Friend WithEvents lblTrControlOn As Label
    Friend WithEvents Label77 As Label
    Friend WithEvents lblproxip As Label
    Friend WithEvents lblalmsa3 As Label
    Friend WithEvents lblmanauto As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents lbltrconfb As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents lblSONEM2SA4 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents lblrdsa3 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents lblST1SA5 As Label
    Friend WithEvents lblEsscPSOff As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents lblFumeExtOn As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents lblHeadLampOn As Label
    Friend WithEvents lblWeldStart As Label
    Friend WithEvents lblalmsa4 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents lblemeron As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents lblWeldStop As Label
    Friend WithEvents lblTRCWFWDRot As Label
    Friend WithEvents Label79 As Label
    Friend WithEvents lblTRCCWREWRot As Label
    Friend WithEvents Label107 As Label
    Friend WithEvents lblTRStartPB As Label
    Friend WithEvents lblrdsa5 As Label
    Friend WithEvents lblEsscPSOn As Label
    Friend WithEvents lblSONEM2SA5 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents lblalmsa5 As Label
    Friend WithEvents lblResetSA As Label
    Friend WithEvents Label108 As Label
    Friend WithEvents Label106 As Label
    Friend WithEvents lblFluxFunnDn As Label
    Friend WithEvents Label110 As Label
    Friend WithEvents lblStripDn As Label
    Friend WithEvents lblTREmerg As Label
    Friend WithEvents lblStripUp As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents lblSONEM2SA2 As Label
    Friend WithEvents lblSONEM2SA3 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents lblFluxFunnUp As Label
    Friend WithEvents lblSONEM2SA1 As Label
    Friend WithEvents Label66 As Label
    Friend WithEvents Label68 As Label
    Friend WithEvents Label71 As Label
    Friend WithEvents lblDirSa4 As Label
    Friend WithEvents lblFaultLamp As Label
    Friend WithEvents lblAutoOnLamp As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents Label84 As Label
    Friend WithEvents Label85 As Label
    Friend WithEvents lblrdsa1 As Label
    Friend WithEvents lblalmsa2 As Label
    Friend WithEvents lblalmsa1 As Label
    Friend WithEvents lblrdsa2 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents DIOy5 As Label
    Friend WithEvents DIOy4 As Label
    Friend WithEvents DIOy3 As Label
    Friend WithEvents DIOy2 As Label
    Friend WithEvents DIOy1 As Label
    Friend WithEvents DIOy0 As Label
    Friend WithEvents lblPulseSa1 As Label
    Friend WithEvents lblPulseSa2 As Label
    Friend WithEvents lblPulseSa3 As Label
    Friend WithEvents lblPulseSa4 As Label
    Friend WithEvents lblDirSa1 As Label
    Friend WithEvents lblDirSa2 As Label
    Friend WithEvents lblDirSa3 As Label
    Friend WithEvents lblantdftrip As Label
    Friend WithEvents DIOx7 As Label
    Friend WithEvents DIOx6 As Label
    Friend WithEvents DIOx5 As Label
    Friend WithEvents DIOx4 As Label
    Friend WithEvents DIOx3 As Label
    Friend WithEvents DIOx2 As Label
    Friend WithEvents DIOx1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblbpts As Label
    Friend WithEvents lblapxas As Label
    Friend WithEvents lblapts As Label
    Friend WithEvents lblbpxas As Label
    Friend WithEvents lblapyas As Label
    Friend WithEvents lblbpyas As Label
    Friend WithEvents lblapcs As Label
    Friend WithEvents lblbpcs As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblrdsa4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents lblSpare As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents lblTRTravelSpeed As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents lblAngFluxWeight As Label
    Friend WithEvents lblAngTrSpeed As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents lblAngAntiDriftTrip As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents lblAngCurrent As Label
    Friend WithEvents lblAngVoltage As Label
    Friend WithEvents lblAngJobTemp As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents lblAngFluxTemp As Label
    Friend WithEvents btnangstatus As Button
End Class
