﻿'----------------------------------
' iotESSC for L&T
' by  trapasia DigiReach @ 2017
' Diagnostice screen, status /value of all Digital and Analouge ports
' 
'----------------------------------
Public Class frmDiag
    Dim green As Color = Color.LightGreen
    Dim red As Color = Color.MistyRose

    Dim plcinstrg As String = ""
    Dim y As Integer = 0
    Dim y1 As Double
    Private Sub frmDiag_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        Timer1.Enabled = True

    End Sub

    Private Sub frmDiag_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Panel6.Left = (Me.Width - Panel6.Width) / 2
        Panel6.Top = (Me.Height - Panel6.Height) / 2
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Timer1.Enabled = false
        Me.Close()
    End Sub


    Private Sub Timer1_Tick(sender As Object, e As System.EventArgs) Handles Timer1.Tick
        Dim colorarr() As Color = {Color.Red, Color.LightGreen}

        Try
            'DIGNOSIS READ

            '-------------------       DIGITAL INPUT STATUS  ---------------------- 

            ' ALL READ CONTINUS




            plcinstrg = txComRX("03 01 00 00 00 14 3D E7", 150)
            Dim x1() As String = plcinstrg.Split(" "c)
            If x1.Count >= 4 Then
                If x1(0) = "03" And x1(1) = "01" Then

                    'A-PHASE TROLLEY SERVO

                    Dim bin As String = ReverseString(Hex2Bin(x1(4) & x1(3)))
                    Dim digits() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                    '  P1 = digits25(0) & ":" & digits25(1) & ":" & digits25(2) & ":" & digits25(3) & ":" & digits25(4) & ":" & digits25(5) & ":" & digits25(6) & ":" & digits25(7) & ":" & digits25(10) & ":" & digits25(11) & ":" & digits25(13) & ":" & digits25(14) & ":" & digits25(16)  & ":" & digits25(17)

                    Me.lblapts.BackColor = colorarr(digits(0))
                    Me.lblbpts.BackColor = colorarr(digits(1))
                    Me.lblapxas.BackColor = colorarr(digits(2))
                    Me.lblbpxas.BackColor = colorarr(digits(3))
                    Me.lblapyas.BackColor = colorarr(digits(4))
                    Me.lblbpyas.BackColor = colorarr(digits(5))
                    Me.lblapcs.BackColor = colorarr(digits(6))
                    Me.lblbpcs.BackColor = colorarr(digits(7))
                    Me.lblalmsa1.BackColor = colorarr(digits(10))
                    Me.lblrdsa1.BackColor = colorarr(digits(11))
                    Me.lblalmsa2.BackColor = colorarr(digits(13))
                    Me.lblrdsa2.BackColor = colorarr(digits(14))
                    Me.lblalmsa3.BackColor = colorarr(digits(16))
                    Me.lblrdsa3.BackColor = colorarr(digits(17))

                End If

            End If



            plcinstrg = ""
            plcinstrg = txComRX("03 01 00 15 00 11  EC 20", 150)
            Dim x2() As String = plcinstrg.Split(" "c)
            If x2.Count >= 4 Then
                If x2(0) = "03" And x2(1) = "01" Then

                    'ALM SA-4
                    Dim bin As String = ReverseString(Hex2Bin(x2(4) & x2(3)))
                    Dim digits1() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                    'P2 = digits26(0) & ":" & digits26(1) & ":" & digits26(3) & ":" & digits26(4) & ":" & digits26(6) & ":" & digits26(9) & ":" & digits26(10) & ":" & digits26(14) & ":" & digits26(15)

                    Me.lblalmsa4.BackColor = colorarr(digits1(0))
                    Me.lblrdsa4.BackColor = colorarr(digits1(1))
                    Me.lblalmsa5.BackColor = colorarr(digits1(3))
                    Me.lblrdsa5.BackColor = colorarr(digits1(4))
                    Me.lblemeron.BackColor = colorarr(digits1(6))
                    Me.lblproxip.BackColor = colorarr(digits1(9))
                    Me.lblmanauto.BackColor = colorarr(digits1(10))
                    Me.lbltrconfb.BackColor = colorarr(digits1(14))
                    Me.lblAngAntiDriftTrip.BackColor = colorarr(digits1(15))

                End If

            End If

            '-------------   DIGITAL OUTPUT STATUS  --------------------------



            plcinstrg = ""
            plcinstrg = txComRX("03 01 00 00 00 15 FC 27", 150)
            Dim x3() As String = plcinstrg.Split(" "c)
            If x3.Count >= 4 Then
                If x3(0) = "03" And x3(1) = "01" Then

                    'PULSE SA-1

                    Dim bin As String = ReverseString(Hex2Bin(x3(4) & x3(3)))
                    Dim digits2() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                    ' p3 = digits27(0) & ":" & digits27(1) & ":" & digits27(2) & ":" & digits27(3) & ":" & digits27(4) & ":" & digits27(5) & ":" & digits27(6) & ":" & digits27(7) & ":" & digits27(10) & ":" & digits27(11) & ":" & digits27(14) & ":" & digits27(15) & ":" & digits27(16) & ":" & digits27(17) & ":" & digits27(20)

                    Me.lblPulseSa1.BackColor = colorarr(digits2(0))
                    Me.lblPulseSa2.BackColor = colorarr(digits2(1))
                    Me.lblPulseSa3.BackColor = colorarr(digits2(2))
                    Me.lblPulseSa4.BackColor = colorarr(digits2(3))
                    Me.lblDirSa1.BackColor = colorarr(digits2(4))
                    Me.lblDirSa2.BackColor = colorarr(digits2(5))
                    Me.lblDirSa3.BackColor = colorarr(digits2(6))
                    Me.lblDirSa4.BackColor = colorarr(digits2(7))
                    Me.lblFaultLamp.BackColor = colorarr(digits2(10))
                    Me.lblAutoOnLamp.BackColor = colorarr(digits2(11))
                    Me.lblSONEM2SA1.BackColor = colorarr(digits2(14))
                    Me.lblSONEM2SA2.BackColor = colorarr(digits2(15))
                    Me.lblSONEM2SA3.BackColor = colorarr(digits2(16))
                    Me.lblSONEM2SA4.BackColor = colorarr(digits2(17))
                    Me.lblSONEM2SA5.BackColor = colorarr(digits2(20))


                End If
            End If


            plcinstrg = ""
            plcinstrg = txComRX("03 01 00 15 00 14 2C 23", 150)
            Dim x4() As String = plcinstrg.Split(" "c)
            If x4.Count >= 4 Then
                If x4(0) = "03" And x4(1) = "01" Then

                    'RESET SA 1-5

                    Dim bin As String = ReverseString(Hex2Bin(x4(4) & x4(3)))
                    Dim digits3() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                    '   p4 = digits27(0) & ":" & digits27(1) & ":" & digits27(2) & ":" & digits27(5) & ":" & digits27(6) & ":" & digits27(9) & ":" & digits27(10) & ":" & digits27(11) & ":" & digits27(12) & ":" & digits27(13) & ":" & digits27(14) & ":" & digits27(15) & ":" & digits27(16) & ":" & digits27(19)


                    Me.lblResetSA.BackColor = colorarr(digits3(0))
                    Me.lblFluxFunnUp.BackColor = colorarr(digits3(1))
                    Me.lblFluxFunnDn.BackColor = colorarr(digits3(2))
                    Me.lblST1SA5.BackColor = colorarr(digits3(5))
                    Me.lblTrControlOn.BackColor = colorarr(digits3(6))
                    Me.lblWeldStart.BackColor = colorarr(digits3(9))
                    Me.lblWeldStop.BackColor = colorarr(digits3(10))
                    Me.lblStripUp.BackColor = colorarr(digits3(11))
                    Me.lblStripDn.BackColor = colorarr(digits3(12))
                    Me.lblTREmerg.BackColor = colorarr(digits3(13))
                    Me.lblTRStartPB.BackColor = colorarr(digits3(14))
                    Me.lblTRCWFWDRot.BackColor = colorarr(digits3(15))
                    Me.lblTRCCWREWRot.BackColor = colorarr(digits3(16))
                    Me.lblEsscPSOn.BackColor = colorarr(digits3(19))

                End If
            End If

            plcinstrg = ""
            plcinstrg = txComRX("03 01 00 29 00 11 2C 2C", 150)
            Dim x5() As String = plcinstrg.Split(" "c)
            If x5.Count >= 4 Then
                If x5(0) = "03" And x5(1) = "01" Then


                    'ESSC P/S OFF

                    Dim bin As String = ReverseString(Hex2Bin(x5(4) & x5(3)))
                    Dim digits4() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                    '     p5 = digits28(0) & ":" & digits28(1) & ":" & digits28(2) & ":" & digits28(3) & ":" & digits28(4) & ":" & digits28(5) & ":" & digits28(6) & ":" & digits28(9) & ":" & digits28(10) & ":" & digits28(11) & ":" & digits28(12)


                    Me.lblEsscPSOff.BackColor = colorarr(digits4(0))
                    Me.lblFumeExtOn.BackColor = colorarr(digits4(1))
                    Me.lblHeadLampOn.BackColor = colorarr(digits4(2))
                    Me.lblHeadCollOn.BackColor = colorarr(digits4(3))
                    Me.lblFluxRecOn.BackColor = colorarr(digits4(4))
                    Me.lblFluxOvenOn.BackColor = colorarr(digits4(5))
                    Me.lblFluxFill.BackColor = colorarr(digits4(6))
                    Me.lblMagnetOn.BackColor = colorarr(digits4(9))
                    Me.lblWinchOn.BackColor = colorarr(digits4(10))
                    Me.lblIRHeatSysOn.BackColor = colorarr(digits4(11))
                    Me.lblTrolOn.BackColor = colorarr(digits4(12))

                End If

            End If

            y = 0
            y1 = 0
            plcinstrg = ""

            plcinstrg = txComRX("03 03 05 DC 00 10 84 D2", 50)
            Dim x49() As String = plcinstrg.Split(" "c)
            If x49.Count >= 4 Then
                If x49(0) = "03" And x49(1) = "03" Then
                    y = Convert.ToInt32(x49(3) & x49(4), 16)
                    ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                    gANGCURRENT = Math.Round(y / 1000, 2)
                    ' MessageBox.Show("Essc current := " + gESSCcur.ToString())

                    y = 0
                    y = Convert.ToInt32(x49(5) & x49(6), 16)
                    ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                    gANGVOLTAGE = Math.Round(y / 1000, 2)

                    y = 0
                    y = Convert.ToInt32(x49(7) & x49(8), 16)
                    ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                    gANGJOBTEMP = Math.Round(y / 1000, 2)

                    y = 0
                    y = Convert.ToInt32(x49(9) & x49(10), 16)
                    ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                    gANGFLUXTEMP = Math.Round(y / 1000, 2)

                    y = 0
                    y = Convert.ToInt32(x49(11) & x49(12), 16)
                    ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                    gANGFLUXWEIGHT = Math.Round(y / 1000, 2)

                    y = 0
                    y = Convert.ToInt32(x49(13) & x49(14), 16)
                    ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                    gANGANTDRIFT = Math.Round(y / 1000, 2)

                    y = 0
                    y = Convert.ToInt32(x49(15) & x49(16), 16)
                    ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                    gANGTRspeed = Math.Round(y / 1000, 2)

                End If
            End If

            Me.lblAngCurrent.Text = gANGCURRENT.ToString()
            Me.lblAngVoltage.Text = gANGVOLTAGE.ToString()
            Me.lblAngJobTemp.Text = gANGJOBTEMP.ToString()
            Me.lblAngFluxTemp.Text = gANGFLUXTEMP.ToString()
            Me.lblAngFluxWeight.Text = gANGFLUXWEIGHT.ToString()
            Me.lblAngTrSpeed.Text = gANGTRspeed.ToString()
            Me.lblAngAntiDriftTrip.Text = gANGANTDRIFT.ToString()


            y = 0
            y1 = 0
            plcinstrg = ""

            plcinstrg = txComRX("03 03 04 10 00 02 C51C", 50)
            Dim x52() As String = plcinstrg.Split(" "c)
            If x52.Count >= 4 Then
                If x52(0) = "03" And x52(1) = "03" Then
                    y = Convert.ToInt32(x52(3) & x52(4), 16)
                    ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                    gANGCURRENT = Math.Round(y / 1000, 2)
                    ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                End If
            End If

        Catch ex As Exception
            MessageBox.Show("Error during Timer1_Tick method of frmDiag module, Error : " + ex.Message.ToString())
        End Try

    End Sub

    Private Sub btnSetup_Click(sender As System.Object, e As System.EventArgs) Handles btnSetup.Click
        Dim testDialog As New frmParaPass

        ' Show testDialog as a modal dialog and determine if DialogResult = OK.
        If testDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
            ' Read the contents of testDialog's TextBox.
            If testDialog.txtPass.Text = "" Then
            Else
                If (testDialog.txtPass.Text = gParaPass) Then

                    Dim obj As New frmSetup
                    obj.Show()
                Else
                    Dim result As String = MessageBoxEx.Show("Invalid Password ", "Para Setting", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
                End If
            End If
        End If
        testDialog.Dispose()
    End Sub

    Private Sub btnangstatus_Click(sender As Object, e As EventArgs) Handles btnangstatus.Click

        Dim obj As New frmAndstatus
        obj.TopLevel = False
        obj.Dock = DockStyle.Fill
        obj.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        obj.ControlBox = False
        obj.Text = ""
        obj.WindowState = FormWindowState.Maximized
        obj.MdiParent = Me
        obj.Show()
    End Sub
End Class