﻿'----------------------------------
' iotESSC for L&T
' by  trapasia DigiReach @ 2017
' Diagnostice screen, status /value of all Digital and Analouge ports
' 
'----------------------------------
Public Class frmDiag
    Dim green As Color = Color.LightGreen
    Dim red As Color = Color.MistyRose

    Dim plcinstrg As String = ""
    Dim y As Integer = 0 '
    Dim y1 As Double
    Dim colorarr() As Color = {Color.Silver, Color.Green}

    Dim tx As String = ""
    Dim rx As String = ""


    Private Sub frmDiag_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        Me.WindowState = FormWindowState.Maximized
        Timer1.Enabled = True

    End Sub

    Private Sub frmDiag_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Panel6.Left = (Me.Width - Panel6.Width) / 2
        Panel6.Top = (Me.Height - Panel6.Height) / 2
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        gDiag = False
        Timer1.Enabled = False
        Me.Close()
    End Sub


    Private Sub Timer1_Tick(sender As Object, e As System.EventArgs) Handles Timer1.Tick

        Try
            'DIGNOSIS READ

            '-------------------       DIGITAL INPUT STATUS  ---------------------- 


            ' ALL READ CONTINUS

            If ghealthy = 1 Then
                lblHealthy.Image = Global.iotPIPECLEDING.My.Resources.healthy
            Else
                lblHealthy.Image = Global.iotPIPECLEDING.My.Resources.healthyG
            End If

            If gFAULT = 1 Then
                lblFault.Image = Global.iotPIPECLEDING.My.Resources.fault
            Else
                lblFault.Image = Global.iotPIPECLEDING.My.Resources.faultG
            End If

            If gALARM = 1 Then
                lblAlarm.Image = Global.iotPIPECLEDING.My.Resources.alarm
            Else
                lblAlarm.Image = Global.iotPIPECLEDING.My.Resources.alarmG
            End If

            Me.lblF1.BackColor = colorarr(gFault1)
            Me.lblF2.BackColor = colorarr(gFault2)
            Me.lblF3.BackColor = colorarr(gFault3)
            Me.lblF4.BackColor = colorarr(gFault4)
            Me.lblF5.BackColor = colorarr(gFault5)
            Me.lblF6.BackColor = colorarr(gFault6)
            Me.lblF7.BackColor = colorarr(gFault7)
            Me.lblF8.BackColor = colorarr(gFault8)
            Me.lblF9.BackColor = colorarr(gFault9)
            Me.lblF10.BackColor = colorarr(gFault10)
            Me.lblF11.BackColor = colorarr(gFault11)
            Me.lblF12.BackColor = colorarr(gFault12)
            Me.lblF13.BackColor = colorarr(gFault13)
            Me.lblF14.BackColor = colorarr(gFault14)
            Me.lblF15.BackColor = colorarr(gFault15)
            Me.lblF16.BackColor = colorarr(gFault16)
            Me.lblF17.BackColor = colorarr(gFault17)
            Me.lblF18.BackColor = colorarr(gFault18)
            Me.lblF19.BackColor = colorarr(gFault19)
            Me.lblF20.BackColor = colorarr(gFault20)
            Me.lblF21.BackColor = colorarr(gFault21)
            Me.lblF22.BackColor = colorarr(gFault22)
            Me.lblF23.BackColor = colorarr(gFault23)
            Me.lblF24.BackColor = colorarr(gFault24)
            Me.lblF25.BackColor = colorarr(gFault25)
            Me.lblF26.BackColor = colorarr(gFault26)
            Me.lblF27.BackColor = colorarr(gFault27)
            Me.lblF28.BackColor = colorarr(gFault28)
            Me.lblF29.BackColor = colorarr(gFault29)
            Me.lblF30.BackColor = colorarr(gFault30)


            '-------------------       ALARM STATUS  ---------------------- 

            ' ALL READ CONTINUS
            '//////////// REV LIMIT /////////////////

            Me.lblXrevlimit.BackColor = colorarr(gRLimitAxis1)
            Me.lblYreviimit.BackColor = colorarr(gRLimitAxis2)
            Me.lblTrevlimit.BackColor = colorarr(gRLimitAxis3)
            Me.lblArevlimit.BackColor = colorarr(gRLimitAxis4)
            Me.lblRrevlimit.BackColor = colorarr(gRLimitAxis5)


            Me.lblXfwdlimit.BackColor = colorarr(gFLIimitAxis1)
            Me.lblYfwdlimit.BackColor = colorarr(gFLIimitAxis2)
            Me.lblTfwdlimit.BackColor = colorarr(gFLIimitAxis3)
            Me.lblAfwdlimit.BackColor = colorarr(gFLIimitAxis4)
            Me.lblRfwdlimit.BackColor = colorarr(gFLIimitAxis5)

            txtFC1.Text = gErrorCodeSA1.ToString()
            txtFC2.Text = gErrorCodeSA2.ToString()
            txtFC3.Text = gErrorCodeSA3.ToString()
            txtFC4.Text = gErrorCodeSA4.ToString()
            txtFC5.Text = gErrorCodeSA5.ToString()

        Catch ex As Exception
            MessageBox.Show("Error during Timer1_Tick method of frmDiag module, Error : " + ex.Message.ToString())
        End Try

    End Sub

    'Private Sub btnSetup_Click(sender As System.Object, e As System.EventArgs) Handles btnSetup.Click
    '    Dim testDialog As New frmParaPass

    '    ' Show testDialog as a modal dialog and determine if DialogResult = OK.
    '    If testDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
    '        ' Read the contents of testDialog's TextBox.
    '        If testDialog.txtPass.Text = "" Then
    '        Else
    '            If (testDialog.txtPass.Text = gParaPass) Then

    '                Dim obj As New frmSetup
    '                obj.Show()
    '            Else
    '                Dim result As String = MessageBoxEx.Show("Invalid Password ", "Para Setting", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
    '            End If
    '        End If
    '    End If
    '    testDialog.Dispose()
    'End Sub

    Private Sub btnang_Click(sender As Object, e As EventArgs) Handles btnang.Click
        'Dim testDialog As New frmAngstatus

        '''''''' ' Show testDialog as a modal dialog and determine if DialogResult = OK.
        '  If testDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
        '''''' ' Read the contents of testDialog's TextBox.
        '      End If
        ' testDialog.Dispose()
        '///////////////////////////////////////////

        Dim testDialog As New frmParaPass
        If testDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
            ' Read the contents of testDialog's TextBox.
            If testDialog.txtPass.Text = "" Then
            Else
                If (testDialog.txtPass.Text = gParaPass) Then
                    Dim obj As New frmAngstatus
                    obj.TopLevel = False
                    obj.Dock = DockStyle.Fill
                    obj.FormBorderStyle = Windows.Forms.FormBorderStyle.None
                    obj.ControlBox = False
                    obj.Text = ""
                    obj.WindowState = FormWindowState.Maximized
                    obj.MdiParent = MdiParent
                    obj.Show()

                Else
                    Dim result As String = MessageBoxEx.Show("Invalid Password ", "Para Setting", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
                End If
            End If
        End If
        testDialog.Dispose()


    End Sub

    Private Sub Label104_Click(sender As Object, e As EventArgs) Handles Label104.Click

    End Sub

    Private Sub BtnDigSts_Click(sender As Object, e As EventArgs) Handles btnDigSts.Click
        ''Dim testDialog As New frmDigStatus

        '' Show testDialog as a modal dialog and determine if DialogResult = OK.
        ''If testDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
        ''    ' Read the contents of testDialog's TextBox.

        ''End If
        '        testDialog.Dispose()

        Dim objdigstatus As New frmDigStatus
        objdigstatus.TopLevel = False
        objdigstatus.Dock = DockStyle.Fill
        objdigstatus.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        objdigstatus.ControlBox = False
        objdigstatus.Text = ""
        objdigstatus.WindowState = FormWindowState.Maximized
        objdigstatus.MdiParent = MdiParent
        objdigstatus.Show()



    End Sub

    Private Sub BtnLimistatus_Click(sender As Object, e As EventArgs) Handles btnLimistatus.Click
        ''''Dim testDialog As New frmlimit

        ''''' Show testDialog as a modal dialog and determine if DialogResult = OK.
        ''''If testDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
        ''''    ' Read the contents of testDialog's TextBox.

        ''''End If
        '''''''''''''' testDialog.Dispose()
        '\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

        Dim testDialog As New frmParaPass
        If testDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
            ' Read the contents of testDialog's TextBox.
            If testDialog.txtPass.Text = "" Then
            Else
                If (testDialog.txtPass.Text = gParaPass) Then
                    Dim obj As New frmlimit
                    obj.TopLevel = False
                    obj.Dock = DockStyle.Fill
                    obj.FormBorderStyle = Windows.Forms.FormBorderStyle.None
                    obj.ControlBox = False
                    obj.Text = ""
                    obj.WindowState = FormWindowState.Maximized
                    obj.MdiParent = MdiParent
                    obj.Show()

                Else
                    Dim result As String = MessageBoxEx.Show("Invalid Password ", "Para Setting", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
                End If
            End If
        End If
        testDialog.Dispose()



    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim testDialog As New frmParaPass
        If testDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
            ' Read the contents of testDialog's TextBox.
            If testDialog.txtPass.Text = "" Then
            Else
                If (testDialog.txtPass.Text = gParaPass) Then
                    Dim obj As New frmDelay
                    obj.TopLevel = False
                    obj.Dock = DockStyle.Fill
                    obj.FormBorderStyle = Windows.Forms.FormBorderStyle.None
                    obj.ControlBox = False
                    obj.Text = ""
                    obj.WindowState = FormWindowState.Maximized
                    obj.MdiParent = MdiParent
                    obj.Show()

                Else
                    Dim result As String = MessageBoxEx.Show("Invalid Password ", "Para Setting", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
                End If
            End If
        End If
        testDialog.Dispose()


    End Sub

    Private Sub btnResetAll_Click(sender As Object, e As EventArgs) Handles btnResetAll.Click
        If isConnection = True Then
            btnResetAll.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resetg

            tx = ""
            rx = ""
            tx = "00 00 00 00 00 06 02 05 00 04 FF 00"
            rx = TCPComA(tx, 0)
            'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

            Threading.Thread.Sleep(1000)

            tx = ""
            rx = ""
            tx = "00 00 00 00 00 06 02 05 00 04 00 00"
            rx = TCPComA(tx, 0)
            'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
            '            
            btnResetAll.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resetb

        End If
    End Sub

    Private Sub btnResetAll_gotfocus(sender As Object, e As EventArgs) Handles btnResetAll.GotFocus
        'btnResetAll.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resetg
        'Threading.Thread.Sleep(1000)
        'btnResetAll.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resetb
    End Sub

    Private Sub DIOx2_Click(sender As Object, e As EventArgs) Handles DIOx2.Click

    End Sub



End Class