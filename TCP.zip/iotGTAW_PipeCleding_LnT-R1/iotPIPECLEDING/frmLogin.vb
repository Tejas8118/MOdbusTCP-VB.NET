﻿'--------------------------------------------------------------------------
' iotESSC for L&T
' by  trapasia DigiReach @ 2017
' Login screen , using RFID Card and converting Decimal value to Hesa CSNo
' if CSN Validate go to next screen or return to main
' 521649452
'--------------------------------------------------------------------------
Imports System.Data
Imports System.Data.OleDb

Public Class frmLogin
    Private Sub frmLogin_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        txtCSN.Select()
    End Sub

    Private Sub frmLogin_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Panel1.Top = (Me.Height - Panel1.Height) / 2
        Panel1.Left = (Me.Width - Panel1.Width) / 2
    End Sub
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles btnLogin.Click
        gLogin = logincheck()
        If gLogin = True Then
            Dim OBJ As New frmPS
            OBJ.MdiParent = MDIParent1
            OBJ.Show()
            Me.Close()
        Else
            Dim result As String = MessageBoxEx.Show("You are not Authorised to Login", "Login", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString
            Me.Close()
        End If
    End Sub

    Private Function logincheck() As Boolean
        'Dim dr As OleDbDataReader
        ' Dim dr1 As OleDbDataReader
        ' Dim dr2 As OleDbDataReader

        gLogin = False
        Dim web As Boolean = False

        If (txtCSN.Text <> "" And IsNumeric(txtCSN.Text)) Then

            'gcsnno = dec2Hex(txtCSN.Text)

            gcsnno = Int64.Parse(txtCSN.Text.Trim()).ToString("X").PadLeft(8, "0")

            'Check ERPLN DB Connectivity
            Using myservice As New SQLDB()
                ERPLNDBConnectivity = myservice.checkERPLNDBConnectivity()
            End Using

            Dim Err As String = ""
            Using myservice As New SQLDB()
                Try
                    'myservice.timeout = 2000
                    Dim z As DataTable = myservice.getEmployeeDataFromCSN(gcsnno, Err)
                    For Each row As DataRow In z.Rows
                        gpsno = row.Item("t_psno")
                        gwelder_nm = row.Item("t_name")
                        ''Dim stmp As String = row.Item("t_stmp")
                        gLogin = True
                        web = True
                    Next row
                Catch ex As Exception
                    'writeLog("Unable to connect web services")
                    MessageBox.Show("Error from logincheck() method, Error : " + ex.Message.ToString())
                    gLogin = False
                End Try
            End Using

            If web = False Then
                'dr = objCon.ExecuteDataReader("select csno,wname,psno,stmp from welderlist where csno='" & gcsnno & "'", CommandType.Text)
                'While dr.Read 'Loop while reading
                '    gwelder_nm = IIf(Convert.IsDBNull(dr("wname")), "", dr("wname"))
                '    gpsno = IIf(Convert.IsDBNull(dr("psno")), "", dr("psno"))
                '    gLogin = True
                'End While

                Using objCon As New dbClass
                    Try
                        Using dt As DataTable = objCon.ExecuteDataTable("select csno,wname,psno,stmp from welderlist where csno='" & gcsnno & "'", CommandType.Text)
                            For Each row As DataRow In dt.Rows
                                gwelder_nm = IIf(Convert.IsDBNull(row("wname")), "", row("wname"))
                                gpsno = IIf(Convert.IsDBNull(row("psno")), "", row("psno"))
                                gLogin = True
                            Next
                        End Using
                    Catch ex As Exception
                        MessageBox.Show("Error from logincheck() method, Error : " + ex.Message.ToString())
                    End Try
                End Using
            End If

            If gLogin = True Then
                Using objCon As New dbClass
                    Try
                        txtName.Text = gwelder_nm
                        txtID.Text = gpsno & " " & gcsnno
                        objCon.ExecuteNonQuery("update device set weldernm='" & gwelder_nm & "',psno='" & gpsno & "',csnno='" & gcsnno & "' where id= 1", CommandType.Text)

                        Using dt As DataTable = objCon.ExecuteDataTable("select * from device where csnno='" & gcsnno & "'", CommandType.Text)
                            For Each row As DataRow In dt.Rows
                                gshop = row("shop")
                                gstation = row("station")
                                gwelder_nm = IIf(Convert.IsDBNull(row("weldernm")), "", row("weldernm"))
                                gpsno = IIf(Convert.IsDBNull(row("psno")), "", row("psno"))
                                gprojectno = IIf(Convert.IsDBNull(row("projectno")), "", row("projectno"))
                                gprojectname = IIf(Convert.IsDBNull(row("projectname")), "", row("projectname"))
                                gseamno = IIf(Convert.IsDBNull(row("seamno")), "", row("seamno"))
                                gPass = IIf(Convert.IsDBNull(row("passno")), "", row("passno"))
                                glayer = IIf(Convert.IsDBNull(row("layerno")), "", row("layerno"))
                                gComTX = IIf(Convert.IsDBNull(row("comportTX")), "", row("comportTX"))
                                gComRX = IIf(Convert.IsDBNull(row("comportRX")), "", row("comportRX"))
                                gSpeed = IIf(Convert.IsDBNull(row("speed")), "", row("speed"))
                                gWPSno = IIf(Convert.IsDBNull(row("wpsno")), "", row("wpsno"))
                                gsize = IIf(Convert.IsDBNull(row("gsize")), "", row("gsize"))
                                'gshopno = IIf(Convert.IsDBNull(row("gshopno")), "", row("gshopno"))
                                'gcmbno = IIf(Convert.IsDBNull(row("gcmbno")), "", row("gcmbno"))
                                'gshopname = IIf(Convert.IsDBNull(row("gshopname")), "", row("gshopname"))
                                'gcmbname = IIf(Convert.IsDBNull(row("gcmbname")), "", row("gcmbname"))
                                gMachineIP = IIf(Convert.IsDBNull(row("machineIP")), "", row("machineIP"))
                                gLogin = True
                            Next
                        End Using
                        gMachine = gPROCESS
                    Catch ex As Exception
                        MessageBox.Show("Error from logincheck() method, Error : " + ex.Message.ToString())
                    End Try
                End Using
            End If
        End If
        Return gLogin
    End Function
End Class
