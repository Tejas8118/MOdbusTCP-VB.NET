﻿
Imports System.Net.HttpWebRequest
Imports System.Net
Imports System.Text
Imports System.Net.WebRequestMethods
Imports System.IO
Public Class UserControl7

    Private Sub btnleft_touchDN(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnleft.TouchEnter
        ' Dim byteArray As Byte()
        Dim webRequest As HttpWebRequest = DirectCast(Net.WebRequest.Create("http://192.168.10.2/PTZ/Channels/1/PTZControl?command=PAN_LEFT&speed=" + gspeedcam + "&mode=start"), HttpWebRequest)
        webRequest.Method = "PUT"
        webRequest.ContentLength = 0
        Dim auth As String = "admin" & ":" & "12345"
        auth = Convert.ToBase64String(Encoding.Default.GetBytes(auth))
        webRequest.Headers("Authorization") = "Basic " & auth
        Dim response As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
        Dim receiveStream As Stream = response.GetResponseStream()
        Dim readStream As New StreamReader(receiveStream, Encoding.UTF8)

        '  Dim requestWriter As Stream = webRequest.GetRequestStream
        ''requestWriter.Write(byteArray, 0, byteArray.Length)

        response.Close()
        readStream.Close()


    End Sub

    Private Sub btnrleft_TouchEnter(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnleft.TouchEnter
        ' Dim byteArray As Byte()
        Dim webRequest As HttpWebRequest = DirectCast(Net.WebRequest.Create("http://192.168.10.2/PTZ/Channels/1/PTZControl?command=PAN_LEFT&speed=" + gspeedcam + "&mode=stop"), HttpWebRequest)
        webRequest.Method = "PUT"
        webRequest.ContentLength = 0
        Dim auth As String = "admin" & ":" & "12345"
        auth = Convert.ToBase64String(Encoding.Default.GetBytes(auth))
        webRequest.Headers("Authorization") = "Basic " & auth
        Dim response As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
        Dim receiveStream As Stream = response.GetResponseStream()
        Dim readStream As New StreamReader(receiveStream, Encoding.UTF8)

        '  Dim requestWriter As Stream = webRequest.GetRequestStream
        ''requestWriter.Write(byteArray, 0, byteArray.Length)

        response.Close()
        readStream.Close()



    End Sub

    Private Sub btnright_touchDN(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnright.TouchEnter
        'Dim byteArray As Byte()
        Dim webRequest As HttpWebRequest = DirectCast(Net.WebRequest.Create("http://192.168.10.2/PTZ/Channels/1/PTZControl?command=PAN_RIGHT&speed=" + gspeedcam + "&mode=start"), HttpWebRequest)
        webRequest.Method = "PUT"
        webRequest.ContentLength = 0
        Dim auth As String = "admin" & ":" & "12345"
        auth = Convert.ToBase64String(Encoding.Default.GetBytes(auth))
        webRequest.Headers("Authorization") = "Basic " & auth
        Dim response As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
        Dim receiveStream As Stream = response.GetResponseStream()
        Dim readStream As New StreamReader(receiveStream, Encoding.UTF8)

        '  Dim requestWriter As Stream = webRequest.GetRequestStream
        ''requestWriter.Write(byteArray, 0, byteArray.Length)

        response.Close()
        readStream.Close()


    End Sub

    Private Sub btnright_TouchEnter(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnright.TouchEnter

        'Dim byteArray As Byte()
        Dim webRequest As HttpWebRequest = DirectCast(Net.WebRequest.Create("http://192.168.10.2/PTZ/Channels/1/PTZControl?command=PAN_RIGHT&speed=" + gspeedcam + "&mode=stop"), HttpWebRequest)
        webRequest.Method = "PUT"
        webRequest.ContentLength = 0
        Dim auth As String = "admin" & ":" & "12345"
        auth = Convert.ToBase64String(Encoding.Default.GetBytes(auth))
        webRequest.Headers("Authorization") = "Basic " & auth
        Dim response As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
        Dim receiveStream As Stream = response.GetResponseStream()
        Dim readStream As New StreamReader(receiveStream, Encoding.UTF8)

        '  Dim requestWriter As Stream = webRequest.GetRequestStream
        ''requestWriter.Write(byteArray, 0, byteArray.Length)

        response.Close()
        readStream.Close()


    End Sub

    Private Sub btnup_touchDN(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnup.TouchEnter
        'Dim byteArray As Byte()
        Dim webRequest As HttpWebRequest = DirectCast(Net.WebRequest.Create("http://192.168.10.2/PTZ/Channels/1/PTZControl?command=TILT_UP&speed=" + gspeedcam + "&mode=start"), HttpWebRequest)
        webRequest.Method = "PUT"
        webRequest.ContentLength = 0
        Dim auth As String = "admin" & ":" & "12345"
        auth = Convert.ToBase64String(Encoding.Default.GetBytes(auth))
        webRequest.Headers("Authorization") = "Basic " & auth
        Dim response As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
        Dim receiveStream As Stream = response.GetResponseStream()
        Dim readStream As New StreamReader(receiveStream, Encoding.UTF8)

        '  Dim requestWriter As Stream = webRequest.GetRequestStream
        ''requestWriter.Write(byteArray, 0, byteArray.Length)

        response.Close()
        readStream.Close()



    End Sub

    Private Sub btnup_TouchEnter(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnup.TouchEnter

        'Dim byteArray As Byte()
        Dim webRequest As HttpWebRequest = DirectCast(Net.WebRequest.Create("http://192.168.10.2/PTZ/Channels/1/PTZControl?command=TILT_UP&speed=" + gspeedcam + "&mode=stop"), HttpWebRequest)
        webRequest.Method = "PUT"
        webRequest.ContentLength = 0
        Dim auth As String = "admin" & ":" & "12345"
        auth = Convert.ToBase64String(Encoding.Default.GetBytes(auth))
        webRequest.Headers("Authorization") = "Basic " & auth
        Dim response As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
        Dim receiveStream As Stream = response.GetResponseStream()
        Dim readStream As New StreamReader(receiveStream, Encoding.UTF8)

        '  Dim requestWriter As Stream = webRequest.GetRequestStream
        ''requestWriter.Write(byteArray, 0, byteArray.Length)

        response.Close()
        readStream.Close()

    End Sub

    Private Sub btndn_touchDN(sender As Object, e As Windows.Input.TouchEventArgs) Handles btndn.TouchEnter

        ' Dim byteArray As Byte()
        Dim webRequest As HttpWebRequest = DirectCast(Net.WebRequest.Create("http://192.168.10.2/PTZ/Channels/1/PTZControl?command=TILT_DN&speed=" + gspeedcam + "&mode=start"), HttpWebRequest)
        webRequest.Method = "PUT"
        webRequest.ContentLength = 0
        Dim auth As String = "admin" & ":" & "12345"
        auth = Convert.ToBase64String(Encoding.Default.GetBytes(auth))
        webRequest.Headers("Authorization") = "Basic " & auth
        Dim response As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
        Dim receiveStream As Stream = response.GetResponseStream()
        Dim readStream As New StreamReader(receiveStream, Encoding.UTF8)

        '  Dim requestWriter As Stream = webRequest.GetRequestStream
        ''requestWriter.Write(byteArray, 0, byteArray.Length)

        response.Close()
        readStream.Close()


    End Sub

    Private Sub btndn_TouchEnter(sender As Object, e As Windows.Input.TouchEventArgs) Handles btndn.TouchEnter

        'Dim byteArray As Byte()
        Dim webRequest As HttpWebRequest = DirectCast(Net.WebRequest.Create("http://192.168.10.2/PTZ/Channels/1/PTZControl?command=TILT_DN&speed=" + gspeedcam + "&mode=stop"), HttpWebRequest)
        webRequest.Method = "PUT"
        webRequest.ContentLength = 0
        Dim auth As String = "admin" & ":" & "12345"
        auth = Convert.ToBase64String(Encoding.Default.GetBytes(auth))
        webRequest.Headers("Authorization") = "Basic " & auth
        Dim response As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
        Dim receiveStream As Stream = response.GetResponseStream()
        Dim readStream As New StreamReader(receiveStream, Encoding.UTF8)

        '  Dim requestWriter As Stream = webRequest.GetRequestStream
        ''requestWriter.Write(byteArray, 0, byteArray.Length)

        response.Close()
        readStream.Close()


    End Sub

    Private Sub btnzoomout_touchDN(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnzoomout.TouchEnter
        'Dim byteArray As Byte()
        Dim webRequest As HttpWebRequest = DirectCast(Net.WebRequest.Create("http://192.168.10.2/PTZ/Channels/1/PTZControl?command=ZOOM_OUT&speed=" + gspeedcam + "&mode=start"), HttpWebRequest)
        webRequest.Method = "PUT"
        webRequest.ContentLength = 0
        Dim auth As String = "admin" & ":" & "12345"
        auth = Convert.ToBase64String(Encoding.Default.GetBytes(auth))
        webRequest.Headers("Authorization") = "Basic " & auth
        Dim response As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
        Dim receiveStream As Stream = response.GetResponseStream()
        Dim readStream As New StreamReader(receiveStream, Encoding.UTF8)

        '  Dim requestWriter As Stream = webRequest.GetRequestStream
        ''requestWriter.Write(byteArray, 0, byteArray.Length)

        response.Close()
        readStream.Close()


    End Sub

    Private Sub btnzoomout_TouchEnter(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnzoomout.TouchEnter
        'Dim byteArray As Byte()
        Dim webRequest As HttpWebRequest = DirectCast(Net.WebRequest.Create("http://192.168.10.2/PTZ/Channels/1/PTZControl?command=ZOOM_OUT&speed=" + gspeedcam + "&mode=stop"), HttpWebRequest)
        webRequest.Method = "PUT"
        webRequest.ContentLength = 0
        Dim auth As String = "admin" & ":" & "12345"
        auth = Convert.ToBase64String(Encoding.Default.GetBytes(auth))
        webRequest.Headers("Authorization") = "Basic " & auth
        Dim response As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
        Dim receiveStream As Stream = response.GetResponseStream()
        Dim readStream As New StreamReader(receiveStream, Encoding.UTF8)

        '  Dim requestWriter As Stream = webRequest.GetRequestStream
        ''requestWriter.Write(byteArray, 0, byteArray.Length)

        response.Close()
        readStream.Close()


    End Sub

    Private Sub btnzoomin_touchDN(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnzoomin.TouchEnter
        'Dim byteArray As Byte()
        Dim webRequest As HttpWebRequest = DirectCast(Net.WebRequest.Create("http://192.168.10.2/PTZ/Channels/1/PTZControl?command=ZOOM_IN&speed=" + gspeedcam + "&mode=start"), HttpWebRequest)
        webRequest.Method = "PUT"
        webRequest.ContentLength = 0
        Dim auth As String = "admin" & ":" & "12345"
        auth = Convert.ToBase64String(Encoding.Default.GetBytes(auth))
        webRequest.Headers("Authorization") = "Basic " & auth
        Dim response As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
        Dim receiveStream As Stream = response.GetResponseStream()
        Dim readStream As New StreamReader(receiveStream, Encoding.UTF8)

        '  Dim requestWriter As Stream = webRequest.GetRequestStream
        ''requestWriter.Write(byteArray, 0, byteArray.Length)

        response.Close()
        readStream.Close()

    End Sub

    Private Sub btnzoomin_TouchEnter(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnzoomin.TouchEnter
        'Dim byteArray As Byte()
        Dim webRequest As HttpWebRequest = DirectCast(Net.WebRequest.Create("http://192.168.10.2/PTZ/Channels/1/PTZControl?command=ZOOM_IN&speed=" + gspeedcam + "&mode=stop"), HttpWebRequest)
        webRequest.Method = "PUT"
        webRequest.ContentLength = 0
        Dim auth As String = "admin" & ":" & "12345"
        auth = Convert.ToBase64String(Encoding.Default.GetBytes(auth))
        webRequest.Headers("Authorization") = "Basic " & auth
        Dim response As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
        Dim receiveStream As Stream = response.GetResponseStream()
        Dim readStream As New StreamReader(receiveStream, Encoding.UTF8)

        '  Dim requestWriter As Stream = webRequest.GetRequestStream
        ''requestWriter.Write(byteArray, 0, byteArray.Length)

        response.Close()
        readStream.Close()

    End Sub

End Class
