﻿

Public Class UserControl1
    Dim tx As String = ""
    Dim rx As String = ""

    Private Sub B1_Click(ByVal sender As Object, ByVal e As Windows.Input.TouchEventArgs) Handles btnvcw.TouchEnter
        ''b2.TouchEnter execution
        'Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/dnE.png"))
        'Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        'b2.Background = imgbrush

        'b1.TouchEnter execution
        Dim imgsrc1 As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/cw1.png"))
        Dim imgbrush1 As New System.Windows.Media.ImageBrush(imgsrc1)
        btnvcw.Background = imgbrush1

        If isConnection = True Then
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 9E FF 00"
            rx = TCPComA(tx, 10)
            'writeLog("|ESSCupR |TX:" & tx & " |RX:" & rx)
        End If
    End Sub
    Private Sub b1_Click1(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnvcw.TouchLeave
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/cw.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnvcw.Background = imgbrush

        If isConnection = True Then
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 9E 00 00"
            rx = TCPComA(tx, 10)
            'writeLog("|ESSCupR |TX:" & tx & " |RX:" & rx)

            Threading.Thread.Sleep(1000)
            tx = ""
            rx = ""

            If isConnection = True Then
                tx = "00 00 00 00 00 06 02 05 00 9E 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|ESSCupR |TX:" & tx & " |RX:" & rx)
            End If

        End If
    End Sub


End Class
