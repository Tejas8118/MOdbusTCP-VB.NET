﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDigStatus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.pnlTR = New System.Windows.Forms.Panel()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.lblDO31 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.lblDO30 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.lblDO29 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.lblDO6 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.lblDO32 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblDO5 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.lblDi32 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.lblDi29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.lblDi28 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.lblDi27 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.lblDi23 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lblDi20 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblDi17 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblDi14 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblDi11 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblDi19 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.lblDO28 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.lblDO23 = New System.Windows.Forms.Label()
        Me.lblDO24 = New System.Windows.Forms.Label()
        Me.lblDO25 = New System.Windows.Forms.Label()
        Me.lblDO26 = New System.Windows.Forms.Label()
        Me.lblDO27 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.lblDO22 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.lblDO21 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.lblDO8 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.lblDi25 = New System.Windows.Forms.Label()
        Me.lblDi15 = New System.Windows.Forms.Label()
        Me.lblDi26 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.lblDi30 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.lblDi16 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.lblDO7 = New System.Windows.Forms.Label()
        Me.lblDO18 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.lblDO19 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.lblDO20 = New System.Windows.Forms.Label()
        Me.lblDO9 = New System.Windows.Forms.Label()
        Me.lblDi18 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.lblDi24 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.lblDO10 = New System.Windows.Forms.Label()
        Me.lblDO15 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.lblDO16 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.lblDO14 = New System.Windows.Forms.Label()
        Me.lblDi22 = New System.Windows.Forms.Label()
        Me.lblDO17 = New System.Windows.Forms.Label()
        Me.lblDO1 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.lblDi21 = New System.Windows.Forms.Label()
        Me.lblDO2 = New System.Windows.Forms.Label()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.lblDO4 = New System.Windows.Forms.Label()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.lblDO12 = New System.Windows.Forms.Label()
        Me.lblDO13 = New System.Windows.Forms.Label()
        Me.lblDO11 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.lblDO3 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.lblDi10 = New System.Windows.Forms.Label()
        Me.lblDi12 = New System.Windows.Forms.Label()
        Me.lblDi9 = New System.Windows.Forms.Label()
        Me.lblDi13 = New System.Windows.Forms.Label()
        Me.DIOy0 = New System.Windows.Forms.Label()
        Me.lblDi31 = New System.Windows.Forms.Label()
        Me.DIOx7 = New System.Windows.Forms.Label()
        Me.DIOx6 = New System.Windows.Forms.Label()
        Me.DIOx5 = New System.Windows.Forms.Label()
        Me.DIOx4 = New System.Windows.Forms.Label()
        Me.DIOx3 = New System.Windows.Forms.Label()
        Me.DIOx2 = New System.Windows.Forms.Label()
        Me.DIOx1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblDi2 = New System.Windows.Forms.Label()
        Me.lblDi3 = New System.Windows.Forms.Label()
        Me.lblDi1 = New System.Windows.Forms.Label()
        Me.lblDi4 = New System.Windows.Forms.Label()
        Me.lblDi5 = New System.Windows.Forms.Label()
        Me.lblDi6 = New System.Windows.Forms.Label()
        Me.lblDi7 = New System.Windows.Forms.Label()
        Me.lblDi8 = New System.Windows.Forms.Label()
        Me.Labei1 = New System.Windows.Forms.Label()
        Me.btnclose = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel6.SuspendLayout()
        Me.pnlTR.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Panel6.Controls.Add(Me.pnlTR)
        Me.Panel6.Controls.Add(Me.btnclose)
        Me.Panel6.Location = New System.Drawing.Point(7, 12)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(1059, 646)
        Me.Panel6.TabIndex = 1
        '
        'pnlTR
        '
        Me.pnlTR.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.pnlTR.Controls.Add(Me.Label61)
        Me.pnlTR.Controls.Add(Me.lblDO31)
        Me.pnlTR.Controls.Add(Me.Label59)
        Me.pnlTR.Controls.Add(Me.lblDO30)
        Me.pnlTR.Controls.Add(Me.Label27)
        Me.pnlTR.Controls.Add(Me.lblDO29)
        Me.pnlTR.Controls.Add(Me.Label23)
        Me.pnlTR.Controls.Add(Me.lblDO6)
        Me.pnlTR.Controls.Add(Me.Label18)
        Me.pnlTR.Controls.Add(Me.lblDO32)
        Me.pnlTR.Controls.Add(Me.Label10)
        Me.pnlTR.Controls.Add(Me.lblDO5)
        Me.pnlTR.Controls.Add(Me.Label41)
        Me.pnlTR.Controls.Add(Me.lblDi32)
        Me.pnlTR.Controls.Add(Me.Label30)
        Me.pnlTR.Controls.Add(Me.lblDi29)
        Me.pnlTR.Controls.Add(Me.Label28)
        Me.pnlTR.Controls.Add(Me.lblDi28)
        Me.pnlTR.Controls.Add(Me.Label24)
        Me.pnlTR.Controls.Add(Me.lblDi27)
        Me.pnlTR.Controls.Add(Me.Label21)
        Me.pnlTR.Controls.Add(Me.lblDi23)
        Me.pnlTR.Controls.Add(Me.Label17)
        Me.pnlTR.Controls.Add(Me.lblDi20)
        Me.pnlTR.Controls.Add(Me.Label13)
        Me.pnlTR.Controls.Add(Me.lblDi17)
        Me.pnlTR.Controls.Add(Me.Label11)
        Me.pnlTR.Controls.Add(Me.lblDi14)
        Me.pnlTR.Controls.Add(Me.Label5)
        Me.pnlTR.Controls.Add(Me.lblDi11)
        Me.pnlTR.Controls.Add(Me.Label7)
        Me.pnlTR.Controls.Add(Me.lblDi19)
        Me.pnlTR.Controls.Add(Me.Label3)
        Me.pnlTR.Controls.Add(Me.Label112)
        Me.pnlTR.Controls.Add(Me.lblDO28)
        Me.pnlTR.Controls.Add(Me.Label2)
        Me.pnlTR.Controls.Add(Me.Label37)
        Me.pnlTR.Controls.Add(Me.Label38)
        Me.pnlTR.Controls.Add(Me.Label39)
        Me.pnlTR.Controls.Add(Me.Label40)
        Me.pnlTR.Controls.Add(Me.lblDO23)
        Me.pnlTR.Controls.Add(Me.lblDO24)
        Me.pnlTR.Controls.Add(Me.lblDO25)
        Me.pnlTR.Controls.Add(Me.lblDO26)
        Me.pnlTR.Controls.Add(Me.lblDO27)
        Me.pnlTR.Controls.Add(Me.Label88)
        Me.pnlTR.Controls.Add(Me.lblDO22)
        Me.pnlTR.Controls.Add(Me.Label90)
        Me.pnlTR.Controls.Add(Me.lblDO21)
        Me.pnlTR.Controls.Add(Me.Label73)
        Me.pnlTR.Controls.Add(Me.Label103)
        Me.pnlTR.Controls.Add(Me.Label104)
        Me.pnlTR.Controls.Add(Me.Label75)
        Me.pnlTR.Controls.Add(Me.Label105)
        Me.pnlTR.Controls.Add(Me.Label76)
        Me.pnlTR.Controls.Add(Me.lblDO8)
        Me.pnlTR.Controls.Add(Me.Label77)
        Me.pnlTR.Controls.Add(Me.lblDi25)
        Me.pnlTR.Controls.Add(Me.lblDi15)
        Me.pnlTR.Controls.Add(Me.lblDi26)
        Me.pnlTR.Controls.Add(Me.Label32)
        Me.pnlTR.Controls.Add(Me.lblDi30)
        Me.pnlTR.Controls.Add(Me.Label33)
        Me.pnlTR.Controls.Add(Me.Label43)
        Me.pnlTR.Controls.Add(Me.Label35)
        Me.pnlTR.Controls.Add(Me.Label44)
        Me.pnlTR.Controls.Add(Me.lblDi16)
        Me.pnlTR.Controls.Add(Me.Label45)
        Me.pnlTR.Controls.Add(Me.Label46)
        Me.pnlTR.Controls.Add(Me.lblDO7)
        Me.pnlTR.Controls.Add(Me.lblDO18)
        Me.pnlTR.Controls.Add(Me.Label78)
        Me.pnlTR.Controls.Add(Me.lblDO19)
        Me.pnlTR.Controls.Add(Me.Label47)
        Me.pnlTR.Controls.Add(Me.lblDO20)
        Me.pnlTR.Controls.Add(Me.lblDO9)
        Me.pnlTR.Controls.Add(Me.lblDi18)
        Me.pnlTR.Controls.Add(Me.Label48)
        Me.pnlTR.Controls.Add(Me.lblDi24)
        Me.pnlTR.Controls.Add(Me.Label49)
        Me.pnlTR.Controls.Add(Me.Label55)
        Me.pnlTR.Controls.Add(Me.lblDO10)
        Me.pnlTR.Controls.Add(Me.lblDO15)
        Me.pnlTR.Controls.Add(Me.Label79)
        Me.pnlTR.Controls.Add(Me.lblDO16)
        Me.pnlTR.Controls.Add(Me.Label107)
        Me.pnlTR.Controls.Add(Me.lblDO14)
        Me.pnlTR.Controls.Add(Me.lblDi22)
        Me.pnlTR.Controls.Add(Me.lblDO17)
        Me.pnlTR.Controls.Add(Me.lblDO1)
        Me.pnlTR.Controls.Add(Me.Label16)
        Me.pnlTR.Controls.Add(Me.Label52)
        Me.pnlTR.Controls.Add(Me.lblDi21)
        Me.pnlTR.Controls.Add(Me.lblDO2)
        Me.pnlTR.Controls.Add(Me.Label108)
        Me.pnlTR.Controls.Add(Me.Label106)
        Me.pnlTR.Controls.Add(Me.lblDO4)
        Me.pnlTR.Controls.Add(Me.Label110)
        Me.pnlTR.Controls.Add(Me.lblDO12)
        Me.pnlTR.Controls.Add(Me.lblDO13)
        Me.pnlTR.Controls.Add(Me.lblDO11)
        Me.pnlTR.Controls.Add(Me.Label51)
        Me.pnlTR.Controls.Add(Me.lblDO3)
        Me.pnlTR.Controls.Add(Me.Label80)
        Me.pnlTR.Controls.Add(Me.Label83)
        Me.pnlTR.Controls.Add(Me.Label84)
        Me.pnlTR.Controls.Add(Me.Label85)
        Me.pnlTR.Controls.Add(Me.lblDi10)
        Me.pnlTR.Controls.Add(Me.lblDi12)
        Me.pnlTR.Controls.Add(Me.lblDi9)
        Me.pnlTR.Controls.Add(Me.lblDi13)
        Me.pnlTR.Controls.Add(Me.DIOy0)
        Me.pnlTR.Controls.Add(Me.lblDi31)
        Me.pnlTR.Controls.Add(Me.DIOx7)
        Me.pnlTR.Controls.Add(Me.DIOx6)
        Me.pnlTR.Controls.Add(Me.DIOx5)
        Me.pnlTR.Controls.Add(Me.DIOx4)
        Me.pnlTR.Controls.Add(Me.DIOx3)
        Me.pnlTR.Controls.Add(Me.DIOx2)
        Me.pnlTR.Controls.Add(Me.DIOx1)
        Me.pnlTR.Controls.Add(Me.Label4)
        Me.pnlTR.Controls.Add(Me.lblDi2)
        Me.pnlTR.Controls.Add(Me.lblDi3)
        Me.pnlTR.Controls.Add(Me.lblDi1)
        Me.pnlTR.Controls.Add(Me.lblDi4)
        Me.pnlTR.Controls.Add(Me.lblDi5)
        Me.pnlTR.Controls.Add(Me.lblDi6)
        Me.pnlTR.Controls.Add(Me.lblDi7)
        Me.pnlTR.Controls.Add(Me.lblDi8)
        Me.pnlTR.Controls.Add(Me.Labei1)
        Me.pnlTR.Location = New System.Drawing.Point(16, 12)
        Me.pnlTR.Margin = New System.Windows.Forms.Padding(2)
        Me.pnlTR.Name = "pnlTR"
        Me.pnlTR.Size = New System.Drawing.Size(1031, 592)
        Me.pnlTR.TabIndex = 10
        '
        'Label61
        '
        Me.Label61.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.Location = New System.Drawing.Point(820, 524)
        Me.Label61.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(174, 19)
        Me.Label61.TabIndex = 271
        Me.Label61.Text = "Y36- HWP/S ON HB"
        Me.Label61.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO31
        '
        Me.lblDO31.AutoEllipsis = True
        Me.lblDO31.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO31.Location = New System.Drawing.Point(788, 524)
        Me.lblDO31.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO31.Name = "lblDO31"
        Me.lblDO31.Size = New System.Drawing.Size(17, 19)
        Me.lblDO31.TabIndex = 270
        Me.lblDO31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label59
        '
        Me.Label59.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(820, 486)
        Me.Label59.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(174, 19)
        Me.Label59.TabIndex = 269
        Me.Label59.Text = "Y35- HWPS ON HA"
        Me.Label59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO30
        '
        Me.lblDO30.AutoEllipsis = True
        Me.lblDO30.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO30.Location = New System.Drawing.Point(788, 486)
        Me.lblDO30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO30.Name = "lblDO30"
        Me.lblDO30.Size = New System.Drawing.Size(17, 19)
        Me.lblDO30.TabIndex = 268
        Me.lblDO30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(820, 450)
        Me.Label27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(174, 19)
        Me.Label27.TabIndex = 267
        Me.Label27.Text = "Y34- P/S ON HB"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO29
        '
        Me.lblDO29.AutoEllipsis = True
        Me.lblDO29.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO29.Location = New System.Drawing.Point(788, 450)
        Me.lblDO29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO29.Name = "lblDO29"
        Me.lblDO29.Size = New System.Drawing.Size(17, 19)
        Me.lblDO29.TabIndex = 266
        Me.lblDO29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label23
        '
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(582, 199)
        Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(131, 19)
        Me.Label23.TabIndex = 265
        Me.Label23.Text = "Y5- SPARE"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO6
        '
        Me.lblDO6.AutoEllipsis = True
        Me.lblDO6.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO6.Location = New System.Drawing.Point(551, 199)
        Me.lblDO6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO6.Name = "lblDO6"
        Me.lblDO6.Size = New System.Drawing.Size(17, 19)
        Me.lblDO6.TabIndex = 264
        Me.lblDO6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(820, 557)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(193, 19)
        Me.Label18.TabIndex = 263
        Me.Label18.Text = "Y37- AUX LIGHT ON-OFF"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO32
        '
        Me.lblDO32.AutoEllipsis = True
        Me.lblDO32.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO32.Location = New System.Drawing.Point(788, 557)
        Me.lblDO32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO32.Name = "lblDO32"
        Me.lblDO32.Size = New System.Drawing.Size(17, 19)
        Me.lblDO32.TabIndex = 262
        Me.lblDO32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(582, 165)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(131, 19)
        Me.Label10.TabIndex = 261
        Me.Label10.Text = "Y4- SPARE"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO5
        '
        Me.lblDO5.AutoEllipsis = True
        Me.lblDO5.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO5.Location = New System.Drawing.Point(551, 165)
        Me.lblDO5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO5.Name = "lblDO5"
        Me.lblDO5.Size = New System.Drawing.Size(17, 19)
        Me.lblDO5.TabIndex = 260
        Me.lblDO5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label41
        '
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(303, 557)
        Me.Label41.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(210, 18)
        Me.Label41.TabIndex = 255
        Me.Label41.Text = "X37- HWP/S HEALTHY HB"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi32
        '
        Me.lblDi32.AutoEllipsis = True
        Me.lblDi32.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi32.Location = New System.Drawing.Point(275, 557)
        Me.lblDi32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi32.Name = "lblDi32"
        Me.lblDi32.Size = New System.Drawing.Size(17, 19)
        Me.lblDi32.TabIndex = 254
        Me.lblDi32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label30
        '
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(303, 450)
        Me.Label30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(143, 18)
        Me.Label30.TabIndex = 253
        Me.Label30.Text = "X34- TORCH FWD"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi29
        '
        Me.lblDi29.AutoEllipsis = True
        Me.lblDi29.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi29.Location = New System.Drawing.Point(275, 450)
        Me.lblDi29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi29.Name = "lblDi29"
        Me.lblDi29.Size = New System.Drawing.Size(17, 19)
        Me.lblDi29.TabIndex = 252
        Me.lblDi29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(303, 414)
        Me.Label28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(159, 18)
        Me.Label28.TabIndex = 251
        Me.Label28.Text = "X33- HB-AVC-OUT"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi28
        '
        Me.lblDi28.AutoEllipsis = True
        Me.lblDi28.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi28.Location = New System.Drawing.Point(275, 414)
        Me.lblDi28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi28.Name = "lblDi28"
        Me.lblDi28.Size = New System.Drawing.Size(17, 19)
        Me.lblDi28.TabIndex = 250
        Me.lblDi28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(303, 379)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(143, 18)
        Me.Label24.TabIndex = 249
        Me.Label24.Text = "X32- HB-AVC-IN"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi27
        '
        Me.lblDi27.AutoEllipsis = True
        Me.lblDi27.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi27.Location = New System.Drawing.Point(275, 379)
        Me.lblDi27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi27.Name = "lblDi27"
        Me.lblDi27.Size = New System.Drawing.Size(17, 19)
        Me.lblDi27.TabIndex = 248
        Me.lblDi27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(303, 235)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(159, 18)
        Me.Label21.TabIndex = 247
        Me.Label21.Text = "X26- ROTATION CW"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi23
        '
        Me.lblDi23.AutoEllipsis = True
        Me.lblDi23.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi23.Location = New System.Drawing.Point(275, 235)
        Me.lblDi23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi23.Name = "lblDi23"
        Me.lblDi23.Size = New System.Drawing.Size(17, 19)
        Me.lblDi23.TabIndex = 246
        Me.lblDi23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(303, 133)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(187, 18)
        Me.Label17.TabIndex = 245
        Me.Label17.Text = "X23- EMG. PENDENT"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi20
        '
        Me.lblDi20.AutoEllipsis = True
        Me.lblDi20.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi20.Location = New System.Drawing.Point(275, 133)
        Me.lblDi20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi20.Name = "lblDi20"
        Me.lblDi20.Size = New System.Drawing.Size(17, 19)
        Me.lblDi20.TabIndex = 244
        Me.lblDi20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(303, 36)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(143, 18)
        Me.Label13.TabIndex = 243
        Me.Label13.Text = "X20- EMG.PANEL"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi17
        '
        Me.lblDi17.AutoEllipsis = True
        Me.lblDi17.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi17.Location = New System.Drawing.Point(275, 36)
        Me.lblDi17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi17.Name = "lblDi17"
        Me.lblDi17.Size = New System.Drawing.Size(17, 19)
        Me.lblDi17.TabIndex = 242
        Me.lblDi17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(56, 486)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(179, 19)
        Me.Label11.TabIndex = 241
        Me.Label11.Text = "X15- P/S HEALTHY HA"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi14
        '
        Me.lblDi14.AutoEllipsis = True
        Me.lblDi14.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi14.Location = New System.Drawing.Point(23, 486)
        Me.lblDi14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi14.Name = "lblDi14"
        Me.lblDi14.Size = New System.Drawing.Size(17, 19)
        Me.lblDi14.TabIndex = 240
        Me.lblDi14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(56, 379)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(179, 19)
        Me.Label5.TabIndex = 239
        Me.Label5.Text = "X12- ALARM-X-AXIS"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi11
        '
        Me.lblDi11.AutoEllipsis = True
        Me.lblDi11.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi11.Location = New System.Drawing.Point(23, 379)
        Me.lblDi11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi11.Name = "lblDi11"
        Me.lblDi11.Size = New System.Drawing.Size(17, 19)
        Me.lblDi11.TabIndex = 238
        Me.lblDi11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(535, 3)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(541, 24)
        Me.Label7.TabIndex = 217
        Me.Label7.Text = "Digital Output Status"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblDi19
        '
        Me.lblDi19.AutoEllipsis = True
        Me.lblDi19.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi19.Location = New System.Drawing.Point(275, 99)
        Me.lblDi19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi19.Name = "lblDi19"
        Me.lblDi19.Size = New System.Drawing.Size(16, 19)
        Me.lblDi19.TabIndex = 214
        Me.lblDi19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(303, 99)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(232, 19)
        Me.Label3.TabIndex = 213
        Me.Label3.Text = "X22- WATER FLOW F/B"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label112
        '
        Me.Label112.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label112.Location = New System.Drawing.Point(820, 414)
        Me.Label112.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(174, 19)
        Me.Label112.TabIndex = 210
        Me.Label112.Text = "Y33- P/S ON-HA"
        Me.Label112.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO28
        '
        Me.lblDO28.AutoEllipsis = True
        Me.lblDO28.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO28.Location = New System.Drawing.Point(788, 414)
        Me.lblDO28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO28.Name = "lblDO28"
        Me.lblDO28.Size = New System.Drawing.Size(17, 19)
        Me.lblDO28.TabIndex = 209
        Me.lblDO28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(820, 379)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(174, 19)
        Me.Label2.TabIndex = 208
        Me.Label2.Text = "Y32-CHILLER ON"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label37
        '
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(820, 343)
        Me.Label37.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(198, 19)
        Me.Label37.TabIndex = 207
        Me.Label37.Text = "Y31-WIRE RETRACT HB"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label38
        '
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(820, 307)
        Me.Label38.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(174, 19)
        Me.Label38.TabIndex = 206
        Me.Label38.Text = "Y30-WIRE FEED HB"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label39
        '
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(820, 271)
        Me.Label39.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(203, 19)
        Me.Label39.TabIndex = 205
        Me.Label39.Text = "Y27- W/F TRIGGER HB"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label40
        '
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(820, 235)
        Me.Label40.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(174, 19)
        Me.Label40.TabIndex = 204
        Me.Label40.Text = "Y26- HW TRIGGER HB"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO23
        '
        Me.lblDO23.AutoEllipsis = True
        Me.lblDO23.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO23.Location = New System.Drawing.Point(788, 235)
        Me.lblDO23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO23.Name = "lblDO23"
        Me.lblDO23.Size = New System.Drawing.Size(17, 19)
        Me.lblDO23.TabIndex = 200
        Me.lblDO23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO24
        '
        Me.lblDO24.AutoEllipsis = True
        Me.lblDO24.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO24.Location = New System.Drawing.Point(788, 271)
        Me.lblDO24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO24.Name = "lblDO24"
        Me.lblDO24.Size = New System.Drawing.Size(17, 19)
        Me.lblDO24.TabIndex = 202
        Me.lblDO24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO25
        '
        Me.lblDO25.AutoEllipsis = True
        Me.lblDO25.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO25.Location = New System.Drawing.Point(788, 307)
        Me.lblDO25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO25.Name = "lblDO25"
        Me.lblDO25.Size = New System.Drawing.Size(17, 19)
        Me.lblDO25.TabIndex = 199
        Me.lblDO25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO26
        '
        Me.lblDO26.AutoEllipsis = True
        Me.lblDO26.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO26.Location = New System.Drawing.Point(788, 343)
        Me.lblDO26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO26.Name = "lblDO26"
        Me.lblDO26.Size = New System.Drawing.Size(17, 19)
        Me.lblDO26.TabIndex = 201
        Me.lblDO26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO27
        '
        Me.lblDO27.AutoEllipsis = True
        Me.lblDO27.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO27.Location = New System.Drawing.Point(788, 379)
        Me.lblDO27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO27.Name = "lblDO27"
        Me.lblDO27.Size = New System.Drawing.Size(17, 19)
        Me.lblDO27.TabIndex = 203
        Me.lblDO27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label88
        '
        Me.Label88.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.Location = New System.Drawing.Point(820, 199)
        Me.Label88.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(193, 19)
        Me.Label88.TabIndex = 198
        Me.Label88.Text = "Y25- WIRE RETRACT HA"
        Me.Label88.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO22
        '
        Me.lblDO22.AutoEllipsis = True
        Me.lblDO22.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO22.Location = New System.Drawing.Point(788, 199)
        Me.lblDO22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO22.Name = "lblDO22"
        Me.lblDO22.Size = New System.Drawing.Size(17, 19)
        Me.lblDO22.TabIndex = 197
        Me.lblDO22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label90
        '
        Me.Label90.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label90.Location = New System.Drawing.Point(820, 165)
        Me.Label90.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(174, 19)
        Me.Label90.TabIndex = 196
        Me.Label90.Text = "Y24- WIRE FEED HA"
        Me.Label90.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO21
        '
        Me.lblDO21.AutoEllipsis = True
        Me.lblDO21.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO21.Location = New System.Drawing.Point(788, 165)
        Me.lblDO21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO21.Name = "lblDO21"
        Me.lblDO21.Size = New System.Drawing.Size(17, 19)
        Me.lblDO21.TabIndex = 195
        Me.lblDO21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label73
        '
        Me.Label73.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.Location = New System.Drawing.Point(56, 557)
        Me.Label73.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(189, 18)
        Me.Label73.TabIndex = 60
        Me.Label73.Text = "X17- W/F HEALTHY HA"
        Me.Label73.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label103
        '
        Me.Label103.AutoEllipsis = True
        Me.Label103.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label103.Location = New System.Drawing.Point(579, 414)
        Me.Label103.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(202, 19)
        Me.Label103.TabIndex = 152
        Me.Label103.Text = "Y13- SON+EM2-X+R-AXIS"
        '
        'Label104
        '
        Me.Label104.AutoEllipsis = True
        Me.Label104.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.Location = New System.Drawing.Point(52, 524)
        Me.Label104.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(209, 18)
        Me.Label104.TabIndex = 151
        Me.Label104.Text = "X16- HWP/S HEALTHY HA"
        '
        'Label75
        '
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.Location = New System.Drawing.Point(303, 486)
        Me.Label75.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(143, 18)
        Me.Label75.TabIndex = 58
        Me.Label75.Text = "X35- TORCH REW"
        Me.Label75.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label105
        '
        Me.Label105.AutoEllipsis = True
        Me.Label105.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label105.Location = New System.Drawing.Point(582, 271)
        Me.Label105.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(131, 19)
        Me.Label105.TabIndex = 150
        Me.Label105.Text = "Y7- SPARE"
        '
        'Label76
        '
        Me.Label76.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(303, 343)
        Me.Label76.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(143, 18)
        Me.Label76.TabIndex = 57
        Me.Label76.Text = "X31- HA-AVC-OUT"
        Me.Label76.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO8
        '
        Me.lblDO8.AutoEllipsis = True
        Me.lblDO8.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO8.Location = New System.Drawing.Point(551, 271)
        Me.lblDO8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO8.Name = "lblDO8"
        Me.lblDO8.Size = New System.Drawing.Size(17, 19)
        Me.lblDO8.TabIndex = 147
        '
        'Label77
        '
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(303, 307)
        Me.Label77.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(143, 18)
        Me.Label77.TabIndex = 56
        Me.Label77.Text = "X30- HA-AVC-IN"
        Me.Label77.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi25
        '
        Me.lblDi25.AutoEllipsis = True
        Me.lblDi25.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi25.Location = New System.Drawing.Point(275, 307)
        Me.lblDi25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi25.Name = "lblDi25"
        Me.lblDi25.Size = New System.Drawing.Size(17, 19)
        Me.lblDi25.TabIndex = 52
        Me.lblDi25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi15
        '
        Me.lblDi15.AutoEllipsis = True
        Me.lblDi15.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi15.Location = New System.Drawing.Point(23, 524)
        Me.lblDi15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi15.Name = "lblDi15"
        Me.lblDi15.Size = New System.Drawing.Size(17, 19)
        Me.lblDi15.TabIndex = 148
        '
        'lblDi26
        '
        Me.lblDi26.AutoEllipsis = True
        Me.lblDi26.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi26.Location = New System.Drawing.Point(275, 343)
        Me.lblDi26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi26.Name = "lblDi26"
        Me.lblDi26.Size = New System.Drawing.Size(17, 19)
        Me.lblDi26.TabIndex = 54
        Me.lblDi26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label32
        '
        Me.Label32.AutoEllipsis = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(582, 343)
        Me.Label32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(151, 19)
        Me.Label32.TabIndex = 146
        Me.Label32.Text = "Y11- AUTO LAMP"
        '
        'lblDi30
        '
        Me.lblDi30.AutoEllipsis = True
        Me.lblDi30.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi30.Location = New System.Drawing.Point(275, 486)
        Me.lblDi30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi30.Name = "lblDi30"
        Me.lblDi30.Size = New System.Drawing.Size(17, 19)
        Me.lblDi30.TabIndex = 51
        Me.lblDi30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label33
        '
        Me.Label33.AutoEllipsis = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(582, 307)
        Me.Label33.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(151, 19)
        Me.Label33.TabIndex = 145
        Me.Label33.Text = "Y10- FAULT LAMP"
        '
        'Label43
        '
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(303, 68)
        Me.Label43.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(232, 18)
        Me.Label43.TabIndex = 59
        Me.Label43.Text = "X21- GAS FLOW F/B HB"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label35
        '
        Me.Label35.AutoEllipsis = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(582, 235)
        Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(131, 19)
        Me.Label35.TabIndex = 144
        Me.Label35.Text = "Y6- SPARE"
        '
        'Label44
        '
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(820, 133)
        Me.Label44.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(193, 19)
        Me.Label44.TabIndex = 58
        Me.Label44.Text = "Y23- W/F TRIGGER HA"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi16
        '
        Me.lblDi16.AutoEllipsis = True
        Me.lblDi16.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi16.Location = New System.Drawing.Point(23, 557)
        Me.lblDi16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi16.Name = "lblDi16"
        Me.lblDi16.Size = New System.Drawing.Size(17, 19)
        Me.lblDi16.TabIndex = 55
        Me.lblDi16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label45
        '
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(820, 99)
        Me.Label45.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(203, 19)
        Me.Label45.TabIndex = 57
        Me.Label45.Text = "Y22- HW TRIGGER-HA"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label46
        '
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(820, 68)
        Me.Label46.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(198, 19)
        Me.Label46.TabIndex = 56
        Me.Label46.Text = "Y21- WELD TRIGGER HA"
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO7
        '
        Me.lblDO7.AutoEllipsis = True
        Me.lblDO7.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO7.Location = New System.Drawing.Point(551, 235)
        Me.lblDO7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO7.Name = "lblDO7"
        Me.lblDO7.Size = New System.Drawing.Size(17, 19)
        Me.lblDO7.TabIndex = 141
        '
        'lblDO18
        '
        Me.lblDO18.AutoEllipsis = True
        Me.lblDO18.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO18.Location = New System.Drawing.Point(788, 68)
        Me.lblDO18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO18.Name = "lblDO18"
        Me.lblDO18.Size = New System.Drawing.Size(17, 19)
        Me.lblDO18.TabIndex = 50
        Me.lblDO18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label78
        '
        Me.Label78.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.Location = New System.Drawing.Point(303, 271)
        Me.Label78.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(173, 18)
        Me.Label78.TabIndex = 50
        Me.Label78.Text = "X27- ROTATION CCW"
        Me.Label78.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO19
        '
        Me.lblDO19.AutoEllipsis = True
        Me.lblDO19.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO19.Location = New System.Drawing.Point(788, 99)
        Me.lblDO19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO19.Name = "lblDO19"
        Me.lblDO19.Size = New System.Drawing.Size(17, 19)
        Me.lblDO19.TabIndex = 46
        Me.lblDO19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label47
        '
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(820, 36)
        Me.Label47.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(174, 19)
        Me.Label47.TabIndex = 55
        Me.Label47.Text = "Y20- GAS TEST HA"
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO20
        '
        Me.lblDO20.AutoEllipsis = True
        Me.lblDO20.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO20.Location = New System.Drawing.Point(788, 133)
        Me.lblDO20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO20.Name = "lblDO20"
        Me.lblDO20.Size = New System.Drawing.Size(16, 19)
        Me.lblDO20.TabIndex = 48
        Me.lblDO20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO9
        '
        Me.lblDO9.AutoEllipsis = True
        Me.lblDO9.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO9.Location = New System.Drawing.Point(551, 307)
        Me.lblDO9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO9.Name = "lblDO9"
        Me.lblDO9.Size = New System.Drawing.Size(17, 19)
        Me.lblDO9.TabIndex = 142
        '
        'lblDi18
        '
        Me.lblDi18.AutoEllipsis = True
        Me.lblDi18.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi18.Location = New System.Drawing.Point(275, 68)
        Me.lblDi18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi18.Name = "lblDi18"
        Me.lblDi18.Size = New System.Drawing.Size(16, 19)
        Me.lblDi18.TabIndex = 51
        Me.lblDi18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label48
        '
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(582, 557)
        Me.Label48.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(182, 19)
        Me.Label48.TabIndex = 54
        Me.Label48.Text = "Y17- RST ALL SERVOS"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi24
        '
        Me.lblDi24.AutoEllipsis = True
        Me.lblDi24.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi24.Location = New System.Drawing.Point(275, 271)
        Me.lblDi24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi24.Name = "lblDi24"
        Me.lblDi24.Size = New System.Drawing.Size(17, 19)
        Me.lblDi24.TabIndex = 49
        Me.lblDi24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label49
        '
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(582, 524)
        Me.Label49.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(182, 19)
        Me.Label49.TabIndex = 53
        Me.Label49.Text = "Y16- SPARE"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label55
        '
        Me.Label55.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(582, 489)
        Me.Label55.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(194, 19)
        Me.Label55.TabIndex = 52
        Me.Label55.Text = "Y15- WELD TRIGGER HB"
        Me.Label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO10
        '
        Me.lblDO10.AutoEllipsis = True
        Me.lblDO10.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO10.Location = New System.Drawing.Point(551, 343)
        Me.lblDO10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO10.Name = "lblDO10"
        Me.lblDO10.Size = New System.Drawing.Size(17, 19)
        Me.lblDO10.TabIndex = 143
        '
        'lblDO15
        '
        Me.lblDO15.AutoEllipsis = True
        Me.lblDO15.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO15.Location = New System.Drawing.Point(551, 524)
        Me.lblDO15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO15.Name = "lblDO15"
        Me.lblDO15.Size = New System.Drawing.Size(17, 19)
        Me.lblDO15.TabIndex = 45
        Me.lblDO15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label79
        '
        Me.Label79.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(303, 199)
        Me.Label79.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(143, 18)
        Me.Label79.TabIndex = 48
        Me.Label79.Text = "X25- WELD STOP"
        Me.Label79.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO16
        '
        Me.lblDO16.AutoEllipsis = True
        Me.lblDO16.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO16.Location = New System.Drawing.Point(551, 557)
        Me.lblDO16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO16.Name = "lblDO16"
        Me.lblDO16.Size = New System.Drawing.Size(17, 19)
        Me.lblDO16.TabIndex = 49
        Me.lblDO16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label107
        '
        Me.Label107.AutoEllipsis = True
        Me.Label107.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label107.Location = New System.Drawing.Point(582, 36)
        Me.Label107.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(131, 19)
        Me.Label107.TabIndex = 140
        Me.Label107.Text = "Y0- SPARE"
        '
        'lblDO14
        '
        Me.lblDO14.AutoEllipsis = True
        Me.lblDO14.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO14.Location = New System.Drawing.Point(551, 486)
        Me.lblDO14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO14.Name = "lblDO14"
        Me.lblDO14.Size = New System.Drawing.Size(17, 19)
        Me.lblDO14.TabIndex = 44
        Me.lblDO14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi22
        '
        Me.lblDi22.AutoEllipsis = True
        Me.lblDi22.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi22.Location = New System.Drawing.Point(275, 199)
        Me.lblDi22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi22.Name = "lblDi22"
        Me.lblDi22.Size = New System.Drawing.Size(17, 19)
        Me.lblDi22.TabIndex = 47
        Me.lblDi22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO17
        '
        Me.lblDO17.AutoEllipsis = True
        Me.lblDO17.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO17.Location = New System.Drawing.Point(788, 36)
        Me.lblDO17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO17.Name = "lblDO17"
        Me.lblDO17.Size = New System.Drawing.Size(17, 19)
        Me.lblDO17.TabIndex = 47
        Me.lblDO17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO1
        '
        Me.lblDO1.AutoEllipsis = True
        Me.lblDO1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO1.Location = New System.Drawing.Point(551, 36)
        Me.lblDO1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO1.Name = "lblDO1"
        Me.lblDO1.Size = New System.Drawing.Size(17, 19)
        Me.lblDO1.TabIndex = 139
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(303, 165)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(159, 18)
        Me.Label16.TabIndex = 46
        Me.Label16.Text = "X24- WELD START"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label52
        '
        Me.Label52.AutoEllipsis = True
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(582, 68)
        Me.Label52.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(131, 19)
        Me.Label52.TabIndex = 138
        Me.Label52.Text = "Y1- SPARE"
        '
        'lblDi21
        '
        Me.lblDi21.AutoEllipsis = True
        Me.lblDi21.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi21.Location = New System.Drawing.Point(275, 165)
        Me.lblDi21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi21.Name = "lblDi21"
        Me.lblDi21.Size = New System.Drawing.Size(17, 19)
        Me.lblDi21.TabIndex = 45
        Me.lblDi21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDO2
        '
        Me.lblDO2.AutoEllipsis = True
        Me.lblDO2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO2.Location = New System.Drawing.Point(551, 68)
        Me.lblDO2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO2.Name = "lblDO2"
        Me.lblDO2.Size = New System.Drawing.Size(17, 19)
        Me.lblDO2.TabIndex = 137
        '
        'Label108
        '
        Me.Label108.AutoEllipsis = True
        Me.Label108.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label108.Location = New System.Drawing.Point(582, 450)
        Me.Label108.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(182, 19)
        Me.Label108.TabIndex = 136
        Me.Label108.Text = "Y14- GAS TEST HB"
        '
        'Label106
        '
        Me.Label106.AutoEllipsis = True
        Me.Label106.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.Location = New System.Drawing.Point(582, 133)
        Me.Label106.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(131, 19)
        Me.Label106.TabIndex = 116
        Me.Label106.Text = "Y3- SPARE"
        '
        'lblDO4
        '
        Me.lblDO4.AutoEllipsis = True
        Me.lblDO4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO4.Location = New System.Drawing.Point(551, 133)
        Me.lblDO4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO4.Name = "lblDO4"
        Me.lblDO4.Size = New System.Drawing.Size(17, 19)
        Me.lblDO4.TabIndex = 108
        '
        'Label110
        '
        Me.Label110.AutoEllipsis = True
        Me.Label110.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label110.Location = New System.Drawing.Point(582, 379)
        Me.Label110.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(202, 19)
        Me.Label110.TabIndex = 134
        Me.Label110.Text = "Y12- SON+EM2-AVC1+2"
        '
        'lblDO12
        '
        Me.lblDO12.AutoEllipsis = True
        Me.lblDO12.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO12.Location = New System.Drawing.Point(551, 414)
        Me.lblDO12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO12.Name = "lblDO12"
        Me.lblDO12.Size = New System.Drawing.Size(17, 19)
        Me.lblDO12.TabIndex = 131
        '
        'lblDO13
        '
        Me.lblDO13.AutoEllipsis = True
        Me.lblDO13.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO13.Location = New System.Drawing.Point(551, 450)
        Me.lblDO13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO13.Name = "lblDO13"
        Me.lblDO13.Size = New System.Drawing.Size(17, 19)
        Me.lblDO13.TabIndex = 133
        '
        'lblDO11
        '
        Me.lblDO11.AutoEllipsis = True
        Me.lblDO11.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO11.Location = New System.Drawing.Point(551, 379)
        Me.lblDO11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO11.Name = "lblDO11"
        Me.lblDO11.Size = New System.Drawing.Size(17, 19)
        Me.lblDO11.TabIndex = 132
        '
        'Label51
        '
        Me.Label51.AutoEllipsis = True
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(582, 99)
        Me.Label51.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(131, 19)
        Me.Label51.TabIndex = 87
        Me.Label51.Text = "Y2- SPARE"
        '
        'lblDO3
        '
        Me.lblDO3.AutoEllipsis = True
        Me.lblDO3.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDO3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDO3.Location = New System.Drawing.Point(551, 99)
        Me.lblDO3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDO3.Name = "lblDO3"
        Me.lblDO3.Size = New System.Drawing.Size(17, 19)
        Me.lblDO3.TabIndex = 79
        '
        'Label80
        '
        Me.Label80.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(56, 450)
        Me.Label80.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(205, 19)
        Me.Label80.TabIndex = 110
        Me.Label80.Text = "X14- GAS FLOW F/B HA"
        Me.Label80.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label83
        '
        Me.Label83.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(56, 414)
        Me.Label83.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(179, 19)
        Me.Label83.TabIndex = 109
        Me.Label83.Text = "X13- ALARM-R-AXIS"
        Me.Label83.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label84
        '
        Me.Label84.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(56, 343)
        Me.Label84.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(205, 19)
        Me.Label84.TabIndex = 108
        Me.Label84.Text = "X11- ALARM-AVC2-AXIS"
        Me.Label84.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label85
        '
        Me.Label85.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(56, 307)
        Me.Label85.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(205, 19)
        Me.Label85.TabIndex = 107
        Me.Label85.Text = "X10- ALARM-AVC1-AXIS"
        Me.Label85.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi10
        '
        Me.lblDi10.AutoEllipsis = True
        Me.lblDi10.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi10.Location = New System.Drawing.Point(23, 343)
        Me.lblDi10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi10.Name = "lblDi10"
        Me.lblDi10.Size = New System.Drawing.Size(17, 19)
        Me.lblDi10.TabIndex = 104
        Me.lblDi10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi12
        '
        Me.lblDi12.AutoEllipsis = True
        Me.lblDi12.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi12.Location = New System.Drawing.Point(23, 414)
        Me.lblDi12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi12.Name = "lblDi12"
        Me.lblDi12.Size = New System.Drawing.Size(17, 19)
        Me.lblDi12.TabIndex = 106
        Me.lblDi12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi9
        '
        Me.lblDi9.AutoEllipsis = True
        Me.lblDi9.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblDi9.Location = New System.Drawing.Point(23, 307)
        Me.lblDi9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi9.Name = "lblDi9"
        Me.lblDi9.Size = New System.Drawing.Size(17, 19)
        Me.lblDi9.TabIndex = 103
        Me.lblDi9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi13
        '
        Me.lblDi13.AutoEllipsis = True
        Me.lblDi13.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi13.Location = New System.Drawing.Point(23, 450)
        Me.lblDi13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi13.Name = "lblDi13"
        Me.lblDi13.Size = New System.Drawing.Size(17, 19)
        Me.lblDi13.TabIndex = 105
        Me.lblDi13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOy0
        '
        Me.DIOy0.AutoEllipsis = True
        Me.DIOy0.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOy0.Location = New System.Drawing.Point(303, 524)
        Me.DIOy0.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOy0.Name = "DIOy0"
        Me.DIOy0.Size = New System.Drawing.Size(187, 18)
        Me.DIOy0.TabIndex = 83
        Me.DIOy0.Text = "X36- P/S HEALTHY HB"
        '
        'lblDi31
        '
        Me.lblDi31.AutoEllipsis = True
        Me.lblDi31.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi31.Location = New System.Drawing.Point(275, 524)
        Me.lblDi31.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi31.Name = "lblDi31"
        Me.lblDi31.Size = New System.Drawing.Size(17, 19)
        Me.lblDi31.TabIndex = 76
        '
        'DIOx7
        '
        Me.DIOx7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx7.Location = New System.Drawing.Point(56, 271)
        Me.DIOx7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx7.Name = "DIOx7"
        Me.DIOx7.Size = New System.Drawing.Size(179, 19)
        Me.DIOx7.TabIndex = 74
        Me.DIOx7.Text = "X7- MANNUAL'/AUTO"
        Me.DIOx7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx6
        '
        Me.DIOx6.Cursor = System.Windows.Forms.Cursors.Default
        Me.DIOx6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx6.Location = New System.Drawing.Point(56, 235)
        Me.DIOx6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx6.Name = "DIOx6"
        Me.DIOx6.Size = New System.Drawing.Size(189, 19)
        Me.DIOx6.TabIndex = 73
        Me.DIOx6.Text = "X6- WIRE RETRACT HB"
        Me.DIOx6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx5
        '
        Me.DIOx5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx5.Location = New System.Drawing.Point(56, 199)
        Me.DIOx5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx5.Name = "DIOx5"
        Me.DIOx5.Size = New System.Drawing.Size(179, 19)
        Me.DIOx5.TabIndex = 72
        Me.DIOx5.Text = "X5-  WIREFEED HB   "
        Me.DIOx5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx4
        '
        Me.DIOx4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx4.Location = New System.Drawing.Point(56, 165)
        Me.DIOx4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx4.Name = "DIOx4"
        Me.DIOx4.Size = New System.Drawing.Size(205, 19)
        Me.DIOx4.TabIndex = 71
        Me.DIOx4.Text = "X4- WIRE RETRACT HA"
        Me.DIOx4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx3
        '
        Me.DIOx3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx3.Location = New System.Drawing.Point(56, 133)
        Me.DIOx3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx3.Name = "DIOx3"
        Me.DIOx3.Size = New System.Drawing.Size(179, 19)
        Me.DIOx3.TabIndex = 70
        Me.DIOx3.Text = "X3- WIREFEED HA"
        Me.DIOx3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx2
        '
        Me.DIOx2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx2.Location = New System.Drawing.Point(56, 99)
        Me.DIOx2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx2.Name = "DIOx2"
        Me.DIOx2.Size = New System.Drawing.Size(179, 19)
        Me.DIOx2.TabIndex = 69
        Me.DIOx2.Text = "X2- SPARE"
        Me.DIOx2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx1
        '
        Me.DIOx1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx1.Location = New System.Drawing.Point(56, 68)
        Me.DIOx1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx1.Name = "DIOx1"
        Me.DIOx1.Size = New System.Drawing.Size(179, 19)
        Me.DIOx1.TabIndex = 68
        Me.DIOx1.Text = "X1- SPARE"
        Me.DIOx1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(56, 36)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(179, 19)
        Me.Label4.TabIndex = 67
        Me.Label4.Text = "X0- SPARE"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi2
        '
        Me.lblDi2.AutoEllipsis = True
        Me.lblDi2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi2.Location = New System.Drawing.Point(23, 68)
        Me.lblDi2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi2.Name = "lblDi2"
        Me.lblDi2.Size = New System.Drawing.Size(17, 19)
        Me.lblDi2.TabIndex = 60
        Me.lblDi2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi3
        '
        Me.lblDi3.AutoEllipsis = True
        Me.lblDi3.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi3.Location = New System.Drawing.Point(23, 99)
        Me.lblDi3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi3.Name = "lblDi3"
        Me.lblDi3.Size = New System.Drawing.Size(17, 19)
        Me.lblDi3.TabIndex = 64
        Me.lblDi3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi1
        '
        Me.lblDi1.AutoEllipsis = True
        Me.lblDi1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblDi1.Location = New System.Drawing.Point(23, 36)
        Me.lblDi1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi1.Name = "lblDi1"
        Me.lblDi1.Size = New System.Drawing.Size(17, 19)
        Me.lblDi1.TabIndex = 59
        Me.lblDi1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi4
        '
        Me.lblDi4.AutoEllipsis = True
        Me.lblDi4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi4.Location = New System.Drawing.Point(23, 133)
        Me.lblDi4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi4.Name = "lblDi4"
        Me.lblDi4.Size = New System.Drawing.Size(17, 19)
        Me.lblDi4.TabIndex = 62
        Me.lblDi4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi5
        '
        Me.lblDi5.AutoEllipsis = True
        Me.lblDi5.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi5.Location = New System.Drawing.Point(23, 165)
        Me.lblDi5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi5.Name = "lblDi5"
        Me.lblDi5.Size = New System.Drawing.Size(17, 19)
        Me.lblDi5.TabIndex = 65
        Me.lblDi5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi6
        '
        Me.lblDi6.AutoEllipsis = True
        Me.lblDi6.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi6.Location = New System.Drawing.Point(23, 199)
        Me.lblDi6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi6.Name = "lblDi6"
        Me.lblDi6.Size = New System.Drawing.Size(17, 19)
        Me.lblDi6.TabIndex = 61
        Me.lblDi6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi7
        '
        Me.lblDi7.AutoEllipsis = True
        Me.lblDi7.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi7.Location = New System.Drawing.Point(23, 235)
        Me.lblDi7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi7.Name = "lblDi7"
        Me.lblDi7.Size = New System.Drawing.Size(17, 19)
        Me.lblDi7.TabIndex = 63
        Me.lblDi7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDi8
        '
        Me.lblDi8.AutoEllipsis = True
        Me.lblDi8.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblDi8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDi8.Location = New System.Drawing.Point(23, 271)
        Me.lblDi8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDi8.Name = "lblDi8"
        Me.lblDi8.Size = New System.Drawing.Size(17, 19)
        Me.lblDi8.TabIndex = 66
        Me.lblDi8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Labei1
        '
        Me.Labei1.BackColor = System.Drawing.SystemColors.Highlight
        Me.Labei1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Labei1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Labei1.Location = New System.Drawing.Point(2, 0)
        Me.Labei1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Labei1.Name = "Labei1"
        Me.Labei1.Size = New System.Drawing.Size(529, 24)
        Me.Labei1.TabIndex = 2
        Me.Labei1.Text = "Digital Input Status"
        Me.Labei1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnclose
        '
        Me.btnclose.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.btnclose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnclose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclose.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnclose.Location = New System.Drawing.Point(919, 608)
        Me.btnclose.Margin = New System.Windows.Forms.Padding(2)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(91, 31)
        Me.btnclose.TabIndex = 4
        Me.btnclose.Text = "Close"
        Me.btnclose.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'frmDigStatus
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1078, 670)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel6)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmDigStatus"
        Me.Text = "frmDigStatus"
        Me.Panel6.ResumeLayout(False)
        Me.pnlTR.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel6 As Panel
    Friend WithEvents pnlTR As Panel
    Friend WithEvents Label61 As Label
    Friend WithEvents lblDO31 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents lblDO30 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents lblDO29 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents lblDO6 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents lblDO32 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents lblDO5 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents lblDi32 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents lblDi29 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents lblDi28 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents lblDi27 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents lblDi23 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents lblDi20 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents lblDi17 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents lblDi14 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblDi11 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lblDi19 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label112 As Label
    Friend WithEvents lblDO28 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents lblDO23 As Label
    Friend WithEvents lblDO24 As Label
    Friend WithEvents lblDO25 As Label
    Friend WithEvents lblDO26 As Label
    Friend WithEvents lblDO27 As Label
    Friend WithEvents Label88 As Label
    Friend WithEvents lblDO22 As Label
    Friend WithEvents Label90 As Label
    Friend WithEvents lblDO21 As Label
    Friend WithEvents Label73 As Label
    Friend WithEvents Label103 As Label
    Friend WithEvents Label104 As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents Label105 As Label
    Friend WithEvents Label76 As Label
    Friend WithEvents lblDO8 As Label
    Friend WithEvents Label77 As Label
    Friend WithEvents lblDi25 As Label
    Friend WithEvents lblDi15 As Label
    Friend WithEvents lblDi26 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents lblDi30 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents lblDi16 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents lblDO7 As Label
    Friend WithEvents lblDO18 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents lblDO19 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents lblDO20 As Label
    Friend WithEvents lblDO9 As Label
    Friend WithEvents lblDi18 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents lblDi24 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents lblDO10 As Label
    Friend WithEvents lblDO15 As Label
    Friend WithEvents Label79 As Label
    Friend WithEvents lblDO16 As Label
    Friend WithEvents Label107 As Label
    Friend WithEvents lblDO14 As Label
    Friend WithEvents lblDi22 As Label
    Friend WithEvents lblDO17 As Label
    Friend WithEvents lblDO1 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents lblDi21 As Label
    Friend WithEvents lblDO2 As Label
    Friend WithEvents Label108 As Label
    Friend WithEvents Label106 As Label
    Friend WithEvents lblDO4 As Label
    Friend WithEvents Label110 As Label
    Friend WithEvents lblDO12 As Label
    Friend WithEvents lblDO13 As Label
    Friend WithEvents lblDO11 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents lblDO3 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents Label84 As Label
    Friend WithEvents Label85 As Label
    Friend WithEvents lblDi10 As Label
    Friend WithEvents lblDi12 As Label
    Friend WithEvents lblDi9 As Label
    Friend WithEvents lblDi13 As Label
    Friend WithEvents DIOy0 As Label
    Friend WithEvents lblDi31 As Label
    Friend WithEvents DIOx7 As Label
    Friend WithEvents DIOx6 As Label
    Friend WithEvents DIOx5 As Label
    Friend WithEvents DIOx4 As Label
    Friend WithEvents DIOx3 As Label
    Friend WithEvents DIOx2 As Label
    Friend WithEvents DIOx1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblDi2 As Label
    Friend WithEvents lblDi3 As Label
    Friend WithEvents lblDi1 As Label
    Friend WithEvents lblDi4 As Label
    Friend WithEvents lblDi5 As Label
    Friend WithEvents lblDi6 As Label
    Friend WithEvents lblDi7 As Label
    Friend WithEvents lblDi8 As Label
    Friend WithEvents Labei1 As Label
    Friend WithEvents btnclose As Button
    Friend WithEvents Timer1 As Timer
End Class
