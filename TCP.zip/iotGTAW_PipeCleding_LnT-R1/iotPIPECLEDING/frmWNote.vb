﻿'----------------------------------
' iotESSC for L&T
' by  trapasia DigiReach @ 2017
' getting WPS Note from webservice
'----------------------------------
Public Class frmWNote
    Private Sub frmWNote_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If gOpMode = "live" Then
            Using myservice As New SQLDB()
                Try
                    Dim err As String = ""
                    'myservice.timeout = 2000
                    Dim z As DataTable = myservice.getSWPNotes(gprojectno, err)
                    dgv1.DataSource = z
                Catch ex As Exception
                    MessageBox.Show("Error in frmWNote_Load method of frmWNote module, Error : " + ex.Message.ToString())
                End Try
            End Using
        End If
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub frmWNote_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Me.Width = MDIParent1.Width - 100
        Me.Height = MDIParent1.Height - 150
        Me.Top = 30
        Me.Left = 50
        Panel1.Height = Me.Height - Panel2.Height - Label1.Height - 5
        Panel1.Width = Me.Width
        Panel2.Width = Me.Width
        Label1.Width = Me.Width
        Button1.Left = (Panel1.Width - Button1.Width) / 2
    End Sub

    Private Sub Panel2_Paint(sender As System.Object, e As System.Windows.Forms.PaintEventArgs) Handles Panel2.Paint

    End Sub
End Class