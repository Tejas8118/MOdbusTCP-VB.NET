﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmConsum
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblProjectName = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblWPS = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RFlux = New System.Windows.Forms.CheckBox()
        Me.cmbFluxAWS = New System.Windows.Forms.ComboBox()
        Me.cmbFluxItem = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RWire = New System.Windows.Forms.CheckBox()
        Me.cmbAWS = New System.Windows.Forms.ComboBox()
        Me.cmbSize = New System.Windows.Forms.ComboBox()
        Me.cmbLayer = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmbItem = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblSeam = New System.Windows.Forms.Label()
        Me.lblProcess = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.lblProject = New System.Windows.Forms.Label()
        Me.label16 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnToken = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.lblProjectName)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.lblWPS)
        Me.Panel1.Controls.Add(Me.GroupBox2)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Controls.Add(Me.lblSeam)
        Me.Panel1.Controls.Add(Me.lblProcess)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.label16)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.btnToken)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(12, 14)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1202, 644)
        Me.Panel1.TabIndex = 2
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Button1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Location = New System.Drawing.Point(296, 553)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(183, 79)
        Me.Button1.TabIndex = 44
        Me.Button1.Text = "WPS"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'lblProjectName
        '
        Me.lblProjectName.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lblProjectName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProjectName.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProjectName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblProjectName.Location = New System.Drawing.Point(167, 77)
        Me.lblProjectName.Name = "lblProjectName"
        Me.lblProjectName.Size = New System.Drawing.Size(1024, 41)
        Me.lblProjectName.TabIndex = 42
        Me.lblProjectName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label8.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label8.Location = New System.Drawing.Point(12, 77)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(154, 41)
        Me.Label8.TabIndex = 41
        Me.Label8.Text = "Project Name"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblWPS
        '
        Me.lblWPS.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lblWPS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblWPS.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWPS.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblWPS.Location = New System.Drawing.Point(760, 132)
        Me.lblWPS.Name = "lblWPS"
        Me.lblWPS.Size = New System.Drawing.Size(431, 41)
        Me.lblWPS.TabIndex = 39
        Me.lblWPS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RFlux)
        Me.GroupBox2.Controls.Add(Me.cmbFluxAWS)
        Me.GroupBox2.Controls.Add(Me.cmbFluxItem)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GroupBox2.Location = New System.Drawing.Point(620, 236)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(577, 256)
        Me.GroupBox2.TabIndex = 35
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Flux Details"
        '
        'RFlux
        '
        Me.RFlux.AutoSize = True
        Me.RFlux.Checked = True
        Me.RFlux.CheckState = System.Windows.Forms.CheckState.Checked
        Me.RFlux.Location = New System.Drawing.Point(190, 163)
        Me.RFlux.Name = "RFlux"
        Me.RFlux.Size = New System.Drawing.Size(183, 33)
        Me.RFlux.TabIndex = 40
        Me.RFlux.Text = "Flux Required"
        Me.RFlux.UseVisualStyleBackColor = True
        '
        'cmbFluxAWS
        '
        Me.cmbFluxAWS.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbFluxAWS.FormattingEnabled = True
        Me.cmbFluxAWS.IntegralHeight = False
        Me.cmbFluxAWS.Location = New System.Drawing.Point(126, 51)
        Me.cmbFluxAWS.Name = "cmbFluxAWS"
        Me.cmbFluxAWS.Size = New System.Drawing.Size(445, 33)
        Me.cmbFluxAWS.TabIndex = 36
        '
        'cmbFluxItem
        '
        Me.cmbFluxItem.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbFluxItem.FormattingEnabled = True
        Me.cmbFluxItem.IntegralHeight = False
        Me.cmbFluxItem.Location = New System.Drawing.Point(126, 101)
        Me.cmbFluxItem.Name = "cmbFluxItem"
        Me.cmbFluxItem.Size = New System.Drawing.Size(445, 33)
        Me.cmbFluxItem.TabIndex = 35
        '
        'Label6
        '
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label6.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label6.Location = New System.Drawing.Point(6, 51)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(114, 33)
        Me.Label6.TabIndex = 32
        Me.Label6.Text = "Flux AWS"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label5.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label5.Location = New System.Drawing.Point(6, 100)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(114, 34)
        Me.Label5.TabIndex = 31
        Me.Label5.Text = "Flux Item"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RWire)
        Me.GroupBox1.Controls.Add(Me.cmbAWS)
        Me.GroupBox1.Controls.Add(Me.cmbSize)
        Me.GroupBox1.Controls.Add(Me.cmbLayer)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.cmbItem)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GroupBox1.Location = New System.Drawing.Point(5, 236)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(609, 296)
        Me.GroupBox1.TabIndex = 34
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Consumable Details"
        '
        'RWire
        '
        Me.RWire.AutoSize = True
        Me.RWire.Checked = True
        Me.RWire.CheckState = System.Windows.Forms.CheckState.Checked
        Me.RWire.Location = New System.Drawing.Point(162, 257)
        Me.RWire.Name = "RWire"
        Me.RWire.Size = New System.Drawing.Size(274, 33)
        Me.RWire.TabIndex = 39
        Me.RWire.Text = "Consumable Required"
        Me.RWire.UseVisualStyleBackColor = True
        '
        'cmbAWS
        '
        Me.cmbAWS.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbAWS.FormattingEnabled = True
        Me.cmbAWS.IntegralHeight = False
        Me.cmbAWS.Location = New System.Drawing.Point(131, 100)
        Me.cmbAWS.Name = "cmbAWS"
        Me.cmbAWS.Size = New System.Drawing.Size(467, 33)
        Me.cmbAWS.TabIndex = 36
        '
        'cmbSize
        '
        Me.cmbSize.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbSize.FormattingEnabled = True
        Me.cmbSize.IntegralHeight = False
        Me.cmbSize.Location = New System.Drawing.Point(130, 153)
        Me.cmbSize.Name = "cmbSize"
        Me.cmbSize.Size = New System.Drawing.Size(467, 33)
        Me.cmbSize.TabIndex = 35
        '
        'cmbLayer
        '
        Me.cmbLayer.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbLayer.FormattingEnabled = True
        Me.cmbLayer.IntegralHeight = False
        Me.cmbLayer.Location = New System.Drawing.Point(131, 47)
        Me.cmbLayer.Name = "cmbLayer"
        Me.cmbLayer.Size = New System.Drawing.Size(467, 33)
        Me.cmbLayer.TabIndex = 34
        '
        'Label4
        '
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label4.Location = New System.Drawing.Point(7, 47)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(123, 33)
        Me.Label4.TabIndex = 33
        Me.Label4.Text = "Layer"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmbItem
        '
        Me.cmbItem.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbItem.FormattingEnabled = True
        Me.cmbItem.IntegralHeight = False
        Me.cmbItem.Location = New System.Drawing.Point(131, 206)
        Me.cmbItem.Name = "cmbItem"
        Me.cmbItem.Size = New System.Drawing.Size(468, 33)
        Me.cmbItem.TabIndex = 37
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label3.Location = New System.Drawing.Point(7, 100)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(123, 33)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "AWS"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label7.Location = New System.Drawing.Point(7, 206)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(123, 33)
        Me.Label7.TabIndex = 36
        Me.Label7.Text = "Item"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label1.Location = New System.Drawing.Point(6, 153)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(123, 33)
        Me.Label1.TabIndex = 31
        Me.Label1.Text = "Size"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSeam
        '
        Me.lblSeam.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lblSeam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSeam.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSeam.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblSeam.Location = New System.Drawing.Point(167, 188)
        Me.lblSeam.Name = "lblSeam"
        Me.lblSeam.Size = New System.Drawing.Size(441, 41)
        Me.lblSeam.TabIndex = 32
        Me.lblSeam.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblProcess
        '
        Me.lblProcess.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lblProcess.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProcess.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProcess.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblProcess.Location = New System.Drawing.Point(760, 188)
        Me.lblProcess.Name = "lblProcess"
        Me.lblProcess.Size = New System.Drawing.Size(431, 41)
        Me.lblProcess.TabIndex = 33
        Me.lblProcess.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label14
        '
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label14.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label14.Location = New System.Drawing.Point(620, 188)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(138, 41)
        Me.Label14.TabIndex = 31
        Me.Label14.Text = "Process"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label15
        '
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label15.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label15.Location = New System.Drawing.Point(12, 188)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(154, 41)
        Me.Label15.TabIndex = 30
        Me.Label15.Text = "SEAM"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblProject
        '
        Me.lblProject.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lblProject.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProject.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProject.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblProject.Location = New System.Drawing.Point(167, 132)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(441, 41)
        Me.lblProject.TabIndex = 28
        Me.lblProject.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label16
        '
        Me.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.label16.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label16.ForeColor = System.Drawing.Color.DarkBlue
        Me.label16.Location = New System.Drawing.Point(620, 132)
        Me.label16.Name = "label16"
        Me.label16.Size = New System.Drawing.Size(138, 41)
        Me.label16.TabIndex = 27
        Me.label16.Text = "WPS No."
        Me.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label10.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label10.Location = New System.Drawing.Point(12, 132)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(154, 41)
        Me.Label10.TabIndex = 26
        Me.Label10.Text = "Project No."
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnToken
        '
        Me.btnToken.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btnToken.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.btnToken.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnToken.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnToken.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnToken.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnToken.Location = New System.Drawing.Point(11, 553)
        Me.btnToken.Name = "btnToken"
        Me.btnToken.Size = New System.Drawing.Size(279, 79)
        Me.btnToken.TabIndex = 10
        Me.btnToken.Text = "Generate Token"
        Me.btnToken.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.logo
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1200, 65)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'frmConsum
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(1226, 670)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmConsum"
        Me.Text = "frmConsum"
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cmbItem As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbFluxAWS As System.Windows.Forms.ComboBox
    Friend WithEvents cmbFluxItem As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbAWS As System.Windows.Forms.ComboBox
    Friend WithEvents cmbSize As System.Windows.Forms.ComboBox
    Friend WithEvents cmbLayer As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblSeam As System.Windows.Forms.Label
    Friend WithEvents lblProcess As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents lblProject As System.Windows.Forms.Label
    Friend WithEvents label16 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents btnToken As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblWPS As System.Windows.Forms.Label
    Friend WithEvents lblProjectName As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button1 As Button
    Friend WithEvents RFlux As CheckBox
    Friend WithEvents RWire As CheckBox
End Class
