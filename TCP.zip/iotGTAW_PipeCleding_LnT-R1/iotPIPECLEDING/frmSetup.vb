﻿'----------------------------------
' iotESSC for L&T
' by  trapasia DigiReach @ 2017
' setting up sensor value conversion and stroing in local database accessdb
'----------------------------------
Public Class frmSetup
    Dim ACT As String = "NEW"
    Dim oid As String = ""
    Dim txid As String = ""
    Dim tx As String = ""
    Dim rx As String = ""
    Dim t1 As Integer = 0
    Dim t01 As Integer = 0
    Dim h1 As String = 0


    Private Sub frmSetup_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Call fillgrid()
    End Sub
    Private Sub fillgrid()
        'Dim dt As DataTable
        'dt = objCon.ExecuteDataTable("select * from sensor_para", CommandType.Text)
        Using objCon As New dbClass
            Using dt As DataTable = objCon.ExecuteDataTable("select * from sensor_para", CommandType.Text)
                DataGridView1.DataSource = dt
            End Using
        End Using
    End Sub
    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        If Not DataGridView1.Rows(e.RowIndex).Cells(e.ColumnIndex).Value Is Nothing Then
            oid = DataGridView1.Rows(e.RowIndex).Cells(0).Value
            txtSPort.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
            txtTitle.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
            txtYMin.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
            txtYMax.Text = DataGridView1.Rows(e.RowIndex).Cells(4).Value
            txtXmin.Text = DataGridView1.Rows(e.RowIndex).Cells(5).Value
            txtXMax.Text = DataGridView1.Rows(e.RowIndex).Cells(6).Value


            btnSave.Text = "Update"
            ACT = "UPD"
            ' btnNew.Enabled = False
            btnSave.Enabled = True
            Panel2.Enabled = True
            'Else
            '    oid = ""
            '    ACT = "NEW"
            '    btnSave.Text = "Save"
            '    btnNew.Enabled = True
            '    btnSave.Enabled = False

        End If
    End Sub

    Private Sub btnClose_Click(sender As System.Object, e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    'Private Sub btnNew_Click(sender As System.Object, e As System.EventArgs)
    '    Panel2.Enabled = True
    '    btnNew.Enabled = False
    '    btnClear.Enabled = True
    '    btnSave.Enabled = True

    '    ACT = "NEW"
    '    btnSave.Text = "Save"
    '    clearCtl()
    'End Sub
    Private Sub clearCtl()
        txtSPort.Text = ""
        txtTitle.Text = ""
        txtYMin.Text = "0"
        txtYMax.Text = "0"
        txtXmin.Text = "0"
        txtXMax.Text = "0"
        txtMultiplier.Text = "0.0"
        txtRatio.Text = "0.0"
    End Sub

    Private Sub btnSave_Click(sender As System.Object, e As System.EventArgs) Handles btnSave.Click
        Dim mMulti As Double = 0.0
        Dim mRatio As Double = 0.0

        'If CDbl(txtYMax.Text) > 0 And CDbl(txtXMax.Text) > 0 Then
        '    mMulti = (txtYMax.Text - txtYMin.Text) / (txtXMax.Text - txtXmin.Text)
        '    mRatio = (txtYMin.Text - mMulti * txtXmin.Text)
        'End If

        Using objCon As New dbClass
            'If ACT = "NEW" Then
            '    ''insert
            '    Dim q As String = "select count(*) as cnt from sensor_para where sport='" & txtSPort.Text & "'"
            '    Dim cnt = objCon.ExecuteScaller(q, CommandType.Text)
            '    If cnt > 0 Then
            '        MessageBox.Show("Item is Already there...")
            '    Else
            '        Dim sql As String = "insert into sensor_para (sport,stitle,ymin,ymax,xmin,xmax,multiplier,ratio) values ('" &
            '              txtSPort.Text & "','" & txtTitle.Text & "','" & txtYMin.Text & "','" & txtYMax.Text & "','" &
            '              txtXmin.Text & "','" & txtXMax.Text & "','" & mMulti & "','" & mRatio & "')"
            '        Dim bool As Boolean = objCon.ExecuteNonQuery(sql, CommandType.Text)
            '        If bool = True Then
            '            MessageBox.Show("Data Added Successfully.")
            '            btnNew.Enabled = True
            '        End If
            '    End If
            ' End If

            If ACT = "UPD" Then
                ''update
                txid = oid
                Dim sql As String = "update sensor_para set sport='" & txtSPort.Text & "',stitle='" & txtTitle.Text.Trim & "',ymin='" & txtYMin.Text.Trim & "'" &
                    ",ymax='" & txtYMax.Text & "',xmin='" & txtXmin.Text & "',xmax='" & txtXMax.Text & "'  where id=" & oid & ""
                Dim bool As Boolean = objCon.ExecuteNonQuery(sql, CommandType.Text)
                If bool = True Then
                    MessageBox.Show("Data Updated Successfully.")
                    '  btnNew.Enabled = True
                End If
                If isConnection = True Then

                    If txid = "1" Then
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMax.Text)
                        t1 = t1 * 10
                        h1 = "02060708" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)

                        Threading.Thread.Sleep(100)

                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMin.Text)
                        t1 = t1 * 10
                        h1 = "0206070C" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                    End If

                    If txid = "2" Then
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMax.Text)
                        t1 = t1 * 10
                        h1 = "0206071C" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)

                        Threading.Thread.Sleep(100)

                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMin.Text)
                        t1 = t1 * 10
                        h1 = "02060720" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                    End If

                    If txid = "3" Then
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMax.Text)
                        t1 = t1 * 10
                        h1 = "02060730" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                        Threading.Thread.Sleep(100)
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMin.Text)
                        t1 = t1 * 10
                        h1 = "02060734" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                    End If
                    If txid = "4" Then
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMax.Text)
                        t1 = t1 * 10
                        h1 = "02060744" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                        Threading.Thread.Sleep(100)
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMin.Text)
                        t1 = t1 * 10
                        h1 = "02060748" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                    End If
                    If txid = "5" Then
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMax.Text)
                        t1 = t1 * 10
                        h1 = "02060758" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                        Threading.Thread.Sleep(100)
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMin.Text)
                        t1 = t1 * 10
                        h1 = "0206075C" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                    End If

                    If txid = "6" Then
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMax.Text)
                        t1 = t1 * 10
                        h1 = "0206076C" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                        Threading.Thread.Sleep(100)
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMin.Text)
                        t1 = t1 * 10
                        h1 = "02060770" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                    End If

                    If txid = "7" Then
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMax.Text)
                        t1 = t1 * 10
                        h1 = "02060780" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                        Threading.Thread.Sleep(100)
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMin.Text)
                        t1 = t1 * 10
                        h1 = "02060784" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                    End If


                    If txid = "8" Then
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMax.Text)
                        '  t01  = t1 * 10
                        h1 = "02060794" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                        Threading.Thread.Sleep(100)
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMin.Text)
                        t1 = t1 * 10
                        h1 = "02060798" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)

                    End If

                    If txid = "9" Then
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMax.Text)
                        t1 = t1 * 10
                        h1 = "020607A8" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                        Threading.Thread.Sleep(100)
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMin.Text)
                        t1 = t1 * 10
                        h1 = "020607AA" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)

                    End If

                    If txid = "11" Then
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMax.Text)
                        t1 = t1 * 10
                        h1 = "020607B2" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                        Threading.Thread.Sleep(100)
                        t1 = 0
                        t01 = 0
                        h1 = 0
                        t1 = CDbl(txtYMin.Text)
                        t1 = t1 * 10
                        h1 = "020607B4" & dec2Hex(t1)

                        tx = h1 & ComputeCrc(h1)
                        'MessageBox.Show("string = " + tx.ToString())
                        rx = txComA(tx, 50)
                        'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)

                    End If

                End If

            End If

        End Using

        Call fillgrid()
        Call clearCtl()

        'btnNew.Enabled = True
        btnClear.Enabled = True
        btnSave.Enabled = False
        Panel2.Enabled = False

    End Sub

    Private Sub DataGridView1_RowEnter(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.RowEnter
        If Not DataGridView1.Rows(e.RowIndex).Cells(e.ColumnIndex).Value Is Nothing Then
            oid = DataGridView1.Rows(e.RowIndex).Cells(0).Value
            txtSPort.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
            txtTitle.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
            txtYMin.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
            txtYMax.Text = DataGridView1.Rows(e.RowIndex).Cells(4).Value
            txtXmin.Text = DataGridView1.Rows(e.RowIndex).Cells(5).Value
            txtXMax.Text = DataGridView1.Rows(e.RowIndex).Cells(6).Value


            btnSave.Text = "Update"
            ACT = "UPD"
            ' btnNew.Enabled = False
            btnSave.Enabled = True
            Panel2.Enabled = True
            'Else
            '    oid = ""
            '    ACT = "NEW"
            '    btnSave.Text = "Save"
            '    'btnNew.Enabled = True
            '    btnSave.Enabled = False

        End If
    End Sub


End Class