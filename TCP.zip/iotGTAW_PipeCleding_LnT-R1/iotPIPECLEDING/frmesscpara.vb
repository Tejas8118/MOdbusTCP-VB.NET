﻿Public Class frmesscpara
    Dim Oid As Integer = 0
    Dim Cid As Integer = 0
    Dim objConn As New dbClass
    Dim tx As String = ""
    Dim rx As String = ""


    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        If gsetesscpara = 1 Then
            MessageBox.Show("Please Click on save button to update the changes..")
        Else
            Me.Close()
        End If
    End Sub

    Private Sub txttrospeed_GotFocus(sender As Object, e As System.EventArgs) Handles txttrospeed.GotFocus
        MyKB1.CurrTextBox = Me.txttrospeed
        MyKB1.Visible = True
    End Sub
    Private Sub txttroslowspeed_GotFocus(sender As Object, e As System.EventArgs) Handles txttroslowspeed.GotFocus
        MyKB1.CurrTextBox = Me.txttroslowspeed
        MyKB1.Visible = True
    End Sub
    Private Sub txttrorapspeed_GotFocus(sender As Object, e As System.EventArgs) Handles txttrorapspeed.GotFocus
        MyKB1.CurrTextBox = Me.txttrorapspeed
        MyKB1.Visible = True
    End Sub
    Private Sub txtxspeed_GotFocus(sender As Object, e As System.EventArgs) Handles txtxspeed.GotFocus
        MyKB1.CurrTextBox = Me.txtxspeed
        MyKB1.Visible = True
    End Sub
    Private Sub txtxslowspeed_GotFocus(sender As Object, e As System.EventArgs) Handles txtxslowspeed.GotFocus
        MyKB1.CurrTextBox = Me.txtxslowspeed
        MyKB1.Visible = True
    End Sub
    Private Sub txtxrapspeed_GotFocus(sender As Object, e As System.EventArgs) Handles txtxrapspeed.GotFocus
        MyKB1.CurrTextBox = Me.txtxrapspeed
        MyKB1.Visible = True
    End Sub
    Private Sub txtyspeed_GotFocus(sender As Object, e As System.EventArgs) Handles txtyspeed.GotFocus
        MyKB1.CurrTextBox = Me.txtyspeed
        MyKB1.Visible = True
    End Sub
    Private Sub txtyslowspeed_GotFocus(sender As Object, e As System.EventArgs) Handles txtyslowspeed.GotFocus
        MyKB1.CurrTextBox = Me.txtyslowspeed
        MyKB1.Visible = True
    End Sub
    Private Sub txtyrapspeed_GotFocus(sender As Object, e As System.EventArgs) Handles txtyrapspeed.GotFocus
        MyKB1.CurrTextBox = Me.txtyrapspeed
        MyKB1.Visible = True
    End Sub
    Private Sub txtstrcutslide_GotFocus(sender As Object, e As System.EventArgs) Handles txtstrcutslide.GotFocus
        MyKB1.CurrTextBox = Me.txtstrcutslide
        MyKB1.Visible = True
    End Sub
    Private Sub txtstpoverwidth_GotFocus(sender As Object, e As System.EventArgs) Handles txtstpoverwidth.GotFocus
        MyKB1.CurrTextBox = Me.txtstpoverwidth
        MyKB1.Visible = True
    End Sub

    Private Sub frmesscpara_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillform()
        'fillform1()

    End Sub
    Private Sub fillform()
        'objConn.dbConnect()
        'Dim sql As String = "select * from esscpara"
        'Dim dt As DataTable
        'dt = objCon.ExecuteDataTable(sql, CommandType.Text)

        Using objCon As New dbClass
            Try
                Using dt As DataTable = objCon.ExecuteDataTable("select * from esscpara", CommandType.Text)
                    For Each row As DataRow In dt.Rows
                        Oid = row("id")

                        txttrospeed.Text = row("trospeed")
                        txttroslowspeed.Text = row("troslowspeed")
                        txttrorapspeed.Text = row("trorapspeed")
                        txtxspeed.Text = row("xspeed")
                        txtxslowspeed.Text = row("xslowspeed")
                        txtxrapspeed.Text = row("xrapspeed")
                        txtyspeed.Text = row("yspeed")
                        txtyslowspeed.Text = row("yslowspeed")
                        txtyrapspeed.Text = row("yrapspeed")
                        txtstrcutslide.Text = row("strcutslide")
                        txtstpoverwidth.Text = row("stpoverwidth")

                    Next
                End Using
            Catch ex As Exception
                MessageBox.Show("Error in fillform method of frmesscpara module, Error : " + ex.Message.ToString())
            End Try
        End Using
    End Sub

    'Private Sub fillform1()
    '    Dim y As Integer
    '    Dim plcinstrg As String
    '    Dim y1 As Double
    '    Dim xslidespeed As Double = 0.0
    '    Dim yslidespeed As Double = 0.0
    '    Dim trolleyspeed As Double = 0.0
    '    Dim stepoverwidth As Double = 0.0

    '    ''X Slide speed
    '    y = 0
    '    y1 = 0
    '    plcinstrg = ""
    '    plcinstrg = txComRX("03 03 00 FC 00 02 05 D9", 50)
    '    Dim x1() As String = plcinstrg.Split(" "c)
    '    If x1.Count >= 4 Then
    '        If x1(0) = "03" And x1(1) = "03" Then
    '            y = Convert.ToInt32(x1(3) & x1(4), 16)
    '            ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
    '            xslidespeed = Math.Round(y)
    '            txtxspeed.Text = xslidespeed
    '            ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
    '        End If
    '    End If

    '    ''y Slide speed
    '    y = 0
    '    y1 = 0
    '    plcinstrg = ""
    '    plcinstrg = txComRX("03 03 01 1A 00 02 E5 D2", 50)
    '    Dim x2() As String = plcinstrg.Split(" "c)
    '    If x2.Count >= 4 Then
    '        If x2(0) = "03" And x2(1) = "03" Then
    '            y = Convert.ToInt32(x2(3) & x2(4), 16)
    '            ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
    '            yslidespeed = Math.Round(y)
    '            txtyslowspeed.Text = yslidespeed
    '            ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
    '        End If
    '    End If

    '    ''Trolley speed speed
    '    y = 0
    '    y1 = 0
    '    plcinstrg = ""
    '    plcinstrg = txComRX("03 03 00 FA 00 02 E5 D8", 50)
    '    Dim x3() As String = plcinstrg.Split(" "c)
    '    If x3.Count >= 4 Then
    '        If x3(0) = "03" And x3(1) = "03" Then
    '            y = Convert.ToInt32(x3(3) & x3(4), 16)
    '            ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
    '            trolleyspeed = Math.Round(y)
    '            txttrorapspeed.Text = trolleyspeed
    '            ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
    '        End If
    '    End If

    '    ''Step overlaping width
    '    y = 0
    '    y1 = 0
    '    plcinstrg = ""
    '    plcinstrg = txComRX("03 03 04 5C 00 02 04 CB", 50)
    '    Dim x4() As String = plcinstrg.Split(" "c)
    '    If x4.Count >= 4 Then
    '        If x4(0) = "03" And x4(1) = "03" Then
    '            y = Convert.ToInt32(x4(3) & x4(4), 16)
    '            ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
    '            stepoverwidth = Math.Round(y / 10, 2)
    '            txtstpoverwidth.Text = stepoverwidth
    '            ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
    '        End If
    '    End If
    'End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Using objCon As New dbClass
            Try
                If Oid = 0 Then
                    Dim q As String = "insert into esscpara(trospeed,troslowspeed,trorapspeed,xspeed,xslowspeed,xrapspeed,yspeed,yslowspeed,yrapspeed,strcutslide,stpoverwidth) values (" &
                        "" & txttrospeed.Text & "," & txttroslowspeed.Text & "," & txttrorapspeed.Text & "," & txtxspeed.Text & "," & txtxslowspeed.Text & "," & txtxrapspeed.Text & "," &
                        "" & txtyspeed.Text & "," & txtyslowspeed.Text & "," & txtyrapspeed.Text & "," & txtstrcutslide.Text & "," & txtstpoverwidth.Text & ")"
                    objCon.ExecuteNonQuery(q, CommandType.Text)
                Else
                    Dim q As String = "update esscpara set trospeed=" & txttrospeed.Text & ",troslowspeed=" & txttroslowspeed.Text & ",trorapspeed=" & txttrorapspeed.Text & ",xspeed=" & txtxspeed.Text & "" &
                        ",xslowspeed=" & txtxslowspeed.Text & ",xrapspeed=" & txtxrapspeed.Text & ",yspeed=" & txtyspeed.Text & ",yslowspeed=" & txtyslowspeed.Text & "" &
                        ",yrapspeed=" & txtyrapspeed.Text & ",strcutslide=" & txtstrcutslide.Text & ",stpoverwidth=" & txtstpoverwidth.Text & " where id=" & Oid
                    objCon.ExecuteNonQuery(q, CommandType.Text)
                End If

                getesscPara()

                Select Case MsgBox("Data has been Saved", MsgBoxStyle.OkOnly, "Message")
                    Case MsgBoxResult.Ok
                        Me.Close()
                End Select
            Catch ex As Exception
                MessageBox.Show("Error in BtnSave_Click method of frmesscpara module, Error : " + ex.Message.ToString())
            End Try
        End Using
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btntroslow.Click
        Try
            If isConnection = True Then

                Dim t1 As Integer = CDbl(txttroslowspeed.Text)
                Dim t01 As Integer = t1 * 10
                Dim h1 As String = "0206010E" & dec2Hex(t01)

                tx = h1 & ComputeCrc(h1)
                Dim esscread1 As String = txComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread1)
                If esscread1.Length <> 24 Then
                    MessageBox.Show("Error in Communicating..")
                Else
                    gsetesscpara = 1
                    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error in btntroslow.Click method of frmesscpara module, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btntrorap.Click
        Try
            If isConnection = True Then

                Dim t1 As Integer = CDbl(txttrorapspeed.Text)
                Dim t01 As Integer = t1 * 10
                Dim h1 As String = "020600C8" & dec2Hex(t01)

                tx = h1 & ComputeCrc(h1)
                Dim esscread2 As String = txComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                If esscread2.Length <> 24 Then
                    MessageBox.Show("Error in Communicating..")
                Else
                    gsetesscpara = 1
                    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error in btntrorap.Click method of frmesscpara module, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            If isConnection = True Then
                Dim t1 As Integer = CDbl(txtxslowspeed.Text)
                Dim t01 As Integer = t1 * 10
                Dim h1 As String = "02060110" & dec2Hex(t01)

                tx = h1 & ComputeCrc(h1)
                Dim esscread3 As String = txComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread3)

                If esscread3.Length <> 24 Then
                    MessageBox.Show("Error in Communicating..")
                Else
                    gsetesscpara = 1
                    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error in Button3.Click method of frmesscpara module, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Try
            If isConnection = True Then
                Dim t1 As Integer = CDbl(txtxrapspeed.Text)
                Dim t01 As Integer = t1 * 10
                Dim h1 As String = "020600CA" & dec2Hex(t01)

                tx = h1 & ComputeCrc(h1)
                Dim esscread4 As String = txComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread4)
                If esscread4.Length <> 24 Then
                    MessageBox.Show("Error in Communicating..")
                Else
                    gsetesscpara = 1
                    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error in Button4.Click method of frmesscpara module, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Try
            If isConnection = True Then
                Dim t1 As Integer = CDbl(txtyslowspeed.Text)
                Dim t01 As Integer = t1 * 10
                Dim h1 As String = "02060122" & dec2Hex(t01)

                tx = h1 & ComputeCrc(h1)
                Dim esscread5 As String = txComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread5)
                If esscread5.Length <> 24 Then
                    MessageBox.Show("Error in Communicating..")
                Else
                    gsetesscpara = 1
                    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error in Button5.Click method of frmesscpara module, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Try
            If isConnection = True Then
                Dim t1 As Integer = CDbl(txtyrapspeed.Text)
                Dim t01 As Integer = t1 * 10
                Dim h1 As String = "02060118" & dec2Hex(t01)

                tx = h1 & ComputeCrc(h1)
                Dim esscread6 As String = txComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread6)
                If esscread6.Length <> 24 Then
                    MessageBox.Show("Error in Communicating..")
                Else
                    gsetesscpara = 1
                    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error in Button6.Click method of frmesscpara module, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Try
            If isConnection = True Then
                Dim t1 As Integer = CDbl(txtstrcutslide.Text)
                Dim t01 As Integer = t1 * 10
                Dim h1 As String = "02060126" & dec2Hex(t01)

                tx = h1 & ComputeCrc(h1)
                Dim esscread7 As String = txComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread7)
                If esscread7.Length <> 24 Then
                    MessageBox.Show("Error in Communicating..")
                Else
                    gsetesscpara = 1
                    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error in Button7.Click method of frmesscpara module, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Try
            If isConnection = True Then
                Dim t1 As Integer = CDbl(txtxspeed.Text)
                Dim t01 As Integer = t1 * 10
                Dim h1 As String = "020600FC" & dec2Hex(t01)

                tx = h1 & ComputeCrc(h1)
                Dim esscread8 As String = txComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread8)
                If esscread8.Length <> 24 Then
                    MessageBox.Show("Error in Communicating..")
                Else
                    gsetesscpara = 1
                    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error in Button8.Click method of frmesscpara module, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Try
            If isConnection = True Then
                Dim t1 As Integer = CDbl(txtyspeed.Text)
                Dim t01 As Integer = t1 * 10
                Dim h1 As String = "0206011A" & dec2Hex(t01)

                tx = h1 & ComputeCrc(h1)
                Dim esscread9 As String = txComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread9)
                If esscread9.Length <> 24 Then
                    MessageBox.Show("Error in Communicating..")
                Else
                    gsetesscpara = 1
                    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error in Button9.Click method of frmesscpara module, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Try
            If isConnection = True Then
                Dim t1 As Integer = CDbl(txttrospeed.Text)
                Dim t01 As Integer = t1 * 10
                Dim h1 As String = "020600FA" & dec2Hex(t01)

                tx = h1 & ComputeCrc(h1)
                Dim esscread10 As String = txComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread10)
                If esscread10.Length <> 24 Then
                    MessageBox.Show("Error in Communicating..")
                Else
                    gsetesscpara = 1
                    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error in Button10.Click method of frmesscpara module, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Try
            If isConnection = True Then
                Dim t1 As Integer = CDbl(txtstpoverwidth.Text)
                Dim t01 As Integer = t1 * 100
                Dim h1 As String = "0206045C" & dec2Hex(t01)

                tx = h1 & ComputeCrc(h1)
                Dim esscread11 As String = txComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread11)
                If esscread11.Length <> 24 Then
                    MessageBox.Show("Error in Communicating..")
                Else
                    gsetesscpara = 1
                    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error in Button11.Click method of frmesscpara module, Error : " + ex.Message.ToString())
        End Try
    End Sub

End Class