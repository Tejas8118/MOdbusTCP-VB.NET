﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAngstatus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Wrkb1 = New myControls.WRKB()
        Me.txtAOMaxScale2 = New System.Windows.Forms.TextBox()
        Me.txtAOMaxScale3 = New System.Windows.Forms.TextBox()
        Me.txtAOMaxScale4 = New System.Windows.Forms.TextBox()
        Me.txtAOMaxScale5 = New System.Windows.Forms.TextBox()
        Me.txtAOMaxScale6 = New System.Windows.Forms.TextBox()
        Me.txtAOMaxScale7 = New System.Windows.Forms.TextBox()
        Me.txtAOMaxScale8 = New System.Windows.Forms.TextBox()
        Me.txtAOMaxScale1 = New System.Windows.Forms.TextBox()
        Me.txtAOMinScale2 = New System.Windows.Forms.TextBox()
        Me.txtAOMinScale3 = New System.Windows.Forms.TextBox()
        Me.txtAOMinScale4 = New System.Windows.Forms.TextBox()
        Me.txtAOMinScale5 = New System.Windows.Forms.TextBox()
        Me.txtAOMinScale6 = New System.Windows.Forms.TextBox()
        Me.txtAOMinScale7 = New System.Windows.Forms.TextBox()
        Me.txtAOMinScale8 = New System.Windows.Forms.TextBox()
        Me.txtAOMinScale1 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.txtAiMaxScale2 = New System.Windows.Forms.TextBox()
        Me.txtAiMaxScale3 = New System.Windows.Forms.TextBox()
        Me.txtAiMaxScale4 = New System.Windows.Forms.TextBox()
        Me.txtAiMaxScale5 = New System.Windows.Forms.TextBox()
        Me.txtAiMaxScale6 = New System.Windows.Forms.TextBox()
        Me.txtAiMaxScale7 = New System.Windows.Forms.TextBox()
        Me.txtAiMaxScale8 = New System.Windows.Forms.TextBox()
        Me.txtAiMaxScale1 = New System.Windows.Forms.TextBox()
        Me.txtAiMinScale2 = New System.Windows.Forms.TextBox()
        Me.txtAiMinScale3 = New System.Windows.Forms.TextBox()
        Me.txtAiMinScale4 = New System.Windows.Forms.TextBox()
        Me.txtAiMinScale5 = New System.Windows.Forms.TextBox()
        Me.txtAiMinScale6 = New System.Windows.Forms.TextBox()
        Me.txtAiMinScale7 = New System.Windows.Forms.TextBox()
        Me.txtAiMinScale8 = New System.Windows.Forms.TextBox()
        Me.txtAiMinScale1 = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.lblAO5 = New System.Windows.Forms.Label()
        Me.lblAO6 = New System.Windows.Forms.Label()
        Me.lblAO7 = New System.Windows.Forms.Label()
        Me.lblAO8 = New System.Windows.Forms.Label()
        Me.lblAO3 = New System.Windows.Forms.Label()
        Me.lblAO4 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lblAO2 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.lblAO1 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblAI6 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblAI8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblAI7 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblAI5 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblAI4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblAI3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblAI1 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.lblAI2 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Location = New System.Drawing.Point(6, 11)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1159, 591)
        Me.Panel1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Location = New System.Drawing.Point(1006, 546)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(91, 43)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.Panel2.Controls.Add(Me.Label43)
        Me.Panel2.Controls.Add(Me.Label44)
        Me.Panel2.Controls.Add(Me.Label33)
        Me.Panel2.Controls.Add(Me.Label34)
        Me.Panel2.Controls.Add(Me.Wrkb1)
        Me.Panel2.Controls.Add(Me.txtAOMaxScale2)
        Me.Panel2.Controls.Add(Me.txtAOMaxScale3)
        Me.Panel2.Controls.Add(Me.txtAOMaxScale4)
        Me.Panel2.Controls.Add(Me.txtAOMaxScale5)
        Me.Panel2.Controls.Add(Me.txtAOMaxScale6)
        Me.Panel2.Controls.Add(Me.txtAOMaxScale7)
        Me.Panel2.Controls.Add(Me.txtAOMaxScale8)
        Me.Panel2.Controls.Add(Me.txtAOMaxScale1)
        Me.Panel2.Controls.Add(Me.txtAOMinScale2)
        Me.Panel2.Controls.Add(Me.txtAOMinScale3)
        Me.Panel2.Controls.Add(Me.txtAOMinScale4)
        Me.Panel2.Controls.Add(Me.txtAOMinScale5)
        Me.Panel2.Controls.Add(Me.txtAOMinScale6)
        Me.Panel2.Controls.Add(Me.txtAOMinScale7)
        Me.Panel2.Controls.Add(Me.txtAOMinScale8)
        Me.Panel2.Controls.Add(Me.txtAOMinScale1)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.Label26)
        Me.Panel2.Controls.Add(Me.Label27)
        Me.Panel2.Controls.Add(Me.Label29)
        Me.Panel2.Controls.Add(Me.Label30)
        Me.Panel2.Controls.Add(Me.Label31)
        Me.Panel2.Controls.Add(Me.Label32)
        Me.Panel2.Controls.Add(Me.txtAiMaxScale2)
        Me.Panel2.Controls.Add(Me.txtAiMaxScale3)
        Me.Panel2.Controls.Add(Me.txtAiMaxScale4)
        Me.Panel2.Controls.Add(Me.txtAiMaxScale5)
        Me.Panel2.Controls.Add(Me.txtAiMaxScale6)
        Me.Panel2.Controls.Add(Me.txtAiMaxScale7)
        Me.Panel2.Controls.Add(Me.txtAiMaxScale8)
        Me.Panel2.Controls.Add(Me.txtAiMaxScale1)
        Me.Panel2.Controls.Add(Me.txtAiMinScale2)
        Me.Panel2.Controls.Add(Me.txtAiMinScale3)
        Me.Panel2.Controls.Add(Me.txtAiMinScale4)
        Me.Panel2.Controls.Add(Me.txtAiMinScale5)
        Me.Panel2.Controls.Add(Me.txtAiMinScale6)
        Me.Panel2.Controls.Add(Me.txtAiMinScale7)
        Me.Panel2.Controls.Add(Me.txtAiMinScale8)
        Me.Panel2.Controls.Add(Me.txtAiMinScale1)
        Me.Panel2.Controls.Add(Me.Label28)
        Me.Panel2.Controls.Add(Me.Label25)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label42)
        Me.Panel2.Controls.Add(Me.Label40)
        Me.Panel2.Controls.Add(Me.Label39)
        Me.Panel2.Controls.Add(Me.Label38)
        Me.Panel2.Controls.Add(Me.Label37)
        Me.Panel2.Controls.Add(Me.Label36)
        Me.Panel2.Controls.Add(Me.Label35)
        Me.Panel2.Controls.Add(Me.Label24)
        Me.Panel2.Controls.Add(Me.Label23)
        Me.Panel2.Controls.Add(Me.Label22)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Controls.Add(Me.Label20)
        Me.Panel2.Controls.Add(Me.Label19)
        Me.Panel2.Controls.Add(Me.Label18)
        Me.Panel2.Controls.Add(Me.lblAO5)
        Me.Panel2.Controls.Add(Me.lblAO6)
        Me.Panel2.Controls.Add(Me.lblAO7)
        Me.Panel2.Controls.Add(Me.lblAO8)
        Me.Panel2.Controls.Add(Me.lblAO3)
        Me.Panel2.Controls.Add(Me.lblAO4)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.lblAO2)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.lblAO1)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.lblAI6)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.lblAI8)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.lblAI7)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.lblAI5)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.lblAI4)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.lblAI3)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.lblAI1)
        Me.Panel2.Controls.Add(Me.Label41)
        Me.Panel2.Controls.Add(Me.lblAI2)
        Me.Panel2.Location = New System.Drawing.Point(5, 9)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1139, 535)
        Me.Panel2.TabIndex = 0
        '
        'Label43
        '
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.Red
        Me.Label43.Location = New System.Drawing.Point(1001, 306)
        Me.Label43.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(96, 20)
        Me.Label43.TabIndex = 364
        Me.Label43.Text = "Max Value"
        '
        'Label44
        '
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.Red
        Me.Label44.Location = New System.Drawing.Point(903, 306)
        Me.Label44.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(82, 20)
        Me.Label44.TabIndex = 363
        Me.Label44.Text = "Min Value"
        '
        'Label33
        '
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.Red
        Me.Label33.Location = New System.Drawing.Point(1001, 40)
        Me.Label33.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(96, 20)
        Me.Label33.TabIndex = 362
        Me.Label33.Text = "Max Value"
        '
        'Label34
        '
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.Red
        Me.Label34.Location = New System.Drawing.Point(903, 39)
        Me.Label34.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(82, 20)
        Me.Label34.TabIndex = 361
        Me.Label34.Text = "Min Value"
        '
        'Wrkb1
        '
        Me.Wrkb1.CurrTextBox = Nothing
        Me.Wrkb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Wrkb1.Location = New System.Drawing.Point(110, 21)
        Me.Wrkb1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.Wrkb1.Name = "Wrkb1"
        Me.Wrkb1.Size = New System.Drawing.Size(386, 305)
        Me.Wrkb1.TabIndex = 360
        '
        'txtAOMaxScale2
        '
        Me.txtAOMaxScale2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMaxScale2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMaxScale2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMaxScale2.Location = New System.Drawing.Point(688, 386)
        Me.txtAOMaxScale2.Name = "txtAOMaxScale2"
        Me.txtAOMaxScale2.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMaxScale2.TabIndex = 359
        Me.txtAOMaxScale2.Text = "0000.00"
        '
        'txtAOMaxScale3
        '
        Me.txtAOMaxScale3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMaxScale3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMaxScale3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMaxScale3.Location = New System.Drawing.Point(688, 434)
        Me.txtAOMaxScale3.Name = "txtAOMaxScale3"
        Me.txtAOMaxScale3.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMaxScale3.TabIndex = 358
        Me.txtAOMaxScale3.Text = "0000.00"
        '
        'txtAOMaxScale4
        '
        Me.txtAOMaxScale4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMaxScale4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMaxScale4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMaxScale4.Location = New System.Drawing.Point(688, 478)
        Me.txtAOMaxScale4.Name = "txtAOMaxScale4"
        Me.txtAOMaxScale4.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMaxScale4.TabIndex = 357
        Me.txtAOMaxScale4.Text = "0000.00"
        '
        'txtAOMaxScale5
        '
        Me.txtAOMaxScale5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMaxScale5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMaxScale5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMaxScale5.Location = New System.Drawing.Point(1000, 335)
        Me.txtAOMaxScale5.Name = "txtAOMaxScale5"
        Me.txtAOMaxScale5.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMaxScale5.TabIndex = 356
        Me.txtAOMaxScale5.Text = "0000.00"
        '
        'txtAOMaxScale6
        '
        Me.txtAOMaxScale6.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMaxScale6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMaxScale6.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMaxScale6.Location = New System.Drawing.Point(1000, 386)
        Me.txtAOMaxScale6.Name = "txtAOMaxScale6"
        Me.txtAOMaxScale6.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMaxScale6.TabIndex = 355
        Me.txtAOMaxScale6.Text = "0000.00"
        '
        'txtAOMaxScale7
        '
        Me.txtAOMaxScale7.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMaxScale7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMaxScale7.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMaxScale7.Location = New System.Drawing.Point(1000, 434)
        Me.txtAOMaxScale7.Name = "txtAOMaxScale7"
        Me.txtAOMaxScale7.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMaxScale7.TabIndex = 354
        Me.txtAOMaxScale7.Text = "0000.00"
        '
        'txtAOMaxScale8
        '
        Me.txtAOMaxScale8.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMaxScale8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMaxScale8.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMaxScale8.Location = New System.Drawing.Point(1000, 478)
        Me.txtAOMaxScale8.Name = "txtAOMaxScale8"
        Me.txtAOMaxScale8.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMaxScale8.TabIndex = 353
        Me.txtAOMaxScale8.Text = "0000.00"
        '
        'txtAOMaxScale1
        '
        Me.txtAOMaxScale1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMaxScale1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMaxScale1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMaxScale1.Location = New System.Drawing.Point(688, 335)
        Me.txtAOMaxScale1.Name = "txtAOMaxScale1"
        Me.txtAOMaxScale1.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMaxScale1.TabIndex = 352
        Me.txtAOMaxScale1.Text = "0000.00"
        '
        'txtAOMinScale2
        '
        Me.txtAOMinScale2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMinScale2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMinScale2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMinScale2.Location = New System.Drawing.Point(586, 386)
        Me.txtAOMinScale2.Name = "txtAOMinScale2"
        Me.txtAOMinScale2.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMinScale2.TabIndex = 351
        Me.txtAOMinScale2.Text = "0000.00"
        '
        'txtAOMinScale3
        '
        Me.txtAOMinScale3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMinScale3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMinScale3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMinScale3.Location = New System.Drawing.Point(586, 434)
        Me.txtAOMinScale3.Name = "txtAOMinScale3"
        Me.txtAOMinScale3.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMinScale3.TabIndex = 350
        Me.txtAOMinScale3.Text = "0000.00"
        '
        'txtAOMinScale4
        '
        Me.txtAOMinScale4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMinScale4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMinScale4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMinScale4.Location = New System.Drawing.Point(586, 478)
        Me.txtAOMinScale4.Name = "txtAOMinScale4"
        Me.txtAOMinScale4.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMinScale4.TabIndex = 349
        Me.txtAOMinScale4.Text = "0000.00"
        '
        'txtAOMinScale5
        '
        Me.txtAOMinScale5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMinScale5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMinScale5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMinScale5.Location = New System.Drawing.Point(899, 335)
        Me.txtAOMinScale5.Name = "txtAOMinScale5"
        Me.txtAOMinScale5.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMinScale5.TabIndex = 348
        Me.txtAOMinScale5.Text = "0000.00"
        '
        'txtAOMinScale6
        '
        Me.txtAOMinScale6.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMinScale6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMinScale6.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMinScale6.Location = New System.Drawing.Point(899, 386)
        Me.txtAOMinScale6.Name = "txtAOMinScale6"
        Me.txtAOMinScale6.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMinScale6.TabIndex = 347
        Me.txtAOMinScale6.Text = "0000.00"
        '
        'txtAOMinScale7
        '
        Me.txtAOMinScale7.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMinScale7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMinScale7.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMinScale7.Location = New System.Drawing.Point(899, 434)
        Me.txtAOMinScale7.Name = "txtAOMinScale7"
        Me.txtAOMinScale7.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMinScale7.TabIndex = 346
        Me.txtAOMinScale7.Text = "0000.00"
        '
        'txtAOMinScale8
        '
        Me.txtAOMinScale8.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMinScale8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMinScale8.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMinScale8.Location = New System.Drawing.Point(899, 478)
        Me.txtAOMinScale8.Name = "txtAOMinScale8"
        Me.txtAOMinScale8.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMinScale8.TabIndex = 345
        Me.txtAOMinScale8.Text = "0000.00"
        '
        'txtAOMinScale1
        '
        Me.txtAOMinScale1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAOMinScale1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAOMinScale1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAOMinScale1.Location = New System.Drawing.Point(586, 335)
        Me.txtAOMinScale1.Name = "txtAOMinScale1"
        Me.txtAOMinScale1.Size = New System.Drawing.Size(96, 31)
        Me.txtAOMinScale1.TabIndex = 344
        Me.txtAOMinScale1.Text = "0000.00"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(810, 483)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(84, 22)
        Me.Label8.TabIndex = 343
        Me.Label8.Text = "AO8 Scale "
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(810, 439)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(84, 22)
        Me.Label10.TabIndex = 342
        Me.Label10.Text = "AO7 Scale "
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(810, 391)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(84, 22)
        Me.Label14.TabIndex = 341
        Me.Label14.Text = "AO6 Scale "
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(494, 339)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(87, 25)
        Me.Label16.TabIndex = 340
        Me.Label16.Text = "AO1 Scale "
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(494, 389)
        Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(87, 25)
        Me.Label26.TabIndex = 339
        Me.Label26.Text = "AO2 Scale "
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(494, 436)
        Me.Label27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(87, 25)
        Me.Label27.TabIndex = 338
        Me.Label27.Text = "AO3 Scale "
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label29
        '
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(494, 479)
        Me.Label29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(87, 25)
        Me.Label29.TabIndex = 337
        Me.Label29.Text = "AO4 Scale "
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label30
        '
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(810, 343)
        Me.Label30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(84, 22)
        Me.Label30.TabIndex = 336
        Me.Label30.Text = "AO5 Scale "
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label31
        '
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.Red
        Me.Label31.Location = New System.Drawing.Point(678, 306)
        Me.Label31.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(85, 15)
        Me.Label31.TabIndex = 335
        Me.Label31.Text = "Max Value"
        '
        'Label32
        '
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.Red
        Me.Label32.Location = New System.Drawing.Point(584, 305)
        Me.Label32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(85, 15)
        Me.Label32.TabIndex = 334
        Me.Label32.Text = "Min Value"
        '
        'txtAiMaxScale2
        '
        Me.txtAiMaxScale2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMaxScale2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMaxScale2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMaxScale2.Location = New System.Drawing.Point(688, 121)
        Me.txtAiMaxScale2.Name = "txtAiMaxScale2"
        Me.txtAiMaxScale2.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMaxScale2.TabIndex = 333
        Me.txtAiMaxScale2.Text = "0000.00"
        Me.txtAiMaxScale2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtAiMaxScale3
        '
        Me.txtAiMaxScale3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMaxScale3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMaxScale3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMaxScale3.Location = New System.Drawing.Point(689, 174)
        Me.txtAiMaxScale3.Name = "txtAiMaxScale3"
        Me.txtAiMaxScale3.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMaxScale3.TabIndex = 332
        Me.txtAiMaxScale3.Text = "0000.00"
        Me.txtAiMaxScale3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtAiMaxScale4
        '
        Me.txtAiMaxScale4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMaxScale4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMaxScale4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMaxScale4.Location = New System.Drawing.Point(688, 222)
        Me.txtAiMaxScale4.Name = "txtAiMaxScale4"
        Me.txtAiMaxScale4.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMaxScale4.TabIndex = 331
        Me.txtAiMaxScale4.Text = "0000.00"
        Me.txtAiMaxScale4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtAiMaxScale5
        '
        Me.txtAiMaxScale5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMaxScale5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMaxScale5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMaxScale5.Location = New System.Drawing.Point(1000, 70)
        Me.txtAiMaxScale5.Name = "txtAiMaxScale5"
        Me.txtAiMaxScale5.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMaxScale5.TabIndex = 330
        Me.txtAiMaxScale5.Text = "0000.00"
        '
        'txtAiMaxScale6
        '
        Me.txtAiMaxScale6.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMaxScale6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMaxScale6.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMaxScale6.Location = New System.Drawing.Point(1000, 121)
        Me.txtAiMaxScale6.Name = "txtAiMaxScale6"
        Me.txtAiMaxScale6.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMaxScale6.TabIndex = 329
        Me.txtAiMaxScale6.Text = "0000.00"
        '
        'txtAiMaxScale7
        '
        Me.txtAiMaxScale7.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMaxScale7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMaxScale7.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMaxScale7.Location = New System.Drawing.Point(1000, 174)
        Me.txtAiMaxScale7.Name = "txtAiMaxScale7"
        Me.txtAiMaxScale7.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMaxScale7.TabIndex = 328
        Me.txtAiMaxScale7.Text = "0000.00"
        '
        'txtAiMaxScale8
        '
        Me.txtAiMaxScale8.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMaxScale8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMaxScale8.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMaxScale8.Location = New System.Drawing.Point(1000, 222)
        Me.txtAiMaxScale8.Name = "txtAiMaxScale8"
        Me.txtAiMaxScale8.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMaxScale8.TabIndex = 327
        Me.txtAiMaxScale8.Text = "0000.00"
        '
        'txtAiMaxScale1
        '
        Me.txtAiMaxScale1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMaxScale1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMaxScale1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMaxScale1.Location = New System.Drawing.Point(688, 70)
        Me.txtAiMaxScale1.Name = "txtAiMaxScale1"
        Me.txtAiMaxScale1.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMaxScale1.TabIndex = 326
        Me.txtAiMaxScale1.Text = "0000.00"
        Me.txtAiMaxScale1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtAiMinScale2
        '
        Me.txtAiMinScale2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMinScale2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMinScale2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMinScale2.Location = New System.Drawing.Point(586, 121)
        Me.txtAiMinScale2.Name = "txtAiMinScale2"
        Me.txtAiMinScale2.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMinScale2.TabIndex = 325
        Me.txtAiMinScale2.Text = "0000.00"
        Me.txtAiMinScale2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtAiMinScale3
        '
        Me.txtAiMinScale3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMinScale3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMinScale3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMinScale3.Location = New System.Drawing.Point(587, 174)
        Me.txtAiMinScale3.Name = "txtAiMinScale3"
        Me.txtAiMinScale3.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMinScale3.TabIndex = 324
        Me.txtAiMinScale3.Text = "0000.00"
        Me.txtAiMinScale3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtAiMinScale4
        '
        Me.txtAiMinScale4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMinScale4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMinScale4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMinScale4.Location = New System.Drawing.Point(586, 222)
        Me.txtAiMinScale4.Name = "txtAiMinScale4"
        Me.txtAiMinScale4.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMinScale4.TabIndex = 323
        Me.txtAiMinScale4.Text = "0000.00"
        Me.txtAiMinScale4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtAiMinScale5
        '
        Me.txtAiMinScale5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMinScale5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMinScale5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMinScale5.Location = New System.Drawing.Point(899, 70)
        Me.txtAiMinScale5.Name = "txtAiMinScale5"
        Me.txtAiMinScale5.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMinScale5.TabIndex = 322
        Me.txtAiMinScale5.Text = "0000.00"
        '
        'txtAiMinScale6
        '
        Me.txtAiMinScale6.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMinScale6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMinScale6.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMinScale6.Location = New System.Drawing.Point(899, 121)
        Me.txtAiMinScale6.Name = "txtAiMinScale6"
        Me.txtAiMinScale6.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMinScale6.TabIndex = 321
        Me.txtAiMinScale6.Text = "0000.00"
        '
        'txtAiMinScale7
        '
        Me.txtAiMinScale7.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMinScale7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMinScale7.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMinScale7.Location = New System.Drawing.Point(899, 174)
        Me.txtAiMinScale7.Name = "txtAiMinScale7"
        Me.txtAiMinScale7.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMinScale7.TabIndex = 320
        Me.txtAiMinScale7.Text = "0000.00"
        '
        'txtAiMinScale8
        '
        Me.txtAiMinScale8.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMinScale8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMinScale8.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMinScale8.Location = New System.Drawing.Point(899, 222)
        Me.txtAiMinScale8.Name = "txtAiMinScale8"
        Me.txtAiMinScale8.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMinScale8.TabIndex = 319
        Me.txtAiMinScale8.Text = "0000.00"
        '
        'txtAiMinScale1
        '
        Me.txtAiMinScale1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAiMinScale1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAiMinScale1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAiMinScale1.Location = New System.Drawing.Point(586, 70)
        Me.txtAiMinScale1.Name = "txtAiMinScale1"
        Me.txtAiMinScale1.Size = New System.Drawing.Size(96, 31)
        Me.txtAiMinScale1.TabIndex = 318
        Me.txtAiMinScale1.Text = "0000.00"
        Me.txtAiMinScale1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label28.Location = New System.Drawing.Point(497, 273)
        Me.Label28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(603, 24)
        Me.Label28.TabIndex = 317
        Me.Label28.Text = "Analog Output Calibration"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(818, 229)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(80, 15)
        Me.Label25.TabIndex = 316
        Me.Label25.Text = "Ai8 Scale "
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(817, 182)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(80, 15)
        Me.Label12.TabIndex = 313
        Me.Label12.Text = "Ai7 Scale "
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(818, 129)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(80, 15)
        Me.Label6.TabIndex = 310
        Me.Label6.Text = "Ai6 Scale "
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label42
        '
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(501, 74)
        Me.Label42.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(80, 15)
        Me.Label42.TabIndex = 307
        Me.Label42.Text = "Ai1 Scale "
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label40
        '
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(501, 129)
        Me.Label40.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(80, 15)
        Me.Label40.TabIndex = 306
        Me.Label40.Text = "Ai2 Scale "
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label39
        '
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(501, 182)
        Me.Label39.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(80, 15)
        Me.Label39.TabIndex = 305
        Me.Label39.Text = "Ai3 Scale "
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label38
        '
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(501, 229)
        Me.Label38.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(80, 15)
        Me.Label38.TabIndex = 304
        Me.Label38.Text = "Ai4 Scale "
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label37
        '
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(818, 74)
        Me.Label37.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(80, 15)
        Me.Label37.TabIndex = 303
        Me.Label37.Text = "Ai5 Scale "
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label36
        '
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Red
        Me.Label36.Location = New System.Drawing.Point(688, 39)
        Me.Label36.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(96, 20)
        Me.Label36.TabIndex = 302
        Me.Label36.Text = "Max Value"
        '
        'Label35
        '
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Red
        Me.Label35.Location = New System.Drawing.Point(592, 39)
        Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(82, 20)
        Me.Label35.TabIndex = 301
        Me.Label35.Text = "Min Value"
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(103, 362)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(237, 20)
        Me.Label24.TabIndex = 290
        Me.Label24.Text = "AO3- SPARE"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label23
        '
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(103, 389)
        Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(192, 20)
        Me.Label23.TabIndex = 289
        Me.Label23.Text = "AO4- SPARE"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(103, 420)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(289, 20)
        Me.Label22.TabIndex = 288
        Me.Label22.Text = "AO5- WELDING CURRENT REF -HB"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(103, 445)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(276, 20)
        Me.Label21.TabIndex = 287
        Me.Label21.Text = "AO6- WELDING VOLTAGE REF-HB"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(103, 471)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(119, 20)
        Me.Label20.TabIndex = 286
        Me.Label20.Text = "AO7-  SPARE"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(103, 501)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(119, 20)
        Me.Label19.TabIndex = 285
        Me.Label19.Text = "AO8-  SPARE"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label18.Location = New System.Drawing.Point(497, 2)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(603, 24)
        Me.Label18.TabIndex = 284
        Me.Label18.Text = "Analog Input Calibration"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAO5
        '
        Me.lblAO5.AutoEllipsis = True
        Me.lblAO5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO5.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO5.Location = New System.Drawing.Point(11, 415)
        Me.lblAO5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO5.Name = "lblAO5"
        Me.lblAO5.Size = New System.Drawing.Size(83, 25)
        Me.lblAO5.TabIndex = 283
        Me.lblAO5.Text = "000.0"
        Me.lblAO5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO6
        '
        Me.lblAO6.AutoEllipsis = True
        Me.lblAO6.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO6.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO6.Location = New System.Drawing.Point(11, 443)
        Me.lblAO6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO6.Name = "lblAO6"
        Me.lblAO6.Size = New System.Drawing.Size(83, 25)
        Me.lblAO6.TabIndex = 282
        Me.lblAO6.Text = "000.0"
        Me.lblAO6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO7
        '
        Me.lblAO7.AutoEllipsis = True
        Me.lblAO7.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO7.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO7.Location = New System.Drawing.Point(11, 471)
        Me.lblAO7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO7.Name = "lblAO7"
        Me.lblAO7.Size = New System.Drawing.Size(83, 25)
        Me.lblAO7.TabIndex = 281
        Me.lblAO7.Text = "000.0"
        Me.lblAO7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO8
        '
        Me.lblAO8.AutoEllipsis = True
        Me.lblAO8.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO8.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO8.Location = New System.Drawing.Point(11, 498)
        Me.lblAO8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO8.Name = "lblAO8"
        Me.lblAO8.Size = New System.Drawing.Size(83, 25)
        Me.lblAO8.TabIndex = 280
        Me.lblAO8.Text = "000.0"
        Me.lblAO8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO3
        '
        Me.lblAO3.AutoEllipsis = True
        Me.lblAO3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO3.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO3.Location = New System.Drawing.Point(11, 358)
        Me.lblAO3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO3.Name = "lblAO3"
        Me.lblAO3.Size = New System.Drawing.Size(83, 25)
        Me.lblAO3.TabIndex = 279
        Me.lblAO3.Text = "000.0"
        Me.lblAO3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO4
        '
        Me.lblAO4.AutoEllipsis = True
        Me.lblAO4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO4.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO4.Location = New System.Drawing.Point(11, 388)
        Me.lblAO4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO4.Name = "lblAO4"
        Me.lblAO4.Size = New System.Drawing.Size(83, 25)
        Me.lblAO4.TabIndex = 278
        Me.lblAO4.Text = "000.0"
        Me.lblAO4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(8, 273)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(485, 24)
        Me.Label4.TabIndex = 277
        Me.Label4.Text = "Analog Output (V)"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(8, 2)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(485, 24)
        Me.Label2.TabIndex = 276
        Me.Label2.Text = "Analog Input (Value)"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(103, 331)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(281, 20)
        Me.Label17.TabIndex = 275
        Me.Label17.Text = "AO2- WELDING VOLTAGE REF -HA"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO2
        '
        Me.lblAO2.AutoEllipsis = True
        Me.lblAO2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO2.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO2.Location = New System.Drawing.Point(11, 329)
        Me.lblAO2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO2.Name = "lblAO2"
        Me.lblAO2.Size = New System.Drawing.Size(83, 25)
        Me.lblAO2.TabIndex = 274
        Me.lblAO2.Text = "000.0"
        Me.lblAO2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(98, 304)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(281, 20)
        Me.Label15.TabIndex = 273
        Me.Label15.Text = "AO1- WELDING CURRENT REF -HA"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO1
        '
        Me.lblAO1.AutoEllipsis = True
        Me.lblAO1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO1.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO1.Location = New System.Drawing.Point(11, 301)
        Me.lblAO1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO1.Name = "lblAO1"
        Me.lblAO1.Size = New System.Drawing.Size(83, 25)
        Me.lblAO1.TabIndex = 272
        Me.lblAO1.Text = "000.0"
        Me.lblAO1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(112, 191)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(237, 20)
        Me.Label13.TabIndex = 271
        Me.Label13.Text = "AI6-GAS FLOWSENSOR-HB"
        '
        'lblAI6
        '
        Me.lblAI6.AutoEllipsis = True
        Me.lblAI6.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI6.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI6.Location = New System.Drawing.Point(11, 186)
        Me.lblAI6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI6.Name = "lblAI6"
        Me.lblAI6.Size = New System.Drawing.Size(83, 25)
        Me.lblAI6.TabIndex = 270
        Me.lblAI6.Text = "000.0"
        Me.lblAI6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(107, 249)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(192, 20)
        Me.Label11.TabIndex = 269
        Me.Label11.Text = "AI8- SPARE"
        '
        'lblAI8
        '
        Me.lblAI8.AutoEllipsis = True
        Me.lblAI8.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI8.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI8.Location = New System.Drawing.Point(11, 242)
        Me.lblAI8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI8.Name = "lblAI8"
        Me.lblAI8.Size = New System.Drawing.Size(83, 25)
        Me.lblAI8.TabIndex = 268
        Me.lblAI8.Text = "000.0"
        Me.lblAI8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(112, 223)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(192, 20)
        Me.Label9.TabIndex = 267
        Me.Label9.Text = "AI7- JOB TEMPERATURE"
        '
        'lblAI7
        '
        Me.lblAI7.AutoEllipsis = True
        Me.lblAI7.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI7.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI7.Location = New System.Drawing.Point(11, 215)
        Me.lblAI7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI7.Name = "lblAI7"
        Me.lblAI7.Size = New System.Drawing.Size(83, 25)
        Me.lblAI7.TabIndex = 266
        Me.lblAI7.Text = "000.0"
        Me.lblAI7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(115, 160)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(234, 20)
        Me.Label7.TabIndex = 265
        Me.Label7.Text = "AI5- GAS FLOW SENSOR-HA"
        '
        'lblAI5
        '
        Me.lblAI5.AutoEllipsis = True
        Me.lblAI5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI5.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI5.Location = New System.Drawing.Point(11, 155)
        Me.lblAI5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI5.Name = "lblAI5"
        Me.lblAI5.Size = New System.Drawing.Size(83, 25)
        Me.lblAI5.TabIndex = 264
        Me.lblAI5.Text = "000.0"
        Me.lblAI5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(115, 130)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(234, 20)
        Me.Label5.TabIndex = 263
        Me.Label5.Text = "AI4- WELDING VOLTAGE-HB"
        '
        'lblAI4
        '
        Me.lblAI4.AutoEllipsis = True
        Me.lblAI4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI4.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI4.Location = New System.Drawing.Point(11, 124)
        Me.lblAI4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI4.Name = "lblAI4"
        Me.lblAI4.Size = New System.Drawing.Size(83, 25)
        Me.lblAI4.TabIndex = 262
        Me.lblAI4.Text = "000.0"
        Me.lblAI4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(115, 99)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(234, 20)
        Me.Label3.TabIndex = 261
        Me.Label3.Text = "AI3- WELDING CURRENT-HB"
        '
        'lblAI3
        '
        Me.lblAI3.AutoEllipsis = True
        Me.lblAI3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI3.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI3.Location = New System.Drawing.Point(11, 93)
        Me.lblAI3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI3.Name = "lblAI3"
        Me.lblAI3.Size = New System.Drawing.Size(83, 25)
        Me.lblAI3.TabIndex = 260
        Me.lblAI3.Text = "000.0"
        Me.lblAI3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(115, 37)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(248, 20)
        Me.Label1.TabIndex = 259
        Me.Label1.Text = "AI1- WELDING CURRENT-HA"
        '
        'lblAI1
        '
        Me.lblAI1.AutoEllipsis = True
        Me.lblAI1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI1.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI1.Location = New System.Drawing.Point(11, 32)
        Me.lblAI1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI1.Name = "lblAI1"
        Me.lblAI1.Size = New System.Drawing.Size(83, 25)
        Me.lblAI1.TabIndex = 258
        Me.lblAI1.Text = "000.0"
        Me.lblAI1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label41
        '
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(115, 67)
        Me.Label41.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(234, 20)
        Me.Label41.TabIndex = 257
        Me.Label41.Text = "AI2- WELDING VOLTAGE-HA"
        '
        'lblAI2
        '
        Me.lblAI2.AutoEllipsis = True
        Me.lblAI2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI2.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI2.Location = New System.Drawing.Point(11, 62)
        Me.lblAI2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI2.Name = "lblAI2"
        Me.lblAI2.Size = New System.Drawing.Size(83, 25)
        Me.lblAI2.TabIndex = 256
        Me.lblAI2.Text = "000.0"
        Me.lblAI2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Timer1
        '
        Me.Timer1.Interval = 500
        '
        'Timer2
        '
        '
        'frmAngstatus
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1176, 613)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmAngstatus"
        Me.Text = "frmAngstatus"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents lblAI6 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents lblAI8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents lblAI7 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lblAI5 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblAI4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblAI3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblAI1 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents lblAI2 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents lblAO1 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents lblAO2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblAO5 As Label
    Friend WithEvents lblAO6 As Label
    Friend WithEvents lblAO7 As Label
    Friend WithEvents lblAO8 As Label
    Friend WithEvents lblAO3 As Label
    Friend WithEvents lblAO4 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents txtAiMinScale1 As TextBox
    Friend WithEvents txtAiMinScale2 As TextBox
    Friend WithEvents txtAiMinScale3 As TextBox
    Friend WithEvents txtAiMinScale4 As TextBox
    Friend WithEvents txtAiMinScale5 As TextBox
    Friend WithEvents txtAiMinScale6 As TextBox
    Friend WithEvents txtAiMinScale7 As TextBox
    Friend WithEvents txtAiMinScale8 As TextBox
    Friend WithEvents txtAiMaxScale2 As TextBox
    Friend WithEvents txtAiMaxScale3 As TextBox
    Friend WithEvents txtAiMaxScale4 As TextBox
    Friend WithEvents txtAiMaxScale5 As TextBox
    Friend WithEvents txtAiMaxScale6 As TextBox
    Friend WithEvents txtAiMaxScale7 As TextBox
    Friend WithEvents txtAiMaxScale8 As TextBox
    Friend WithEvents txtAiMaxScale1 As TextBox
    Friend WithEvents txtAOMaxScale2 As TextBox
    Friend WithEvents txtAOMaxScale3 As TextBox
    Friend WithEvents txtAOMaxScale4 As TextBox
    Friend WithEvents txtAOMaxScale5 As TextBox
    Friend WithEvents txtAOMaxScale6 As TextBox
    Friend WithEvents txtAOMaxScale7 As TextBox
    Friend WithEvents txtAOMaxScale8 As TextBox
    Friend WithEvents txtAOMaxScale1 As TextBox
    Friend WithEvents txtAOMinScale2 As TextBox
    Friend WithEvents txtAOMinScale3 As TextBox
    Friend WithEvents txtAOMinScale4 As TextBox
    Friend WithEvents txtAOMinScale5 As TextBox
    Friend WithEvents txtAOMinScale6 As TextBox
    Friend WithEvents txtAOMinScale7 As TextBox
    Friend WithEvents txtAOMinScale8 As TextBox
    Friend WithEvents txtAOMinScale1 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Wrkb1 As myControls.WRKB
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Timer2 As Timer
End Class
