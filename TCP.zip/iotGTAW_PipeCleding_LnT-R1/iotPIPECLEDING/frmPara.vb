﻿'----------------------------------
' iotESSC for L&T
' by  trapasia DigiReach @ 2017
' Parameter setting and storing in Local Database (access db)
'----------------------------------
Imports System.Data
Imports System.Diagnostics


Public Class frmPara
    Dim Oid As Integer = 0
    Dim Cid As Integer = 0
    Dim tx As String = ""
    Dim rx As String = ""

    Private Sub frmPara_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
    End Sub
    Private Sub frmFour_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        fillform()
    End Sub
    Private Sub fillform()
        'objConn.dbConnect()
        'Dim sql As String = "select * from syspara"
        'Dim dt As DataTable
        'dt = objCon.ExecuteDataTable(sql, CommandType.Text)

        Using objCon As New dbClass
            Try
                Using dt As DataTable = objCon.ExecuteDataTable("select * from syspara", CommandType.Text)
                    For Each row As DataRow In dt.Rows
                        Oid = row("id")
                        txtCurStep.Text = row("curstep")
                        txtVolStep.Text = row("volstep")
                        txtWelSpeeddStep.Text = row("weldspeedstep")
                        txtWFStep.Text = row("wirefeedstep")

                        txtCurStep2.Text = row("curstep2")
                        txtVolStep2.Text = row("volstep2")
                        txtWFStep2.Text = row("wirefeedstep2")

                    Next
                End Using
            Catch ex As Exception
                MessageBox.Show("Error in fillform method of frmPara module, Error : " + ex.Message.ToString())
            End Try
        End Using
    End Sub
    Private Sub frmFour_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Panel1.Top = (Me.Height - Panel1.Height) / 2
        Panel1.Left = (Me.Width - Panel1.Width) / 2
    End Sub

    Private Sub BtnSave_Click(sender As System.Object, e As System.EventArgs) Handles BtnSave.Click
        MDIParent1.btnPara.Image = Global.iotPIPECLEDING.My.Resources.btnorg

        Dim circrol As Double = Math.Round((22 / 7) * CDbl(txtVolStep.Text), 3)
        Dim srfcspeed As Double = 0.0
        If circrol > 0 Then
            srfcspeed = Math.Round(circrol * 60 / CDbl(txtWFStep.Text), 3)
        End If

        Using objCon As New dbClass
            Try
                If Oid = 0 Then
                    Dim q As String = "insert into syspara(curstep,volstep,wirefeedstep,weldspeedstep,curstep2,volstep2,wirefeedstep2) values (" & txtCurStep.Text & "," & txtVolStep.Text & "," & CInt(txtWFStep.Text) & "','" & txtWelSpeeddStep.Text & "," & txtCurStep2.Text & "," & txtVolStep2.Text & "," & CInt(txtWFStep2.Text) & "')"
                    objCon.ExecuteNonQuery(q, CommandType.Text)
                Else
                    Dim q As String = "update syspara set curstep=" & txtCurStep.Text & ",curstep2=" & txtCurStep2.Text & ",volstep=" & txtVolStep.Text & ",volstep2=" & txtVolStep2.Text &
                ", wirefeedstep=" & txtWFStep.Text & ", wirefeedstep2='" & txtWFStep2.Text & "',weldspeedstep='" & txtWelSpeeddStep.Text & "' where id=" & Oid
                    objCon.ExecuteNonQuery(q, CommandType.Text)
                End If
            Catch ex As Exception
                MessageBox.Show("Error in BtnSave_Click method of frmPara module, Error : " + ex.Message.ToString())

                'If isConnection = True Then

                '    Dim t1 As Integer = CDbl(txtSetTemp.Text)
                '    ' Dim t01 As Integer = t1 * 10
                '    Dim h1 As String = "020607F0" & dec2Hex(t1)

                '    tx = h1 & ComputeCrc(h1)
                '    rx = txComA(tx, 50)
                '    'writeLog("|TRC Minus PLC |TX:" & tx & " |RX:" & rx)


                'End If
            End Try
        End Using

        getPara()

        Select Case MsgBox("Data has been Saved", MsgBoxStyle.OkOnly, "Message")
            Case MsgBoxResult.Ok
                Me.Close()
        End Select

    End Sub
    Private Sub BtnClose_Click(sender As System.Object, e As System.EventArgs)
        Me.Close()
    End Sub


    Private Sub txtVolStep_GotFocus(sender As Object, e As System.EventArgs) Handles txtVolStep.GotFocus
        MyKB1.CurrTextBox = txtVolStep
        MyKB1.Visible = True
    End Sub

    Private Sub txtVolStep2_GotFocus(sender As Object, e As System.EventArgs) Handles txtVolStep2.GotFocus
        MyKB1.CurrTextBox = txtVolStep2
        MyKB1.Visible = True
    End Sub


    Private Sub txtSetTemp_GotFocus(sender As Object, e As System.EventArgs) Handles txtSetTemp.GotFocus
        MyKB1.CurrTextBox = txtSetTemp
        MyKB1.Visible = True
    End Sub

    Private Sub txtCurStep_GotFocus(sender As Object, e As System.EventArgs) Handles txtCurStep.GotFocus
        MyKB1.CurrTextBox = txtCurStep
        MyKB1.Visible = True
    End Sub

    Private Sub txtCurStep2_GotFocus(sender As Object, e As System.EventArgs) Handles txtCurStep2.GotFocus
        MyKB1.CurrTextBox = txtCurStep2
        MyKB1.Visible = True
    End Sub

    Private Sub txtspeedpm_GotFocus(sender As Object, e As System.EventArgs) Handles txtWelSpeeddStep.GotFocus
        MyKB1.CurrTextBox = txtWelSpeeddStep
        MyKB1.Visible = True
    End Sub

    Private Sub txtmgleftstep_GotFocus(sender As Object, e As System.EventArgs) Handles txtmgleftstep.GotFocus
        MyKB1.CurrTextBox = txtmgleftstep
        MyKB1.Visible = True
    End Sub
    Private Sub txtmgrightstep_GotFocus(sender As Object, e As System.EventArgs) Handles txtmgrightstep.GotFocus
        MyKB1.CurrTextBox = txtmgrightstep
        MyKB1.Visible = True
    End Sub

    Private Sub BtnClose_Click_1(sender As System.Object, e As System.EventArgs) Handles BtnClose.Click
        Me.Close()
        MDIParent1.btnPara.Image = Global.iotPIPECLEDING.My.Resources.btnorg

    End Sub

    Private Sub txtWFStep_GotFocus(sender As Object, e As System.EventArgs) Handles txtWFStep.GotFocus
        MyKB1.CurrTextBox = txtWFStep
        MyKB1.Visible = True
    End Sub

    Private Sub txtWFStep2_GotFocus(sender As Object, e As System.EventArgs) Handles txtWFStep2.GotFocus
        MyKB1.CurrTextBox = txtWFStep2
        MyKB1.Visible = True
    End Sub

    Private Sub txtTempPM_GotFocus(sender As Object, e As System.EventArgs) Handles txtTempPM.GotFocus
        MyKB1.CurrTextBox = txtTempPM
        MyKB1.Visible = True
    End Sub

    Private Sub plcctrlon()
        Dim tx As String = ""
        Dim rx As String = ""
        Try
            If isConnection = True Then

                'X-y slide slow '

                tx = "02 05 02 27 00 00 7C 4A"
                rx = txComA(tx, 50)
                'writeLog("|Auxlmp |TX:" & tx & "|RX:" & rx)

                tx = "02 05 02 28 00 00 4C 49"
                rx = txComA(tx, 50)
                'writeLog("|Auxlmp |TX:" & tx & "|RX:" & rx)

                'Anti drift tracking off'

                tx = "02 05 01 31 00 00 9D CA"
                rx = txComA(tx, 50)
                'writeLog("|Auxlmp |TX:" & tx & "|RX:" & rx)

                'step overlay reverse'

                tx = "02 05 02 31 00 00 9D 8E"
                rx = txComA(tx, 50)
                'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)

                'trolley slow'

                tx = "02 05 02 26 00 00 2D 8A"
                rx = txComA(tx, 50)
                'writeLog("|Auxlmp |TX:" & tx & "|RX:" & rx)

            End If
        Catch ex As Exception
            MessageBox.Show("Error in plcctrlon method of frmPara module, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        If gLogin = False Then
            If isComOpen Then
                closeCom()
                ' plcctrlon()
                'resetCtrl()
            End If

            If isComOpenRX Then
                closeComRX()
                'plcctrlon()
                'resetCtrl()
            End If
            'closeLog()
            End
        Else
            Dim result As String = MessageBoxEx.Show("Kindly Log Off before closing application.", "Application Close", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
            'MessageBox.Show("Kindly logout before closing application.")
        End If
    End Sub

    Private Sub resetCtrl()
        Dim tx As String = ""
        Dim rx As String = ""

        Try
            If isConnection = True Then
                tx = "0B 0F 00 10 00 08 01 00 BF 29"
                rx = txComA(tx, 50)
                'writeLog("|ESSCon |TX:" & tx & " |RX:" & rx)
                tx = "15 0F 00 10 00 08 01 00 3F A9"
                rx = txComA(tx, 50)
                'writeLog("|ESSCon |TX:" & tx & " |RX:" & rx)
                tx = "1F 0F 00 10 00 08 01 00 BF D6"
                rx = txComA(tx, 50)
                'writeLog("|ESSCon |TX:" & tx & " |RX:" & rx)
                tx = "20 0F 00 10 00 08 01 00 FC 82"
                rx = txComA(tx, 50)
                'writeLog("|ESSCon |TX:" & tx & " |RX:" & rx)
                tx = "21 0F 00 10 00 08 01 00 3D 4E"
                rx = txComA(tx, 50)
                'writeLog("|ESSCon |TX:" & tx & " |RX:" & rx)
                tx = "29 0F 00 10 00 08 01 00 3C E8"
                rx = txComA(tx, 50)
                'writeLog("|ESSCon |TX:" & tx & " |RX:" & rx)
            End If
        Catch ex As Exception
            MessageBox.Show("Error in resetCtrl method of frmPara module, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim testDialog As New frmParaPass

        ' Show testDialog as a modal dialog and determine if DialogResult = OK.
        If testDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
            ' Read the contents of testDialog's TextBox.
            If testDialog.txtPass.Text = "" Then
            Else
                If (testDialog.txtPass.Text = gParaPass) Then
                    Dim obj As New frmParaIT
                    obj.TopLevel = True
                    obj.Dock = DockStyle.Fill
                    obj.FormBorderStyle = Windows.Forms.FormBorderStyle.None
                    obj.ControlBox = False
                    obj.Text = ""
                    obj.WindowState = FormWindowState.Maximized

                    obj.Show()
                Else
                    Dim result As String = MessageBoxEx.Show("Invalid Password ", "Para Setting", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
                End If
            End If
        End If
        testDialog.Dispose()
    End Sub

    'Private Sub Button2_Click(sender As Object, e As EventArgs) Handles esscparasetup.Click
    '    Dim testDialog As New frmesscpara

    '    ' Show testDialog as a modal dialog and determine if DialogResult = OK.
    '    If testDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
    '        ' Read the contents of testDialog's TextBox.

    '    End If

    '    testDialog.Dispose()
    'End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        Dim testDialog As New frmalarm

        ' Show testDialog as a modal dialog and determine if DialogResult = OK.
        If testDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
            ' Read the contents of testDialog's TextBox.
        End If

        testDialog.Dispose()

    End Sub

End Class