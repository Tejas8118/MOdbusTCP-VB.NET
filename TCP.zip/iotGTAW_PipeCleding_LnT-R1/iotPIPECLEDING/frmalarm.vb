﻿Public Class frmalarm
    Dim Oid As Integer = 0
    Dim Cid As Integer = 0
    Dim objConn As New dbClass
    Private Sub frmalarm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        fillform()
    End Sub
    Private Sub fillform()
        'objConn.dbConnect()
        'Dim sql As String = "select * from syspara"
        'Dim dt As DataTable
        'dt = objCon.ExecuteDataTable(sql, CommandType.Text)

        Using objCon As New dbClass
            Try
                Using dt As DataTable = objCon.ExecuteDataTable("select * from syspara", CommandType.Text)
                    For Each row As DataRow In dt.Rows
                        Oid = row("id")

                        txtWCMin.Text = row("wcmin")
                        txtWCMax.Text = row("wcmax")

                        txtWVMin.Text = row("wvmin")
                        txtWVMax.Text = row("wvmax")

                        txtTRSMin.Text = row("trsmin")
                        txtTRSMax.Text = row("trsmax")

                        txtJTMin.Text = row("jtmin")
                        txtJTMax.Text = row("jtmax")

                        txtGFmin.Text = row("gfmin")
                        txtGFmax.Text = row("gfmax")

                        txtFWmin.Text = row("fwmin")
                        txtFWmax.Text = row("fwmax")

                        txtWFmin.Text = row("wfmin")
                        txtWFmax.Text = row("wfmax")

                        txtrightmin.Text = row("righcurmin")
                        txtrightmax.Text = row("righcurmax")

                    Next
                End Using
            Catch ex As Exception
                MessageBox.Show("Error in fillform method of frmalarm module, Error : " + ex.Message.ToString())
            End Try
        End Using
    End Sub
    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Me.Close()
    End Sub
    Private Sub txtWCMin_GotFocus(sender As Object, e As System.EventArgs) Handles txtWCMin.GotFocus
        MyKB1.CurrTextBox = txtWCMin
        MyKB1.Visible = True
    End Sub
    Private Sub txtWCMax_GotFocus(sender As Object, e As System.EventArgs) Handles txtWCMax.GotFocus
        MyKB1.CurrTextBox = txtWCMax
        MyKB1.Visible = True
    End Sub

    Private Sub txtWVMin_GotFocus(sender As Object, e As System.EventArgs) Handles txtWVMin.GotFocus
        MyKB1.CurrTextBox = Me.txtWVMin
        MyKB1.Visible = True
    End Sub

    Private Sub txtWVMax_GotFocus(sender As Object, e As System.EventArgs) Handles txtWVMax.GotFocus
        MyKB1.CurrTextBox = txtWVMax
        MyKB1.Visible = True
    End Sub

    Private Sub txtWSMin_GotFocus(sender As Object, e As System.EventArgs) Handles txtTRSMin.GotFocus
        MyKB1.CurrTextBox = txtTRSMin
        MyKB1.Visible = True
    End Sub

    Private Sub txtWSMax_GotFocus(sender As Object, e As System.EventArgs) Handles txtTRSMax.GotFocus
        MyKB1.CurrTextBox = txtTRSMax
        MyKB1.Visible = True
    End Sub

    Private Sub txtJTMax_GotFocus(sender As Object, e As System.EventArgs) Handles txtJTMax.GotFocus
        MyKB1.CurrTextBox = Me.txtJTMax
        MyKB1.Visible = True
    End Sub
    Private Sub txtJTMin_GotFocus(sender As Object, e As System.EventArgs) Handles txtJTMin.GotFocus
        MyKB1.CurrTextBox = Me.txtJTMin
        MyKB1.Visible = True
    End Sub

    Private Sub txtGFmin_GotFocus(sender As Object, e As System.EventArgs) Handles txtGFmin.GotFocus
        MyKB1.CurrTextBox = Me.txtGFmin
        MyKB1.Visible = True
    End Sub
    Private Sub txtGFmax_GotFocus(sender As Object, e As System.EventArgs) Handles txtGFmax.GotFocus
        MyKB1.CurrTextBox = Me.txtGFmax
        MyKB1.Visible = True
    End Sub

    Private Sub txtWFmin_GotFocus(sender As Object, e As System.EventArgs) Handles txtWFmin.GotFocus
        MyKB1.CurrTextBox = Me.txtWFmin
        MyKB1.Visible = True
    End Sub
    Private Sub txtWFmax_GotFocus(sender As Object, e As System.EventArgs) Handles txtWFmax.GotFocus
        MyKB1.CurrTextBox = Me.txtWFmax
        MyKB1.Visible = True
    End Sub

    Private Sub txtrightmin_GotFocus(sender As Object, e As System.EventArgs) Handles txtrightmin.GotFocus
        MyKB1.CurrTextBox = Me.txtrightmin
        MyKB1.Visible = True
    End Sub
    Private Sub txtrightmax_GotFocus(sender As Object, e As System.EventArgs) Handles txtrightmax.GotFocus
        MyKB1.CurrTextBox = Me.txtrightmax
        MyKB1.Visible = True
    End Sub


    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Using objCon As New dbClass
            Try
                ''Check for nirav sir 
                If Oid = 0 Then
                    Dim q As String = "insert into syspara(wcmin,wcmax,wvmin,wvmax,trsmin,trsmax,jtmin,jtmax,gfmin,gfmax,wfmin,wfmax) values (" &
                        "" & txtWCMin.Text & "," & txtWCMax.Text & "," & txtWVMin.Text & "," & txtWVMax.Text & "," & txtTRSMin.Text & "," & txtTRSMax.Text & "," &
                        "" & txtJTMin.Text & "," & txtJTMax.Text & "," & txtGFmin.Text & "," & txtGFmax.Text & "," & txtWFmin.Text & "," & txtWFmax.Text & "," & ")"
                    objCon.ExecuteNonQuery(q, CommandType.Text)
                Else
                    Dim q As String = "update syspara set wcmin=" & txtWCMin.Text & ",wcmax=" & txtWCMax.Text & ",wvmin=" & txtWVMin.Text & ",wvmax=" & txtWVMax.Text & "" &
                    ",trsmin=" & txtTRSMin.Text & ",trsmax=" & txtTRSMax.Text & ",jtmin=" & txtJTMin.Text & ",jtmax=" & txtJTMax.Text & "" &
                    ",gfmin='" & txtGFmin.Text & "',gfmax='" & txtGFmax.Text & "',fwmin='" & txtFWmin.Text & "',fwmax='" & txtFWmax.Text & "',wfmin=" & txtWFmin.Text & ",wfmax=" & txtWFmax.Text & " where id=" & Oid
                    objCon.ExecuteNonQuery(q, CommandType.Text)
                End If

                getPara()

                Select Case MsgBox("Data has been Saved", MsgBoxStyle.OkOnly, "Message")
                    Case MsgBoxResult.Ok
                        Me.Close()
                End Select
            Catch ex As Exception
                MessageBox.Show("Error in BtnSave_Click method of frmalarm module, Error : " + ex.Message.ToString())
            End Try
        End Using
    End Sub

    Private Sub txtFWmin_GotFocus(sender As Object, e As System.EventArgs) Handles txtFWmin.GotFocus
        MyKB1.CurrTextBox = Me.txtFWmin
        MyKB1.Visible = True
    End Sub

    Private Sub txtFWmax_GotFocus(sender As Object, e As System.EventArgs) Handles txtFWmax.GotFocus
        MyKB1.CurrTextBox = Me.txtFWmax
        MyKB1.Visible = True
    End Sub




End Class