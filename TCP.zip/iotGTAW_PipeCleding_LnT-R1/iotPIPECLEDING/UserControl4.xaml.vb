﻿Public Class UserControl4
    Dim tx As String = ""
    Dim rx As String = ""

    Private Sub btnstrpcutstart_touchdn(ByVal sender As Object, ByVal e As Windows.Input.TouchEventArgs) Handles btnvccw.TouchEnter
        Try




            'btnstrpcutstart.TouchEnter execution
            Dim imgsrc1 As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/ccw1.png"))
            Dim imgbrush1 As New System.Windows.Media.ImageBrush(imgsrc1)
            btnvccw.Background = imgbrush1

            If isConnection = True Then
                tx = ""
                rx = ""

                tx = "02 05 00 9F FF 00 BC 27"
                rx = txComA(tx, 50)
                'writeLog("|ESSCupR |TX:" & tx & " |RX:" & rx)


            End If

        Catch ex As Exception
        End Try
    End Sub
    Private Sub btnstrpcutstart_TouchEnter(ByVal sender As Object, ByVal e As Windows.Input.TouchEventArgs) Handles btnvccw.TouchLeave
        Try

            Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/ccw.png"))
            Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
            btnvccw.Background = imgbrush

            If isConnection = True Then
                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 00 9F 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|ESSCupR |TX:" & tx & " |RX:" & rx) 

                Threading.Thread.Sleep(1000)
                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 00 9F 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|ESSCupR |TX:" & tx & " |RX:" & rx) 

            End If

        Catch ex As Exception
        End Try
    End Sub

End Class
