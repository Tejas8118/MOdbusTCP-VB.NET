﻿Public Class frmDelay
    Dim tx As String = ""
    Dim rx As String = ""
    Dim y As Integer = 0
    Dim y1 As Double = 0.0
    Dim errno As Integer = 0

    Private Sub frmDelay_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        Wrkb1.Visible = False
        Timer1.Enabled = True
    End Sub

    Private Sub frmAngstatus_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Panel1.Left = (Me.Width - Panel1.Width) / 2
        Panel1.Top = (Me.Height - Panel1.Height) / 2
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub



    Public Sub Analogread2()
        Try
            errno = 0
            Dim y As Integer
            Dim y1 As Double
            Dim plcinstrg As String = ""
            If isConnection = True Then

                '//// Axis Manual/Auto Speed 1  /////////////
                y = 0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 BC 00 06", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gManSpeedRapidAxis1 = (y / 100)
                        txtRapid1.Text = gManSpeedRapidAxis1.ToString()
                        y = 0
                        y = Convert.ToInt32(x1(15) & x1(16) & x1(13) & x1(14), 16)
                        gManSpeedSlowAxis1 = (y / 100)
                        txtSlow1.Text = gManSpeedSlowAxis1.ToString()
                        y = 0
                        y = Convert.ToInt32(x1(19) & x1(20) & x1(17) & x1(18), 16)
                        gAutoSpeedAxis1 = (y / 100)
                        txtAutoSpeed1.Text = gAutoSpeedAxis1.ToString()

                        errno = 1
                    End If
                End If

                '////  Axis Manual/Auto Speed  2  /////////////
                y = 0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 C6 00 06", 50)
                Dim x2() As String = plcinstrg.Split(" "c)
                If x2.Count >= 8 Then
                    If x2(0) = "02" And x2(1) = "03" Then
                        y = Convert.ToInt32(x2(11) & x2(12) & x2(9) & x2(10), 16)
                        gManSpeedRapidAxis2 = (y / 100)
                        txtRapid2.Text = gManSpeedRapidAxis2.ToString()
                        y = 0
                        y = Convert.ToInt32(x2(15) & x2(16) & x2(13) & x2(14), 16)
                        gManSpeedSlowAxis2 = (y / 100)
                        txtSlow2.Text = gManSpeedSlowAxis2.ToString()
                        y = 0
                        y = Convert.ToInt32(x2(19) & x2(20) & x2(17) & x2(18), 16)
                        gAutoSpeedAxis2 = (y / 100)
                        txtAutoSpeed2.Text = gAutoSpeedAxis2.ToString()
                        errno = 2
                    End If
                End If

                '////  Axis Manual/Auto Speed  3  /////////////
                y = 0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 D0 00 06", 50)
                Dim x3() As String = plcinstrg.Split(" "c)
                If x3.Count >= 8 Then
                    If x3(0) = "02" And x3(1) = "03" Then
                        y = Convert.ToInt32(x3(11) & x3(12) & x3(9) & x3(10), 16)
                        gManSpeedRapidAxis3 = (y / 100)
                        txtRapid3.Text = gManSpeedRapidAxis3.ToString()
                        y = 0
                        y = Convert.ToInt32(x3(15) & x3(16) & x3(13) & x3(14), 16)
                        gManSpeedSlowAxis3 = (y / 100)
                        txtSlow3.Text = gManSpeedSlowAxis3.ToString()
                        y = 0
                        y = Convert.ToInt32(x3(19) & x3(20) & x3(17) & x3(18), 16)
                        gAutoSpeedAxis3 = (y / 100)
                        txtAutoSpeed3.Text = gAutoSpeedAxis3.ToString()

                        errno = 3
                    End If
                End If

                '////  Axis Manual/Auto Speed 4  /////////////
                y = 0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 DA 00 06", 50)
                Dim x4() As String = plcinstrg.Split(" "c)
                If x4.Count >= 8 Then
                    If x4(0) = "02" And x4(1) = "03" Then
                        y = Convert.ToInt32(x4(11) & x4(12) & x4(9) & x4(10), 16)
                        gManSpeedRapidAxis4 = (y / 100)
                        txtRapid4.Text = gManSpeedRapidAxis4
                        y = 0
                        y = Convert.ToInt32(x4(15) & x4(16) & x4(13) & x4(14), 16)
                        gManSpeedSlowAxis4 = (y / 100)
                        txtSlow4.Text = gManSpeedSlowAxis4.ToString()
                        y = 0
                        y = Convert.ToInt32(x4(19) & x4(20) & x4(17) & x4(18), 16)
                        gAutoSpeedAxis4 = (y / 100)
                        txtAutoSpeed4.Text = gAutoSpeedAxis4.ToString()


                        errno = 4
                    End If
                End If

                '////  Axis Manual/Auto Speed  5  /////////////
                y = 0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 E4 00 06", 50)
                Dim x5() As String = plcinstrg.Split(" "c)
                If x5.Count >= 8 Then
                    If x5(0) = "02" And x5(1) = "03" Then
                        y = Convert.ToInt32(x5(11) & x5(12) & x5(9) & x5(10), 16)
                        gManSpeedRapidAxis5 = (y / 100)
                        txtRapid5.Text = gManSpeedRapidAxis5.ToString()
                        y = 0
                        y = Convert.ToInt32(x5(15) & x5(16) & x5(13) & x5(14), 16)
                        gManSpeedSlowAxis5 = (y / 100)
                        txtSlow5.Text = gManSpeedSlowAxis5.ToString()
                        y = 0
                        y = Convert.ToInt32(x5(19) & x5(20) & x5(17) & x5(18), 16)
                        gAutoSpeedAxis5 = (y / 100)
                        txtAutoSpeed5.Text = gAutoSpeedAxis5.ToString()


                        errno = 5
                    End If
                End If

                '//// Delay Perameter 1 TO 10  /////////////
                y = 0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 84 00 14", 50)
                Dim x6() As String = plcinstrg.Split(" "c)
                If x6.Count >= 8 Then
                    If x6(0) = "02" And x6(1) = "03" Then
                        y = Convert.ToInt32(x6(11) & x6(12) & x6(9) & x6(10), 16)
                        gDelay1 = (y / 100)
                        txtDelay1.Text = gDelay1.ToString()
                        '//////////////////////////////////////////////////////////
                        y = 0
                        y = Convert.ToInt32(x6(15) & x6(16) & x6(13) & x6(14), 16)
                        gDelay2 = (y / 100)
                        txtDelay2.Text = gDelay2.ToString()
                        '//////////////////////////////////////////////////////////

                        y = 0
                        y = Convert.ToInt32(x6(19) & x6(20) & x6(17) & x6(18), 16)
                        gDelay3 = (y / 100)
                        txtDelay3.Text = gDelay3.ToString()
                        '//////////////////////////////////////////////////////////

                        y = 0
                        y = Convert.ToInt32(x6(17) & x6(18) & x6(15) & x6(16), 16)
                        gDelay4 = (y / 100)
                        txtDelay4.Text = gDelay4.ToString()
                        '//////////////////////////////////////////////////////////

                        y = 0
                        y = Convert.ToInt32(x6(21) & x6(22) & x6(19) & x6(20), 16)
                        gDelay5 = (y / 100)
                        txtDelay5.Text = gDelay5.ToString()
                        '//////////////////////////////////////////////////////////

                        y = 0
                        y = Convert.ToInt32(x6(25) & x6(26) & x6(23) & x6(24), 16)
                        gDelay6 = (y / 100)
                        txtDelay6.Text = gDelay6.ToString()
                        '//////////////////////////////////////////////////////////

                        y = 0
                        y = Convert.ToInt32(x6(29) & x6(30) & x6(27) & x6(28), 16)
                        gDelay7 = (y / 100)
                        txtDelay7.Text = gDelay7.ToString()
                        '//////////////////////////////////////////////////////////

                        y = 0
                        y = Convert.ToInt32(x6(33) & x6(34) & x6(31) & x6(32), 16)
                        gDelay8 = (y / 100)
                        txtDelay8.Text = gDelay8.ToString()
                        '//////////////////////////////////////////////////////////

                        y = 0
                        y = Convert.ToInt32(x6(37) & x6(38) & x6(35) & x6(36), 16)
                        gDelay9 = (y / 100)
                        txtDelay9.Text = gDelay9.ToString()
                        '//////////////////////////////////////////////////////////

                        y = 0
                        y = Convert.ToInt32(x6(41) & x6(42) & x6(39) & x6(40), 16)
                        gDelay10 = (y / 100)
                        txtDelay10.Text = gDelay10.ToString()

                        errno = 6
                    End If
                End If

                '//// Wirefeed Delay 1 And Retract 1  /////////////
                y = 0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E6 00 04", 50)
                Dim x7() As String = plcinstrg.Split(" "c)
                If x7.Count >= 8 Then
                    If x7(0) = "02" And x7(1) = "03" Then
                        y = Convert.ToInt32(x7(11) & x7(12) & x7(9) & x7(10), 16)
                        gSetWFStartDelay1 = (y / 10)
                        txtWFDelay1.Text = gSetWFStartDelay1.ToString()
                        y = 0
                        y = Convert.ToInt32(x7(15) & x7(16) & x7(13) & x7(14), 16)
                        gSetWFRetractDistance1 = (y / 10)
                        txtWireRet1.Text = gSetWFRetractDistance1.ToString()

                        errno = 7
                    End If
                End If

                '//// Wirefeed Delay 2 And Retract 2  /////////////
                y = 0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 F0 00 04", 50)
                Dim x8() As String = plcinstrg.Split(" "c)
                If x8.Count >= 8 Then
                    If x8(0) = "02" And x8(1) = "03" Then
                        y = Convert.ToInt32(x8(11) & x8(12) & x8(9) & x8(10), 16)
                        gSetWFStartDelay2 = (y / 10)
                        txtWFDelay2.Text = gSetWFStartDelay2.ToString()
                        y = 0
                        y = Convert.ToInt32(x8(15) & x8(16) & x8(13) & x8(14), 16)
                        gSetWFRetractDistance2 = (y / 10)
                        txtWireRet2.Text = gSetWFRetractDistance2.ToString()
                        errno = 8
                    End If
                End If

                '//// AVC BAND And Speed 1  /////////////
                y = 0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 5C 00 04", 50)
                Dim x9() As String = plcinstrg.Split(" "c)
                If x9.Count >= 8 Then
                    If x9(0) = "02" And x9(1) = "03" Then
                        y = Convert.ToInt32(x9(11) & x9(12) & x9(9) & x9(10), 16)
                        gAvcband1 = (y / 10)
                        txtAvcBand1.Text = gAvcband1.ToString()

                        y = 0
                        y = Convert.ToInt32(x9(15) & x9(16) & x9(13) & x9(14), 16)
                        gAvcspeed1 = (y / 100)
                        txtAvcSpeed1.Text = gAvcspeed1.ToString()

                        errno = 9
                    End If
                End If

                '//// AVC BAND And Speed 2  /////////////
                y = 0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 66 00 04", 50)
                Dim x10() As String = plcinstrg.Split(" "c)
                If x10.Count >= 8 Then
                    If x10(0) = "02" And x10(1) = "03" Then
                        y = Convert.ToInt32(x10(11) & x10(12) & x10(9) & x10(10), 16)
                        gAvcband2 = (y / 10)
                        txtAvcBand2.Text = gAvcband2.ToString()

                        y = 0
                        y = Convert.ToInt32(x10(15) & x10(16) & x10(13) & x10(14), 16)
                        gAvcspeed2 = (y / 100)
                        txtAvcSpeed2.Text = gAvcspeed2.ToString()

                        errno = 10
                    End If
                End If



            End If
        Catch ex As Exception
            Dim result1 As String = MessageBoxEx.Show("Error from Analog Input/Output Read, Error : " + ex.Message.ToString() + errno.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString

            '  MessageBox.Show("Error from Analog Input/Output Read, Error : " + ex.Message.ToString() + errno.ToString())
        End Try

    End Sub

    Private Sub txtRapid1_gotfocus(sender As Object, e As EventArgs) Handles txtRapid1.Click
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtRapid1
    End Sub
    Private Sub txtRapid1_TextChanged(sender As Object, e As EventArgs) Handles txtRapid1.TextChanged
        Dim arr As Integer = 0
        arr = txtRapid1.TextLength
        Dim st As String = ""

        st = txtRapid1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtRapid1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtRapid1.Text += ii(ht)
                    Next
                    If txtRapid1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtRapid1.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002BC000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 BC 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gManSpeedRapidAxis1 = (y / 100)
                                    txtRapid1.Text = gManSpeedRapidAxis1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtRapid1.Text = gManSpeedRapidAxis1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtRapid1.Text = gManSpeedRapidAxis1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtRapid2_gotfocus(sender As Object, e As EventArgs) Handles txtRapid2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtRapid2
    End Sub
    Private Sub txtRapid2_TextChanged(sender As Object, e As EventArgs) Handles txtRapid2.TextChanged
        Dim arr As Integer = 0
        arr = txtRapid2.TextLength
        Dim st As String = ""

        st = txtRapid2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtRapid2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtRapid2.Text += ii(ht)
                    Next
                    If txtRapid2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtRapid2.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002C6000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 C6 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gManSpeedRapidAxis2 = (y / 100)
                                    txtRapid2.Text = gManSpeedRapidAxis2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtRapid2.Text = gManSpeedRapidAxis2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtRapid2.Text = gManSpeedRapidAxis2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtRapid3_gotfocus(sender As Object, e As EventArgs) Handles txtRapid3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtRapid3
    End Sub
    Private Sub txtRapid3_TextChanged(sender As Object, e As EventArgs) Handles txtRapid3.TextChanged
        Dim arr As Integer = 0
        arr = txtRapid3.TextLength
        Dim st As String = ""

        st = txtRapid3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtRapid3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtRapid3.Text += ii(ht)
                    Next
                    If txtRapid3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtRapid3.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002D0000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 D0 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gManSpeedRapidAxis3 = (y / 100)
                                    txtRapid3.Text = gManSpeedRapidAxis3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtRapid3.Text = gManSpeedRapidAxis3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtRapid3.Text = gManSpeedRapidAxis3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtRapid4_gotfocus(sender As Object, e As EventArgs) Handles txtRapid4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtRapid4
    End Sub
    Private Sub txtRapid4_TextChanged(sender As Object, e As EventArgs) Handles txtRapid4.TextChanged
        Dim arr As Integer = 0
        arr = txtRapid4.TextLength
        Dim st As String = ""

        st = txtRapid4.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtRapid4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtRapid4.Text += ii(ht)
                    Next
                    If txtRapid4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtRapid4.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002DA000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 DA 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gManSpeedRapidAxis4 = (y / 100)
                                    txtRapid4.Text = gManSpeedRapidAxis4.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtRapid4.Text = gManSpeedRapidAxis4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtRapid4.Text = gManSpeedRapidAxis4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtRapid5_gotfocus(sender As Object, e As EventArgs) Handles txtRapid5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtRapid5
    End Sub
    Private Sub txtRapid5_TextChanged(sender As Object, e As EventArgs) Handles txtRapid5.TextChanged
        Dim arr As Integer = 0
        arr = txtRapid5.TextLength
        Dim st As String = ""

        st = txtRapid5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtRapid5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtRapid5.Text += ii(ht)
                    Next
                    If txtRapid5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtRapid5.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002E4000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 E4 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gManSpeedRapidAxis5 = (y / 100)
                                    txtRapid5.Text = gManSpeedRapidAxis5.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtRapid5.Text = gManSpeedRapidAxis5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtRapid5.Text = gManSpeedRapidAxis5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtSlow1_gotfocus(sender As Object, e As EventArgs) Handles txtSlow1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtSlow1
    End Sub
    Private Sub txtSlow1_TextChanged(sender As Object, e As EventArgs) Handles txtSlow1.TextChanged
        Dim arr As Integer = 0
        arr = txtSlow1.TextLength
        Dim st As String = ""

        st = txtSlow1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtSlow1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtSlow1.Text += ii(ht)
                    Next
                    If txtSlow1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtSlow1.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002BE000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 BE 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gManSpeedSlowAxis1 = (y / 100)
                                    txtSlow1.Text = gManSpeedSlowAxis1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtSlow1.Text = gManSpeedSlowAxis1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtSlow1.Text = gManSpeedSlowAxis1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtSlow2_gotfocus(sender As Object, e As EventArgs) Handles txtSlow2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtSlow2
    End Sub
    Private Sub txtSlow2_TextChanged(sender As Object, e As EventArgs) Handles txtSlow2.TextChanged
        Dim arr As Integer = 0
        arr = txtSlow2.TextLength
        Dim st As String = ""

        st = txtSlow2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtSlow2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtSlow2.Text += ii(ht)
                    Next
                    If txtSlow2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtSlow2.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002C8000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 C8 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gManSpeedSlowAxis2 = (y / 100)
                                    txtSlow2.Text = gManSpeedSlowAxis2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtSlow2.Text = gManSpeedSlowAxis2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtSlow2.Text = gManSpeedSlowAxis2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtSlow3_gotfocus(sender As Object, e As EventArgs) Handles txtSlow3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtSlow3
    End Sub
    Private Sub txtSlow3_TextChanged(sender As Object, e As EventArgs) Handles txtSlow3.TextChanged
        Dim arr As Integer = 0
        arr = txtSlow3.TextLength
        Dim st As String = ""

        st = txtSlow3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtSlow3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtSlow3.Text += ii(ht)
                    Next
                    If txtSlow3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtSlow3.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002D2000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 D2 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gManSpeedSlowAxis3 = (y / 100)
                                    txtSlow3.Text = gManSpeedSlowAxis3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtSlow3.Text = gManSpeedSlowAxis3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtSlow3.Text = gManSpeedSlowAxis3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtSlow4_gotfocus(sender As Object, e As EventArgs) Handles txtSlow4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtSlow4
    End Sub
    Private Sub txtSlow4_TextChanged(sender As Object, e As EventArgs) Handles txtSlow4.TextChanged
        Dim arr As Integer = 0
        arr = txtSlow4.TextLength
        Dim st As String = ""

        st = txtSlow4.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtSlow4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtSlow4.Text += ii(ht)
                    Next
                    If txtSlow4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtSlow4.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002DC000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 DC 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gManSpeedSlowAxis4 = (y / 100)
                                    txtSlow4.Text = gManSpeedSlowAxis4.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtSlow4.Text = gManSpeedSlowAxis4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtSlow4.Text = gManSpeedSlowAxis4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtSlow5_gotfocus(sender As Object, e As EventArgs) Handles txtSlow5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtSlow5
    End Sub
    Private Sub txtSlow5_TextChanged(sender As Object, e As EventArgs) Handles txtSlow5.TextChanged
        Dim arr As Integer = 0
        arr = txtSlow5.TextLength
        Dim st As String = ""

        st = txtSlow5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtSlow5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtSlow5.Text += ii(ht)
                    Next
                    If txtSlow5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtSlow5.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002E6000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 E6 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gManSpeedSlowAxis5 = (y / 100)
                                    txtSlow5.Text = gManSpeedSlowAxis5.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtSlow5.Text = gManSpeedSlowAxis5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtSlow5.Text = gManSpeedSlowAxis5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAutoSpeed1_gotfocus(sender As Object, e As EventArgs) Handles txtAutoSpeed1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAutoSpeed1
    End Sub
    Private Sub txtAutoSpeed1_TextChanged(sender As Object, e As EventArgs) Handles txtAutoSpeed1.TextChanged
        Dim arr As Integer = 0
        arr = txtAutoSpeed1.TextLength
        Dim st As String = ""

        st = txtAutoSpeed1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAutoSpeed1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAutoSpeed1.Text += ii(ht)
                    Next
                    If txtAutoSpeed1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAutoSpeed1.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002C0000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 C0 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gAutoSpeedAxis1 = (y / 100)
                                    txtAutoSpeed1.Text = gAutoSpeedAxis1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAutoSpeed1.Text = gAutoSpeedAxis1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAutoSpeed1.Text = gAutoSpeedAxis1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAutoSpeed2_gotfocus(sender As Object, e As EventArgs) Handles txtAutoSpeed2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAutoSpeed2
    End Sub
    Private Sub txtAutoSpeed2_TextChanged(sender As Object, e As EventArgs) Handles txtAutoSpeed2.TextChanged
        Dim arr As Integer = 0
        arr = txtAutoSpeed2.TextLength
        Dim st As String = ""

        st = txtAutoSpeed2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAutoSpeed2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAutoSpeed2.Text += ii(ht)
                    Next
                    If txtAutoSpeed2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAutoSpeed2.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002CA000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 CA 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gAutoSpeedAxis2 = (y / 100)
                                    txtAutoSpeed2.Text = gAutoSpeedAxis2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAutoSpeed2.Text = gAutoSpeedAxis2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAutoSpeed2.Text = gAutoSpeedAxis2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAutoSpeed3_gotfocus(sender As Object, e As EventArgs) Handles txtAutoSpeed3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAutoSpeed3
    End Sub
    Private Sub txtAutoSpeed3_TextChanged(sender As Object, e As EventArgs) Handles txtAutoSpeed3.TextChanged
        Dim arr As Integer = 0
        arr = txtAutoSpeed3.TextLength
        Dim st As String = ""

        st = txtAutoSpeed3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAutoSpeed3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAutoSpeed3.Text += ii(ht)
                    Next
                    If txtAutoSpeed3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAutoSpeed3.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002D4000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 D4 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gAutoSpeedAxis3 = (y / 100)
                                    txtAutoSpeed3.Text = gAutoSpeedAxis3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAutoSpeed3.Text = gAutoSpeedAxis3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAutoSpeed3.Text = gAutoSpeedAxis3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAutoSpeed4_gotfocus(sender As Object, e As EventArgs) Handles txtAutoSpeed4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAutoSpeed4
    End Sub
    Private Sub txtAutoSpeed4_TextChanged(sender As Object, e As EventArgs) Handles txtAutoSpeed4.TextChanged
        Dim arr As Integer = 0
        arr = txtAutoSpeed4.TextLength
        Dim st As String = ""

        st = txtAutoSpeed4.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAutoSpeed4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAutoSpeed4.Text += ii(ht)
                    Next
                    If txtAutoSpeed4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAutoSpeed4.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002DE000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 DE 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gAutoSpeedAxis4 = (y / 100)
                                    txtAutoSpeed4.Text = gAutoSpeedAxis4.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAutoSpeed4.Text = gAutoSpeedAxis4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAutoSpeed4.Text = gAutoSpeedAxis4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAutoSpeed5_gotfocus(sender As Object, e As EventArgs) Handles txtAutoSpeed5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAutoSpeed5
    End Sub
    Private Sub txtAutoSpeed5_TextChanged(sender As Object, e As EventArgs) Handles txtAutoSpeed5.TextChanged
        Dim arr As Integer = 0
        arr = txtAutoSpeed5.TextLength
        Dim st As String = ""

        st = txtAutoSpeed5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAutoSpeed5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAutoSpeed5.Text += ii(ht)
                    Next
                    If txtAutoSpeed5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAutoSpeed5.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021002E8000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 E8 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gAutoSpeedAxis5 = (y / 100)
                                    txtAutoSpeed5.Text = gAutoSpeedAxis5.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAutoSpeed5.Text = gAutoSpeedAxis5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAutoSpeed5.Text = gAutoSpeedAxis5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtWFDelay1_gotfocus(sender As Object, e As EventArgs) Handles txtWFDelay1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtWFDelay1
    End Sub
    Private Sub txtWFDelay1_TextChanged(sender As Object, e As EventArgs) Handles txtWFDelay1.TextChanged
        Dim arr As Integer = 0
        arr = txtWFDelay1.TextLength
        Dim st As String = ""

        st = txtWFDelay1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtWFDelay1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtWFDelay1.Text += ii(ht)
                    Next
                    If txtWFDelay1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtWFDelay1.Text * 10
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021001E6000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E6 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetWFStartDelay1 = (y / 10)
                                    txtWFDelay1.Text = gSetWFStartDelay1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtWFDelay1.Text = gSetWFStartDelay1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtWFDelay1.Text = gSetWFStartDelay1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtWireRet1_gotfocus(sender As Object, e As EventArgs) Handles txtWireRet1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtWireRet1
    End Sub
    Private Sub txtWireRet1_TextChanged(sender As Object, e As EventArgs) Handles txtWireRet1.TextChanged
        Dim arr As Integer = 0
        arr = txtWireRet1.TextLength
        Dim st As String = ""

        st = txtWireRet1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtWireRet1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtWireRet1.Text += ii(ht)
                    Next
                    If txtWireRet1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtWireRet1.Text * 10
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021001E8000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E8 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetWFRetractDistance1 = (y / 10)
                                    txtWireRet1.Text = gSetWFRetractDistance1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtWireRet1.Text = gSetWFRetractDistance1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtWireRet1.Text = gSetWFRetractDistance1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtWFDelay2_gotfocus(sender As Object, e As EventArgs) Handles txtWFDelay2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtWFDelay2
    End Sub
    Private Sub txtWFDelay2_TextChanged(sender As Object, e As EventArgs) Handles txtWFDelay2.TextChanged
        Dim arr As Integer = 0
        arr = txtWFDelay2.TextLength
        Dim st As String = ""

        st = txtWFDelay2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtWFDelay2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtWFDelay2.Text += ii(ht)
                    Next
                    If txtWFDelay2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtWFDelay2.Text * 10
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021001F0000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 F0 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetWFStartDelay2 = (y / 10)
                                    txtWFDelay2.Text = gSetWFStartDelay2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtWFDelay2.Text = gSetWFStartDelay2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtWFDelay2.Text = gSetWFStartDelay2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtWireRet2_gotfocus(sender As Object, e As EventArgs) Handles txtWireRet2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtWireRet2
    End Sub
    Private Sub txtWireRet2_TextChanged(sender As Object, e As EventArgs) Handles txtWireRet2.TextChanged
        Dim arr As Integer = 0
        arr = txtWireRet2.TextLength
        Dim st As String = ""

        st = txtWireRet2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtWireRet2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtWireRet2.Text += ii(ht)
                    Next
                    If txtWireRet2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtWireRet2.Text * 10
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B021001F2000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 F2 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetWFRetractDistance2 = (y / 10)
                                    txtWireRet2.Text = gSetWFRetractDistance2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtWireRet2.Text = gSetWFRetractDistance2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtWireRet2.Text = gSetWFRetractDistance2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAvcBand1_gotfocus(sender As Object, e As EventArgs) Handles txtAvcBand1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAvcBand1
    End Sub
    Private Sub txtAvcBand1_TextChanged(sender As Object, e As EventArgs) Handles txtAvcBand1.TextChanged
        Dim arr As Integer = 0
        arr = txtAvcBand1.TextLength
        Dim st As String = ""

        st = txtAvcBand1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAvcBand1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAvcBand1.Text += ii(ht)
                    Next
                    If txtAvcBand1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAvcBand1.Text * 10
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B0210035C000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 5C 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gAvcband1 = (y / 10)
                                    txtAvcBand1.Text = gAvcband1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtAvcBand1.Text = gAvcband1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtAvcBand1.Text = gAvcband1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtAvcSpeed1_GotFocus(sender As Object, e As EventArgs) Handles txtAvcSpeed1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAvcSpeed1
    End Sub
    Private Sub txtAvcSpeed1_TextChanged(sender As Object, e As EventArgs) Handles txtAvcSpeed1.TextChanged
        Dim arr As Integer = 0
        arr = txtAvcSpeed1.TextLength
        Dim st As String = ""

        st = txtAvcSpeed1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAvcSpeed1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAvcSpeed1.Text += ii(ht)
                    Next
                    If txtAvcSpeed1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAvcSpeed1.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B0210035E000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 5E 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gAvcspeed1 = (y / 100)
                                    txtAvcSpeed1.Text = gAvcspeed1.ToString()
                                End If

                            End If
                        Else
                            txtAvcSpeed1.Text = gAvcspeed1.ToString()
                            Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                                Case MsgBoxResult.Ok
                            End Select
                        End If
                    Else
                        txtAvcSpeed1.Text = gAvcspeed1.ToString()
                        Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If

                End If
            End If
        End If
    End Sub
    Private Sub txtAvcBand2_GotFocus(sender As Object, e As EventArgs) Handles txtAvcBand2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAvcBand2
    End Sub
    Private Sub txtAvcBand2_TextChanged(sender As Object, e As EventArgs) Handles txtAvcBand2.TextChanged
        Dim arr As Integer = 0
        arr = txtAvcBand2.TextLength
        Dim st As String = ""

        st = txtAvcBand2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAvcBand2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAvcBand2.Text += ii(ht)
                    Next
                    If txtAvcBand2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAvcBand2.Text * 10
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B02100366000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 66 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gAvcband2 = (y / 10)
                                    txtAvcBand2.Text = gAvcband2.ToString()
                                End If

                            End If
                        Else
                            txtAvcBand2.Text = gAvcband2.ToString()
                            Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                                Case MsgBoxResult.Ok
                            End Select
                        End If
                    Else
                        txtAvcBand2.Text = gAvcband2.ToString()
                        Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If

                End If
            End If
        End If
    End Sub
    Private Sub txtAvcSpeed2_GotFocus(sender As Object, e As EventArgs) Handles txtAvcSpeed2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtAvcSpeed2
    End Sub
    Private Sub txtAvcSpeed2_TextChanged(sender As Object, e As EventArgs) Handles txtAvcSpeed2.TextChanged
        Dim arr As Integer = 0
        arr = txtAvcSpeed2.TextLength
        Dim st As String = ""

        st = txtAvcSpeed2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtAvcSpeed2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtAvcSpeed2.Text += ii(ht)
                    Next
                    If txtAvcSpeed2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtAvcSpeed2.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B02100368000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 68 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gAvcspeed2 = (y / 100)
                                    txtAvcSpeed2.Text = gAvcspeed2.ToString()
                                End If

                            End If
                        Else
                            txtAvcSpeed2.Text = gAvcspeed2.ToString()
                            Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                                Case MsgBoxResult.Ok
                            End Select
                        End If
                    Else
                        txtAvcSpeed2.Text = gAvcspeed2.ToString()
                        Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If

                End If
            End If
        End If
    End Sub
    Private Sub txtDelay1_GotFocus(sender As Object, e As EventArgs) Handles txtDelay1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtDelay1
    End Sub
    Private Sub txtDelay1_TextChanged(sender As Object, e As EventArgs) Handles txtDelay1.TextChanged
        Dim arr As Integer = 0
        arr = txtDelay1.TextLength
        Dim st As String = ""

        st = txtDelay1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtDelay1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtDelay1.Text += ii(ht)
                    Next
                    If txtDelay1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtDelay1.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B02100384000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 84 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gDelay1 = (y / 100)
                                    txtDelay1.Text = gDelay1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtDelay1.Text = gDelay1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtDelay1.Text = gDelay1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtDelay2_GotFocus(sender As Object, e As EventArgs) Handles txtDelay2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtDelay2
    End Sub
    Private Sub txtDelay2_TextChanged(sender As Object, e As EventArgs) Handles txtDelay2.TextChanged
        Dim arr As Integer = 0
        arr = txtDelay2.TextLength
        Dim st As String = ""

        st = txtDelay2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtDelay2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtDelay2.Text += ii(ht)
                    Next
                    If txtDelay2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtDelay2.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B02100386000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 86 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gDelay2 = (y / 100)
                                    txtDelay2.Text = gDelay2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtDelay2.Text = gDelay2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtDelay2.Text = gDelay2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtDelay3_GotFocus(sender As Object, e As EventArgs) Handles txtDelay3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtDelay3
    End Sub
    Private Sub txtDelay3_TextChanged(sender As Object, e As EventArgs) Handles txtDelay3.TextChanged
        Dim arr As Integer = 0
        arr = txtDelay3.TextLength
        Dim st As String = ""

        st = txtDelay3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtDelay3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtDelay3.Text += ii(ht)
                    Next
                    If txtDelay3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtDelay3.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B02100388000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 88 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gDelay3 = (y / 100)
                                    txtDelay3.Text = gDelay3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtDelay3.Text = gDelay3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtDelay3.Text = gDelay3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtDelay4_GotFocus(sender As Object, e As EventArgs) Handles txtDelay4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtDelay4
    End Sub
    Private Sub txtDelay4_TextChanged(sender As Object, e As EventArgs) Handles txtDelay4.TextChanged
        Dim arr As Integer = 0
        arr = txtDelay4.TextLength
        Dim st As String = ""

        st = txtDelay4.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtDelay4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtDelay4.Text += ii(ht)
                    Next
                    If txtDelay4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtDelay4.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B0210038A000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 8A 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gDelay4 = (y / 100)
                                    txtDelay4.Text = gDelay4.ToString()
                                End If
                            End If


                        End If
                    Else
                        txtDelay4.Text = gDelay4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtDelay4.Text = gDelay4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtDelay5_GotFocus(sender As Object, e As EventArgs) Handles txtDelay5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtDelay5
    End Sub
    Private Sub txtDelay5_TextChanged(sender As Object, e As EventArgs) Handles txtDelay5.TextChanged
        Dim arr As Integer = 0
        arr = txtDelay5.TextLength
        Dim st As String = ""

        st = txtDelay5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtDelay5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtDelay5.Text += ii(ht)
                    Next
                    If txtDelay5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtDelay5.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B0210038C000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 8C 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gDelay5 = (y / 100)
                                    txtDelay5.Text = gDelay5.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtDelay5.Text = gDelay5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtDelay5.Text = gDelay5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtDelay6_GotFocus(sender As Object, e As EventArgs) Handles txtDelay6.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtDelay6
    End Sub
    Private Sub txtDelay6_TextChanged(sender As Object, e As EventArgs) Handles txtDelay6.TextChanged
        Dim arr As Integer = 0
        arr = txtDelay6.TextLength
        Dim st As String = ""

        st = txtDelay6.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtDelay6.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtDelay6.Text += ii(ht)
                    Next
                    If txtDelay6.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtDelay6.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B0210038E0204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 8E 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gDelay6 = (y / 100)
                                    txtDelay6.Text = gDelay6.ToString()
                                End If
                            End If


                        End If
                    Else
                        txtDelay6.Text = gDelay6.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtDelay6.Text = gDelay6.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtDelay7_GotFocus(sender As Object, e As EventArgs) Handles txtDelay7.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtDelay7
    End Sub
    Private Sub txtDelay7_TextChanged(sender As Object, e As EventArgs) Handles txtDelay7.TextChanged
        Dim arr As Integer = 0
        arr = txtDelay7.TextLength
        Dim st As String = ""

        st = txtDelay7.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtDelay7.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtDelay7.Text += ii(ht)
                    Next
                    If txtDelay7.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtDelay7.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B02100390000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 90 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gDelay7 = (y / 100)
                                    txtDelay7.Text = gDelay7.ToString()
                                End If
                            End If


                        End If
                    Else
                        txtDelay7.Text = gDelay7.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtDelay7.Text = gDelay7.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtDelay8_GotFocus(sender As Object, e As EventArgs) Handles txtDelay8.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtDelay8
    End Sub
    Private Sub txtDelay8_TextChanged(sender As Object, e As EventArgs) Handles txtDelay8.TextChanged
        Dim arr As Integer = 0
        arr = txtDelay8.TextLength
        Dim st As String = ""

        st = txtDelay8.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtDelay8.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtDelay8.Text += ii(ht)
                    Next
                    If txtDelay8.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtDelay8.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B02100392000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 92 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gDelay8 = (y / 100)
                                    txtDelay8.Text = gDelay8.ToString()
                                End If
                            End If


                        End If
                    Else
                        txtDelay8.Text = gDelay8.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtDelay8.Text = gDelay8.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtDelay9_GotFocus(sender As Object, e As EventArgs) Handles txtDelay9.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtDelay9
    End Sub
    Private Sub txtDelay9_TextChanged(sender As Object, e As EventArgs) Handles txtDelay9.TextChanged
        Dim arr As Integer = 0
        arr = txtDelay9.TextLength
        Dim st As String = ""

        st = txtDelay9.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtDelay9.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtDelay9.Text += ii(ht)
                    Next
                    If txtDelay9.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtDelay9.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B02100394000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 94 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gDelay9 = (y / 100)
                                    txtDelay9.Text = gDelay9.ToString()
                                End If
                            End If


                        End If
                    Else
                        txtDelay9.Text = gDelay9.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtDelay9.Text = gDelay9.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtDelay10_GotFocus(sender As Object, e As EventArgs) Handles txtDelay10.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtDelay10
    End Sub
    Private Sub txtDelay10_TextChanged(sender As Object, e As EventArgs) Handles txtDelay10.TextChanged
        Dim arr As Integer = 0
        arr = txtDelay10.TextLength
        Dim st As String = ""

        st = txtDelay10.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtDelay10.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtDelay10.Text += ii(ht)
                    Next
                    If txtDelay10.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtDelay10.Text * 100
                            Dim t02 As String = dec2Hex1(t01)
                            Dim h1 As String = "00000000000B02100396000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 03 96 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gDelay10 = (y / 100)
                                    txtDelay10.Text = gDelay10.ToString()
                                End If
                            End If

                        End If
                        Else
                        txtDelay10.Text = gDelay10.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtDelay10.Text = gDelay10.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Analogread2()
        Timer1.Enabled = False
    End Sub


End Class