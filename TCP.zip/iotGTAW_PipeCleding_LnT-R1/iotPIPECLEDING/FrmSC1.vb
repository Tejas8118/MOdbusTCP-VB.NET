﻿'----------------------------------
' iotPIPECLEDING for L&T
' by  trapasia DigiReach @ 2017
' Main Screen One Form
'----------------------------------
Imports System.Data
Imports System.Data.OleDb
Imports System.Threading
Imports System.Net.HttpWebRequest
Imports System.Net
Imports System.Text
Imports System.Net.WebRequestMethods
Imports System.IO
Imports System.Configuration

Public Class FrmSC1

    Dim cur As Windows.Forms.TextBox
    Dim cscMode As String = "man"
    Dim csconoff As String = "off"
    Dim cscautofwd As Integer = 1
    Dim cscautorev As Integer = 1
    Dim tx As String = ""
    Dim rx As String = ""
    'Dim objThread1 As CallBackThread
    Dim SPEED As Double
    Dim SPEEDYASKA As Integer 'for yaskava'

    Dim plcinstrg As String = ""

    Dim digits1() As Integer
    Dim digits2() As Integer
    Dim digits3() As Integer
    Dim digits4() As Integer
    Dim digits5() As Integer
    Dim digits6() As Integer
    Dim digits7() As Integer
    Dim digits8() As Integer
    Dim digits9() As Integer
    Dim digits10() As Integer
    Dim errno As Integer = 0


    Dim dr As OleDbDataReader
    Dim wcmax1, wvmax1, gfmax1, wfmax1, jtmax1 As String

    'Dim paraArray() As String = getRatio("P2AI1")   'VERTICALOL Voltage
    'Dim paraArray1() As String = getRatio("P2AI2")  'VERTICALOL Current
    'Dim paraArray2() As String = getRatio("P2AI3")  'SMAW Current
    'Dim paraArray3() As String = getRatio("P2AI4")  'SMAW Current

    'Dim paraArray4() As String = getRatio("P3AI1")  'Flux Temp
    'Dim paraArray5() As String = getRatio("P3AI2")  'Flux Weight
    'Dim paraArray6() As String = getRatio("P3AI4")  'Depth
    'Dim paraArray7() As String = getRatio("P3AI5")  'Job Temp
    'Dim paraArray8() As String = getRatio("MCLEFT")  'MCLEFT
    'Dim paraArray9() As String = getRatio("MCRIGHT")  'MCRIGHT

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private Sub FrmSC1_Activated(sender As Object, e As System.EventArgs) Handles Me.Activated
        setControl()
    End Sub

    Private Sub FrmSC1_GotFocus(sender As Object, e As System.EventArgs) Handles Me.GotFocus
        setControl()
    End Sub
    Private Sub setControl()
        txtwname.Text = gwelder_nm
        txtpsno.Text = gpsno
        txtPass.Text = gPass
        txtlayer.Text = glayer


        If gLogin = True Then
            btnpassup.Enabled = True
            btnpassdn.Enabled = True
            btnpassok.Enabled = True
            btnlayerup.Enabled = True
            btnlayerdn.Enabled = True
            btnlayerok.Enabled = True
            btnpassup.BackgroundImage = Global.iotPIPECLEDING.My.Resources.upE
            btnpassdn.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dnE
            btnpassok.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
            btnlayerup.BackgroundImage = Global.iotPIPECLEDING.My.Resources.upE
            btnlayerdn.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dnE
            btnlayerok.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
            btnLogin.Enabled = False
            btnLogin.BackColor = System.Drawing.Color.Gray
            btnLogout.Enabled = True
            btnLogout.BackColor = System.Drawing.Color.SkyBlue
        End If

    End Sub
    Private Sub FrmSC1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Try

            Me.WindowState = FormWindowState.Maximized
            frmjobdata.Hide()
            frmcontrols.Hide()
            frmAux.Hide()

            Dim cmbbb As New Dictionary(Of String, String)()
            cmbbb.Add("1", "1")
            cmbbb.Add("2", "2")
            cmbbb.Add("3", "3")
            cmbbb.Add("4", "4")
            cmbbb.Add("5", "5")
            cmbbb.Add("6", "6")
            cmbbb.Add("7", "7")

            setControl()
            getPara()

            gWeldingStart = False
            gLocalDataSync = False

            Togdataread()
            Lblread()

            Using objCon As New dbClass
                Using dt As DataTable = objCon.ExecuteDataTable("select * from device", CommandType.Text)
                    For Each row As DataRow In dt.Rows
                        txtStationNumber.Text = row("station") & " / " & row("shop")
                    Next
                End Using

                'Showing Actual IP address of Local Machine
                Dim GetIPv4Address As String = String.Empty
                Dim strHostName As String = System.Net.Dns.GetHostName()
                Dim iphe As System.Net.IPHostEntry = System.Net.Dns.GetHostEntry(strHostName)

                For Each ipheal As System.Net.IPAddress In iphe.AddressList
                    If ipheal.AddressFamily = System.Net.Sockets.AddressFamily.InterNetwork Then
                        GetIPv4Address = ipheal.ToString()
                    End If
                Next

                txtIP.Text = GetIPv4Address.Trim & " / " & Dns.GetHostName()
                lblLastBuildDate.Text = "16-09-2019 [R1]"
                lblLocalDataCount.Text = LocalDataCount().ToString()
            End Using
        Catch ex As Exception
            MessageBox.Show("Error from FrmSC1_Load() method, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Public Sub Togdataread()

        Try
            errno = 0
            If isConnection = True Then
                '' HEAD A  READ FUNCTION
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 00 D5 00 05", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(6) = "02" And x1(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x1(10) & x1(9)))
                        digits1 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 1
                        '' Check Condition
                        If digits1(0) = 1 Then
                            objSC1.btnWIREFEEDA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.wirefeedon
                            objSC1.btnWIREFEEDA.Tag = 1
                        Else
                            objSC1.btnWIREFEEDA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.wirefeedoff
                            objSC1.btnWIREFEEDA.Tag = 0
                        End If

                        If digits1(1) = 1 Then
                            btnHOTWIREA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hotwireon
                            btnHOTWIREA.Tag = 1
                        Else
                            btnHOTWIREA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hotwireoff
                            btnHOTWIREA.Tag = 0
                        End If

                        If digits1(2) = 1 Then
                            btnAVCA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.avcon
                            btnAVCA.Tag = 1
                        Else
                            btnAVCA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.avcoff
                            btnAVCA.Tag = 0
                        End If

                        If digits1(3) = 1 Then
                            btnWELDA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldon
                            btnWELDA.Tag = 1
                        Else
                            btnWELDA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldoff
                            btnWELDA.Tag = 0
                        End If

                        If digits1(4) = 1 Then
                            btnWELDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldon
                            btnWELDB.Tag = 1
                        Else
                            btnWELDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldoff
                            btnWELDB.Tag = 0
                        End If

                    End If
                End If

                'HEAD B READ FUNCTION

                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 00 DF 00 03", 50)
                Dim x2() As String = plcinstrg.Split(" "c)
                If x2.Count >= 8 Then
                    If x2(6) = "02" And x2(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x2(10) & x2(9)))
                        digits2 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 2
                        ''''  Check Condition   /////////////  
                        If digits2(0) = 1 Then
                            btnWIREFEEDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.wirefeedon
                            btnWIREFEEDB.Tag = 1
                        Else
                            btnWIREFEEDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.wirefeedoff
                            btnWIREFEEDB.Tag = 0
                        End If

                        If digits2(1) = 1 Then
                            btnHOTWIREB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hotwireon
                            btnHOTWIREB.Tag = 1
                        Else
                            btnHOTWIREB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hotwireoff
                            btnHOTWIREB.Tag = 0
                        End If

                        If digits2(2) = 1 Then
                            btnAVCB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.avcon
                            btnAVCB.Tag = 1
                        Else
                            btnAVCB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.avcoff
                            btnAVCB.Tag = 0
                        End If
                    End If
                End If

                '//////////////  Read Resume ON/Off ////////////////
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 00 8C 00 01", 50)
                Dim x5() As String = plcinstrg.Split(" "c)
                If x5.Count >= 8 Then
                    If x5(0) = "02" And x5(1) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x5(10) & x5(9)))
                        digits9 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 3
                        '///////////////// check condition  //////////////////////
                        If digits9(0) = 1 Then
                            btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resumeg
                        Else
                            btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resumeb
                        End If

                    End If
                End If


                '////////////    Auto manual read //////////////
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 00 0A 00 01", 50)
                Dim x3() As String = plcinstrg.Split(" "c)
                If x3.Count >= 8 Then
                    If x3(6) = "02" And x3(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x3(10) & x3(9)))
                        digits3 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 4
                        ''''''''' check condition
                        If digits3(0) = 1 Then
                            btnauto.BackgroundImage = Global.iotPIPECLEDING.My.Resources._on
                            btnauto.Tag = 1
                        Else
                            btnauto.BackgroundImage = Global.iotPIPECLEDING.My.Resources.off
                            btnauto.Tag = 0
                        End If

                    End If
                End If

                ''/////     Dry run read
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 02 26 00 03", 50)
                Dim x4() As String = plcinstrg.Split(" "c)
                If x4.Count >= 8 Then
                    If x4(6) = "02" And x4(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x4(10) & x4(9)))
                        digits4 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 5
                        ''''''''' check condition
                        If digits4(0) = 1 Then
                            btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldrun
                            btndryweldrun.Tag = 1
                        Else
                            btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dryrun
                            btndryweldrun.Tag = 0
                        End If

                        ''''''''' check condition
                        If digits4(1) = 1 Then
                            btntag1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag1G
                            btntag1.Tag = 1
                            btntag2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag2grey
                            btntag2.Enabled = False

                        Else
                            btntag1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag1
                            btntag1.Tag = 0
                            btntag2.Enabled = True
                            btntag2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag2

                        End If

                        ''''''''' check condition
                        If digits4(2) = 1 Then
                            btntag2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag2G
                            btntag2.Tag = 1
                            btntag1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag1grey
                            btntag1.Enabled = False
                        Else
                            btntag2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag2
                            btntag2.Tag = 0
                            btntag1.Enabled = True
                            btntag1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag1

                        End If


                    End If
                End If


            End If
        Catch ex As Exception
            Dim result1 As String = MessageBoxEx.Show("Error in FrmSc1 Toogle read Method : " + ex.Message.ToString() + errno.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString

            ' MessageBox.Show("Error in FrmSc1 Toogle read Method : " + ex.Message.ToString() + errno.ToString())
        End Try
    End Sub

    Public Sub Lblread()
        Try
            errno = 0
            If isConnection = True Then

                ''  step read
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 01 FE 00 01", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(6) = "02" And x1(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x1(10) & x1(9)))
                        digits5 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 1
                        ''''''''' check condition
                        If digits5(0) = 1 Then
                            lblStep.Image = Global.iotPIPECLEDING.My.Resources.stepG
                        Else
                            frmjobdata.btnStepONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stepoff
                            lblStep.Image = Global.iotPIPECLEDING.My.Resources.step1
                        End If

                    End If
                End If

                ''/  spiral read
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 02 08 00 01", 50)
                Dim x2() As String = plcinstrg.Split(" "c)
                If x2.Count >= 8 Then
                    If x2(6) = "02" And x2(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x2(10) & x2(9)))
                        digits6 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 2
                        ''''''''' check condition
                        If digits6(0) = 1 Then
                            lblSpiral.Image = Global.iotPIPECLEDING.My.Resources.spiral

                        Else
                            lblSpiral.Image = Global.iotPIPECLEDING.My.Resources.spiral1
                        End If

                    End If
                End If


                '////////////////   Label Nozzle / Flange /Backface read //////////////////
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 01 90 00 03", 50)
                Dim x4() As String = plcinstrg.Split(" "c)
                If x4.Count >= 8 Then
                    If x4(6) = "02" And x4(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x4(10) & x4(9)))
                        digits8 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 4
                        ''''''''' check condition
                        If digits8(0) = 1 Then
                            lblNozzle.Image = Global.iotPIPECLEDING.My.Resources.nozzle
                        Else
                            lblNozzle.Image = Global.iotPIPECLEDING.My.Resources.nozzle1
                        End If

                        'If digits8(1) = 1 Then
                        '    lblFlange.Image = Global.iotPIPECLEDING.My.Resources.flange
                        'Else
                        '    lblFlange.Image = Global.iotPIPECLEDING.My.Resources.flange1
                        'End If

                        'If digits8(2) = 1 Then
                        '    lblBackface.Image = Global.iotPIPECLEDING.My.Resources.backface
                        'Else
                        '    lblBackface.Image = Global.iotPIPECLEDING.My.Resources.backface1
                        'End If

                    End If
                End If


            End If

        Catch ex As Exception
            Dim result1 As String = MessageBoxEx.Show("Error in FrmSc1 Label read Method : " + ex.Message.ToString() + errno.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString

            ' MessageBox.Show("Error in FrmSc1 Label read Method : " + ex.Message.ToString() + errno.ToString())
        End Try

    End Sub


    Private Sub FrmSC1_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Me.Text = ""
        Me.WindowState = FormWindowState.Maximized
        Me.Dock = DockStyle.Fill
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        Me.ControlBox = False
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.ShowIcon = False
        Me.Icon = Nothing

    End Sub


    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        gPROCESS = "GTAW"
        Dim OBJ As New frmLogin
        OBJ.MdiParent = MDIParent1
        OBJ.Show()

        gMachine = "GTAW"

    End Sub


    Private curst As String

    Public Property Currstring() As String

        Get
            Return curst
        End Get
        Set(ByVal Value As String)
            curst = Value
        End Set
    End Property


    Public Sub btnClose_lostfocus(sender As System.Object, e As System.EventArgs) Handles lblRSPEED.LostFocus
        'MessageBox.Show("hello")
        'Wrkb1.CurrTextBox = lblRSPEED
        'Wrkb1.CurrTextBox = TextBox1
    End Sub

    Private Sub BtnWELDA_Click(sender As Object, e As EventArgs) Handles btnWELDA.Click
        If gLogin = False Then
            Dim result1 As String = MessageBoxEx.Show("Please Login...", "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
        ElseIf gLocalDataSync = True Then
            Dim result1 As String = MessageBoxEx.Show("Local data sync is in progress, Please try after sometime.", "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
        Else
            If e Is EventArgs.Empty Then
            Else
                If btnWELDA.Tag = 0 Then
                    'Weld ON Start
                    If isConnection = True Then
                        tx = ""
                        rx = ""
                        tx = "00 00 00 00 00 06 02 05 00 D8 FF 00"
                        rx = TCPComA(tx, 10)
                        'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                        'End If
                        btnWELDA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldon
                        btnWELDA.Tag = 1
                        'Else
                        'Weld ON Stop 
                        If isConnection = True Then
                            tx = ""
                            rx = ""
                            tx = "00 00 00 00 00 06 02 05 00 D8 00 00"
                            rx = TCPComA(tx, 10)
                            'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                        End If
                        btnWELDA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldoff
                        btnWELDA.Tag = 0
                    End If
                End If
            End If
        End If
    End Sub

    'Private Sub BtnWELDB_Click(sender As Object, e As EventArgs) Handles btnWELDB.Click
    '    If e Is EventArgs.Empty Then
    '    Else
    '        If btnWELDB.Tag = 0 Then

    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""
    '                tx = "00 00 00 00 00 06 02 05 00 E2 FF 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 4 Then

    '            End If
    '            btnWELDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldon
    '            btnWELDB.Tag = 1
    '        Else

    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""
    '                tx = "00 00 00 00 00 06 02 05 00 E2 00 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 4 Then
    '                btnWELDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldoff
    '                btnWELDB.Tag = 0

    '            End If
    '        End If

    '    End If
    'End Sub

    Private Sub BtnWIREFEEDA_Click(sender As Object, e As EventArgs) Handles btnWIREFEEDA.Click
        Try


            'Tcp Programm
            If networkStream.CanWrite And networkStream.CanRead Then
                ' Do a simple write.
                tx = "00 00 00 00 00 06 01 03 00 00 00 02"
                rx = TCPComA(tx, 10)

                '' MsgBox(BigEndianHexToSingle("436A3333").ToString())

            Else

            End If
            '' MessageBox.Show("data= " + data.ToString())

            Thread.Sleep(300)

        Catch ex As Exception
            Dim result1 As String = MessageBoxEx.Show("Data Not Write : " + ex.Message.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString

        End Try
        If e Is EventArgs.Empty Then
        Else
            If btnWIREFEEDA.Tag = 0 Then
                btnWIREFEEDA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.wirefeedon
                btnWIREFEEDA.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 D5 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            Else
                btnWIREFEEDA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.wirefeedoff
                btnWIREFEEDA.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 D5 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
                If rx.Count > 4 Then

                End If
            End If

        End If
    End Sub

    Private Sub BtnHOTWIREA_Click(sender As Object, e As EventArgs) Handles btnHOTWIREA.Click
        If e Is EventArgs.Empty Then
        Else
            If btnHOTWIREA.Tag = 0 Then

                If isConnection = True Then
                    btnHOTWIREA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hotwireon
                    btnHOTWIREA.Tag = 1
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 D6 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            Else

                If isConnection = True Then
                    btnHOTWIREA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hotwireoff
                    btnHOTWIREA.Tag = 0
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 D6 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            End If

        End If
    End Sub

    'Private Sub btnWIREFEEDB_Click(sender As Object, e As EventArgs) Handles btnWIREFEEDB.Click
    '    If e Is EventArgs.Empty Then
    '    Else
    '        If btnWIREFEEDB.Tag = 0 Then
    '            btnWIREFEEDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.wirefeedon
    '            btnWIREFEEDB.Tag = 1
    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""
    '                tx = "00 00 00 00 00 06 02 05 00 DF FF 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 4 Then

    '            End If
    '        Else
    '            btnWIREFEEDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.wirefeedoff
    '            btnWIREFEEDB.Tag = 0
    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""
    '                tx = "00 00 00 00 00 06 02 05 00 DF 00 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 4 Then

    '            End If
    '        End If

    '    End If
    'End Sub

    'Private Sub btnHOTWIREB_Click(sender As Object, e As EventArgs) Handles btnHOTWIREB.Click
    '    If e Is EventArgs.Empty Then
    '    Else
    '        If btnHOTWIREB.Tag = 0 Then
    '            btnHOTWIREB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hotwireon
    '            btnHOTWIREB.Tag = 1
    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""
    '                tx = "00 00 00 00 00 06 02 05 00 E0 FF 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 4 Then

    '            End If
    '        Else
    '            btnHOTWIREB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hotwireoff
    '            btnHOTWIREB.Tag = 0
    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""
    '                tx = "00 00 00 00 00 06 02 05 00 E0 00 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 4 Then

    '            End If
    '        End If

    '    End If
    'End Sub

    Private Sub btnAVCA_Click(sender As Object, e As EventArgs) Handles btnAVCA.Click
        If e Is EventArgs.Empty Then
        Else
            If btnAVCA.Tag = 0 Then

                If isConnection = True Then
                    btnAVCA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.avcon
                    btnAVCA.Tag = 1
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 D7 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            Else

                If isConnection = True Then
                    btnAVCA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.avcoff
                    btnAVCA.Tag = 0
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 D7 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            End If

        End If
    End Sub

    'Private Sub btnAVCB_Click(sender As Object, e As EventArgs) Handles btnAVCB.Click
    '    If e Is EventArgs.Empty Then
    '    Else
    '        If btnAVCB.Tag = 0 Then
    '            btnAVCB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.avcon
    '            btnAVCB.Tag = 1
    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""
    '                tx = "00 00 00 00 00 06 02 05 00 E1 FF 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 4 Then

    '            End If
    '        Else
    '            btnAVCB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.avcoff
    '            btnAVCB.Tag = 0
    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""
    '                tx = "00 00 00 00 00 06 02 05 00 E1 00 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 4 Then

    '            End If
    '        End If

    '    End If
    'End Sub

    Private Sub btnauto_Click(sender As Object, e As EventArgs) Handles btnauto.Click
        If e Is EventArgs.Empty Then
        Else
            If btnauto.Tag = 0 Then
                btnauto.BackgroundImage = Global.iotPIPECLEDING.My.Resources._on
                btnauto.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 03 05 00 0A FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            Else
                btnauto.BackgroundImage = Global.iotPIPECLEDING.My.Resources.off
                btnauto.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 03 05 00 0A 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            End If

        End If
    End Sub

    Private Sub btntag1_Click(sender As Object, e As EventArgs) Handles btntag1.Click
        If e Is EventArgs.Empty Then
        Else
            If btntag1.Tag = 0 Then
                btntag1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag1G
                btntag1.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 02 27 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                    btntag2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag2grey
                    btntag2.Enabled = False
                End If

                Threading.Thread.Sleep(300)
                ''/////     Dry run read

                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 02 26 00 01", 50)
                Dim x4() As String = plcinstrg.Split(" "c)
                If x4.Count >= 8 Then
                    If x4(0) = "02" And x4(1) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x4(4) & x4(3)))
                        digits4 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 5
                        ''''''''' check condition
                        If digits4(0) = 1 Then
                            btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldrun
                            btndryweldrun.Tag = 1
                        Else
                            btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dryrun
                            btndryweldrun.Tag = 0
                        End If

                    End If
                End If

            Else
                btntag1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag1
                btntag1.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 02 27 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)

                    btntag2.Enabled = True
                    btntag2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag2

                End If

                Threading.Thread.Sleep(500)
                ''/////     Dry run read

                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 02 26 00 01", 50)
                Dim x4() As String = plcinstrg.Split(" "c)
                If x4.Count >= 8 Then
                    If x4(6) = "02" And x4(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x4(10) & x4(9)))
                        digits4 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 5
                        ''''''''' check condition
                        If digits4(0) = 1 Then
                            btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldrun
                            btndryweldrun.Tag = 1
                        Else
                            btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dryrun
                            btndryweldrun.Tag = 0
                        End If

                    End If
                End If


            End If

        End If
    End Sub

    Private Sub btntag2_Click(sender As Object, e As EventArgs) Handles btntag2.Click
        If e Is EventArgs.Empty Then
        Else
            If btntag2.Tag = 0 Then
                btntag2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag2G
                btntag2.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 02 28 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                    btntag1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag1grey
                    btntag1.Enabled = False

                End If
                Threading.Thread.Sleep(500)
                ''/////     Dry run read

                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 02 26 00 01", 50)
                Dim x4() As String = plcinstrg.Split(" "c)
                If x4.Count >= 8 Then
                    If x4(6) = "02" And x4(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x4(10) & x4(9)))
                        digits4 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 5
                        ''''''''' check condition
                        If digits4(0) = 1 Then
                            btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldrun
                            btndryweldrun.Tag = 1
                        Else
                            btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dryrun
                            btndryweldrun.Tag = 0
                        End If

                    End If
                End If

            Else
                btntag2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag2
                btntag2.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 02 28 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)

                    btntag1.Enabled = True
                    btntag1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.tag1

                End If
                Threading.Thread.Sleep(500)
                ''/////     Dry run read

                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 02 26 00 01", 50)
                Dim x4() As String = plcinstrg.Split(" "c)
                If x4.Count >= 8 Then
                    If x4(6) = "02" And x4(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x4(10) & x4(9)))
                        digits4 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 5
                        ''''''''' check condition
                        If digits4(0) = 1 Then
                            btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldrun
                            btndryweldrun.Tag = 1
                        Else
                            btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dryrun
                            btndryweldrun.Tag = 0
                        End If

                    End If
                End If

            End If

        End If
    End Sub

    Private Sub btndryweldrun_Click(sender As Object, e As EventArgs) Handles btndryweldrun.Click
        If e Is EventArgs.Empty Then
        Else
            If btndryweldrun.Tag = 0 Then
                btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldrun
                btndryweldrun.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 02 26 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            Else
                btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dryrun
                btndryweldrun.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 02 26 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            End If

        End If

    End Sub

    'Private Sub btnstart_GotFocus(sender As Object, e As EventArgs) Handles btnstart.GotFocus
    'btnstart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.startOn
    'Thread.Sleep(1500)
    'btnstart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.startE
    'End Sub

    Private Sub btnstart_Click(sender As Object, e As EventArgs) Handles btnstart.Click

        Try
            Using objCon As New dbClass
                Using dt As DataTable = objCon.ExecuteDataTable("select * from syspara where id=1", CommandType.Text)
                    For Each row As DataRow In dt.Rows
                        wcmax1 = IIf(Convert.IsDBNull(row("wcmax")), "", row("wcmax"))
                        wvmax1 = IIf(Convert.IsDBNull(row("wvmax")), "", row("wvmax"))
                        gfmax1 = IIf(Convert.IsDBNull(row("gfmax")), "", row("gfmax"))
                        jtmax1 = IIf(Convert.IsDBNull(row("jtmax")), "", row("jtmax"))
                        wfmax1 = IIf(Convert.IsDBNull(row("wfmax")), "", row("wfmax"))
                    Next
                End Using
            End Using

            If isConnection = True Then
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 CA FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                'Thread.Sleep(300)
                'tx = ""
                'rx = ""
                'tx = "02 05 00 CA FF 00 AC 37"
                'rx = TCPComA(tx, 10)

                btnstart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.startOn
                btnstop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stopE

                Thread.Sleep(500)

                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 CA 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                'Thread.Sleep(300)
                'tx = ""
                'rx = ""
                'tx = "02 05 00 CA 00 00 ED C7"
                'rx = TCPComA(tx, 10)

                tParalog.Interval = 10000
                tParalog.Enabled = True

            End If

        Catch ex As Exception
            MessageBox.Show("Error in RS485 Communication in Button start : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub btnstop_GotFocus(sender As Object, e As EventArgs) Handles btnstop.GotFocus
        'btnstop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stopD
        'Thread.Sleep(1500)
        'btnstop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stopE
    End Sub

    Private Sub btnstop_Click(sender As Object, e As EventArgs) Handles btnstop.Click
        Try

            If isConnection = True Then
                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 CB FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                'Thread.Sleep(300)
                'tx = ""
                'rx = ""
                'tx = "00 00 00 00 00 06 02 05 00 CB FF 00"
                'rx = TCPComA(tx, 10)
                ''writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                btnstop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stopD
                btnstart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.startE

                Thread.Sleep(500)

                tx = ""
                rx = ""
                tx = "00 00 00 00 00 06 02 05 00 CB 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                'Thread.Sleep(300)
                'tx = ""
                'rx = ""
                'tx = "00 00 00 00 00 06 02 05 00 CB 00 00"
                'rx = TCPComA(tx, 10)
                ''writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

            End If

        Catch ex As Exception
            MessageBox.Show("Error in RS485 Communivation in Stop Button: " + ex.Message.ToString())
        End Try
    End Sub


    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        If isConnection = True Then
            tx = ""
            rx = ""
            tx = "00 00 00 00 00 06 02 05 00 D8 00 00"
            rx = TCPComA(tx, 10)
            'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)

            btnWELDA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldoff
            btnWELDA.Tag = 0
        End If


        If gstop = 1 Then
            Dim dd As Integer = SaveOPLog(2)


            gLogin = False
            btnpassup.Enabled = False
            btnpassdn.Enabled = False
            btnpassok.Enabled = False
            btnlayerup.Enabled = False
            btnlayerdn.Enabled = False
            btnlayerok.Enabled = False
            btnpassup.BackgroundImage = Global.iotPIPECLEDING.My.Resources.upD
            btnpassdn.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dnD
            btnpassok.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngrey
            btnlayerup.BackgroundImage = Global.iotPIPECLEDING.My.Resources.upD
            btnlayerdn.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dnD
            btnlayerok.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngrey
            gPROCESS = ""
            gMachine = ""
            MDIParent1.btnConsum.Enabled = False
            MDIParent1.btnWNote.Enabled = False
            MDIParent1.btnBatch.Enabled = False

            btnLogin.Enabled = True
            btnLogin.BackColor = System.Drawing.Color.SkyBlue
            btnLogout.Enabled = False
            btnLogout.BackColor = System.Drawing.Color.Gray
        ElseIf gstop = 0 Then


            Dim dd As Integer = SaveOPLog(2)

            gPROCESS = ""
            gMachine = ""
            gLogin = False
            btnpassup.Enabled = False
            btnpassdn.Enabled = False
            btnpassok.Enabled = False
            btnlayerup.Enabled = False
            btnlayerdn.Enabled = False
            btnlayerok.Enabled = False
            btnpassup.BackgroundImage = Global.iotPIPECLEDING.My.Resources.upD
            btnpassdn.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dnD
            btnpassok.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngrey
            btnlayerup.BackgroundImage = Global.iotPIPECLEDING.My.Resources.upD
            btnlayerdn.BackgroundImage = Global.iotPIPECLEDING.My.Resources.dnD
            btnlayerok.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngrey

            btnLogin.Enabled = True
            btnLogout.Enabled = False
            btnLogin.BackColor = System.Drawing.Color.SkyBlue
            btnLogout.BackColor = System.Drawing.Color.Gray
            MDIParent1.btnConsum.Enabled = False

            MDIParent1.btnWNote.Enabled = False
            MDIParent1.btnBatch.Enabled = False

        Else
            Dim result As String = MessageBoxEx.Show("Please stop " & gPROCESS, "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString

        End If
    End Sub

    Private Sub btnpassup_Click(sender As Object, e As EventArgs) Handles btnpassup.Click
        txtPass.Text = txtPass.Text + 1
        If txtPass.Text > 10000 Then
            txtPass.Text = 10000
        End If
    End Sub

    Private Sub btnpassok_Click_1(sender As Object, e As EventArgs) Handles btnpassok.Click

        'gPass = txtPass.Text
        'objCon.ExecuteNonQuery("update device set passno='" & gPass & "' where station='" & gstation & "'", CommandType.Text)
        Using objCon As New dbClass
            gPass = txtPass.Text
            objCon.ExecuteNonQuery("update device set passno='" & gPass & "' where station='" & gstation & "'", CommandType.Text)
        End Using

    End Sub

    Private Sub btnresume_Click(sender As Object, e As EventArgs) Handles btnresume.Click
        If e Is EventArgs.Empty Then
        Else
            If btnresume.Tag = 0 Then

                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 8C FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
                btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resumeg
                btnresume.Tag = 1
            Else

                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 8C 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
                btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resumeb

                btnresume.Tag = 0
            End If

        End If
    End Sub

    Private Sub tParalog_Tick(sender As Object, e As EventArgs) Handles tParalog.Tick
        '//////////////  Read Resume ON/Off ////////////////
        plcinstrg = ""
        plcinstrg = TCPComA("00 00 00 00 00 06 02 01 00 8C 00 01", 50)
        Dim x5() As String = plcinstrg.Split(" "c)
        If x5.Count >= 8 Then
            If x5(6) = "02" And x5(7) = "01" Then
                Dim bin As String = ReverseString(Hex2Bin(x5(10) & x5(9)))
                digits9 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                errno = 3
            End If
        End If

        '///////////////// check condition  //////////////////////
        If digits9(0) = 1 Then
            btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resumeg
        Else
            btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.resumeb
        End If
        tParalog.Enabled = False

    End Sub

    Private Sub btnWIREFEEDB_Click(sender As Object, e As EventArgs) Handles btnWIREFEEDB.Click
        If e Is EventArgs.Empty Then
        Else
            If btnWIREFEEDB.Tag = 0 Then
                btnWIREFEEDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.wirefeedon
                btnWIREFEEDB.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 DF FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            Else
                btnWIREFEEDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.wirefeedoff
                btnWIREFEEDB.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 DF 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            End If

        End If
    End Sub

    Private Sub btnHOTWIREB_Click(sender As Object, e As EventArgs) Handles btnHOTWIREB.Click
        If e Is EventArgs.Empty Then
        Else
            If btnHOTWIREB.Tag = 0 Then
                btnHOTWIREB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hotwireon
                btnHOTWIREB.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 E0 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            Else
                btnHOTWIREB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hotwireoff
                btnHOTWIREB.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 E0 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            End If

        End If
    End Sub

    Private Sub btnAVCB_Click(sender As Object, e As EventArgs) Handles btnAVCB.Click
        If e Is EventArgs.Empty Then
        Else
            If btnAVCB.Tag = 0 Then
                btnAVCB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.avcon
                btnAVCB.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 E1 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            Else
                btnAVCB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.avcoff
                btnAVCB.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 E1 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            End If

        End If
    End Sub

    Private Sub btnWELDB_Click(sender As Object, e As EventArgs) Handles btnWELDB.Click
        If gLogin = False Then
            Dim result1 As String = MessageBoxEx.Show("Please Login...", "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
        ElseIf gLocalDataSync = True Then
            Dim result1 As String = MessageBoxEx.Show("Local data sync is in progress, Please try after sometime.", "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
        Else
            If e Is EventArgs.Empty Then
            Else
                If btnWELDB.Tag = 0 Then

                    If isConnection = True Then
                        tx = ""
                        rx = ""
                        tx = "00 00 00 00 00 06 02 05 00 E2 FF 00"
                        rx = TCPComA(tx, 10)
                        'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                    End If
                    If rx.Count > 4 Then

                    End If
                    btnWELDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldon
                    btnWELDB.Tag = 1
                Else

                    If isConnection = True Then
                        tx = ""
                        rx = ""
                        tx = "00 00 00 00 00 06 02 05 00 E2 00 00"
                        rx = TCPComA(tx, 10)
                        'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                    End If
                    btnWELDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldoff
                    btnWELDB.Tag = 0


                    End If

            End If
        End If
    End Sub

    Private Sub btnlayerok_Click(sender As Object, e As EventArgs) Handles btnlayerok.Click
        'glayer = txtPass.Text
        'objCon.ExecuteNonQuery("update device set layerno='" & glayer & "' where station='" & gstation & "'", CommandType.Text)
        Using objCon As New dbClass
            glayer = txtlayer.Text
            objCon.ExecuteNonQuery("update device set layerno='" & glayer & "' where station='" & gstation & "'", CommandType.Text)
        End Using

    End Sub

    Private Sub btnpassdn_Click(sender As Object, e As EventArgs) Handles btnpassdn.Click
        txtPass.Text = txtPass.Text - 1
        If txtPass.Text < gPass Then
            txtPass.Text = gPass
        End If
    End Sub
    Private Sub btnlayerup_Click(sender As Object, e As EventArgs) Handles btnlayerup.Click
        txtlayer.Text = txtlayer.Text + 1
        If txtlayer.Text > 10000 Then
            txtlayer.Text = 10000
        End If
    End Sub
    Private Sub btnlayerdn_Click(sender As Object, e As EventArgs) Handles btnlayerdn.Click
        txtlayer.Text = txtlayer.Text - 1
        If txtlayer.Text < glayer Then
            txtlayer.Text = glayer
        End If
    End Sub



End Class