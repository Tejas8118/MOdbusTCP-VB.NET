﻿Public Class UserControl5
    Dim tx As String = ""
    Dim rx As String = ""

    Private Sub btntleft_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btntleft.TouchEnter
        'btnTROrev.TouchEnter execution
        'Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/in.png"))
        'Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        'btntright.Background = imgbrush

        'btnTROfwd.TouchEnter execution
        Dim imgsrc1 As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/in.png"))
        Dim imgbrush1 As New System.Windows.Media.ImageBrush(imgsrc1)
        btntleft.Background = imgbrush1

        If isConnection = True Then
            tx = ""
            rx = ""
            tx = "00 00 00 00 00 06 02 05 00 9C FF 00"

            rx = TCPComA(tx, 10)
            'writeLog("|btnTROrev.TouchEnter |TX:" & tx & "|RX:" & rx)

        End If
    End Sub

    Private Sub btntleft_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btntleft.TouchLeave
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/in1.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btntleft.Background = imgbrush

        If isConnection = True Then
            tx = ""
            rx = ""
            tx = "00 00 00 00 00 06 02 05 00 9C 00 00"

            rx = TCPComA(tx, 10)
            'writeLog("|btnTROrev.TouchEnter |TX:" & tx & "|RX:" & rx)

            Threading.Thread.Sleep(1000)
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 9C 00 00"
            rx = TCPComA(tx, 10)

            'writeLog("|btnTROfwd.TouchEnter |TX:" & tx & "|RX:" & rx)

        End If
    End Sub

    Private Sub btntrorev_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btntright.TouchEnter
        'btnTROfwd.TouchEnter execution
        'Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/fwdE.png"))
        'Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        'btnTROfwd.Background = imgbrush

        'btnTROrev.TouchEnter execution
        Dim imgsrc1 As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/out.png"))
        Dim imgbrush1 As New System.Windows.Media.ImageBrush(imgsrc1)
        btntright.Background = imgbrush1

        If isConnection = True Then
            tx = ""
            rx = ""
            tx = "00 00 00 00 00 06 02 05 00 9D FF 00"

            rx = TCPComA(tx, 10)
            'writeLog("|btnTROfwd.TouchEnter |TX:" & tx & "|RX:" & rx)


        End If
    End Sub

    Private Sub btntrorev_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btntright.TouchLeave
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/out1.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btntright.Background = imgbrush

        If isConnection = True Then
            tx = ""
            rx = ""
            tx = "00 00 00 00 00 06 02 05 00 9D 00 00"

            rx = TCPComA(tx, 10)
            'writeLog("|btnTROfwd.TouchEnter |TX:" & tx & "|RX:" & rx)

            Threading.Thread.Sleep(1000)
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 9D 00 00"
            rx = TCPComA(tx, 10)


            'writeLog("|btnTROrev.TouchEnter |TX:" & tx & "|RX:" & rx)

        End If
    End Sub


End Class
