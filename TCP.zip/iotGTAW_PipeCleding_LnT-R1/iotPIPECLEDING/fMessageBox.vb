Option Strict On

Public Class fMessageBox
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents lblTimer As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents chkDontShowAgain As System.Windows.Forms.CheckBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(fMessageBox))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lblTimer = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.chkDontShowAgain = New System.Windows.Forms.CheckBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'lblTimer
        '
        Me.lblTimer.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.lblTimer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimer.Location = New System.Drawing.Point(0, 358)
        Me.lblTimer.Name = "lblTimer"
        Me.lblTimer.Size = New System.Drawing.Size(764, 24)
        Me.lblTimer.TabIndex = 5
        Me.lblTimer.Tag = "This message will disappear in @0@"
        Me.lblTimer.Text = "This message will disappear in @0@"
        Me.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Location = New System.Drawing.Point(679, 297)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 43)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Button1"
        '
        'Button2
        '
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), System.Drawing.Image)
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button2.Location = New System.Drawing.Point(599, 297)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 43)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Button2"
        '
        'Button3
        '
        Me.Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), System.Drawing.Image)
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button3.Location = New System.Drawing.Point(520, 297)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(74, 43)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "Button3"
        '
        'chkDontShowAgain
        '
        Me.chkDontShowAgain.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chkDontShowAgain.Location = New System.Drawing.Point(48, 313)
        Me.chkDontShowAgain.Name = "chkDontShowAgain"
        Me.chkDontShowAgain.Size = New System.Drawing.Size(267, 16)
        Me.chkDontShowAgain.TabIndex = 1
        Me.chkDontShowAgain.Text = "Don't show again"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox1.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.Location = New System.Drawing.Point(48, 47)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ReadOnly = True
        Me.RichTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox1.Size = New System.Drawing.Size(579, 194)
        Me.RichTextBox1.TabIndex = 0
        Me.RichTextBox1.Text = "Message"
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(5, 46)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(38, 37)
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblTitle.Location = New System.Drawing.Point(-4, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(768, 36)
        Me.lblTitle.TabIndex = 7
        Me.lblTitle.Text = "Title"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'fMessageBox
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(764, 382)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.chkDontShowAgain)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lblTimer)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "fMessageBox"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " - Members - "

    Public Enum enuLanguage
        English = 0
        French = 1
    End Enum

    Private mButtons As MessageBoxButtons
    Private mDefaultButton As MessageBoxDefaultButton
    Private mintLanguage As enuLanguage
    Private mintTimeOut As Integer

    Private Const LEFT_PADDING As Integer = 12
    Private Const RIGHT_PADDING As Integer = 12
    Private Const TOP_PADDING As Integer = 12
    Private Const ITEM_PADDING As Integer = 12
    Private Const BOTTOM_PADDING As Integer = 12

#End Region ' - Members - 

#Region " - Properties - "

    'Display the required buttons 
    'Set the caption of the buttons (in the selected language)
    'Set the dialog result of the buttons
    Public Property Buttons() As MessageBoxButtons
        Get
            Return mButtons
        End Get
        Set(ByVal Value As MessageBoxButtons)
            mButtons = Value
            Select Case Value
                Case MessageBoxButtons.AbortRetryIgnore
                    With Button1
                        .Text = IIf(Language = enuLanguage.English, "Abort", "Abandonner").ToString
                        .DialogResult = DialogResult.Abort
                    End With
                    With Button2
                        .Text = IIf(Language = enuLanguage.English, "Retry", "R�-essayer").ToString
                        .DialogResult = DialogResult.Retry
                    End With
                    With Button3
                        .Text = IIf(Language = enuLanguage.English, "Ignore", "Ignorer").ToString
                        .DialogResult = DialogResult.Ignore
                    End With

                Case MessageBoxButtons.OK
                    With Button1
                        .Text = "OK"
                        .DialogResult = DialogResult.OK
                    End With
                    Button2.Visible = False
                    Button3.Visible = False

                Case MessageBoxButtons.OKCancel
                    With Button1
                        .Text = "OK"
                        .DialogResult = DialogResult.OK
                    End With
                    With Button2
                        .Text = IIf(Language = enuLanguage.English, "Cancel", "Annuler").ToString
                        .DialogResult = DialogResult.Cancel
                    End With
                    Button3.Visible = False

                Case MessageBoxButtons.RetryCancel
                    With Button1
                        .Text = IIf(Language = enuLanguage.English, "Retry", "R�-essayer").ToString
                        .DialogResult = DialogResult.Retry
                    End With
                    With Button2
                        .Text = IIf(Language = enuLanguage.English, "Cancel", "Annuler").ToString
                        .DialogResult = DialogResult.Cancel
                    End With
                    Button3.Visible = False

                Case MessageBoxButtons.YesNo
                    With Button1
                        .Text = IIf(Language = enuLanguage.English, "Yes", "Oui").ToString
                        .DialogResult = DialogResult.Yes
                    End With
                    With Button2
                        .Text = IIf(Language = enuLanguage.English, "No", "Non").ToString
                        .DialogResult = DialogResult.No
                    End With
                    Button3.Visible = False

                Case MessageBoxButtons.YesNoCancel
                    With Button1
                        .Text = IIf(Language = enuLanguage.English, "Yes", "Oui").ToString
                        .DialogResult = DialogResult.Yes
                    End With
                    With Button2
                        .Text = IIf(Language = enuLanguage.English, "No", "Non").ToString
                        .DialogResult = DialogResult.No
                    End With
                    With Button3
                        .Text = IIf(Language = enuLanguage.English, "Cancel", "Annuler").ToString
                        .DialogResult = DialogResult.Cancel
                    End With
            End Select
        End Set
    End Property

    'Keep the value of the default button (which will receive focus in the Load event)
    Public Property DefaultButton() As MessageBoxDefaultButton
        Get
            Return mDefaultButton
        End Get
        Set(ByVal Value As MessageBoxDefaultButton)
            mDefaultButton = Value
        End Set
    End Property

    'Set the image property
    Public Shadows WriteOnly Property Icon() As MessageBoxIcon
        Set(ByVal Value As MessageBoxIcon)
            Select Case Value
                Case MessageBoxIcon.Asterisk, MessageBoxIcon.Information '64
                    PictureBox1.Image = SystemIcons.Asterisk.ToBitmap
                Case MessageBoxIcon.Error, MessageBoxIcon.Hand, MessageBoxIcon.Stop '16
                    PictureBox1.Image = SystemIcons.Error.ToBitmap
                Case MessageBoxIcon.Exclamation, MessageBoxIcon.Warning '48
                    PictureBox1.Image = SystemIcons.Exclamation.ToBitmap
                Case MessageBoxIcon.Question '32
                    PictureBox1.Image = SystemIcons.Question.ToBitmap
            End Select
        End Set
    End Property

    'Keep the language value - will be used in the Buttons property
    Public Property Language() As enuLanguage
        Get
            Return mintLanguage
        End Get
        Set(ByVal Value As enuLanguage)
            mintLanguage = Value
        End Set
    End Property

    'Sets the message to be displayed
    Public Property Message() As String
        Get
            Return RichTextBox1.Text
        End Get
        Set(ByVal Value As String)
            RichTextBox1.Text = Value
        End Set
    End Property

    'Do we have to show the checkbox
    Public Property ShowCheckBox() As Boolean
        Get
            Return chkDontShowAgain.Visible
        End Get
        Set(ByVal Value As Boolean)
            chkDontShowAgain.Visible = Value
        End Set
    End Property

    'Set the TimeOut of the MessageBox
    'Starts a timer to countdown to 0
    Public Property TimeOut() As Integer
        Get
            Return mintTimeOut
        End Get
        Set(ByVal Value As Integer)
            If Value >= 0 Then
                mintTimeOut = Value
                If Language = enuLanguage.English Then
                    lblTimer.Text = "This message will disappear in " + mintTimeOut.ToString + " seconds."
                Else
                    lblTimer.Text = "Ce message dispara�tra dans " + mintTimeOut.ToString + " secondes."
                End If
                Timer1.Interval = 1000
                Timer1.Enabled = True
            Else
                mintTimeOut = 0
                lblTimer.Visible = False
                Timer1.Enabled = False
            End If
        End Set
    End Property

#End Region     ' - Properties -

#Region " - Methods - "

    'Measures a string using the Graphics object for this form with the specified font
    Private Function MeasureString(ByVal pStr As String, ByVal pMaxWidth As Integer, ByVal pfont As Font) As Size
        Dim g As Graphics = Me.CreateGraphics()
        Dim strRectSizeF As SizeF = g.MeasureString(pStr, pfont, pMaxWidth)
        g.Dispose()

        Return New Size(Convert.ToInt32(Math.Ceiling(strRectSizeF.Width)), Convert.ToInt32(Math.Ceiling(strRectSizeF.Height)))
    End Function

    'Sets the optimum size for the form based on the controls that need to be displayed
    Private Sub SetFormSize()
        ''The current width of the form
        'Dim intCurrentWidth As Integer = Me.Width - Me.ClientSize.Width
        'Dim intCurrentHeight As Integer = Me.Height - Me.ClientSize.Height
        ''The width of the Messagebox (including its left padding)
        'Dim intMessageRowWidth As Integer = RichTextBox1.Width + RichTextBox1.Left
        ''The required size
        'Dim intRequiredWidth As Integer = LEFT_PADDING + Math.Max(Me.Width, intMessageRowWidth) + RIGHT_PADDING + intCurrentWidth
        'Dim intRequiredHeight As Integer = TOP_PADDING + RichTextBox1.Height + ITEM_PADDING + chkDontShowAgain.Height + ITEM_PADDING + Button1.Height + BOTTOM_PADDING + intCurrentHeight
        ''The maximum width available (to be sure not to cover the whole screen
        'Dim intMaxWidth As Integer = Convert.ToInt32(SystemInformation.WorkingArea.Width * 0.6)
        'Dim intMaxHeight As Integer = Convert.ToInt32(SystemInformation.WorkingArea.Height * 0.9)

        ''Fix the bug where if the message text is huge then the buttons are overwritten.
        ''Incase the required height is more than the max height then adjust that in the message height
        'If intRequiredHeight > intMaxHeight Then
        '    RichTextBox1.Height -= intRequiredHeight - intMaxHeight
        'End If
        ''Resize the form
        'Me.Size = New Size(Math.Min(intRequiredWidth, intMaxWidth), Math.Min(intRequiredHeight, intMaxHeight))
        ''Recenter the form
        Me.Location = New Point((SystemInformation.WorkingArea.Width - Me.Width) \ 2, (SystemInformation.WorkingArea.Height - Me.Height) \ 2)
    End Sub

    'Sets the size of the Message (RichTextBox)
    Private Sub SetMessageSize()
        'If RichTextBox1.Text Is Nothing OrElse RichTextBox1.Text.Trim.Length = 0 Then
        '    RichTextBox1.Size = Size.Empty
        '    RichTextBox1.Visible = False
        'Else
        '    'Not to use the complete screen area
        '    Dim intMaxWidth As Integer = Convert.ToInt32(SystemInformation.WorkingArea.Width * 0.6)
        '    intMaxWidth -= RichTextBox1.Left - RIGHT_PADDING

        '    'We need to account for scroll bar width and height, otherwise for certains
        '    'kinds of text the scroll bar shows up unnecessarily
        '    intMaxWidth -= SystemInformation.VerticalScrollBarWidth
        '    Dim sizMessageRect As Size = MeasureString(RichTextBox1.Text, intMaxWidth, Me.Font)
        '    sizMessageRect.Height += BOTTOM_PADDING

        '    RichTextBox1.Size = sizMessageRect
        '    RichTextBox1.Visible = True
        'End If
    End Sub

#End Region ' - Methods -

#Region " - Events - "

    Private Sub MessageBox_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.FormBorderStyle = FormBorderStyle.FixedToolWindow

        'Select the default button
        Select Case DefaultButton
            Case MessageBoxDefaultButton.Button1
                Button1.Focus()
            Case MessageBoxDefaultButton.Button2
                If Button2.Visible Then
                    Button2.Focus()
                Else
                    Button1.Focus()
                End If
            Case MessageBoxDefaultButton.Button3
                If Button3.Visible Then
                    Button3.Focus()
                Else
                    Button1.Focus()
                End If
        End Select

        'Resize the form to fit the message
        SetMessageSize()
        SetFormSize()
    End Sub

    'CountDown if the MessageBox has a TimeOut
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        mintTimeOut -= 1
        If mintTimeOut <= 0 Then
            Timer1.Enabled = False
            DialogResult = DialogResult.Cancel
        Else
            If Language = enuLanguage.English Then
                lblTimer.Text = "This message will disappear in " + mintTimeOut.ToString + " seconds."
            Else
                lblTimer.Text = "Ce message dispara�tra dans " + mintTimeOut.ToString + " secondes."
            End If
        End If
    End Sub

#End Region ' - Events -

End Class
