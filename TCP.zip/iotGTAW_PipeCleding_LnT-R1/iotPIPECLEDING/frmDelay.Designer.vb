﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDelay
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Wrkb1 = New myControls.WRKB()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtAvcSpeed2 = New System.Windows.Forms.TextBox()
        Me.txtAvcBand2 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtAvcSpeed1 = New System.Windows.Forms.TextBox()
        Me.txtAvcBand1 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtWireRet1 = New System.Windows.Forms.TextBox()
        Me.txtWireRet2 = New System.Windows.Forms.TextBox()
        Me.txtDelay6 = New System.Windows.Forms.TextBox()
        Me.txtWFDelay2 = New System.Windows.Forms.TextBox()
        Me.txtDelay7 = New System.Windows.Forms.TextBox()
        Me.txtDelay8 = New System.Windows.Forms.TextBox()
        Me.txtDelay9 = New System.Windows.Forms.TextBox()
        Me.txtDelay10 = New System.Windows.Forms.TextBox()
        Me.txtWFDelay1 = New System.Windows.Forms.TextBox()
        Me.txtDelay5 = New System.Windows.Forms.TextBox()
        Me.txtDelay2 = New System.Windows.Forms.TextBox()
        Me.txtDelay3 = New System.Windows.Forms.TextBox()
        Me.txtDelay4 = New System.Windows.Forms.TextBox()
        Me.txtAutoSpeed2 = New System.Windows.Forms.TextBox()
        Me.txtAutoSpeed3 = New System.Windows.Forms.TextBox()
        Me.txtAutoSpeed4 = New System.Windows.Forms.TextBox()
        Me.txtAutoSpeed5 = New System.Windows.Forms.TextBox()
        Me.txtDelay1 = New System.Windows.Forms.TextBox()
        Me.txtRapid2 = New System.Windows.Forms.TextBox()
        Me.txtRapid3 = New System.Windows.Forms.TextBox()
        Me.txtRapid4 = New System.Windows.Forms.TextBox()
        Me.txtRapid5 = New System.Windows.Forms.TextBox()
        Me.txtSlow1 = New System.Windows.Forms.TextBox()
        Me.txtSlow2 = New System.Windows.Forms.TextBox()
        Me.txtSlow3 = New System.Windows.Forms.TextBox()
        Me.txtSlow4 = New System.Windows.Forms.TextBox()
        Me.txtSlow5 = New System.Windows.Forms.TextBox()
        Me.txtAutoSpeed1 = New System.Windows.Forms.TextBox()
        Me.txtRapid1 = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Location = New System.Drawing.Point(3, 9)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1044, 664)
        Me.Panel1.TabIndex = 2
        '
        'Button1
        '
        Me.Button1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Location = New System.Drawing.Point(855, 629)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(91, 31)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Wrkb1)
        Me.Panel2.Controls.Add(Me.Label32)
        Me.Panel2.Controls.Add(Me.Label31)
        Me.Panel2.Controls.Add(Me.Label30)
        Me.Panel2.Controls.Add(Me.Label28)
        Me.Panel2.Controls.Add(Me.Label27)
        Me.Panel2.Controls.Add(Me.Label26)
        Me.Panel2.Controls.Add(Me.Label25)
        Me.Panel2.Controls.Add(Me.Label24)
        Me.Panel2.Controls.Add(Me.Label23)
        Me.Panel2.Controls.Add(Me.Label22)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Controls.Add(Me.Label20)
        Me.Panel2.Controls.Add(Me.txtAvcSpeed2)
        Me.Panel2.Controls.Add(Me.txtAvcBand2)
        Me.Panel2.Controls.Add(Me.Label19)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.txtAvcSpeed1)
        Me.Panel2.Controls.Add(Me.txtAvcBand1)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.txtWireRet1)
        Me.Panel2.Controls.Add(Me.txtWireRet2)
        Me.Panel2.Controls.Add(Me.txtDelay6)
        Me.Panel2.Controls.Add(Me.txtWFDelay2)
        Me.Panel2.Controls.Add(Me.txtDelay7)
        Me.Panel2.Controls.Add(Me.txtDelay8)
        Me.Panel2.Controls.Add(Me.txtDelay9)
        Me.Panel2.Controls.Add(Me.txtDelay10)
        Me.Panel2.Controls.Add(Me.txtWFDelay1)
        Me.Panel2.Controls.Add(Me.txtDelay5)
        Me.Panel2.Controls.Add(Me.txtDelay2)
        Me.Panel2.Controls.Add(Me.txtDelay3)
        Me.Panel2.Controls.Add(Me.txtDelay4)
        Me.Panel2.Controls.Add(Me.txtAutoSpeed2)
        Me.Panel2.Controls.Add(Me.txtAutoSpeed3)
        Me.Panel2.Controls.Add(Me.txtAutoSpeed4)
        Me.Panel2.Controls.Add(Me.txtAutoSpeed5)
        Me.Panel2.Controls.Add(Me.txtDelay1)
        Me.Panel2.Controls.Add(Me.txtRapid2)
        Me.Panel2.Controls.Add(Me.txtRapid3)
        Me.Panel2.Controls.Add(Me.txtRapid4)
        Me.Panel2.Controls.Add(Me.txtRapid5)
        Me.Panel2.Controls.Add(Me.txtSlow1)
        Me.Panel2.Controls.Add(Me.txtSlow2)
        Me.Panel2.Controls.Add(Me.txtSlow3)
        Me.Panel2.Controls.Add(Me.txtSlow4)
        Me.Panel2.Controls.Add(Me.txtSlow5)
        Me.Panel2.Controls.Add(Me.txtAutoSpeed1)
        Me.Panel2.Controls.Add(Me.txtRapid1)
        Me.Panel2.Controls.Add(Me.Label45)
        Me.Panel2.Controls.Add(Me.Label29)
        Me.Panel2.Controls.Add(Me.Label44)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label36)
        Me.Panel2.Controls.Add(Me.Label35)
        Me.Panel2.Controls.Add(Me.Label18)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Location = New System.Drawing.Point(12, 9)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1019, 618)
        Me.Panel2.TabIndex = 0
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(59, 487)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(124, 20)
        Me.Label5.TabIndex = 415
        Me.Label5.Text = "Axis-5-R-AXIS"
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(59, 446)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(105, 20)
        Me.Label11.TabIndex = 414
        Me.Label11.Text = "Axis-4-AVC-2"
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(59, 408)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(108, 20)
        Me.Label12.TabIndex = 413
        Me.Label12.Text = "Axis-3-AVC-1"
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(59, 325)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(111, 20)
        Me.Label13.TabIndex = 412
        Me.Label13.Text = "Axis-1-X-AXIS"
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(59, 366)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(117, 20)
        Me.Label14.TabIndex = 411
        Me.Label14.Text = "Axis-2-SPARE"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(24, 228)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(124, 20)
        Me.Label6.TabIndex = 410
        Me.Label6.Text = "Axis-5-R-AXIS"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(24, 186)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(105, 20)
        Me.Label7.TabIndex = 409
        Me.Label7.Text = "Axis-4-AVC-2"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(24, 149)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(108, 20)
        Me.Label8.TabIndex = 408
        Me.Label8.Text = "Axis-3-AVC-1"
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(24, 64)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(111, 20)
        Me.Label9.TabIndex = 407
        Me.Label9.Text = "Axis-1-X-AXIS"
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(24, 105)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(117, 20)
        Me.Label10.TabIndex = 406
        Me.Label10.Text = "Axis-2-SPARE"
        '
        'Wrkb1
        '
        Me.Wrkb1.CurrTextBox = Nothing
        Me.Wrkb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Wrkb1.Location = New System.Drawing.Point(444, 195)
        Me.Wrkb1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Wrkb1.Name = "Wrkb1"
        Me.Wrkb1.Size = New System.Drawing.Size(351, 308)
        Me.Wrkb1.TabIndex = 373
        '
        'Label32
        '
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(640, 585)
        Me.Label32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(172, 20)
        Me.Label32.TabIndex = 405
        Me.Label32.Text = "Delay 10 (s)"
        '
        'Label31
        '
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(673, 469)
        Me.Label31.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(139, 20)
        Me.Label31.TabIndex = 404
        Me.Label31.Text = "Delay  7 (S)"
        '
        'Label30
        '
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(573, 508)
        Me.Label30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(239, 20)
        Me.Label30.TabIndex = 403
        Me.Label30.Text = "ARC ON FB Error Delay  8 (S)"
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(565, 550)
        Me.Label28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(247, 20)
        Me.Label28.TabIndex = 402
        Me.Label28.Text = "GAS FLOW Error DELAY 9 (S)"
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(656, 266)
        Me.Label27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(155, 20)
        Me.Label27.TabIndex = 401
        Me.Label27.Text = "Travel ON Delay (S)"
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(673, 307)
        Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(139, 20)
        Me.Label26.TabIndex = 400
        Me.Label26.Text = "Avc ON Delay (S)"
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(634, 349)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(177, 20)
        Me.Label25.TabIndex = 399
        Me.Label25.Text = "Wirefeed ON Delay (S)"
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(637, 391)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(177, 20)
        Me.Label24.TabIndex = 398
        Me.Label24.Text = "Hotwire ON Delay (S)"
        '
        'Label23
        '
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(673, 425)
        Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(139, 20)
        Me.Label23.TabIndex = 397
        Me.Label23.Text = "Delay  6 (S)"
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Red
        Me.Label22.Location = New System.Drawing.Point(874, 33)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(60, 20)
        Me.Label22.TabIndex = 396
        Me.Label22.Text = "W/F-2"
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(570, 114)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(141, 20)
        Me.Label21.TabIndex = 394
        Me.Label21.Text = "Wire Retract(mm)"
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(570, 67)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(141, 20)
        Me.Label20.TabIndex = 393
        Me.Label20.Text = "Wirefeed Delay(s)"
        '
        'txtAvcSpeed2
        '
        Me.txtAvcSpeed2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAvcSpeed2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAvcSpeed2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAvcSpeed2.Location = New System.Drawing.Point(432, 581)
        Me.txtAvcSpeed2.Name = "txtAvcSpeed2"
        Me.txtAvcSpeed2.Size = New System.Drawing.Size(100, 31)
        Me.txtAvcSpeed2.TabIndex = 392
        Me.txtAvcSpeed2.Text = "000.00"
        '
        'txtAvcBand2
        '
        Me.txtAvcBand2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAvcBand2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAvcBand2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAvcBand2.Location = New System.Drawing.Point(432, 544)
        Me.txtAvcBand2.Name = "txtAvcBand2"
        Me.txtAvcBand2.Size = New System.Drawing.Size(100, 31)
        Me.txtAvcBand2.TabIndex = 391
        Me.txtAvcBand2.Text = "0.0"
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(272, 585)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(155, 20)
        Me.Label19.TabIndex = 390
        Me.Label19.Text = "AVC2 SPeed(mm/m)"
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(281, 551)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(131, 20)
        Me.Label17.TabIndex = 389
        Me.Label17.Text = "AVC2 BAND (V)"
        '
        'txtAvcSpeed1
        '
        Me.txtAvcSpeed1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAvcSpeed1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAvcSpeed1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAvcSpeed1.Location = New System.Drawing.Point(172, 581)
        Me.txtAvcSpeed1.Name = "txtAvcSpeed1"
        Me.txtAvcSpeed1.Size = New System.Drawing.Size(100, 31)
        Me.txtAvcSpeed1.TabIndex = 388
        Me.txtAvcSpeed1.Text = "000.00"
        '
        'txtAvcBand1
        '
        Me.txtAvcBand1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAvcBand1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAvcBand1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAvcBand1.Location = New System.Drawing.Point(172, 544)
        Me.txtAvcBand1.Name = "txtAvcBand1"
        Me.txtAvcBand1.Size = New System.Drawing.Size(100, 31)
        Me.txtAvcBand1.TabIndex = 387
        Me.txtAvcBand1.Text = "0.0"
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(30, 552)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(131, 20)
        Me.Label15.TabIndex = 386
        Me.Label15.Text = "AVC1 BAND (V)"
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(18, 585)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(152, 20)
        Me.Label16.TabIndex = 385
        Me.Label16.Text = "AVC1 SPeed(mm/m)"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(15, 517)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(517, 24)
        Me.Label1.TabIndex = 384
        Me.Label1.Text = "AVC Parameter"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'txtWireRet1
        '
        Me.txtWireRet1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtWireRet1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWireRet1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtWireRet1.Location = New System.Drawing.Point(732, 106)
        Me.txtWireRet1.Name = "txtWireRet1"
        Me.txtWireRet1.Size = New System.Drawing.Size(100, 31)
        Me.txtWireRet1.TabIndex = 383
        Me.txtWireRet1.Text = "000.00"
        '
        'txtWireRet2
        '
        Me.txtWireRet2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtWireRet2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWireRet2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtWireRet2.Location = New System.Drawing.Point(855, 105)
        Me.txtWireRet2.Name = "txtWireRet2"
        Me.txtWireRet2.Size = New System.Drawing.Size(100, 31)
        Me.txtWireRet2.TabIndex = 382
        Me.txtWireRet2.Text = "000.00"
        '
        'txtDelay6
        '
        Me.txtDelay6.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtDelay6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDelay6.ForeColor = System.Drawing.SystemColors.Info
        Me.txtDelay6.Location = New System.Drawing.Point(833, 416)
        Me.txtDelay6.Name = "txtDelay6"
        Me.txtDelay6.Size = New System.Drawing.Size(100, 31)
        Me.txtDelay6.TabIndex = 381
        Me.txtDelay6.Text = "000.00"
        '
        'txtWFDelay2
        '
        Me.txtWFDelay2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtWFDelay2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWFDelay2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtWFDelay2.Location = New System.Drawing.Point(855, 53)
        Me.txtWFDelay2.Name = "txtWFDelay2"
        Me.txtWFDelay2.Size = New System.Drawing.Size(100, 31)
        Me.txtWFDelay2.TabIndex = 380
        Me.txtWFDelay2.Text = "000.00"
        '
        'txtDelay7
        '
        Me.txtDelay7.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtDelay7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDelay7.ForeColor = System.Drawing.SystemColors.Info
        Me.txtDelay7.Location = New System.Drawing.Point(833, 458)
        Me.txtDelay7.Name = "txtDelay7"
        Me.txtDelay7.Size = New System.Drawing.Size(100, 31)
        Me.txtDelay7.TabIndex = 379
        Me.txtDelay7.Text = "000.00"
        '
        'txtDelay8
        '
        Me.txtDelay8.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtDelay8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDelay8.ForeColor = System.Drawing.SystemColors.Info
        Me.txtDelay8.Location = New System.Drawing.Point(833, 499)
        Me.txtDelay8.Name = "txtDelay8"
        Me.txtDelay8.Size = New System.Drawing.Size(100, 31)
        Me.txtDelay8.TabIndex = 378
        Me.txtDelay8.Text = "000.00"
        '
        'txtDelay9
        '
        Me.txtDelay9.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtDelay9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDelay9.ForeColor = System.Drawing.SystemColors.Info
        Me.txtDelay9.Location = New System.Drawing.Point(833, 541)
        Me.txtDelay9.Name = "txtDelay9"
        Me.txtDelay9.Size = New System.Drawing.Size(100, 31)
        Me.txtDelay9.TabIndex = 377
        Me.txtDelay9.Text = "000.00"
        '
        'txtDelay10
        '
        Me.txtDelay10.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtDelay10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDelay10.ForeColor = System.Drawing.SystemColors.Info
        Me.txtDelay10.Location = New System.Drawing.Point(833, 580)
        Me.txtDelay10.Name = "txtDelay10"
        Me.txtDelay10.Size = New System.Drawing.Size(100, 31)
        Me.txtDelay10.TabIndex = 376
        Me.txtDelay10.Text = "000.00"
        '
        'txtWFDelay1
        '
        Me.txtWFDelay1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtWFDelay1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWFDelay1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtWFDelay1.Location = New System.Drawing.Point(732, 53)
        Me.txtWFDelay1.Name = "txtWFDelay1"
        Me.txtWFDelay1.Size = New System.Drawing.Size(100, 31)
        Me.txtWFDelay1.TabIndex = 374
        Me.txtWFDelay1.Text = "000.00"
        '
        'txtDelay5
        '
        Me.txtDelay5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtDelay5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDelay5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtDelay5.Location = New System.Drawing.Point(833, 380)
        Me.txtDelay5.Name = "txtDelay5"
        Me.txtDelay5.Size = New System.Drawing.Size(100, 31)
        Me.txtDelay5.TabIndex = 367
        Me.txtDelay5.Text = "000.00"
        '
        'txtDelay2
        '
        Me.txtDelay2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtDelay2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDelay2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtDelay2.Location = New System.Drawing.Point(833, 254)
        Me.txtDelay2.Name = "txtDelay2"
        Me.txtDelay2.Size = New System.Drawing.Size(100, 31)
        Me.txtDelay2.TabIndex = 366
        Me.txtDelay2.Text = "000.00"
        '
        'txtDelay3
        '
        Me.txtDelay3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtDelay3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDelay3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtDelay3.Location = New System.Drawing.Point(833, 298)
        Me.txtDelay3.Name = "txtDelay3"
        Me.txtDelay3.Size = New System.Drawing.Size(100, 31)
        Me.txtDelay3.TabIndex = 365
        Me.txtDelay3.Text = "000.00"
        '
        'txtDelay4
        '
        Me.txtDelay4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtDelay4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDelay4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtDelay4.Location = New System.Drawing.Point(833, 340)
        Me.txtDelay4.Name = "txtDelay4"
        Me.txtDelay4.Size = New System.Drawing.Size(100, 31)
        Me.txtDelay4.TabIndex = 364
        Me.txtDelay4.Text = "000.00"
        '
        'txtAutoSpeed2
        '
        Me.txtAutoSpeed2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAutoSpeed2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAutoSpeed2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAutoSpeed2.Location = New System.Drawing.Point(201, 357)
        Me.txtAutoSpeed2.Name = "txtAutoSpeed2"
        Me.txtAutoSpeed2.Size = New System.Drawing.Size(100, 31)
        Me.txtAutoSpeed2.TabIndex = 363
        Me.txtAutoSpeed2.Text = "000.00"
        '
        'txtAutoSpeed3
        '
        Me.txtAutoSpeed3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAutoSpeed3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAutoSpeed3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAutoSpeed3.Location = New System.Drawing.Point(201, 401)
        Me.txtAutoSpeed3.Name = "txtAutoSpeed3"
        Me.txtAutoSpeed3.Size = New System.Drawing.Size(100, 31)
        Me.txtAutoSpeed3.TabIndex = 362
        Me.txtAutoSpeed3.Text = "000.00"
        '
        'txtAutoSpeed4
        '
        Me.txtAutoSpeed4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAutoSpeed4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAutoSpeed4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAutoSpeed4.Location = New System.Drawing.Point(201, 443)
        Me.txtAutoSpeed4.Name = "txtAutoSpeed4"
        Me.txtAutoSpeed4.Size = New System.Drawing.Size(100, 31)
        Me.txtAutoSpeed4.TabIndex = 361
        Me.txtAutoSpeed4.Text = "000.00"
        '
        'txtAutoSpeed5
        '
        Me.txtAutoSpeed5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAutoSpeed5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAutoSpeed5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAutoSpeed5.Location = New System.Drawing.Point(201, 483)
        Me.txtAutoSpeed5.Name = "txtAutoSpeed5"
        Me.txtAutoSpeed5.Size = New System.Drawing.Size(100, 31)
        Me.txtAutoSpeed5.TabIndex = 360
        Me.txtAutoSpeed5.Text = "000.00"
        '
        'txtDelay1
        '
        Me.txtDelay1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtDelay1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDelay1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtDelay1.Location = New System.Drawing.Point(833, 213)
        Me.txtDelay1.Name = "txtDelay1"
        Me.txtDelay1.Size = New System.Drawing.Size(100, 31)
        Me.txtDelay1.TabIndex = 359
        Me.txtDelay1.Text = "000.00"
        '
        'txtRapid2
        '
        Me.txtRapid2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtRapid2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRapid2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtRapid2.Location = New System.Drawing.Point(152, 99)
        Me.txtRapid2.Name = "txtRapid2"
        Me.txtRapid2.Size = New System.Drawing.Size(100, 31)
        Me.txtRapid2.TabIndex = 358
        Me.txtRapid2.Text = "000.00"
        '
        'txtRapid3
        '
        Me.txtRapid3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtRapid3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRapid3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtRapid3.Location = New System.Drawing.Point(152, 141)
        Me.txtRapid3.Name = "txtRapid3"
        Me.txtRapid3.Size = New System.Drawing.Size(100, 31)
        Me.txtRapid3.TabIndex = 357
        Me.txtRapid3.Text = "000.00"
        '
        'txtRapid4
        '
        Me.txtRapid4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtRapid4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRapid4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtRapid4.Location = New System.Drawing.Point(152, 180)
        Me.txtRapid4.Name = "txtRapid4"
        Me.txtRapid4.Size = New System.Drawing.Size(100, 31)
        Me.txtRapid4.TabIndex = 356
        Me.txtRapid4.Text = "000.00"
        '
        'txtRapid5
        '
        Me.txtRapid5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtRapid5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRapid5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtRapid5.Location = New System.Drawing.Point(152, 223)
        Me.txtRapid5.Name = "txtRapid5"
        Me.txtRapid5.Size = New System.Drawing.Size(100, 31)
        Me.txtRapid5.TabIndex = 355
        Me.txtRapid5.Text = "000.00"
        '
        'txtSlow1
        '
        Me.txtSlow1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtSlow1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSlow1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtSlow1.Location = New System.Drawing.Point(289, 58)
        Me.txtSlow1.Name = "txtSlow1"
        Me.txtSlow1.Size = New System.Drawing.Size(100, 31)
        Me.txtSlow1.TabIndex = 354
        Me.txtSlow1.Text = "000.00"
        '
        'txtSlow2
        '
        Me.txtSlow2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtSlow2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSlow2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtSlow2.Location = New System.Drawing.Point(289, 99)
        Me.txtSlow2.Name = "txtSlow2"
        Me.txtSlow2.Size = New System.Drawing.Size(100, 31)
        Me.txtSlow2.TabIndex = 353
        Me.txtSlow2.Text = "000.00"
        '
        'txtSlow3
        '
        Me.txtSlow3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtSlow3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSlow3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtSlow3.Location = New System.Drawing.Point(289, 141)
        Me.txtSlow3.Name = "txtSlow3"
        Me.txtSlow3.Size = New System.Drawing.Size(100, 31)
        Me.txtSlow3.TabIndex = 352
        Me.txtSlow3.Text = "000.00"
        '
        'txtSlow4
        '
        Me.txtSlow4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtSlow4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSlow4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtSlow4.Location = New System.Drawing.Point(289, 180)
        Me.txtSlow4.Name = "txtSlow4"
        Me.txtSlow4.Size = New System.Drawing.Size(100, 31)
        Me.txtSlow4.TabIndex = 351
        Me.txtSlow4.Text = "000.00"
        '
        'txtSlow5
        '
        Me.txtSlow5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtSlow5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSlow5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtSlow5.Location = New System.Drawing.Point(289, 223)
        Me.txtSlow5.Name = "txtSlow5"
        Me.txtSlow5.Size = New System.Drawing.Size(100, 31)
        Me.txtSlow5.TabIndex = 350
        Me.txtSlow5.Text = "000.00"
        '
        'txtAutoSpeed1
        '
        Me.txtAutoSpeed1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtAutoSpeed1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAutoSpeed1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtAutoSpeed1.Location = New System.Drawing.Point(201, 316)
        Me.txtAutoSpeed1.Name = "txtAutoSpeed1"
        Me.txtAutoSpeed1.Size = New System.Drawing.Size(100, 31)
        Me.txtAutoSpeed1.TabIndex = 349
        Me.txtAutoSpeed1.Text = "000.00"
        '
        'txtRapid1
        '
        Me.txtRapid1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtRapid1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRapid1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtRapid1.Location = New System.Drawing.Point(152, 58)
        Me.txtRapid1.Name = "txtRapid1"
        Me.txtRapid1.Size = New System.Drawing.Size(100, 31)
        Me.txtRapid1.TabIndex = 348
        Me.txtRapid1.Text = "000.00"
        '
        'Label45
        '
        Me.Label45.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label45.Location = New System.Drawing.Point(528, 2)
        Me.Label45.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(489, 24)
        Me.Label45.TabIndex = 342
        Me.Label45.Text = "Wirefeed Controls"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label29
        '
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(656, 222)
        Me.Label29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(139, 20)
        Me.Label29.TabIndex = 338
        Me.Label29.Text = "Arc ON Delay (S)"
        '
        'Label44
        '
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.Red
        Me.Label44.Location = New System.Drawing.Point(752, 28)
        Me.Label44.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(60, 20)
        Me.Label44.TabIndex = 325
        Me.Label44.Text = "W/F-1"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Red
        Me.Label3.Location = New System.Drawing.Point(224, 296)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(54, 20)
        Me.Label3.TabIndex = 308
        Me.Label3.Text = "AUTO"
        '
        'Label36
        '
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Red
        Me.Label36.Location = New System.Drawing.Point(304, 33)
        Me.Label36.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(66, 20)
        Me.Label36.TabIndex = 302
        Me.Label36.Text = "SLOW"
        '
        'Label35
        '
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Red
        Me.Label35.Location = New System.Drawing.Point(172, 33)
        Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(60, 20)
        Me.Label35.TabIndex = 301
        Me.Label35.Text = "RAPID"
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label18.Location = New System.Drawing.Point(2, 3)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(512, 24)
        Me.Label18.TabIndex = 284
        Me.Label18.Text = "Axis Speed Manual Mode"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(550, 179)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(461, 24)
        Me.Label4.TabIndex = 277
        Me.Label4.Text = "Delay Settings"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(-3, 266)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(517, 24)
        Me.Label2.TabIndex = 276
        Me.Label2.Text = "Axis Speed Auto Mode "
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Timer1
        '
        Me.Timer1.Interval = 200
        '
        'frmDelay
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1060, 681)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmDelay"
        Me.Text = "frmDelay"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents txtWireRet1 As TextBox
    Friend WithEvents txtWireRet2 As TextBox
    Friend WithEvents txtDelay6 As TextBox
    Friend WithEvents txtWFDelay2 As TextBox
    Friend WithEvents txtDelay7 As TextBox
    Friend WithEvents txtDelay8 As TextBox
    Friend WithEvents txtDelay9 As TextBox
    Friend WithEvents txtDelay10 As TextBox
    Friend WithEvents txtWFDelay1 As TextBox
    Friend WithEvents Wrkb1 As myControls.WRKB
    Friend WithEvents txtDelay5 As TextBox
    Friend WithEvents txtDelay2 As TextBox
    Friend WithEvents txtDelay3 As TextBox
    Friend WithEvents txtDelay4 As TextBox
    Friend WithEvents txtAutoSpeed2 As TextBox
    Friend WithEvents txtAutoSpeed3 As TextBox
    Friend WithEvents txtAutoSpeed4 As TextBox
    Friend WithEvents txtAutoSpeed5 As TextBox
    Friend WithEvents txtDelay1 As TextBox
    Friend WithEvents txtRapid2 As TextBox
    Friend WithEvents txtRapid3 As TextBox
    Friend WithEvents txtRapid4 As TextBox
    Friend WithEvents txtRapid5 As TextBox
    Friend WithEvents txtSlow1 As TextBox
    Friend WithEvents txtSlow2 As TextBox
    Friend WithEvents txtSlow3 As TextBox
    Friend WithEvents txtSlow4 As TextBox
    Friend WithEvents txtSlow5 As TextBox
    Friend WithEvents txtAutoSpeed1 As TextBox
    Friend WithEvents txtRapid1 As TextBox
    Friend WithEvents Label45 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents txtAvcSpeed1 As TextBox
    Friend WithEvents txtAvcBand1 As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents txtAvcSpeed2 As TextBox
    Friend WithEvents txtAvcBand2 As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
End Class
