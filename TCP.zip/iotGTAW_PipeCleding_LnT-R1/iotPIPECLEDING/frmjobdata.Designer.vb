﻿Imports Microsoft.VisualBasic.PowerPacks

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmjobdata
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmjobdata))
        Me.ShapeContainer2 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.rsMan = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.ShapeContainer7 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtShellID = New System.Windows.Forms.TextBox()
        Me.txtNozzleRefDia = New System.Windows.Forms.TextBox()
        Me.txtBackfaceID = New System.Windows.Forms.TextBox()
        Me.txtBackfaceOD = New System.Windows.Forms.TextBox()
        Me.txtPipeNozzleOD = New System.Windows.Forms.TextBox()
        Me.txtPipeNozzleLen = New System.Windows.Forms.TextBox()
        Me.txtFlangeID = New System.Windows.Forms.TextBox()
        Me.txtFlangeOD = New System.Windows.Forms.TextBox()
        Me.txtBeadShiftSpeed = New System.Windows.Forms.TextBox()
        Me.txtBeadWidth = New System.Windows.Forms.TextBox()
        Me.txtShellOD = New System.Windows.Forms.TextBox()
        Me.txtPipeNozzleID = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ShapeContainer8 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.Wrkb1 = New myControls.WRKB()
        Me.ShapeContainer4 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnBeadShiFWDREW = New System.Windows.Forms.Button()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.btnNozzPipeIDOL = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.btnMinusWirefeed2 = New System.Windows.Forms.Button()
        Me.btnMinusVol2 = New System.Windows.Forms.Button()
        Me.btnMinusCurr2 = New System.Windows.Forms.Button()
        Me.btnPlusSetWirefeed2 = New System.Windows.Forms.Button()
        Me.btnPlusVol2 = New System.Windows.Forms.Button()
        Me.btnPlusCurr2 = New System.Windows.Forms.Button()
        Me.txtSetWirefeed2 = New System.Windows.Forms.TextBox()
        Me.txtSetVol2 = New System.Windows.Forms.TextBox()
        Me.txtSetCurr2 = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.btnMinusWirefeed = New System.Windows.Forms.Button()
        Me.btnMinusWeldSpeed = New System.Windows.Forms.Button()
        Me.btnMinusVol = New System.Windows.Forms.Button()
        Me.btnMinusCurr = New System.Windows.Forms.Button()
        Me.btnPlusWeldSpeed = New System.Windows.Forms.Button()
        Me.btnPlusSetWirefeed = New System.Windows.Forms.Button()
        Me.btnPlusVol = New System.Windows.Forms.Button()
        Me.btnPlusCurr = New System.Windows.Forms.Button()
        Me.txtWeldSpeed = New System.Windows.Forms.TextBox()
        Me.txtSetWirefeed = New System.Windows.Forms.TextBox()
        Me.txtSetVol = New System.Windows.Forms.TextBox()
        Me.txtSetCurr = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnSpiralONOFF = New System.Windows.Forms.Button()
        Me.btnStepONOFF = New System.Windows.Forms.Button()
        Me.btnLinearCirculae = New System.Windows.Forms.Button()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtFlt = New System.Windows.Forms.TextBox()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'ShapeContainer2
        '
        Me.ShapeContainer2.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer2.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer2.Name = "ShapeContainer2"
        Me.ShapeContainer2.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.rsMan, Me.RectangleShape1})
        Me.ShapeContainer2.Size = New System.Drawing.Size(410, 239)
        Me.ShapeContainer2.TabIndex = 21
        Me.ShapeContainer2.TabStop = False
        '
        'rsMan
        '
        Me.rsMan.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.rsMan.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.rsMan.BorderColor = System.Drawing.Color.DarkSalmon
        Me.rsMan.BorderWidth = 2
        Me.rsMan.CornerRadius = 5
        Me.rsMan.FillColor = System.Drawing.SystemColors.Highlight
        Me.rsMan.FillGradientStyle = Microsoft.VisualBasic.PowerPacks.FillGradientStyle.Horizontal
        Me.rsMan.Location = New System.Drawing.Point(130, 195)
        Me.rsMan.Name = "rsMan"
        Me.rsMan.Size = New System.Drawing.Size(145, 140)
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.RectangleShape1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape1.BorderColor = System.Drawing.Color.DarkSalmon
        Me.RectangleShape1.BorderWidth = 2
        Me.RectangleShape1.CornerRadius = 5
        Me.RectangleShape1.FillColor = System.Drawing.SystemColors.Highlight
        Me.RectangleShape1.FillGradientStyle = Microsoft.VisualBasic.PowerPacks.FillGradientStyle.Horizontal
        Me.RectangleShape1.Location = New System.Drawing.Point(7, 52)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(115, 284)
        '
        'ShapeContainer7
        '
        Me.ShapeContainer7.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer7.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer7.Name = "ShapeContainer7"
        Me.ShapeContainer7.TabIndex = 0
        Me.ShapeContainer7.TabStop = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.txtFlt)
        Me.Panel1.Controls.Add(Me.txtShellID)
        Me.Panel1.Controls.Add(Me.txtNozzleRefDia)
        Me.Panel1.Controls.Add(Me.txtBackfaceID)
        Me.Panel1.Controls.Add(Me.txtBackfaceOD)
        Me.Panel1.Controls.Add(Me.txtPipeNozzleOD)
        Me.Panel1.Controls.Add(Me.txtPipeNozzleLen)
        Me.Panel1.Controls.Add(Me.txtFlangeID)
        Me.Panel1.Controls.Add(Me.txtFlangeOD)
        Me.Panel1.Controls.Add(Me.txtBeadShiftSpeed)
        Me.Panel1.Controls.Add(Me.txtBeadWidth)
        Me.Panel1.Controls.Add(Me.txtShellOD)
        Me.Panel1.Controls.Add(Me.txtPipeNozzleID)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.ShapeContainer8)
        Me.Panel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(11, 33)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(6)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(428, 735)
        Me.Panel1.TabIndex = 63
        '
        'txtShellID
        '
        Me.txtShellID.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShellID.Location = New System.Drawing.Point(252, 453)
        Me.txtShellID.Name = "txtShellID"
        Me.txtShellID.Size = New System.Drawing.Size(147, 31)
        Me.txtShellID.TabIndex = 50
        Me.txtShellID.Text = "00000"
        Me.txtShellID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtNozzleRefDia
        '
        Me.txtNozzleRefDia.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNozzleRefDia.Location = New System.Drawing.Point(252, 405)
        Me.txtNozzleRefDia.Name = "txtNozzleRefDia"
        Me.txtNozzleRefDia.Size = New System.Drawing.Size(147, 31)
        Me.txtNozzleRefDia.TabIndex = 49
        Me.txtNozzleRefDia.Text = "00000"
        Me.txtNozzleRefDia.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtBackfaceID
        '
        Me.txtBackfaceID.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBackfaceID.Location = New System.Drawing.Point(252, 297)
        Me.txtBackfaceID.Name = "txtBackfaceID"
        Me.txtBackfaceID.Size = New System.Drawing.Size(147, 31)
        Me.txtBackfaceID.TabIndex = 48
        Me.txtBackfaceID.Text = "00000"
        Me.txtBackfaceID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtBackfaceOD
        '
        Me.txtBackfaceOD.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBackfaceOD.Location = New System.Drawing.Point(252, 347)
        Me.txtBackfaceOD.Name = "txtBackfaceOD"
        Me.txtBackfaceOD.Size = New System.Drawing.Size(147, 31)
        Me.txtBackfaceOD.TabIndex = 47
        Me.txtBackfaceOD.Text = "00000"
        Me.txtBackfaceOD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtPipeNozzleOD
        '
        Me.txtPipeNozzleOD.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPipeNozzleOD.Location = New System.Drawing.Point(252, 85)
        Me.txtPipeNozzleOD.Name = "txtPipeNozzleOD"
        Me.txtPipeNozzleOD.Size = New System.Drawing.Size(147, 31)
        Me.txtPipeNozzleOD.TabIndex = 46
        Me.txtPipeNozzleOD.Text = "00000"
        Me.txtPipeNozzleOD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtPipeNozzleLen
        '
        Me.txtPipeNozzleLen.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPipeNozzleLen.Location = New System.Drawing.Point(252, 138)
        Me.txtPipeNozzleLen.Name = "txtPipeNozzleLen"
        Me.txtPipeNozzleLen.Size = New System.Drawing.Size(147, 31)
        Me.txtPipeNozzleLen.TabIndex = 45
        Me.txtPipeNozzleLen.Text = "00000"
        Me.txtPipeNozzleLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtFlangeID
        '
        Me.txtFlangeID.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFlangeID.Location = New System.Drawing.Point(252, 192)
        Me.txtFlangeID.Name = "txtFlangeID"
        Me.txtFlangeID.Size = New System.Drawing.Size(147, 31)
        Me.txtFlangeID.TabIndex = 44
        Me.txtFlangeID.Text = "00000"
        Me.txtFlangeID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtFlangeOD
        '
        Me.txtFlangeOD.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFlangeOD.Location = New System.Drawing.Point(252, 246)
        Me.txtFlangeOD.Name = "txtFlangeOD"
        Me.txtFlangeOD.Size = New System.Drawing.Size(147, 31)
        Me.txtFlangeOD.TabIndex = 43
        Me.txtFlangeOD.Text = "00000"
        Me.txtFlangeOD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtBeadShiftSpeed
        '
        Me.txtBeadShiftSpeed.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBeadShiftSpeed.Location = New System.Drawing.Point(252, 615)
        Me.txtBeadShiftSpeed.Name = "txtBeadShiftSpeed"
        Me.txtBeadShiftSpeed.Size = New System.Drawing.Size(147, 31)
        Me.txtBeadShiftSpeed.TabIndex = 42
        Me.txtBeadShiftSpeed.Text = "000.0"
        Me.txtBeadShiftSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtBeadWidth
        '
        Me.txtBeadWidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBeadWidth.Location = New System.Drawing.Point(252, 559)
        Me.txtBeadWidth.Name = "txtBeadWidth"
        Me.txtBeadWidth.Size = New System.Drawing.Size(147, 31)
        Me.txtBeadWidth.TabIndex = 41
        Me.txtBeadWidth.Text = "00.0"
        Me.txtBeadWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtShellOD
        '
        Me.txtShellOD.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShellOD.Location = New System.Drawing.Point(252, 507)
        Me.txtShellOD.Name = "txtShellOD"
        Me.txtShellOD.Size = New System.Drawing.Size(147, 31)
        Me.txtShellOD.TabIndex = 40
        Me.txtShellOD.Text = "00000"
        Me.txtShellOD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtPipeNozzleID
        '
        Me.txtPipeNozzleID.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPipeNozzleID.Location = New System.Drawing.Point(252, 36)
        Me.txtPipeNozzleID.Name = "txtPipeNozzleID"
        Me.txtPipeNozzleID.Size = New System.Drawing.Size(147, 31)
        Me.txtPipeNozzleID.TabIndex = 39
        Me.txtPipeNozzleID.Text = "00000"
        Me.txtPipeNozzleID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(12, 618)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(166, 24)
        Me.Label14.TabIndex = 38
        Me.Label14.Text = "Bead Shift Speed"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(12, 564)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(166, 24)
        Me.Label13.TabIndex = 37
        Me.Label13.Text = "Bead Shift"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(12, 507)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(166, 24)
        Me.Label12.TabIndex = 36
        Me.Label12.Text = "- - - - "
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(12, 456)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(166, 24)
        Me.Label11.TabIndex = 35
        Me.Label11.Text = "- - - -"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(12, 405)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(166, 24)
        Me.Label10.TabIndex = 34
        Me.Label10.Text = "- - - -"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(12, 350)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(185, 24)
        Me.Label9.TabIndex = 33
        Me.Label9.Text = "- - - - "
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(12, 301)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(166, 24)
        Me.Label8.TabIndex = 32
        Me.Label8.Text = "- - - - "
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(12, 254)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(166, 24)
        Me.Label7.TabIndex = 31
        Me.Label7.Text = "- - - - "
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(12, 201)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(144, 24)
        Me.Label5.TabIndex = 30
        Me.Label5.Text = "- - - - "
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(12, 138)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(205, 24)
        Me.Label4.TabIndex = 29
        Me.Label4.Text = "Pipe/Nozzle Length(C)"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(12, 90)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(205, 24)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Pipe/Nozzle Index(B)"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(12, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(166, 24)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "Pipe/Nozzle ID(A)"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.SkyBlue
        Me.Label1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(-1, -1)
        Me.Label1.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(427, 27)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Job Data"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ShapeContainer8
        '
        Me.ShapeContainer8.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer8.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer8.Name = "ShapeContainer2"
        Me.ShapeContainer8.Size = New System.Drawing.Size(426, 733)
        Me.ShapeContainer8.TabIndex = 26
        Me.ShapeContainer8.TabStop = False
        '
        'Wrkb1
        '
        Me.Wrkb1.CurrTextBox = Nothing
        Me.Wrkb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Wrkb1.Location = New System.Drawing.Point(23, 13)
        Me.Wrkb1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Wrkb1.Name = "Wrkb1"
        Me.Wrkb1.Size = New System.Drawing.Size(348, 299)
        Me.Wrkb1.TabIndex = 39
        '
        'ShapeContainer4
        '
        Me.ShapeContainer4.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer4.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer4.Name = "ShapeContainer4"
        Me.ShapeContainer4.TabIndex = 0
        Me.ShapeContainer4.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Wrkb1)
        Me.Panel2.Controls.Add(Me.btnBeadShiFWDREW)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.btnNozzPipeIDOL)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel2.Location = New System.Drawing.Point(452, 33)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(817, 313)
        Me.Panel2.TabIndex = 64
        '
        'btnBeadShiFWDREW
        '
        Me.btnBeadShiFWDREW.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.rew
        Me.btnBeadShiFWDREW.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnBeadShiFWDREW.FlatAppearance.BorderSize = 0
        Me.btnBeadShiFWDREW.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBeadShiFWDREW.Location = New System.Drawing.Point(666, 43)
        Me.btnBeadShiFWDREW.Name = "btnBeadShiFWDREW"
        Me.btnBeadShiFWDREW.Size = New System.Drawing.Size(103, 57)
        Me.btnBeadShiFWDREW.TabIndex = 36
        Me.btnBeadShiFWDREW.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(466, 57)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(177, 24)
        Me.Label21.TabIndex = 33
        Me.Label21.Text = "Bead Shift Direction"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(19, 57)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(171, 24)
        Me.Label16.TabIndex = 28
        Me.Label16.Text = "Nozzle/Pipe ID O/L"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnNozzPipeIDOL
        '
        Me.btnNozzPipeIDOL.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.off
        Me.btnNozzPipeIDOL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnNozzPipeIDOL.FlatAppearance.BorderSize = 0
        Me.btnNozzPipeIDOL.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNozzPipeIDOL.Location = New System.Drawing.Point(212, 43)
        Me.btnNozzPipeIDOL.Name = "btnNozzPipeIDOL"
        Me.btnNozzPipeIDOL.Size = New System.Drawing.Size(121, 50)
        Me.btnNozzPipeIDOL.TabIndex = 2
        Me.btnNozzPipeIDOL.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.SkyBlue
        Me.Label15.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label15.Location = New System.Drawing.Point(-4, 0)
        Me.Label15.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(821, 27)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Job Selection"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Label29)
        Me.Panel4.Controls.Add(Me.Label28)
        Me.Panel4.Controls.Add(Me.Label27)
        Me.Panel4.Controls.Add(Me.btnMinusWirefeed2)
        Me.Panel4.Controls.Add(Me.btnMinusVol2)
        Me.Panel4.Controls.Add(Me.btnMinusCurr2)
        Me.Panel4.Controls.Add(Me.btnPlusSetWirefeed2)
        Me.Panel4.Controls.Add(Me.btnPlusVol2)
        Me.Panel4.Controls.Add(Me.btnPlusCurr2)
        Me.Panel4.Controls.Add(Me.txtSetWirefeed2)
        Me.Panel4.Controls.Add(Me.txtSetVol2)
        Me.Panel4.Controls.Add(Me.txtSetCurr2)
        Me.Panel4.Controls.Add(Me.Label26)
        Me.Panel4.Controls.Add(Me.Label25)
        Me.Panel4.Controls.Add(Me.Label24)
        Me.Panel4.Controls.Add(Me.Label23)
        Me.Panel4.Controls.Add(Me.btnMinusWirefeed)
        Me.Panel4.Controls.Add(Me.btnMinusWeldSpeed)
        Me.Panel4.Controls.Add(Me.btnMinusVol)
        Me.Panel4.Controls.Add(Me.btnMinusCurr)
        Me.Panel4.Controls.Add(Me.btnPlusWeldSpeed)
        Me.Panel4.Controls.Add(Me.btnPlusSetWirefeed)
        Me.Panel4.Controls.Add(Me.btnPlusVol)
        Me.Panel4.Controls.Add(Me.btnPlusCurr)
        Me.Panel4.Controls.Add(Me.txtWeldSpeed)
        Me.Panel4.Controls.Add(Me.txtSetWirefeed)
        Me.Panel4.Controls.Add(Me.txtSetVol)
        Me.Panel4.Controls.Add(Me.txtSetCurr)
        Me.Panel4.Location = New System.Drawing.Point(452, 460)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(817, 306)
        Me.Panel4.TabIndex = 66
        '
        'Label29
        '
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(419, 176)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(143, 24)
        Me.Label29.TabIndex = 79
        Me.Label29.Text = "Set Wirefeed-2"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(422, 97)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(129, 24)
        Me.Label28.TabIndex = 78
        Me.Label28.Text = "Set Voltage-2"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(427, 20)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(120, 24)
        Me.Label27.TabIndex = 77
        Me.Label27.Text = "Set Current-2"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnMinusWirefeed2
        '
        Me.btnMinusWirefeed2.BackgroundImage = CType(resources.GetObject("btnMinusWirefeed2.BackgroundImage"), System.Drawing.Image)
        Me.btnMinusWirefeed2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMinusWirefeed2.FlatAppearance.BorderSize = 0
        Me.btnMinusWirefeed2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMinusWirefeed2.Location = New System.Drawing.Point(570, 158)
        Me.btnMinusWirefeed2.Name = "btnMinusWirefeed2"
        Me.btnMinusWirefeed2.Size = New System.Drawing.Size(66, 58)
        Me.btnMinusWirefeed2.TabIndex = 76
        Me.btnMinusWirefeed2.UseVisualStyleBackColor = True
        '
        'btnMinusVol2
        '
        Me.btnMinusVol2.BackgroundImage = CType(resources.GetObject("btnMinusVol2.BackgroundImage"), System.Drawing.Image)
        Me.btnMinusVol2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMinusVol2.FlatAppearance.BorderSize = 0
        Me.btnMinusVol2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMinusVol2.Location = New System.Drawing.Point(568, 85)
        Me.btnMinusVol2.Name = "btnMinusVol2"
        Me.btnMinusVol2.Size = New System.Drawing.Size(66, 58)
        Me.btnMinusVol2.TabIndex = 75
        Me.btnMinusVol2.UseVisualStyleBackColor = True
        '
        'btnMinusCurr2
        '
        Me.btnMinusCurr2.BackgroundImage = CType(resources.GetObject("btnMinusCurr2.BackgroundImage"), System.Drawing.Image)
        Me.btnMinusCurr2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMinusCurr2.FlatAppearance.BorderSize = 0
        Me.btnMinusCurr2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMinusCurr2.Location = New System.Drawing.Point(568, 10)
        Me.btnMinusCurr2.Name = "btnMinusCurr2"
        Me.btnMinusCurr2.Size = New System.Drawing.Size(66, 58)
        Me.btnMinusCurr2.TabIndex = 74
        Me.btnMinusCurr2.UseVisualStyleBackColor = True
        '
        'btnPlusSetWirefeed2
        '
        Me.btnPlusSetWirefeed2.BackgroundImage = CType(resources.GetObject("btnPlusSetWirefeed2.BackgroundImage"), System.Drawing.Image)
        Me.btnPlusSetWirefeed2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPlusSetWirefeed2.FlatAppearance.BorderSize = 0
        Me.btnPlusSetWirefeed2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPlusSetWirefeed2.Location = New System.Drawing.Point(741, 158)
        Me.btnPlusSetWirefeed2.Name = "btnPlusSetWirefeed2"
        Me.btnPlusSetWirefeed2.Size = New System.Drawing.Size(66, 58)
        Me.btnPlusSetWirefeed2.TabIndex = 73
        Me.btnPlusSetWirefeed2.UseVisualStyleBackColor = True
        '
        'btnPlusVol2
        '
        Me.btnPlusVol2.BackgroundImage = CType(resources.GetObject("btnPlusVol2.BackgroundImage"), System.Drawing.Image)
        Me.btnPlusVol2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPlusVol2.FlatAppearance.BorderSize = 0
        Me.btnPlusVol2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPlusVol2.Location = New System.Drawing.Point(741, 85)
        Me.btnPlusVol2.Name = "btnPlusVol2"
        Me.btnPlusVol2.Size = New System.Drawing.Size(66, 58)
        Me.btnPlusVol2.TabIndex = 72
        Me.btnPlusVol2.UseVisualStyleBackColor = True
        '
        'btnPlusCurr2
        '
        Me.btnPlusCurr2.BackgroundImage = CType(resources.GetObject("btnPlusCurr2.BackgroundImage"), System.Drawing.Image)
        Me.btnPlusCurr2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPlusCurr2.FlatAppearance.BorderSize = 0
        Me.btnPlusCurr2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPlusCurr2.Location = New System.Drawing.Point(741, 10)
        Me.btnPlusCurr2.Name = "btnPlusCurr2"
        Me.btnPlusCurr2.Size = New System.Drawing.Size(66, 58)
        Me.btnPlusCurr2.TabIndex = 71
        Me.btnPlusCurr2.UseVisualStyleBackColor = True
        '
        'txtSetWirefeed2
        '
        Me.txtSetWirefeed2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSetWirefeed2.Location = New System.Drawing.Point(638, 169)
        Me.txtSetWirefeed2.Name = "txtSetWirefeed2"
        Me.txtSetWirefeed2.Size = New System.Drawing.Size(105, 31)
        Me.txtSetWirefeed2.TabIndex = 70
        Me.txtSetWirefeed2.Text = "000.0"
        Me.txtSetWirefeed2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSetVol2
        '
        Me.txtSetVol2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSetVol2.Location = New System.Drawing.Point(636, 96)
        Me.txtSetVol2.Name = "txtSetVol2"
        Me.txtSetVol2.Size = New System.Drawing.Size(105, 31)
        Me.txtSetVol2.TabIndex = 69
        Me.txtSetVol2.Text = "000.0"
        Me.txtSetVol2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSetCurr2
        '
        Me.txtSetCurr2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSetCurr2.Location = New System.Drawing.Point(636, 21)
        Me.txtSetCurr2.Name = "txtSetCurr2"
        Me.txtSetCurr2.Size = New System.Drawing.Size(105, 31)
        Me.txtSetCurr2.TabIndex = 68
        Me.txtSetCurr2.Text = "000.0"
        Me.txtSetCurr2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(18, 97)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(106, 24)
        Me.Label26.TabIndex = 64
        Me.Label26.Text = "Set Voltage"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(11, 176)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(127, 24)
        Me.Label25.TabIndex = 63
        Me.Label25.Text = "Set Wirefeed"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(9, 241)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(115, 24)
        Me.Label24.TabIndex = 62
        Me.Label24.Text = "Weld Speed"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label23
        '
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(13, 20)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(106, 24)
        Me.Label23.TabIndex = 61
        Me.Label23.Text = "Set Current"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnMinusWirefeed
        '
        Me.btnMinusWirefeed.BackgroundImage = CType(resources.GetObject("btnMinusWirefeed.BackgroundImage"), System.Drawing.Image)
        Me.btnMinusWirefeed.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMinusWirefeed.FlatAppearance.BorderSize = 0
        Me.btnMinusWirefeed.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMinusWirefeed.Location = New System.Drawing.Point(144, 158)
        Me.btnMinusWirefeed.Name = "btnMinusWirefeed"
        Me.btnMinusWirefeed.Size = New System.Drawing.Size(66, 58)
        Me.btnMinusWirefeed.TabIndex = 57
        Me.btnMinusWirefeed.UseVisualStyleBackColor = True
        '
        'btnMinusWeldSpeed
        '
        Me.btnMinusWeldSpeed.BackgroundImage = CType(resources.GetObject("btnMinusWeldSpeed.BackgroundImage"), System.Drawing.Image)
        Me.btnMinusWeldSpeed.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMinusWeldSpeed.FlatAppearance.BorderSize = 0
        Me.btnMinusWeldSpeed.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMinusWeldSpeed.Location = New System.Drawing.Point(144, 226)
        Me.btnMinusWeldSpeed.Name = "btnMinusWeldSpeed"
        Me.btnMinusWeldSpeed.Size = New System.Drawing.Size(66, 58)
        Me.btnMinusWeldSpeed.TabIndex = 56
        Me.btnMinusWeldSpeed.UseVisualStyleBackColor = True
        '
        'btnMinusVol
        '
        Me.btnMinusVol.BackgroundImage = CType(resources.GetObject("btnMinusVol.BackgroundImage"), System.Drawing.Image)
        Me.btnMinusVol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMinusVol.FlatAppearance.BorderSize = 0
        Me.btnMinusVol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMinusVol.Location = New System.Drawing.Point(144, 85)
        Me.btnMinusVol.Name = "btnMinusVol"
        Me.btnMinusVol.Size = New System.Drawing.Size(66, 58)
        Me.btnMinusVol.TabIndex = 55
        Me.btnMinusVol.UseVisualStyleBackColor = True
        '
        'btnMinusCurr
        '
        Me.btnMinusCurr.BackgroundImage = CType(resources.GetObject("btnMinusCurr.BackgroundImage"), System.Drawing.Image)
        Me.btnMinusCurr.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMinusCurr.FlatAppearance.BorderSize = 0
        Me.btnMinusCurr.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMinusCurr.Location = New System.Drawing.Point(144, 10)
        Me.btnMinusCurr.Name = "btnMinusCurr"
        Me.btnMinusCurr.Size = New System.Drawing.Size(66, 58)
        Me.btnMinusCurr.TabIndex = 54
        Me.btnMinusCurr.UseVisualStyleBackColor = True
        '
        'btnPlusWeldSpeed
        '
        Me.btnPlusWeldSpeed.BackgroundImage = CType(resources.GetObject("btnPlusWeldSpeed.BackgroundImage"), System.Drawing.Image)
        Me.btnPlusWeldSpeed.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPlusWeldSpeed.FlatAppearance.BorderSize = 0
        Me.btnPlusWeldSpeed.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPlusWeldSpeed.Location = New System.Drawing.Point(317, 226)
        Me.btnPlusWeldSpeed.Name = "btnPlusWeldSpeed"
        Me.btnPlusWeldSpeed.Size = New System.Drawing.Size(66, 58)
        Me.btnPlusWeldSpeed.TabIndex = 50
        Me.btnPlusWeldSpeed.UseVisualStyleBackColor = True
        '
        'btnPlusSetWirefeed
        '
        Me.btnPlusSetWirefeed.BackgroundImage = CType(resources.GetObject("btnPlusSetWirefeed.BackgroundImage"), System.Drawing.Image)
        Me.btnPlusSetWirefeed.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPlusSetWirefeed.FlatAppearance.BorderSize = 0
        Me.btnPlusSetWirefeed.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPlusSetWirefeed.Location = New System.Drawing.Point(317, 158)
        Me.btnPlusSetWirefeed.Name = "btnPlusSetWirefeed"
        Me.btnPlusSetWirefeed.Size = New System.Drawing.Size(66, 58)
        Me.btnPlusSetWirefeed.TabIndex = 49
        Me.btnPlusSetWirefeed.UseVisualStyleBackColor = True
        '
        'btnPlusVol
        '
        Me.btnPlusVol.BackgroundImage = CType(resources.GetObject("btnPlusVol.BackgroundImage"), System.Drawing.Image)
        Me.btnPlusVol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPlusVol.FlatAppearance.BorderSize = 0
        Me.btnPlusVol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPlusVol.Location = New System.Drawing.Point(317, 85)
        Me.btnPlusVol.Name = "btnPlusVol"
        Me.btnPlusVol.Size = New System.Drawing.Size(66, 58)
        Me.btnPlusVol.TabIndex = 48
        Me.btnPlusVol.UseVisualStyleBackColor = True
        '
        'btnPlusCurr
        '
        Me.btnPlusCurr.BackgroundImage = CType(resources.GetObject("btnPlusCurr.BackgroundImage"), System.Drawing.Image)
        Me.btnPlusCurr.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPlusCurr.FlatAppearance.BorderSize = 0
        Me.btnPlusCurr.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPlusCurr.Location = New System.Drawing.Point(317, 10)
        Me.btnPlusCurr.Name = "btnPlusCurr"
        Me.btnPlusCurr.Size = New System.Drawing.Size(66, 58)
        Me.btnPlusCurr.TabIndex = 47
        Me.btnPlusCurr.UseVisualStyleBackColor = True
        '
        'txtWeldSpeed
        '
        Me.txtWeldSpeed.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWeldSpeed.Location = New System.Drawing.Point(211, 237)
        Me.txtWeldSpeed.Name = "txtWeldSpeed"
        Me.txtWeldSpeed.Size = New System.Drawing.Size(105, 31)
        Me.txtWeldSpeed.TabIndex = 43
        Me.txtWeldSpeed.Text = "000.0"
        Me.txtWeldSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSetWirefeed
        '
        Me.txtSetWirefeed.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSetWirefeed.Location = New System.Drawing.Point(211, 169)
        Me.txtSetWirefeed.Name = "txtSetWirefeed"
        Me.txtSetWirefeed.Size = New System.Drawing.Size(105, 31)
        Me.txtSetWirefeed.TabIndex = 42
        Me.txtSetWirefeed.Text = "000.0"
        Me.txtSetWirefeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSetVol
        '
        Me.txtSetVol.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSetVol.Location = New System.Drawing.Point(211, 96)
        Me.txtSetVol.Name = "txtSetVol"
        Me.txtSetVol.Size = New System.Drawing.Size(105, 31)
        Me.txtSetVol.TabIndex = 41
        Me.txtSetVol.Text = "000.0"
        Me.txtSetVol.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSetCurr
        '
        Me.txtSetCurr.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSetCurr.Location = New System.Drawing.Point(211, 21)
        Me.txtSetCurr.Name = "txtSetCurr"
        Me.txtSetCurr.Size = New System.Drawing.Size(105, 31)
        Me.txtSetCurr.TabIndex = 40
        Me.txtSetCurr.Text = "000.0"
        Me.txtSetCurr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.btnSpiralONOFF)
        Me.Panel3.Controls.Add(Me.btnStepONOFF)
        Me.Panel3.Controls.Add(Me.btnLinearCirculae)
        Me.Panel3.Controls.Add(Me.Label22)
        Me.Panel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel3.Location = New System.Drawing.Point(453, 354)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(817, 97)
        Me.Panel3.TabIndex = 65
        '
        'btnSpiralONOFF
        '
        Me.btnSpiralONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.spiraloff
        Me.btnSpiralONOFF.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnSpiralONOFF.FlatAppearance.BorderSize = 0
        Me.btnSpiralONOFF.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSpiralONOFF.Location = New System.Drawing.Point(607, 15)
        Me.btnSpiralONOFF.Name = "btnSpiralONOFF"
        Me.btnSpiralONOFF.Size = New System.Drawing.Size(158, 64)
        Me.btnSpiralONOFF.TabIndex = 39
        Me.btnSpiralONOFF.UseVisualStyleBackColor = True
        '
        'btnStepONOFF
        '
        Me.btnStepONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.stepoff
        Me.btnStepONOFF.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnStepONOFF.FlatAppearance.BorderSize = 0
        Me.btnStepONOFF.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStepONOFF.Location = New System.Drawing.Point(381, 15)
        Me.btnStepONOFF.Name = "btnStepONOFF"
        Me.btnStepONOFF.Size = New System.Drawing.Size(158, 64)
        Me.btnStepONOFF.TabIndex = 37
        Me.btnStepONOFF.UseVisualStyleBackColor = True
        '
        'btnLinearCirculae
        '
        Me.btnLinearCirculae.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.circular
        Me.btnLinearCirculae.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnLinearCirculae.FlatAppearance.BorderSize = 0
        Me.btnLinearCirculae.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLinearCirculae.Location = New System.Drawing.Point(147, 13)
        Me.btnLinearCirculae.Name = "btnLinearCirculae"
        Me.btnLinearCirculae.Size = New System.Drawing.Size(158, 64)
        Me.btnLinearCirculae.TabIndex = 36
        Me.btnLinearCirculae.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(10, 40)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(123, 24)
        Me.Label22.TabIndex = 30
        Me.Label22.Text = "Sequence"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.SkyBlue
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(0, 0)
        Me.Label6.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(226, 37)
        Me.Label6.TabIndex = 48
        Me.Label6.Text = "Step Movement"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtFlt
        '
        Me.txtFlt.Location = New System.Drawing.Point(188, 677)
        Me.txtFlt.Name = "txtFlt"
        Me.txtFlt.Size = New System.Drawing.Size(114, 29)
        Me.txtFlt.TabIndex = 51
        '
        'frmjobdata
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(1276, 770)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmjobdata"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "  "
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents ShapeContainer2 As PowerPacks.ShapeContainer
    Private WithEvents ShapeContainer7 As ShapeContainer
    Private WithEvents rsMan As RectangleShape

    Private WithEvents RectangleShape1 As RectangleShape
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Private WithEvents ShapeContainer8 As ShapeContainer
    Private WithEvents ShapeContainer4 As ShapeContainer
    Friend UserControl11 As UserControl1
    Friend UserControl21 As UserControl2
    Friend UserControl41 As UserControl4
    Friend WithEvents Label6 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtShellID As TextBox
    Friend WithEvents txtNozzleRefDia As TextBox
    Friend WithEvents txtBackfaceID As TextBox
    Friend WithEvents txtBackfaceOD As TextBox
    Friend WithEvents txtPipeNozzleOD As TextBox
    Friend WithEvents txtPipeNozzleLen As TextBox
    Friend WithEvents txtFlangeID As TextBox
    Friend WithEvents txtFlangeOD As TextBox
    Friend WithEvents txtBeadShiftSpeed As TextBox
    Friend WithEvents txtBeadWidth As TextBox
    Friend WithEvents txtShellOD As TextBox
    Friend WithEvents txtPipeNozzleID As TextBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label15 As Label
    Friend WithEvents btnNozzPipeIDOL As Button
    Friend WithEvents Label21 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents btnBeadShiFWDREW As Button
    Friend WithEvents txtWeldSpeed As TextBox
    Friend WithEvents txtSetWirefeed As TextBox
    Friend WithEvents txtSetVol As TextBox
    Friend WithEvents txtSetCurr As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents btnLinearCirculae As Button
    Friend WithEvents btnSpiralONOFF As Button
    Friend WithEvents btnStepONOFF As Button
    Friend WithEvents btnPlusCurr As Button
    Friend WithEvents btnPlusWeldSpeed As Button
    Friend WithEvents btnPlusSetWirefeed As Button
    Friend WithEvents btnPlusVol As Button
    Friend WithEvents btnMinusWirefeed As Button
    Friend WithEvents btnMinusWeldSpeed As Button
    Friend WithEvents btnMinusVol As Button
    Friend WithEvents btnMinusCurr As Button
    Friend WithEvents Label23 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Wrkb1 As myControls.WRKB
    Friend WithEvents Label29 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents btnMinusWirefeed2 As Button
    Friend WithEvents btnMinusVol2 As Button
    Friend WithEvents btnMinusCurr2 As Button
    Friend WithEvents btnPlusSetWirefeed2 As Button
    Friend WithEvents btnPlusVol2 As Button
    Friend WithEvents btnPlusCurr2 As Button
    Friend WithEvents txtSetWirefeed2 As TextBox
    Friend WithEvents txtSetVol2 As TextBox
    Friend WithEvents txtSetCurr2 As TextBox
    Friend WithEvents txtFlt As TextBox
End Class
