﻿'----------------------------------
' iotESSC for L&T
' by  trapasia DigiReach @ 2017
' Consumable entry form using webservices
' 
'----------------------------------
Imports System.Data

Public Class frmConsum
    Dim proc As Process
    'Dim myservice As New SQLDB()
    Dim EMPLLOC As String = ""
    Dim ERPLNP As String = ""
    Private Sub frmConsum_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        fillform()
    End Sub
    Private Sub fillform()
        Dim err As String = ""
        lblProject.Text = gprojectno
        lblProjectName.Text = gprojectname
        lblSeam.Text = gseamno
        lblProcess.Text = gPROCESS
        lblWPS.Text = gWPSno

        Using myservice As New SQLDB()
            Try
                'myservice.timeout = 2000
                Dim z As DataTable = myservice.getEmployeeLocation(gpsno, err)
                ''t_psno, t_name, t_loca 
                For Each row As DataRow In z.Rows
                    EMPLLOC = row.Item("t_loca").trim
                Next row

                Dim z1 As DataTable = myservice.getERPLNProjectNumber(gprojectno, err)
                For Each row As DataRow In z1.Rows
                    ERPLNP = row.Item("t_cprj").trim
                Next
            Catch ex As Exception
                MessageBox.Show("Error in fillform method of frmConsum module, Error : " + ex.Message.ToString())
            End Try
        End Using

        getLayer()
    End Sub
    Private Sub btnToken_Click(sender As System.Object, e As System.EventArgs) Handles btnToken.Click
        Dim dg As New frmWaitDialog()
        gconsItem = cmbItem.SelectedValue
        gFluxItem = cmbFluxItem.SelectedValue
        If RWire.Checked = False And RFlux.Checked = False Then
            Dim result1 As String = MessageBoxEx.Show("Kindly choose any one option", "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString

        Else
            If RFlux.Checked = True Then
                gmaterialflag = 2
            ElseIf RWire.Checked = True Then
                gmaterialflag = 1

            End If
            If RFlux.Checked = True And RWire.Checked = True Then
                gmaterialflag = 3
            End If
            '  MessageBox.Show(gcaws)
            gConsBatch = ""
            gFluxBatch = ""
            Dim errret As String = ""

            Using myservice As New SQLDB()
                Try
                    'myservice.timeout = 1000
                    dg.StartPosition = FormStartPosition.CenterScreen
                    dg.Show()
                    Dim zz As Boolean = myservice.generateToken(EMPLLOC, gpsno, gprojectno, gseamno, gWPSno, gPROCESS, cmbLayer.SelectedValue, cmbSize.SelectedValue, cmbItem.SelectedValue, cmbFluxItem.SelectedValue, gmaterialflag, gstation, gshopno, gcmbno, errret)
                    dg.Close()
                    If zz = True Then
                        Dim result As String = MessageBoxEx.Show(errret & " Token Number Generated", "Token", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString
                    Else
                        Dim result As String = MessageBoxEx.Show(errret, "Token", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString
                    End If
                Catch ex As Exception
                    MessageBox.Show("Error in btnToken_Click method of frmConsum module, Error : " + ex.Message.ToString())
                End Try
            End Using
        End If
    End Sub

    Private Sub frmConsum_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Panel1.Left = (Me.Width - Panel1.Width) / 2
        Panel1.Top = (Me.Height - Panel1.Height) / 2
    End Sub
    Private Sub getLayer()
        If gOpMode = "live" Then
            Using myservice As New SQLDB()
                Try
                    Dim err As String = ""
                    'myservice.timeout = 2000
                    Dim z As DataTable = myservice.getLayerDetail(gprojectno, gseamno, gWPSno, gPROCESS, err)

                    cmbLayer.Items.Clear()
                    cmbAWS.Items.Clear()
                    cmbSize.Items.Clear()
                    cmbItem.Items.Clear()

                    'Dim disValue As String = ""
                    'Dim fldValue As String = ""

                    'Dim citems As DataTable = New DataTable()
                    'citems.Columns.Add("Display")
                    'citems.Columns.Add("Value")

                    ''Dim itemRow1 As DataRow = citems.NewRow()
                    ''itemRow1("Display") = "Select Layer"
                    ''itemRow1("Value") = ""
                    ''citems.Rows.Add(itemRow1)

                    'For Each row As DataRow In z.Rows
                    '    Dim itemRow As DataRow = citems.NewRow()
                    '    itemRow("Display") = row.Item("t_layr").trim
                    '    itemRow("Value") = row.Item("t_layr").trim
                    '    citems.Rows.Add(itemRow)
                    'Next row

                    cmbLayer.DisplayMember = "t_layr"
                    cmbLayer.ValueMember = "t_layr"
                    cmbLayer.DataSource = z
                    'cmbLayer.SelectedValue = ""
                Catch ex As Exception
                    MessageBox.Show("Error in getLayer method of frmConsum module, Error : " + ex.Message.ToString())
                End Try
            End Using
        End If
    End Sub

    Private Sub cmbLayer_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbLayer.SelectedValueChanged
        Dim disValue As String = ""
        Dim fldValue As String = ""
        Dim err As String = ""

        If gOpMode = "live" And cmbLayer.SelectedValue <> "" Then
            'Using myservice As New SQLDB()
            Using myservice As New SQLDB()
                err = ""
                ''myservice.timeout = 2000

                Dim z As DataTable = myservice.getConsumableAWSDetail(gprojectno, gseamno, gWPSno, gPROCESS, cmbLayer.SelectedValue, err)

                'disValue = ""
                'fldValue = ""

                'Dim citems As DataTable = New DataTable()
                'citems.Columns.Add("Display")
                'citems.Columns.Add("Value")

                ''Dim itemRow1 As DataRow = citems.NewRow()
                ''itemRow1("Display") = "Select AWS"
                ''itemRow1("Value") = ""
                ''citems.Rows.Add(itemRow1)

                'For Each row As DataRow In z.Rows
                '    Dim itemRow As DataRow = citems.NewRow()
                '    itemRow("Display") = row.Item("t_caws").trim
                '    itemRow("Value") = row.Item("t_caws").trim
                '    citems.Rows.Add(itemRow)
                'Next row

                cmbAWS.DisplayMember = "t_caws"
                cmbAWS.ValueMember = "t_caws"
                cmbAWS.DataSource = z
                ''cmbAWS.SelectedValue = ""


                err = ""
                'myservice.timeout = 2000

                Dim z1 As DataTable = myservice.getFluxAWSDetail(gprojectno, gseamno, gWPSno, gPROCESS, cmbLayer.SelectedValue, err)

                'disValue = ""
                'fldValue = ""

                'Dim citems1 As DataTable = New DataTable()
                'citems1.Columns.Add("Display")
                'citems1.Columns.Add("Value")

                ''Dim itemRow11 As DataRow = citems1.NewRow()
                ''itemRow11("Display") = "Select FluxAWS"
                ''itemRow11("Value") = ""
                ''citems1.Rows.Add(itemRow11)

                'For Each row As DataRow In z1.Rows
                '    Dim itemRow As DataRow = citems1.NewRow()
                '    itemRow("Display") = row.Item("t_faws").trim
                '    itemRow("Value") = row.Item("t_faws").trim
                '    citems1.Rows.Add(itemRow)
                'Next row

                cmbFluxAWS.DisplayMember = "t_faws"
                cmbFluxAWS.ValueMember = "t_faws"
                cmbFluxAWS.DataSource = z1
                gclayer = cmbLayer.SelectedValue
                'cmbFluxAWS.SelectedValue = ""
            End Using
        End If
    End Sub

    Private Sub cmbAWS_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbAWS.SelectedValueChanged
        If gOpMode = "live" Then
            If (cmbAWS.SelectedValue <> "" And cmbLayer.SelectedValue <> "") Then
                Using myservice As New SQLDB()
                    Dim err As String = ""
                    'myservice.timeout = 2000

                    Dim z As DataTable = myservice.getConsumableSizeDetail(gprojectno, gseamno, gWPSno, gPROCESS, cmbLayer.SelectedValue, cmbAWS.SelectedValue, err)

                    'Dim disValue As String = ""
                    'Dim fldValue As String = ""

                    'Dim citems As DataTable = New DataTable()
                    'citems.Columns.Add("Display")
                    'citems.Columns.Add("Value")

                    ''Dim itemRow1 As DataRow = citems.NewRow()
                    ''itemRow1("Display") = "Select Size"
                    ''itemRow1("Value") = ""
                    ''citems.Rows.Add(itemRow1)

                    'For Each row As DataRow In z.Rows
                    '    Dim itemRow As DataRow = citems.NewRow()
                    '    itemRow("Display") = row.Item("t_csiz").trim
                    '    itemRow("Value") = row.Item("t_csiz").trim
                    '    citems.Rows.Add(itemRow)
                    'Next row

                    cmbSize.DisplayMember = "t_csiz"
                    cmbSize.ValueMember = "t_csiz"
                    cmbSize.DataSource = z
                    gcaws = cmbAWS.SelectedValue
                    'cmbSize.SelectedValue = ""
                End Using
            End If
        End If
    End Sub


    Private Sub cmbFluxAWS_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbFluxAWS.SelectedValueChanged
        If gOpMode = "live" Then
            If (cmbFluxAWS.SelectedValue <> "") Then
                Using myservice As New SQLDB()
                    Dim err As String = ""
                    'myservice.timeout = 2000

                    Dim z As DataTable = myservice.getFluxItemDetail(EMPLLOC, ERPLNP, cmbFluxAWS.SelectedValue, err)

                    'Dim disValue As String = ""
                    'Dim fldValue As String = ""

                    'Dim citems As DataTable = New DataTable()
                    'citems.Columns.Add("Display")
                    'citems.Columns.Add("Value")

                    ''Dim itemRow1 As DataRow = citems.NewRow()
                    ''itemRow1("Display") = "Select Size"
                    ''itemRow1("Value") = ""
                    ''citems.Rows.Add(itemRow1)

                    'For Each row As DataRow In z.Rows
                    '    Dim itemRow As DataRow = citems.NewRow()
                    '    itemRow("Display") = row.Item("t_item").trim & " # " & row.Item("t_dsca").trim
                    '    itemRow("Value") = row.Item("t_item").trim
                    '    citems.Rows.Add(itemRow)
                    'Next row

                    cmbFluxItem.DisplayMember = "DisplayMember"
                    cmbFluxItem.ValueMember = "t_item"
                    cmbFluxItem.DataSource = z
                    'cmbFluxItem.SelectedValue = ""
                End Using
            End If
        End If
    End Sub

    Private Sub cmbSize_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbSize.SelectedValueChanged
        If gOpMode = "live" Then
            If (cmbAWS.SelectedValue <> "" And cmbSize.SelectedValue <> "") Then
                Using myservice As New SQLDB()
                    Dim err As String = ""
                    'myservice.timeout = 2000

                    Dim z As DataTable = myservice.getConsumableItemDetail(EMPLLOC, ERPLNP, cmbAWS.SelectedValue, cmbSize.SelectedValue, err)

                    'Dim disValue As String = ""
                    'Dim fldValue As String = ""

                    'Dim citems As DataTable = New DataTable()
                    'citems.Columns.Add("Display")
                    'citems.Columns.Add("Value")

                    ''Dim itemRow1 As DataRow = citems.NewRow()
                    ''itemRow1("Display") = "Select Item"
                    ''itemRow1("Value") = ""
                    ''citems.Rows.Add(itemRow1)

                    'For Each row As DataRow In z.Rows
                    '    Dim itemRow As DataRow = citems.NewRow()
                    '    itemRow("Display") = row.Item("t_item").trim & " # " & row.Item("t_dsca").trim
                    '    itemRow("Value") = row.Item("t_item").trim
                    '    citems.Rows.Add(itemRow)
                    'Next row

                    cmbItem.DisplayMember = "DisplayMember"
                    cmbItem.ValueMember = "t_item"
                    cmbItem.DataSource = z
                    'cmbItem.SelectedValue = ""

                End Using
            End If
        End If
    End Sub

    Private Sub btnNext_Click(sender As System.Object, e As System.EventArgs)
        ' MessageBox.Show(gPowersrc)
        ' Dim OBJ As New frmPass
        ' OBJ.Show()
        ' OBJ.MdiParent = MDIParent1
        'Me.Close()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Dim arg As String = gpsno & " " & """" & gwelder_nm & """"
        'Dim arg As String = "" & gpsno & " " & gprojectno & " " & gseamno & " " & gWPSno & " " & gPROCESS & " " & gwelder_nm & " " & gcaws & " " & gclayer & ""
        Dim arg As String = gWPSno & " " & """" & gprojectno & """" & " " & """" & gseamno & """" & " " & """" & gPROCESS & """" & " " & """" & gpsno & """" & " " & """" & gwelder_nm & """" & " " & """" & gcaws & """" & " " & """" & gpsno & """" & " " & """" & gclayer & """" & ""
        proc = Process.Start(gExe, arg)
        ' MessageBox.Show(gwelder_nm)
    End Sub

End Class