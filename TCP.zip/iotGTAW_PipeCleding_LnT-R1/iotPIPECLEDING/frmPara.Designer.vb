﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPara
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPara))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.txtCurStep2 = New System.Windows.Forms.TextBox()
        Me.txtVolStep2 = New System.Windows.Forms.TextBox()
        Me.txtWFStep2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtmgrightstep = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtmgleftstep = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtWelSpeeddStep = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtWFStep = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.txtTempPM = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.txtSetTemp = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.txtVolStep = New System.Windows.Forms.TextBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.txtCurStep = New System.Windows.Forms.TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.MyKB1 = New myControls.myKB()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.BtnClose = New System.Windows.Forms.Button()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.BtnSave = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.Controls.Add(Me.Panel6)
        Me.Panel1.Controls.Add(Me.Panel5)
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Location = New System.Drawing.Point(1, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1197, 713)
        Me.Panel1.TabIndex = 0
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel6.Controls.Add(Me.txtCurStep2)
        Me.Panel6.Controls.Add(Me.txtVolStep2)
        Me.Panel6.Controls.Add(Me.txtWFStep2)
        Me.Panel6.Controls.Add(Me.Label2)
        Me.Panel6.Controls.Add(Me.Label3)
        Me.Panel6.Controls.Add(Me.Label5)
        Me.Panel6.Controls.Add(Me.Label6)
        Me.Panel6.Controls.Add(Me.Label7)
        Me.Panel6.Controls.Add(Me.Label8)
        Me.Panel6.Controls.Add(Me.Label22)
        Me.Panel6.Controls.Add(Me.txtmgrightstep)
        Me.Panel6.Controls.Add(Me.Label20)
        Me.Panel6.Controls.Add(Me.txtmgleftstep)
        Me.Panel6.Controls.Add(Me.Label19)
        Me.Panel6.Controls.Add(Me.Label14)
        Me.Panel6.Controls.Add(Me.Label31)
        Me.Panel6.Controls.Add(Me.txtWelSpeeddStep)
        Me.Panel6.Controls.Add(Me.Label30)
        Me.Panel6.Controls.Add(Me.txtWFStep)
        Me.Panel6.Controls.Add(Me.Label35)
        Me.Panel6.Controls.Add(Me.Label36)
        Me.Panel6.Controls.Add(Me.txtTempPM)
        Me.Panel6.Controls.Add(Me.Label37)
        Me.Panel6.Controls.Add(Me.Label38)
        Me.Panel6.Controls.Add(Me.txtSetTemp)
        Me.Panel6.Controls.Add(Me.Label44)
        Me.Panel6.Controls.Add(Me.txtVolStep)
        Me.Panel6.Controls.Add(Me.Label51)
        Me.Panel6.Controls.Add(Me.txtCurStep)
        Me.Panel6.Controls.Add(Me.Label53)
        Me.Panel6.Location = New System.Drawing.Point(7, 8)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(947, 501)
        Me.Panel6.TabIndex = 64
        '
        'txtCurStep2
        '
        Me.txtCurStep2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCurStep2.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCurStep2.Location = New System.Drawing.Point(680, 49)
        Me.txtCurStep2.Name = "txtCurStep2"
        Me.txtCurStep2.Size = New System.Drawing.Size(89, 35)
        Me.txtCurStep2.TabIndex = 131
        Me.txtCurStep2.Text = "0"
        '
        'txtVolStep2
        '
        Me.txtVolStep2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVolStep2.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVolStep2.Location = New System.Drawing.Point(680, 91)
        Me.txtVolStep2.Name = "txtVolStep2"
        Me.txtVolStep2.Size = New System.Drawing.Size(89, 35)
        Me.txtVolStep2.TabIndex = 130
        Me.txtVolStep2.Text = "0"
        '
        'txtWFStep2
        '
        Me.txtWFStep2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWFStep2.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWFStep2.Location = New System.Drawing.Point(680, 129)
        Me.txtWFStep2.Name = "txtWFStep2"
        Me.txtWFStep2.Size = New System.Drawing.Size(89, 35)
        Me.txtWFStep2.TabIndex = 129
        Me.txtWFStep2.Text = "0"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(776, 130)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 35)
        Me.Label2.TabIndex = 128
        Me.Label2.Text = "+-"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(776, 48)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 35)
        Me.Label3.TabIndex = 127
        Me.Label3.Text = "+-"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label5.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label5.Location = New System.Drawing.Point(420, 129)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(254, 35)
        Me.Label5.TabIndex = 123
        Me.Label5.Text = "7. Wirefeed Step Value 2"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(776, 89)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 35)
        Me.Label6.TabIndex = 122
        Me.Label6.Text = "+-"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label7.Location = New System.Drawing.Point(420, 88)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(254, 35)
        Me.Label7.TabIndex = 120
        Me.Label7.Text = "6. Voltage Step Value 2"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label8.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label8.Location = New System.Drawing.Point(420, 48)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(254, 35)
        Me.Label8.TabIndex = 118
        Me.Label8.Text = "5. Current Step Value 2"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(367, 174)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(40, 35)
        Me.Label22.TabIndex = 117
        Me.Label22.Text = "+-"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtmgrightstep
        '
        Me.txtmgrightstep.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtmgrightstep.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmgrightstep.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtmgrightstep.Location = New System.Drawing.Point(274, 444)
        Me.txtmgrightstep.Name = "txtmgrightstep"
        Me.txtmgrightstep.Size = New System.Drawing.Size(58, 35)
        Me.txtmgrightstep.TabIndex = 116
        Me.txtmgrightstep.Text = "10"
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(367, 137)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(40, 35)
        Me.Label20.TabIndex = 115
        Me.Label20.Text = "+-"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtmgleftstep
        '
        Me.txtmgleftstep.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtmgleftstep.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmgleftstep.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtmgleftstep.Location = New System.Drawing.Point(274, 403)
        Me.txtmgleftstep.Name = "txtmgleftstep"
        Me.txtmgleftstep.Size = New System.Drawing.Size(58, 35)
        Me.txtmgleftstep.TabIndex = 114
        Me.txtmgleftstep.Text = "10"
        '
        'Label19
        '
        Me.Label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label19.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label19.Location = New System.Drawing.Point(19, 444)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(249, 35)
        Me.Label19.TabIndex = 113
        Me.Label19.Text = "7. ------"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label14
        '
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label14.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label14.Location = New System.Drawing.Point(19, 403)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(249, 35)
        Me.Label14.TabIndex = 112
        Me.Label14.Text = "6. ------"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label31
        '
        Me.Label31.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(367, 48)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(40, 35)
        Me.Label31.TabIndex = 111
        Me.Label31.Text = "+-"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtWelSpeeddStep
        '
        Me.txtWelSpeeddStep.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWelSpeeddStep.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWelSpeeddStep.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWelSpeeddStep.Location = New System.Drawing.Point(271, 173)
        Me.txtWelSpeeddStep.Name = "txtWelSpeeddStep"
        Me.txtWelSpeeddStep.Size = New System.Drawing.Size(97, 35)
        Me.txtWelSpeeddStep.TabIndex = 110
        Me.txtWelSpeeddStep.Text = "10"
        '
        'Label30
        '
        Me.Label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label30.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label30.Location = New System.Drawing.Point(13, 173)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(255, 35)
        Me.Label30.TabIndex = 109
        Me.Label30.Text = "4. Weld Speed Step Value 1"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtWFStep
        '
        Me.txtWFStep.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWFStep.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWFStep.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWFStep.Location = New System.Drawing.Point(271, 129)
        Me.txtWFStep.Name = "txtWFStep"
        Me.txtWFStep.Size = New System.Drawing.Size(97, 35)
        Me.txtWFStep.TabIndex = 103
        Me.txtWFStep.Text = "0"
        '
        'Label35
        '
        Me.Label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label35.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label35.Location = New System.Drawing.Point(13, 129)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(255, 35)
        Me.Label35.TabIndex = 102
        Me.Label35.Text = "3. Wirefeed Step Value 1"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label36
        '
        Me.Label36.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(367, 89)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(40, 35)
        Me.Label36.TabIndex = 101
        Me.Label36.Text = "+-"
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtTempPM
        '
        Me.txtTempPM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTempPM.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTempPM.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTempPM.Location = New System.Drawing.Point(455, 361)
        Me.txtTempPM.Name = "txtTempPM"
        Me.txtTempPM.Size = New System.Drawing.Size(58, 35)
        Me.txtTempPM.TabIndex = 100
        Me.txtTempPM.Text = "10"
        '
        'Label37
        '
        Me.Label37.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label37.Location = New System.Drawing.Point(0, 0)
        Me.Label37.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(947, 38)
        Me.Label37.TabIndex = 82
        Me.Label37.Text = "Setup"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label38
        '
        Me.Label38.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(368, 361)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(79, 35)
        Me.Label38.TabIndex = 74
        Me.Label38.Text = "Deg"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtSetTemp
        '
        Me.txtSetTemp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSetTemp.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSetTemp.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSetTemp.Location = New System.Drawing.Point(256, 361)
        Me.txtSetTemp.Name = "txtSetTemp"
        Me.txtSetTemp.Size = New System.Drawing.Size(112, 35)
        Me.txtSetTemp.TabIndex = 73
        Me.txtSetTemp.Text = "0"
        '
        'Label44
        '
        Me.Label44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label44.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label44.Location = New System.Drawing.Point(19, 361)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(234, 35)
        Me.Label44.TabIndex = 72
        Me.Label44.Text = "5. ------"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtVolStep
        '
        Me.txtVolStep.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVolStep.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVolStep.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtVolStep.Location = New System.Drawing.Point(271, 88)
        Me.txtVolStep.Name = "txtVolStep"
        Me.txtVolStep.Size = New System.Drawing.Size(97, 35)
        Me.txtVolStep.TabIndex = 68
        Me.txtVolStep.Text = "0"
        '
        'Label51
        '
        Me.Label51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label51.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label51.Location = New System.Drawing.Point(13, 88)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(255, 35)
        Me.Label51.TabIndex = 67
        Me.Label51.Text = "2. Voltage Step Value 1"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtCurStep
        '
        Me.txtCurStep.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCurStep.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCurStep.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCurStep.Location = New System.Drawing.Point(271, 48)
        Me.txtCurStep.Name = "txtCurStep"
        Me.txtCurStep.Size = New System.Drawing.Size(97, 35)
        Me.txtCurStep.TabIndex = 63
        Me.txtCurStep.Text = "0"
        '
        'Label53
        '
        Me.Label53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label53.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label53.Location = New System.Drawing.Point(13, 48)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(255, 35)
        Me.Label53.TabIndex = 62
        Me.Label53.Text = "1. Current Step Value 1"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel5.Controls.Add(Me.MyKB1)
        Me.Panel5.Location = New System.Drawing.Point(11, 516)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1176, 191)
        Me.Panel5.TabIndex = 65
        '
        'MyKB1
        '
        Me.MyKB1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MyKB1.CurrTextBox = Nothing
        Me.MyKB1.Location = New System.Drawing.Point(143, 7)
        Me.MyKB1.Margin = New System.Windows.Forms.Padding(2)
        Me.MyKB1.Name = "MyKB1"
        Me.MyKB1.Size = New System.Drawing.Size(864, 175)
        Me.MyKB1.TabIndex = 0
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel4.Controls.Add(Me.Button2)
        Me.Panel4.Controls.Add(Me.Button1)
        Me.Panel4.Controls.Add(Me.Button3)
        Me.Panel4.Controls.Add(Me.BtnClose)
        Me.Panel4.Controls.Add(Me.Label29)
        Me.Panel4.Controls.Add(Me.BtnSave)
        Me.Panel4.Location = New System.Drawing.Point(960, 9)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(227, 505)
        Me.Panel4.TabIndex = 64
        '
        'Button2
        '
        Me.Button2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button2.Location = New System.Drawing.Point(28, 231)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(185, 73)
        Me.Button2.TabIndex = 93
        Me.Button2.Text = "Alarm/Offset Setup"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Location = New System.Drawing.Point(28, 142)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(185, 73)
        Me.Button1.TabIndex = 91
        Me.Button1.Text = "IT Setting"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button3.Location = New System.Drawing.Point(28, 52)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(185, 73)
        Me.Button3.TabIndex = 90
        Me.Button3.Text = "Close Station"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'BtnClose
        '
        Me.BtnClose.BackgroundImage = CType(resources.GetObject("BtnClose.BackgroundImage"), System.Drawing.Image)
        Me.BtnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClose.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnClose.Location = New System.Drawing.Point(28, 415)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(185, 73)
        Me.BtnClose.TabIndex = 89
        Me.BtnClose.Text = "Cancel"
        Me.BtnClose.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label29.Location = New System.Drawing.Point(0, 0)
        Me.Label29.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(418, 38)
        Me.Label29.TabIndex = 82
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BtnSave
        '
        Me.BtnSave.BackgroundImage = CType(resources.GetObject("BtnSave.BackgroundImage"), System.Drawing.Image)
        Me.BtnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSave.ForeColor = System.Drawing.Color.Cornsilk
        Me.BtnSave.Location = New System.Drawing.Point(28, 324)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(185, 73)
        Me.BtnSave.TabIndex = 83
        Me.BtnSave.Text = "Save"
        Me.BtnSave.UseVisualStyleBackColor = True
        '
        'frmPara
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(1200, 711)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmPara"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmFour"
        Me.Panel1.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents BtnSave As System.Windows.Forms.Button
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents BtnClose As System.Windows.Forms.Button
    Friend WithEvents MyKB1 As myControls.myKB
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label31 As Label
    Friend WithEvents txtWelSpeeddStep As TextBox
    Friend WithEvents Label30 As Label
    Friend WithEvents txtWFStep As TextBox
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents txtTempPM As TextBox
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents txtSetTemp As TextBox
    Friend WithEvents Label44 As Label
    Friend WithEvents txtVolStep As TextBox
    Friend WithEvents Label51 As Label
    Friend WithEvents txtCurStep As TextBox
    Friend WithEvents Label53 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents txtmgrightstep As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents txtmgleftstep As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtWFStep2 As TextBox
    Friend WithEvents txtCurStep2 As TextBox
    Friend WithEvents txtVolStep2 As TextBox
End Class
