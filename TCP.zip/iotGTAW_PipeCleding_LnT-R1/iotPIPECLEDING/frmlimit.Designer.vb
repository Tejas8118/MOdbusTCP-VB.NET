﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmlimit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Wrkb1 = New myControls.WRKB()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtHomePos2 = New System.Windows.Forms.TextBox()
        Me.txtHomePos3 = New System.Windows.Forms.TextBox()
        Me.txtHomePos4 = New System.Windows.Forms.TextBox()
        Me.txtHomePos5 = New System.Windows.Forms.TextBox()
        Me.txtActPos1 = New System.Windows.Forms.TextBox()
        Me.txtActPos2 = New System.Windows.Forms.TextBox()
        Me.txtActPos3 = New System.Windows.Forms.TextBox()
        Me.txtActPos4 = New System.Windows.Forms.TextBox()
        Me.txtActPos5 = New System.Windows.Forms.TextBox()
        Me.txtHomePos1 = New System.Windows.Forms.TextBox()
        Me.btnOPR5 = New System.Windows.Forms.Button()
        Me.btnOPR4 = New System.Windows.Forms.Button()
        Me.btnOPR3 = New System.Windows.Forms.Button()
        Me.btnOPR2 = New System.Windows.Forms.Button()
        Me.btnOPR1 = New System.Windows.Forms.Button()
        Me.txtYfactor5 = New System.Windows.Forms.TextBox()
        Me.txtYfactor2 = New System.Windows.Forms.TextBox()
        Me.txtYfactor3 = New System.Windows.Forms.TextBox()
        Me.txtYfactor4 = New System.Windows.Forms.TextBox()
        Me.txtXfactor2 = New System.Windows.Forms.TextBox()
        Me.txtXfactor3 = New System.Windows.Forms.TextBox()
        Me.txtXfactor4 = New System.Windows.Forms.TextBox()
        Me.txtXfactor5 = New System.Windows.Forms.TextBox()
        Me.txtYfactor1 = New System.Windows.Forms.TextBox()
        Me.txtFwdLimit2 = New System.Windows.Forms.TextBox()
        Me.txtFwdLimit3 = New System.Windows.Forms.TextBox()
        Me.txtFwdLimit4 = New System.Windows.Forms.TextBox()
        Me.txtFwdLimit5 = New System.Windows.Forms.TextBox()
        Me.txtRevLimit1 = New System.Windows.Forms.TextBox()
        Me.txtRevLimit2 = New System.Windows.Forms.TextBox()
        Me.txtRevLimit3 = New System.Windows.Forms.TextBox()
        Me.txtRevLimit4 = New System.Windows.Forms.TextBox()
        Me.txtRevLimit5 = New System.Windows.Forms.TextBox()
        Me.txtXfactor1 = New System.Windows.Forms.TextBox()
        Me.txtFwdLimit1 = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Location = New System.Drawing.Point(10, 9)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1044, 553)
        Me.Panel1.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Location = New System.Drawing.Point(855, 522)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(91, 31)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.Panel2.Controls.Add(Me.Wrkb1)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Controls.Add(Me.Label22)
        Me.Panel2.Controls.Add(Me.Label23)
        Me.Panel2.Controls.Add(Me.Label24)
        Me.Panel2.Controls.Add(Me.Label25)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.Label19)
        Me.Panel2.Controls.Add(Me.Label20)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.txtHomePos2)
        Me.Panel2.Controls.Add(Me.txtHomePos3)
        Me.Panel2.Controls.Add(Me.txtHomePos4)
        Me.Panel2.Controls.Add(Me.txtHomePos5)
        Me.Panel2.Controls.Add(Me.txtActPos1)
        Me.Panel2.Controls.Add(Me.txtActPos2)
        Me.Panel2.Controls.Add(Me.txtActPos3)
        Me.Panel2.Controls.Add(Me.txtActPos4)
        Me.Panel2.Controls.Add(Me.txtActPos5)
        Me.Panel2.Controls.Add(Me.txtHomePos1)
        Me.Panel2.Controls.Add(Me.btnOPR5)
        Me.Panel2.Controls.Add(Me.btnOPR4)
        Me.Panel2.Controls.Add(Me.btnOPR3)
        Me.Panel2.Controls.Add(Me.btnOPR2)
        Me.Panel2.Controls.Add(Me.btnOPR1)
        Me.Panel2.Controls.Add(Me.txtYfactor5)
        Me.Panel2.Controls.Add(Me.txtYfactor2)
        Me.Panel2.Controls.Add(Me.txtYfactor3)
        Me.Panel2.Controls.Add(Me.txtYfactor4)
        Me.Panel2.Controls.Add(Me.txtXfactor2)
        Me.Panel2.Controls.Add(Me.txtXfactor3)
        Me.Panel2.Controls.Add(Me.txtXfactor4)
        Me.Panel2.Controls.Add(Me.txtXfactor5)
        Me.Panel2.Controls.Add(Me.txtYfactor1)
        Me.Panel2.Controls.Add(Me.txtFwdLimit2)
        Me.Panel2.Controls.Add(Me.txtFwdLimit3)
        Me.Panel2.Controls.Add(Me.txtFwdLimit4)
        Me.Panel2.Controls.Add(Me.txtFwdLimit5)
        Me.Panel2.Controls.Add(Me.txtRevLimit1)
        Me.Panel2.Controls.Add(Me.txtRevLimit2)
        Me.Panel2.Controls.Add(Me.txtRevLimit3)
        Me.Panel2.Controls.Add(Me.txtRevLimit4)
        Me.Panel2.Controls.Add(Me.txtRevLimit5)
        Me.Panel2.Controls.Add(Me.txtXfactor1)
        Me.Panel2.Controls.Add(Me.txtFwdLimit1)
        Me.Panel2.Controls.Add(Me.Label45)
        Me.Panel2.Controls.Add(Me.Label43)
        Me.Panel2.Controls.Add(Me.Label44)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label36)
        Me.Panel2.Controls.Add(Me.Label35)
        Me.Panel2.Controls.Add(Me.Label18)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Location = New System.Drawing.Point(12, 9)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1019, 512)
        Me.Panel2.TabIndex = 0
        '
        'Wrkb1
        '
        Me.Wrkb1.CurrTextBox = Nothing
        Me.Wrkb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Wrkb1.Location = New System.Drawing.Point(390, 197)
        Me.Wrkb1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Wrkb1.Name = "Wrkb1"
        Me.Wrkb1.Size = New System.Drawing.Size(340, 307)
        Me.Wrkb1.TabIndex = 373
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(759, 476)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(124, 20)
        Me.Label21.TabIndex = 398
        Me.Label21.Text = "Axis-5-R-AXIS"
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(759, 435)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(105, 20)
        Me.Label22.TabIndex = 397
        Me.Label22.Text = "Axis-4-AVC-2"
        '
        'Label23
        '
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(759, 397)
        Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(108, 20)
        Me.Label23.TabIndex = 396
        Me.Label23.Text = "Axis-3-AVC-1"
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(759, 314)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(111, 20)
        Me.Label24.TabIndex = 395
        Me.Label24.Text = "Axis-1-X-AXIS"
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(759, 355)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(117, 20)
        Me.Label25.TabIndex = 394
        Me.Label25.Text = "Axis-2-SPARE"
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(597, 220)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(124, 20)
        Me.Label15.TabIndex = 393
        Me.Label15.Text = "Axis-5-R-AXIS"
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(597, 179)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(105, 20)
        Me.Label16.TabIndex = 392
        Me.Label16.Text = "Axis-4-AVC-2"
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(597, 141)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(108, 20)
        Me.Label17.TabIndex = 391
        Me.Label17.Text = "Axis-3-AVC-1"
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(597, 58)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(111, 20)
        Me.Label19.TabIndex = 390
        Me.Label19.Text = "Axis-1-X-AXIS"
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(597, 99)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(117, 20)
        Me.Label20.TabIndex = 389
        Me.Label20.Text = "Axis-2-SPARE"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(18, 483)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(124, 20)
        Me.Label5.TabIndex = 388
        Me.Label5.Text = "Axis-5-R-AXIS"
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(18, 442)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(105, 20)
        Me.Label11.TabIndex = 387
        Me.Label11.Text = "Axis-4-AVC-2"
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(18, 404)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(108, 20)
        Me.Label12.TabIndex = 386
        Me.Label12.Text = "Axis-3-AVC-1"
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(18, 321)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(111, 20)
        Me.Label13.TabIndex = 385
        Me.Label13.Text = "Axis-1-X-AXIS"
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(18, 362)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(117, 20)
        Me.Label14.TabIndex = 384
        Me.Label14.Text = "Axis-2-SPARE"
        '
        'txtHomePos2
        '
        Me.txtHomePos2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtHomePos2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHomePos2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtHomePos2.Location = New System.Drawing.Point(732, 94)
        Me.txtHomePos2.Name = "txtHomePos2"
        Me.txtHomePos2.Size = New System.Drawing.Size(100, 31)
        Me.txtHomePos2.TabIndex = 383
        Me.txtHomePos2.Text = "000.00"
        '
        'txtHomePos3
        '
        Me.txtHomePos3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtHomePos3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHomePos3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtHomePos3.Location = New System.Drawing.Point(732, 136)
        Me.txtHomePos3.Name = "txtHomePos3"
        Me.txtHomePos3.Size = New System.Drawing.Size(100, 31)
        Me.txtHomePos3.TabIndex = 382
        Me.txtHomePos3.Text = "000.00"
        '
        'txtHomePos4
        '
        Me.txtHomePos4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtHomePos4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHomePos4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtHomePos4.Location = New System.Drawing.Point(732, 175)
        Me.txtHomePos4.Name = "txtHomePos4"
        Me.txtHomePos4.Size = New System.Drawing.Size(100, 31)
        Me.txtHomePos4.TabIndex = 381
        Me.txtHomePos4.Text = "000.00"
        '
        'txtHomePos5
        '
        Me.txtHomePos5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtHomePos5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHomePos5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtHomePos5.Location = New System.Drawing.Point(732, 218)
        Me.txtHomePos5.Name = "txtHomePos5"
        Me.txtHomePos5.Size = New System.Drawing.Size(100, 31)
        Me.txtHomePos5.TabIndex = 380
        Me.txtHomePos5.Text = "000.00"
        '
        'txtActPos1
        '
        Me.txtActPos1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtActPos1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtActPos1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtActPos1.Location = New System.Drawing.Point(869, 53)
        Me.txtActPos1.Name = "txtActPos1"
        Me.txtActPos1.Size = New System.Drawing.Size(100, 31)
        Me.txtActPos1.TabIndex = 379
        Me.txtActPos1.Text = "000.00"
        '
        'txtActPos2
        '
        Me.txtActPos2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtActPos2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtActPos2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtActPos2.Location = New System.Drawing.Point(869, 94)
        Me.txtActPos2.Name = "txtActPos2"
        Me.txtActPos2.Size = New System.Drawing.Size(100, 31)
        Me.txtActPos2.TabIndex = 378
        Me.txtActPos2.Text = "000.00"
        '
        'txtActPos3
        '
        Me.txtActPos3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtActPos3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtActPos3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtActPos3.Location = New System.Drawing.Point(869, 136)
        Me.txtActPos3.Name = "txtActPos3"
        Me.txtActPos3.Size = New System.Drawing.Size(100, 31)
        Me.txtActPos3.TabIndex = 377
        Me.txtActPos3.Text = "000.00"
        '
        'txtActPos4
        '
        Me.txtActPos4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtActPos4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtActPos4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtActPos4.Location = New System.Drawing.Point(869, 175)
        Me.txtActPos4.Name = "txtActPos4"
        Me.txtActPos4.Size = New System.Drawing.Size(100, 31)
        Me.txtActPos4.TabIndex = 376
        Me.txtActPos4.Text = "000.00"
        '
        'txtActPos5
        '
        Me.txtActPos5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtActPos5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtActPos5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtActPos5.Location = New System.Drawing.Point(869, 218)
        Me.txtActPos5.Name = "txtActPos5"
        Me.txtActPos5.Size = New System.Drawing.Size(100, 31)
        Me.txtActPos5.TabIndex = 375
        Me.txtActPos5.Text = "000.00"
        '
        'txtHomePos1
        '
        Me.txtHomePos1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtHomePos1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHomePos1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtHomePos1.Location = New System.Drawing.Point(732, 53)
        Me.txtHomePos1.Name = "txtHomePos1"
        Me.txtHomePos1.Size = New System.Drawing.Size(100, 31)
        Me.txtHomePos1.TabIndex = 374
        Me.txtHomePos1.Text = "000.00"
        '
        'btnOPR5
        '
        Me.btnOPR5.BackColor = System.Drawing.Color.DarkSalmon
        Me.btnOPR5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOPR5.Location = New System.Drawing.Point(900, 472)
        Me.btnOPR5.Name = "btnOPR5"
        Me.btnOPR5.Size = New System.Drawing.Size(82, 32)
        Me.btnOPR5.TabIndex = 372
        Me.btnOPR5.Text = "OPR-5"
        Me.btnOPR5.UseVisualStyleBackColor = False
        '
        'btnOPR4
        '
        Me.btnOPR4.BackColor = System.Drawing.Color.DarkSalmon
        Me.btnOPR4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOPR4.Location = New System.Drawing.Point(900, 427)
        Me.btnOPR4.Name = "btnOPR4"
        Me.btnOPR4.Size = New System.Drawing.Size(82, 32)
        Me.btnOPR4.TabIndex = 371
        Me.btnOPR4.Text = "OPR-4"
        Me.btnOPR4.UseVisualStyleBackColor = False
        '
        'btnOPR3
        '
        Me.btnOPR3.BackColor = System.Drawing.Color.DarkSalmon
        Me.btnOPR3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOPR3.Location = New System.Drawing.Point(900, 385)
        Me.btnOPR3.Name = "btnOPR3"
        Me.btnOPR3.Size = New System.Drawing.Size(82, 32)
        Me.btnOPR3.TabIndex = 370
        Me.btnOPR3.Text = "OPR-3"
        Me.btnOPR3.UseVisualStyleBackColor = False
        '
        'btnOPR2
        '
        Me.btnOPR2.BackColor = System.Drawing.Color.DarkSalmon
        Me.btnOPR2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOPR2.Location = New System.Drawing.Point(900, 343)
        Me.btnOPR2.Name = "btnOPR2"
        Me.btnOPR2.Size = New System.Drawing.Size(82, 32)
        Me.btnOPR2.TabIndex = 369
        Me.btnOPR2.Text = "OPR-2"
        Me.btnOPR2.UseVisualStyleBackColor = False
        '
        'btnOPR1
        '
        Me.btnOPR1.BackColor = System.Drawing.Color.DarkSalmon
        Me.btnOPR1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOPR1.Location = New System.Drawing.Point(900, 305)
        Me.btnOPR1.Name = "btnOPR1"
        Me.btnOPR1.Size = New System.Drawing.Size(82, 32)
        Me.btnOPR1.TabIndex = 368
        Me.btnOPR1.Text = "OPR-1"
        Me.btnOPR1.UseVisualStyleBackColor = False
        '
        'txtYfactor5
        '
        Me.txtYfactor5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtYfactor5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYfactor5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtYfactor5.Location = New System.Drawing.Point(284, 479)
        Me.txtYfactor5.Name = "txtYfactor5"
        Me.txtYfactor5.Size = New System.Drawing.Size(100, 31)
        Me.txtYfactor5.TabIndex = 367
        Me.txtYfactor5.Text = "000.00"
        '
        'txtYfactor2
        '
        Me.txtYfactor2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtYfactor2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYfactor2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtYfactor2.Location = New System.Drawing.Point(284, 353)
        Me.txtYfactor2.Name = "txtYfactor2"
        Me.txtYfactor2.Size = New System.Drawing.Size(100, 31)
        Me.txtYfactor2.TabIndex = 366
        Me.txtYfactor2.Text = "000.00"
        '
        'txtYfactor3
        '
        Me.txtYfactor3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtYfactor3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYfactor3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtYfactor3.Location = New System.Drawing.Point(284, 397)
        Me.txtYfactor3.Name = "txtYfactor3"
        Me.txtYfactor3.Size = New System.Drawing.Size(100, 31)
        Me.txtYfactor3.TabIndex = 365
        Me.txtYfactor3.Text = "000.00"
        '
        'txtYfactor4
        '
        Me.txtYfactor4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtYfactor4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYfactor4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtYfactor4.Location = New System.Drawing.Point(284, 439)
        Me.txtYfactor4.Name = "txtYfactor4"
        Me.txtYfactor4.Size = New System.Drawing.Size(100, 31)
        Me.txtYfactor4.TabIndex = 364
        Me.txtYfactor4.Text = "000.00"
        '
        'txtXfactor2
        '
        Me.txtXfactor2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtXfactor2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtXfactor2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtXfactor2.Location = New System.Drawing.Point(152, 353)
        Me.txtXfactor2.Name = "txtXfactor2"
        Me.txtXfactor2.Size = New System.Drawing.Size(100, 31)
        Me.txtXfactor2.TabIndex = 363
        Me.txtXfactor2.Text = "000.00"
        '
        'txtXfactor3
        '
        Me.txtXfactor3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtXfactor3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtXfactor3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtXfactor3.Location = New System.Drawing.Point(152, 397)
        Me.txtXfactor3.Name = "txtXfactor3"
        Me.txtXfactor3.Size = New System.Drawing.Size(100, 31)
        Me.txtXfactor3.TabIndex = 362
        Me.txtXfactor3.Text = "000.00"
        '
        'txtXfactor4
        '
        Me.txtXfactor4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtXfactor4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtXfactor4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtXfactor4.Location = New System.Drawing.Point(152, 439)
        Me.txtXfactor4.Name = "txtXfactor4"
        Me.txtXfactor4.Size = New System.Drawing.Size(100, 31)
        Me.txtXfactor4.TabIndex = 361
        Me.txtXfactor4.Text = "000.00"
        '
        'txtXfactor5
        '
        Me.txtXfactor5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtXfactor5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtXfactor5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtXfactor5.Location = New System.Drawing.Point(152, 479)
        Me.txtXfactor5.Name = "txtXfactor5"
        Me.txtXfactor5.Size = New System.Drawing.Size(100, 31)
        Me.txtXfactor5.TabIndex = 360
        Me.txtXfactor5.Text = "000.00"
        '
        'txtYfactor1
        '
        Me.txtYfactor1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtYfactor1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYfactor1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtYfactor1.Location = New System.Drawing.Point(284, 312)
        Me.txtYfactor1.Name = "txtYfactor1"
        Me.txtYfactor1.Size = New System.Drawing.Size(100, 31)
        Me.txtYfactor1.TabIndex = 359
        Me.txtYfactor1.Text = "000.00"
        '
        'txtFwdLimit2
        '
        Me.txtFwdLimit2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtFwdLimit2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFwdLimit2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtFwdLimit2.Location = New System.Drawing.Point(152, 99)
        Me.txtFwdLimit2.Name = "txtFwdLimit2"
        Me.txtFwdLimit2.Size = New System.Drawing.Size(100, 31)
        Me.txtFwdLimit2.TabIndex = 358
        Me.txtFwdLimit2.Text = "000.00"
        '
        'txtFwdLimit3
        '
        Me.txtFwdLimit3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtFwdLimit3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFwdLimit3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtFwdLimit3.Location = New System.Drawing.Point(152, 141)
        Me.txtFwdLimit3.Name = "txtFwdLimit3"
        Me.txtFwdLimit3.Size = New System.Drawing.Size(100, 31)
        Me.txtFwdLimit3.TabIndex = 357
        Me.txtFwdLimit3.Text = "000.00"
        '
        'txtFwdLimit4
        '
        Me.txtFwdLimit4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtFwdLimit4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFwdLimit4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtFwdLimit4.Location = New System.Drawing.Point(152, 180)
        Me.txtFwdLimit4.Name = "txtFwdLimit4"
        Me.txtFwdLimit4.Size = New System.Drawing.Size(100, 31)
        Me.txtFwdLimit4.TabIndex = 356
        Me.txtFwdLimit4.Text = "000.00"
        '
        'txtFwdLimit5
        '
        Me.txtFwdLimit5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtFwdLimit5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFwdLimit5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtFwdLimit5.Location = New System.Drawing.Point(152, 223)
        Me.txtFwdLimit5.Name = "txtFwdLimit5"
        Me.txtFwdLimit5.Size = New System.Drawing.Size(100, 31)
        Me.txtFwdLimit5.TabIndex = 355
        Me.txtFwdLimit5.Text = "000.00"
        '
        'txtRevLimit1
        '
        Me.txtRevLimit1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtRevLimit1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRevLimit1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtRevLimit1.Location = New System.Drawing.Point(283, 58)
        Me.txtRevLimit1.Name = "txtRevLimit1"
        Me.txtRevLimit1.Size = New System.Drawing.Size(100, 31)
        Me.txtRevLimit1.TabIndex = 354
        Me.txtRevLimit1.Text = "000.00"
        '
        'txtRevLimit2
        '
        Me.txtRevLimit2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtRevLimit2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRevLimit2.ForeColor = System.Drawing.SystemColors.Info
        Me.txtRevLimit2.Location = New System.Drawing.Point(283, 99)
        Me.txtRevLimit2.Name = "txtRevLimit2"
        Me.txtRevLimit2.Size = New System.Drawing.Size(100, 31)
        Me.txtRevLimit2.TabIndex = 353
        Me.txtRevLimit2.Text = "000.00"
        '
        'txtRevLimit3
        '
        Me.txtRevLimit3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtRevLimit3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRevLimit3.ForeColor = System.Drawing.SystemColors.Info
        Me.txtRevLimit3.Location = New System.Drawing.Point(283, 141)
        Me.txtRevLimit3.Name = "txtRevLimit3"
        Me.txtRevLimit3.Size = New System.Drawing.Size(100, 31)
        Me.txtRevLimit3.TabIndex = 352
        Me.txtRevLimit3.Text = "000.00"
        '
        'txtRevLimit4
        '
        Me.txtRevLimit4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtRevLimit4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRevLimit4.ForeColor = System.Drawing.SystemColors.Info
        Me.txtRevLimit4.Location = New System.Drawing.Point(283, 180)
        Me.txtRevLimit4.Name = "txtRevLimit4"
        Me.txtRevLimit4.Size = New System.Drawing.Size(100, 31)
        Me.txtRevLimit4.TabIndex = 351
        Me.txtRevLimit4.Text = "000.00"
        '
        'txtRevLimit5
        '
        Me.txtRevLimit5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtRevLimit5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRevLimit5.ForeColor = System.Drawing.SystemColors.Info
        Me.txtRevLimit5.Location = New System.Drawing.Point(283, 223)
        Me.txtRevLimit5.Name = "txtRevLimit5"
        Me.txtRevLimit5.Size = New System.Drawing.Size(100, 31)
        Me.txtRevLimit5.TabIndex = 350
        Me.txtRevLimit5.Text = "000.00"
        '
        'txtXfactor1
        '
        Me.txtXfactor1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtXfactor1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtXfactor1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtXfactor1.Location = New System.Drawing.Point(152, 312)
        Me.txtXfactor1.Name = "txtXfactor1"
        Me.txtXfactor1.Size = New System.Drawing.Size(100, 31)
        Me.txtXfactor1.TabIndex = 349
        Me.txtXfactor1.Text = "000.00"
        '
        'txtFwdLimit1
        '
        Me.txtFwdLimit1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtFwdLimit1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFwdLimit1.ForeColor = System.Drawing.SystemColors.Info
        Me.txtFwdLimit1.Location = New System.Drawing.Point(152, 58)
        Me.txtFwdLimit1.Name = "txtFwdLimit1"
        Me.txtFwdLimit1.Size = New System.Drawing.Size(100, 31)
        Me.txtFwdLimit1.TabIndex = 348
        Me.txtFwdLimit1.Text = "000.00"
        '
        'Label45
        '
        Me.Label45.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label45.Location = New System.Drawing.Point(528, 2)
        Me.Label45.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(489, 24)
        Me.Label45.TabIndex = 342
        Me.Label45.Text = "Axis Home Position"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label43
        '
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.Red
        Me.Label43.Location = New System.Drawing.Point(878, 28)
        Me.Label43.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(76, 20)
        Me.Label43.TabIndex = 326
        Me.Label43.Text = "ACT POS"
        '
        'Label44
        '
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.Red
        Me.Label44.Location = New System.Drawing.Point(742, 28)
        Me.Label44.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(90, 20)
        Me.Label44.TabIndex = 325
        Me.Label44.Text = "HOME POS"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(295, 293)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(89, 20)
        Me.Label1.TabIndex = 309
        Me.Label1.Text = "Y-FACTOR"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Red
        Me.Label3.Location = New System.Drawing.Point(149, 293)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(89, 20)
        Me.Label3.TabIndex = 308
        Me.Label3.Text = "X-FACTOR"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(18, 224)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(124, 20)
        Me.Label6.TabIndex = 307
        Me.Label6.Text = "Axis-5-R-AXIS"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(18, 183)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(105, 20)
        Me.Label7.TabIndex = 306
        Me.Label7.Text = "Axis-4-AVC-2"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(18, 145)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(108, 20)
        Me.Label8.TabIndex = 305
        Me.Label8.Text = "Axis-3-AVC-1"
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(18, 62)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(111, 20)
        Me.Label9.TabIndex = 304
        Me.Label9.Text = "Axis-1-X-AXIS"
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(18, 103)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(117, 20)
        Me.Label10.TabIndex = 303
        Me.Label10.Text = "Axis-2-SPARE"
        '
        'Label36
        '
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Red
        Me.Label36.Location = New System.Drawing.Point(294, 31)
        Me.Label36.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(89, 20)
        Me.Label36.TabIndex = 302
        Me.Label36.Text = "REV LIMIT"
        '
        'Label35
        '
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Red
        Me.Label35.Location = New System.Drawing.Point(149, 31)
        Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(89, 20)
        Me.Label35.TabIndex = 301
        Me.Label35.Text = "FWD LIMIT"
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label18.Location = New System.Drawing.Point(2, 3)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(512, 24)
        Me.Label18.TabIndex = 284
        Me.Label18.Text = "Axis Software Limits"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(531, 269)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(461, 24)
        Me.Label4.TabIndex = 277
        Me.Label4.Text = "Analog Output "
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(-3, 266)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(517, 24)
        Me.Label2.TabIndex = 276
        Me.Label2.Text = "Axis Calibration Factor"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'Timer2
        '
        Me.Timer2.Interval = 200
        '
        'frmlimit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1068, 573)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmlimit"
        Me.Text = "frmlimit"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label36 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents txtFwdLimit1 As TextBox
    Friend WithEvents txtYfactor5 As TextBox
    Friend WithEvents txtYfactor2 As TextBox
    Friend WithEvents txtYfactor3 As TextBox
    Friend WithEvents txtYfactor4 As TextBox
    Friend WithEvents txtXfactor2 As TextBox
    Friend WithEvents txtXfactor3 As TextBox
    Friend WithEvents txtXfactor4 As TextBox
    Friend WithEvents txtXfactor5 As TextBox
    Friend WithEvents txtYfactor1 As TextBox
    Friend WithEvents txtFwdLimit2 As TextBox
    Friend WithEvents txtFwdLimit3 As TextBox
    Friend WithEvents txtFwdLimit4 As TextBox
    Friend WithEvents txtFwdLimit5 As TextBox
    Friend WithEvents txtRevLimit1 As TextBox
    Friend WithEvents txtRevLimit2 As TextBox
    Friend WithEvents txtRevLimit3 As TextBox
    Friend WithEvents txtRevLimit4 As TextBox
    Friend WithEvents txtRevLimit5 As TextBox
    Friend WithEvents txtXfactor1 As TextBox
    Friend WithEvents btnOPR5 As Button
    Friend WithEvents btnOPR4 As Button
    Friend WithEvents btnOPR3 As Button
    Friend WithEvents btnOPR2 As Button
    Friend WithEvents btnOPR1 As Button
    Friend WithEvents Wrkb1 As myControls.WRKB
    Friend WithEvents txtHomePos2 As TextBox
    Friend WithEvents txtHomePos3 As TextBox
    Friend WithEvents txtHomePos4 As TextBox
    Friend WithEvents txtHomePos5 As TextBox
    Friend WithEvents txtActPos1 As TextBox
    Friend WithEvents txtActPos2 As TextBox
    Friend WithEvents txtActPos3 As TextBox
    Friend WithEvents txtActPos4 As TextBox
    Friend WithEvents txtActPos5 As TextBox
    Friend WithEvents txtHomePos1 As TextBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Label5 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
End Class
