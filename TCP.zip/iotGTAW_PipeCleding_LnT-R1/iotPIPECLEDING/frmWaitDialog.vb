﻿Public Class frmWaitDialog
    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub frmWaitDialog_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' this.Location = new Point(200, 200);
        Me.StartPosition = FormStartPosition.CenterScreen
    End Sub


End Class