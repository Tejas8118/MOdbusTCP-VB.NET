﻿Public Class UserControl3
    Dim tx As String = ""
    Dim rx As String = ""


    Private Sub btnesscflux_touchdn(ByVal sender As Object, ByVal e As Windows.Input.TouchEventArgs) Handles btnesscFlux.TouchEnter
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/fluxon.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnesscFlux.Background = imgbrush
        If isConnection = True Then
            tx = "02 05 00 E5 FF 00 9D FE"
            rx = txComA(tx, 50)
            'writeLog("|Flux |TX:" & tx & " |RX:" & rx)
        End If
    End Sub
    Private Sub btnesscflux_TouchEnter(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnesscFlux.TouchEnter
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/flux.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnesscFlux.Background = imgbrush
        If isConnection = True Then
            tx = "02 05 00 E5 00 00 DC 0E"
            rx = txComA(tx, 50)
            'writeLog("|Flux |TX:" & tx & " |RX:" & rx)
        End If
    End Sub
    Private Sub btnesscdn_touchdn(ByVal sender As Object, ByVal e As Windows.Input.TouchEventArgs) Handles btnesscdn.TouchEnter
        'btnesscup.TouchEnter execution
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/upE.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnesscup.Background = imgbrush

        'btnesscdn.TouchEnter execution
        Dim imgsrc1 As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/dnon.png"))
        Dim imgbrush1 As New System.Windows.Media.ImageBrush(imgsrc1)
        btnesscdn.Background = imgbrush1

        If isConnection = True Then

            'btnesscdn.TouchEnter execution
            tx = "02 05 00 E4 FF 00 CC 3E"
            rx = txComA(tx, 50)
            'writeLog("|ESSCdnP |TX:" & tx & " |RX:" & rx)
        End If
    End Sub
    Private Sub btnesscdn_TouchEnter(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnesscdn.TouchEnter
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/dnE.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnesscdn.Background = imgbrush

        If isConnection = True Then
            tx = "02 05 00 E4 00 00 8D CE"
            rx = txComA(tx, 50)
            'writeLog("|ESSCdnP |TX:" & tx & " |RX:" & rx)
        End If
    End Sub
    Private Sub btnesscup_touchdn(ByVal sender As Object, ByVal e As Windows.Input.TouchEventArgs) Handles btnesscup.TouchEnter
        'btnesscdn.TouchEnter execution
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/dnE.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnesscdn.Background = imgbrush

        'btnesscup.TouchEnter execution
        Dim imgsrc1 As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/upon.png"))
        Dim imgbrush1 As New System.Windows.Media.ImageBrush(imgsrc1)
        btnesscup.Background = imgbrush1

        If isConnection = True Then

            'btnesscup.TouchEnter execution
            tx = "02 05 00 E3 FF 00 7D FF"
            rx = txComA(tx, 50)
            'writeLog("|ESSCupP |TX:" & tx & " |RX:" & rx)
        End If
    End Sub
    Private Sub btnesscup_TouchEnter(sender As Object, e As Windows.Input.TouchEventArgs) Handles btnesscup.TouchEnter
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/upE.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnesscup.Background = imgbrush
        If isConnection = True Then
            tx = "02 05 00 E3 00 00 3C 0F"
            rx = txComA(tx, 50)
            'writeLog("|ESSCupR |TX:" & tx & " |RX:" & rx)
        End If
    End Sub


End Class
