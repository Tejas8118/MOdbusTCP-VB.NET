﻿Imports Microsoft.VisualBasic.PowerPacks

Imports System.Data
Imports System.Text

Public Class frmjobdata
    Dim rs As New Resizer
    'Dim phs As String = "man"
    Dim cscautofwd As Integer = 1
    Dim cscautorev As Integer = 1
    Dim tx As String = ""
    Dim rx As String = ""

    Dim plcinstrg As String = ""
    Dim digits1() As Integer
    Dim digits2() As Integer
    Dim digits3() As Integer
    Dim digits4() As Integer
    Dim digits5() As Integer
    Dim digits6() As Integer
    Dim digits7() As Integer
    Dim digits8() As Integer
    Dim digits9() As Integer
    Dim digits10() As Integer
    Dim errno As Integer = 0

    Dim y As Integer = 0
    Dim y1 As Double = 0.0

    Private Sub frmjobdata_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        rs.FindAllControls(Me)

        Me.WindowState = FormWindowState.Maximized

        'Timer1.Interval = 1000
        'Timer1.Enabled = True
        Wrkb1.Visible = False


    End Sub
    Private Sub Frmjobdata_Activated(sender As Object, e As System.EventArgs) Handles Me.Activated
        ''////////   Data Read Function /////
        objJobData.Togleread()
        objJobData.Analogread2()
    End Sub
    Private Sub frmjobdata_Resize(sender As System.Object, e As System.EventArgs) Handles Me.Resize
        rs.ResizeAllControls(Me)
        Wrkb1.Visible = False

    End Sub

    Public Sub Togleread()
        Try
            errno = 0
            ' Dim y As Integer

            ' Dim y1 As Double
            If isConnection = True Then

                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 01 90 00 03", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(6) = "02" And x1(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x1(10) & x1(9)))
                        digits1 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 1
                        ''''''''' check condition
                        If digits1(0) = 1 Then
                            btnNozzPipeIDOL.BackgroundImage = Global.iotPIPECLEDING.My.Resources._on
                            btnNozzPipeIDOL.Tag = 1
                        Else
                            btnNozzPipeIDOL.BackgroundImage = Global.iotPIPECLEDING.My.Resources.off
                            btnNozzPipeIDOL.Tag = 0
                        End If

                        'If digits1(1) = 1 Then
                        '    btnFlangeOL.BackgroundImage = Global.iotHORIZONTALOL.My.Resources._on
                        '    btnFlangeOL.Tag = 1
                        'Else
                        '    btnFlangeOL.BackgroundImage = Global.iotHORIZONTALOL.My.Resources.off
                        '    btnFlangeOL.Tag = 0
                        'End If

                        'If digits1(2) = 1 Then
                        '    btnBackfaceOL.BackgroundImage = Global.iotHORIZONTALOL.My.Resources._on
                        '    btnBackfaceOL.Tag = 1
                        'Else
                        '    btnBackfaceOL.BackgroundImage = Global.iotHORIZONTALOL.My.Resources.off
                        '    btnBackfaceOL.Tag = 0
                        'End If

                    End If
                End If

                ''////////////////////////////////////
                '''''  Shift direction read
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 01 9A 00 03", 50)
                Dim x2() As String = plcinstrg.Split(" "c)
                If x2.Count >= 8 Then
                    If x2(6) = "02" And x2(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x2(10) & x2(9)))
                        digits2 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 2
                        ''check condition

                        If digits2(0) = 1 Then
                            btnBeadShiFWDREW.BackgroundImage = Global.iotPIPECLEDING.My.Resources.fwd
                            btnBeadShiFWDREW.Tag = 1
                        Else
                            btnBeadShiFWDREW.BackgroundImage = Global.iotPIPECLEDING.My.Resources.rew
                            btnBeadShiFWDREW.Tag = 0
                        End If

                        'If digits2(1) = 1 Then
                        '    btnBeadShiDirINOUT.BackgroundImage = Global.iotHORIZONTALOL.My.Resources.in2
                        '    btnBeadShiDirINOUT.Tag = 1
                        'Else
                        '    btnBeadShiDirINOUT.BackgroundImage = Global.iotHORIZONTALOL.My.Resources.out2
                        '    btnBeadShiDirINOUT.Tag = 0
                        'End If

                        'If digits2(2) = 1 Then
                        '    btnBeadShiDirFWDREV.BackgroundImage = Global.iotHORIZONTALOL.My.Resources.fwd
                        '    btnBeadShiDirFWDREV.Tag = 1
                        'Else
                        '    btnBeadShiDirFWDREV.BackgroundImage = Global.iotHORIZONTALOL.My.Resources.rew
                        '    btnBeadShiDirFWDREV.Tag = 0
                        'End If


                    End If
                End If


                ''  step read
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 01 FE 00 01", 50)
                Dim x4() As String = plcinstrg.Split(" "c)
                If x4.Count >= 8 Then
                    If x4(6) = "02" And x4(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x4(10) & x4(9)))
                        digits4 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 4
                        ''''''''' check condition
                        If digits4(0) = 1 Then
                            btnStepONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stepon
                            btnStepONOFF.Tag = 1

                            btnSpiralONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.spiralgrey
                            btnSpiralONOFF.Enabled = False

                        Else
                            ' btnStepONOFF.BackgroundImage = Global.iotHORIZONTALOL.My.Resources.stepoff
                            btnStepONOFF.Tag = 0

                            btnSpiralONOFF.Enabled = True
                            ' btnSpiralONOFF.BackgroundImage = Global.iotHORIZONTALOL.My.Resources.spiraloff

                        End If

                    End If
                End If


                ''/  spiral read
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 02 08 00 01", 50)
                Dim x5() As String = plcinstrg.Split(" "c)
                If x5.Count >= 8 Then
                    If x5(6) = "02" And x5(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x5(10) & x5(9)))
                        digits5 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 5
                        ''''''''' check condition
                        If digits5(0) = 1 Then
                            btnSpiralONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.spiralon
                            btnSpiralONOFF.Tag = 1

                            btnStepONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stepgrey
                            btnStepONOFF.Enabled = False

                        Else
                            '   btnSpiralONOFF.BackgroundImage = Global.iotHORIZONTALOL.My.Resources.spiraloff
                            btnSpiralONOFF.Tag = 0

                            btnStepONOFF.Enabled = True
                            ' btnStepONOFF.BackgroundImage = Global.iotHORIZONTALOL.My.Resources.stepoff

                        End If

                    End If
                End If


                ''  linear/circular read
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 01 F4 00 01", 50)
                Dim x3() As String = plcinstrg.Split(" "c)
                If x3.Count >= 8 Then
                    If x3(6) = "02" And x3(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x3(10) & x3(9)))
                        digits3 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 3
                        If digits3(0) = 1 Then
                            btnLinearCirculae.BackgroundImage = Global.iotPIPECLEDING.My.Resources.linear
                            btnLinearCirculae.Tag = 1

                            btnStepONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stepgrey
                            btnStepONOFF.Tag = 0
                            btnStepONOFF.Enabled = False
                            btnSpiralONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.spiralgrey
                            btnSpiralONOFF.Tag = 0
                            btnSpiralONOFF.Enabled = False

                        Else
                            btnLinearCirculae.BackgroundImage = Global.iotPIPECLEDING.My.Resources.circular
                            '  btnStepONOFF.Enabled = True
                            '  btnSpiralONOFF.Enabled = True
                            btnLinearCirculae.Tag = 0
                        End If

                    End If
                End If




                ''///////  Sagita read
                'plcinstrg = ""
                'plcinstrg = TCPComA("00 00 00 00 00 06 02 01 02 12 00 01", 50)
                'Dim x6() As String = plcinstrg.Split(" "c)
                'If x6.Count >= 8 Then
                '    If x6(6) = "02" And x6(7) = "01" Then
                '        Dim bin As String = ReverseString(Hex2Bin(x6(10) & x6(9)))
                '        digits6 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                'errno = 6
                '''''''''' check condition
                'If digits6(0) = 1 Then
                '    btnSagitaONOFF.BackgroundImage = Global.iotHORIZONTALOL.My.Resources.sagitaon
                '    btnSagitaONOFF.Tag = 1
                'Else
                '    btnSagitaONOFF.BackgroundImage = Global.iotHORIZONTALOL.My.Resources.sagitaoff
                '    btnSagitaONOFF.Tag = 0
                'End If

                '    End If
                'End If



            End If
        Catch ex As Exception
            Dim result1 As String = MessageBoxEx.Show("Error in FrmJobdata Toogle read Method : " + ex.Message.ToString() + errno.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString

            ' MessageBox.Show("Error in Toogle read Method : " + ex.Message.ToString() + errno.ToString())
        End Try
    End Sub

    '' convert without division
    '' Convert.ToDouble(y.ToString("0.00"))

    Public Sub Analogread2()
        Try
            errno = 0
            plcinstrg = ""
            Dim y As Integer = 0

            Dim y1 As Double
            If isConnection = True Then
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 90 00 06", 50)
                '//////////////////////   Analog Read Job data  //////////////////////////////////
                y = 0
                y1 = 0.0
                plcinstrg = ""

                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 90 00 06", 70)
                Dim x7() As String = plcinstrg.Split(" "c)
                If x7.Count >= 8 Then
                    If x7(6) = "02" And x7(7) = "03" Then
                        y = Convert.ToInt32(x7(11) & x7(12) & x7(9) & x7(10), 16)
                        gPipeNozzleID = (y / 100)
                        y = 0
                        y = Convert.ToInt32(x7(15) & x7(16) & x7(13) & x7(14), 16)
                        gPipeNozzleOD = (y / 100)
                        y = 0
                        y = Convert.ToInt32(x7(19) & x7(20) & x7(17) & x7(18), 16)
                        gPipeNozzleLength = (y / 100)
                        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        errno = 1
                    End If
                End If

                '/////   Flange Read //////////////////////
                y = 0
                y1 = 0
                plcinstrg = ""

                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 9A 00 04", 50)
                Dim x8() As String = plcinstrg.Split(" "c)
                If x8.Count >= 8 Then
                    If x8(6) = "02" And x8(7) = "03" Then
                        y = Convert.ToInt32(x8(11) & x8(12) & x8(9) & x8(10), 16)
                        gFlangeID = (y / 100)
                        y = 0
                        y = Convert.ToInt32(x8(15) & x8(16) & x8(13) & x8(14), 16)
                        gFlangeOD = (y / 100)
                        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        errno = 2
                    End If
                End If


                '/////   Backface Read //////////////////////
                y = 0
                y1 = 0
                plcinstrg = ""

                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 A4 00 04", 50)
                Dim x9() As String = plcinstrg.Split(" "c)
                If x9.Count >= 8 Then
                    If x9(6) = "02" And x9(7) = "03" Then
                        y = Convert.ToInt32(x9(11) & x9(12) & x9(9) & x9(10), 16)
                        gBackfaceID = (y / 100)
                        y = 0
                        y = Convert.ToInt32(x9(15) & x9(16) & x9(13) & x9(14), 16)
                        gBackfaceOD = (y / 100)
                        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        errno = 3
                    End If
                End If

                '/////   Nozzle Dia // Shell Read  //////////////////////
                y = 0
                y1 = 0
                plcinstrg = ""

                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 AE 00 06", 50)
                Dim x10() As String = plcinstrg.Split(" "c)
                If x10.Count >= 8 Then
                    If x10(6) = "02" And x10(7) = "03" Then
                        y = Convert.ToInt32(x10(11) & x10(12) & x10(9) & x10(10), 16)
                        gNozzleRefDIA = (y / 100)
                        y = 0
                        y = Convert.ToInt32(x10(15) & x10(16) & x10(13) & x10(14), 16)
                        gShellID = (y / 100)
                        y = 0
                        y = Convert.ToInt32(x10(19) & x10(20) & x10(17) & x10(18), 16)
                        gShellOD = (y / 100)
                        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        errno = 4
                    End If
                End If

                '/////   Bead Shift / Shift Speed  //////////////////////
                y = 0
                y1 = 0
                plcinstrg = ""

                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 D8 00 04", 50)
                Dim x11() As String = plcinstrg.Split(" "c)
                If x11.Count >= 8 Then
                    If x11(6) = "02" And x11(7) = "03" Then
                        y = Convert.ToInt32(x11(11) & x11(12) & x11(9) & x11(10), 16)
                        gBeadShift = (y / 100)
                        y = 0
                        y = Convert.ToInt32(x11(15) & x11(16) & x11(13) & x11(14), 16)
                        gBeadShiftSpeed = (y / 100)

                        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        errno = 5
                    End If
                End If

                '/////   Read current / voltage / Bead Shift Speed / 1  //////////////////////
                y = 0
                y1 = 0
                plcinstrg = ""

                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E0 00 06", 70)
                Dim x12() As String = plcinstrg.Split(" "c)
                If x12.Count >= 8 Then
                    If x12(6) = "02" And x12(7) = "03" Then
                        y = Convert.ToInt32(x12(11) & x12(12) & x12(9) & x12(10), 16)
                        gSetCurrent1 = (y / 10)
                        y = 0
                        y = Convert.ToInt32(x12(15) & x12(16) & x12(13) & x12(14), 16)
                        gSetVoltage1 = (y / 10)
                        y = 0
                        y = Convert.ToInt32(x12(19) & x12(20) & x12(17) & x12(18), 16)
                        gSetWFSpeed1 = (y / 10)

                        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        errno = 6
                    End If
                End If

                '/////   Read current / voltage / Bead Shift Speed / 2  //////////////////////
                y = 0
                y1 = 0
                plcinstrg = ""

                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 EA 00 06", 50)
                Dim x13() As String = plcinstrg.Split(" "c)
                If x13.Count >= 8 Then
                    If x13(6) = "02" And x13(7) = "03" Then
                        y = Convert.ToInt32(x13(11) & x13(12) & x13(9) & x13(10), 16)
                        gSetCurrent2 = (y / 10)
                        y = 0
                        y = Convert.ToInt32(x13(15) & x13(16) & x13(13) & x13(14), 16)
                        gSetVoltage2 = (y / 10)
                        y = 0
                        y = Convert.ToInt32(x13(19) & x13(20) & x13(17) & x13(18), 16)
                        gSetWFSpeed2 = (y / 10)

                        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        errno = 7
                    End If
                End If


                '/////   Read Welding Speed  //////////////////////
                y = 0
                y1 = 0
                plcinstrg = ""

                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 D6 00 02", 50)
                Dim x14() As String = plcinstrg.Split(" "c)
                If x14.Count >= 8 Then
                    If x14(0) = "02" And x14(1) = "03" Then
                        y = Convert.ToInt32(x14(11) & x14(12) & x14(9) & x14(10), 16)
                        gWeldingSpeed = (y / 100)
                        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        errno = 8
                    End If
                End If

                txtPipeNozzleID.Text = gPipeNozzleID.ToString()
                txtPipeNozzleOD.Text = gPipeNozzleOD.ToString()
                txtPipeNozzleLen.Text = gPipeNozzleLength.ToString()
                txtFlangeID.Text = gFlangeID.ToString()
                txtFlangeOD.Text = gFlangeOD.ToString()
                txtBackfaceID.Text = gBackfaceID.ToString()
                txtBackfaceOD.Text = gBackfaceOD.ToString()
                txtNozzleRefDia.Text = gNozzleRefDIA.ToString()
                txtShellID.Text = gShellID.ToString()
                txtShellOD.Text = gShellOD.ToString()
                txtBeadWidth.Text = gBeadShift.ToString()
                txtBeadShiftSpeed.Text = gBeadShiftSpeed.ToString()
                txtSetCurr.Text = gSetCurrent1.ToString()
                txtSetVol.Text = gSetVoltage1.ToString()
                txtSetWirefeed.Text = gSetWFSpeed1.ToString()
                txtWeldSpeed.Text = gWeldingSpeed.ToString()
                txtSetCurr2.Text = gSetCurrent2.ToString()
                txtSetVol2.Text = gSetVoltage2.ToString()
                txtSetWirefeed2.Text = gSetWFSpeed2.ToString()

            End If
        Catch ex As Exception
            Dim result1 As String = MessageBoxEx.Show("Error in FrmJobdata Analog read Method : " + ex.Message.ToString() + errno.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString

            ' MessageBox.Show("Error in Analog Read read Method : " + ex.Message.ToString() + errno.ToString())
        End Try
    End Sub

    Private Sub btnpxmtMouseDown(sender As Object, e As System.Windows.Forms.MouseEventArgs)
        'Btnpxmt.Image = Global.iotPIPECLEDING.My.Resources.btngreen
        If isConnection = True Then
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 5F FF 00"
            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)
        End If

    End Sub
    Private Sub btnpxmtMouseUp(sender As Object, e As System.Windows.Forms.MouseEventArgs)
        ' Btnpxmt.Image = Global.iotPIPECLEDING.My.Resources.btnblue
        If isConnection = True Then
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 5F 00 00"
            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)
        End If

    End Sub




    'Private Sub xySlow_Click(sender As Object, e As EventArgs)


    '    'xySlow.Enabled = False
    '    'xySlow.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
    '    'xyRapid.Enabled = True
    '    'xyRapid.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnorg
    '    If isConnection = True Then
    '        tx = "00 00 00 00 00 06 02 05 02 27 00 00"
    '        rx = TCPComA(tx, 50)
    '        'writeLog("|Auxlmp |TX:" & tx & "|RX:" & rx)
    '        tx = "00 00 00 00 00 06 02 05 02 28 00 00"
    '        rx = TCPComA(tx, 50)
    '        'writeLog("|Auxlmp |TX:" & tx & "|RX:" & rx)
    '    End If
    'End Sub

    'Private Sub xyRapid_Click(sender As Object, e As EventArgs)
    '    'xyRapid.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
    '    'xySlow.Enabled = True
    '    'xySlow.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnorg
    '    'xyRapid.Enabled = False
    '    If isConnection = True Then
    '        tx = "00 00 00 00 00 06 02 05 02 27 FF 00"
    '        rx = TCPComA(tx, 50)
    '        'writeLog("|Auxlmp |TX:" & tx & "|RX:" & rx)
    '        tx = "00 00 00 00 00 06 02 05 02 28 FF 00"
    '        rx = TCPComA(tx, 50)
    '        'writeLog("|Auxlmp |TX:" & tx & "|RX:" & rx)
    '    End If
    'End Sub


    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub btnLinearCirculae_Click(sender As Object, e As EventArgs) Handles btnLinearCirculae.Click
        If e Is EventArgs.Empty Then
        Else
            If btnLinearCirculae.Tag = 0 Then

                If isConnection = True Then
                    btnLinearCirculae.BackgroundImage = Global.iotPIPECLEDING.My.Resources.linear
                    btnLinearCirculae.Tag = 1
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 01 F4 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                    btnStepONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stepgrey
                    btnStepONOFF.Tag = 0
                    btnStepONOFF.Enabled = False
                    btnSpiralONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.spiralgrey
                    btnSpiralONOFF.Tag = 0
                    btnSpiralONOFF.Enabled = False

                End If
                If rx.Count > 4 Then

                End If
            Else
                btnLinearCirculae.BackgroundImage = Global.iotPIPECLEDING.My.Resources.circular
                btnLinearCirculae.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 01 F4 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                    btnStepONOFF.Enabled = True
                    btnStepONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stepoff
                    btnStepONOFF.Tag = 0

                    btnSpiralONOFF.Enabled = True
                    btnSpiralONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.spiraloff
                    btnSpiralONOFF.Tag = 0

                End If
                If rx.Count > 4 Then

                End If
            End If

        End If
    End Sub

    Private Sub btnStepONOFF_Click(sender As Object, e As EventArgs) Handles btnStepONOFF.Click
        If e Is EventArgs.Empty Then
        Else
            If btnStepONOFF.Tag = 0 Then

                If isConnection = True Then

                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 01 FE FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                    btnStepONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stepon
                    btnStepONOFF.Tag = 1


                    btnSpiralONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.spiralgrey
                    btnSpiralONOFF.Enabled = False
                End If

            Else
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 01 FE 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)

                    btnStepONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stepoff
                    btnStepONOFF.Tag = 0

                    btnSpiralONOFF.Enabled = True
                    btnSpiralONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.spiraloff

                End If

            End If

        End If

    End Sub

    Private Sub btnSpiralONOFF_Click(sender As Object, e As EventArgs) Handles btnSpiralONOFF.Click
        If e Is EventArgs.Empty Then
        Else
            If btnSpiralONOFF.Tag = 0 Then


                If isConnection = True Then

                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 02 08 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                    btnSpiralONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.spiralon
                    btnSpiralONOFF.Tag = 1

                    btnStepONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stepgrey
                    btnStepONOFF.Enabled = False
                End If

            Else
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 02 08 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)

                    btnSpiralONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.spiraloff
                    btnSpiralONOFF.Tag = 0

                    btnStepONOFF.Enabled = True
                    btnStepONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stepoff


                End If

            End If

        End If

    End Sub



    Private Sub btnNozzPipeIDOL_Click(sender As Object, e As EventArgs) Handles btnNozzPipeIDOL.Click
        If e Is EventArgs.Empty Then
        Else
            If btnNozzPipeIDOL.Tag = 0 Then

                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 01 90 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                    btnNozzPipeIDOL.BackgroundImage = Global.iotPIPECLEDING.My.Resources._on
                    btnNozzPipeIDOL.Tag = 1

                    Threading.Thread.Sleep(200)
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 01 9A 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                    btnBeadShiFWDREW.BackgroundImage = Global.iotPIPECLEDING.My.Resources.rew
                    btnBeadShiFWDREW.Tag = 0

                    Threading.Thread.Sleep(200)
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 01 F4 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                    btnLinearCirculae.BackgroundImage = Global.iotPIPECLEDING.My.Resources.circular
                    btnLinearCirculae.Tag = 0

                    Threading.Thread.Sleep(200)
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 02 08 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                    btnSpiralONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.spiralon
                    btnSpiralONOFF.Tag = 1

                    btnStepONOFF.BackgroundImage = Global.iotPIPECLEDING.My.Resources.stepgrey
                    btnStepONOFF.Enabled = False
                    btnStepONOFF.Tag = 0
                End If
                If rx.Count > 4 Then

                End If
            Else
                btnNozzPipeIDOL.BackgroundImage = Global.iotPIPECLEDING.My.Resources.off
                btnNozzPipeIDOL.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 01 90 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            End If

        End If
    End Sub





    Private Sub btnBeadShiFWDREW_Click(sender As Object, e As EventArgs) Handles btnBeadShiFWDREW.Click
        If e Is EventArgs.Empty Then
        Else
            If btnBeadShiFWDREW.Tag = 0 Then
                btnBeadShiFWDREW.BackgroundImage = Global.iotPIPECLEDING.My.Resources.fwd
                btnBeadShiFWDREW.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 01 9A FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            Else
                btnBeadShiFWDREW.BackgroundImage = Global.iotPIPECLEDING.My.Resources.rew
                btnBeadShiFWDREW.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 01 9A 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 4 Then

                End If
            End If

        End If

    End Sub




    Private Sub txtPipeNozzleID_gotfocus(sender As Object, e As EventArgs) Handles txtPipeNozzleID.Click
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtPipeNozzleID
    End Sub
    Private Sub txtPipeNozzleID_TextChanged(sender As Object, e As EventArgs) Handles txtPipeNozzleID.TextChanged
        Dim arr As Integer = 0
        arr = txtPipeNozzleID.TextLength
        Dim st As String = ""

        st = txtPipeNozzleID.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtPipeNozzleID.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtPipeNozzleID.Text += ii(ht)
                    Next
                    If txtPipeNozzleID.Text <> "-" Then

                        If isConnection = True Then
                            Dim t01 As Single = txtPipeNozzleID.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100190000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 90 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gPipeNozzleID = (y / 100)
                                    txtPipeNozzleID.Text = gPipeNozzleID.ToString()
                                End If
                            End If


                        End If
                    Else
                        txtPipeNozzleID.Text = gPipeNozzleID.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtPipeNozzleID.Text = gPipeNozzleID.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If
    End Sub
    Private Sub txtPipeNozzleOD_gotfocus(sender As Object, e As EventArgs) Handles txtPipeNozzleOD.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtPipeNozzleOD
    End Sub
    Private Sub txtPipeNozzleOD_TextChanged(sender As Object, e As EventArgs) Handles txtPipeNozzleOD.TextChanged
        Dim arr As Integer = 0
        arr = txtPipeNozzleOD.TextLength
        Dim st As String = ""

        st = txtPipeNozzleOD.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtPipeNozzleOD.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtPipeNozzleOD.Text += ii(ht)
                    Next
                    If txtPipeNozzleOD.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtPipeNozzleOD.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100192000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 92 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gPipeNozzleOD = (y / 100)
                                    txtPipeNozzleOD.Text = gPipeNozzleOD.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtPipeNozzleOD.Text = gPipeNozzleOD.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtPipeNozzleOD.Text = gPipeNozzleOD.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If
    End Sub
    Private Sub txtPipeNozzleLen_gotfocus(sender As Object, e As EventArgs) Handles txtPipeNozzleLen.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtPipeNozzleLen
    End Sub
    Private Sub txtPipeNozzleLen_TextChanged(sender As Object, e As EventArgs) Handles txtPipeNozzleLen.TextChanged
        Dim arr As Integer = 0
        arr = txtPipeNozzleLen.TextLength
        Dim st As String = ""

        st = txtPipeNozzleLen.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtPipeNozzleLen.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtPipeNozzleLen.Text += ii(ht)
                    Next
                    If txtPipeNozzleLen.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtPipeNozzleLen.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100194000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 94 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gPipeNozzleLength = (y / 100)
                                    txtPipeNozzleLen.Text = gPipeNozzleLength.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtPipeNozzleLen.Text = gPipeNozzleLength.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtPipeNozzleLen.Text = gPipeNozzleLength.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtFlangeID_gotfocus(sender As Object, e As EventArgs) Handles txtFlangeID.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtFlangeID
    End Sub
    Private Sub txtFlangeID_TextChanged(sender As Object, e As EventArgs) Handles txtFlangeID.TextChanged
        Dim arr As Integer = 0
        arr = txtFlangeID.TextLength
        Dim st As String = ""

        st = txtFlangeID.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtFlangeID.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtFlangeID.Text += ii(ht)
                    Next
                    If txtFlangeID.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtFlangeID.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210019A000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 9A 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gFlangeID = (y / 100)
                                    txtFlangeID.Text = gFlangeID.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtFlangeID.Text = gFlangeID.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtFlangeID.Text = gFlangeID.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtFlangeOD_gotfocus(sender As Object, e As EventArgs) Handles txtFlangeOD.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtFlangeOD
    End Sub
    Private Sub txtFlangeOD_TextChanged(sender As Object, e As EventArgs) Handles txtFlangeOD.TextChanged
        Dim arr As Integer = 0
        arr = txtFlangeOD.TextLength
        Dim st As String = ""

        st = txtFlangeOD.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtFlangeOD.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtFlangeOD.Text += ii(ht)
                    Next
                    If txtFlangeOD.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtFlangeOD.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210019C000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 9C 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gFlangeOD = (y / 100)
                                    txtFlangeOD.Text = gFlangeOD.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtFlangeOD.Text = gFlangeOD.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtFlangeOD.Text = gFlangeOD.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtBackfaceID_gotfocus(sender As Object, e As EventArgs) Handles txtBackfaceID.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtBackfaceID
    End Sub
    Private Sub txtBackfaceID_TextChanged(sender As Object, e As EventArgs) Handles txtBackfaceID.TextChanged
        Dim arr As Integer = 0
        arr = txtBackfaceID.TextLength
        Dim st As String = ""

        st = txtBackfaceID.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtBackfaceID.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtBackfaceID.Text += ii(ht)
                    Next
                    If txtBackfaceID.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtBackfaceID.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001A4000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 A4 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gBackfaceID = (y / 100)
                                    txtBackfaceID.Text = gBackfaceID.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtBackfaceID.Text = gBackfaceID.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtBackfaceID.Text = gBackfaceID.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtBackfaceOD_gotfocus(sender As Object, e As EventArgs) Handles txtBackfaceOD.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtBackfaceOD
    End Sub
    Private Sub txtBackfaceOD_TextChanged(sender As Object, e As EventArgs) Handles txtBackfaceOD.TextChanged
        Dim arr As Integer = 0
        arr = txtBackfaceOD.TextLength
        Dim st As String = ""

        st = txtBackfaceOD.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtBackfaceOD.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtBackfaceOD.Text += ii(ht)
                    Next
                    If txtBackfaceOD.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtBackfaceOD.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001A6000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 A6 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gBackfaceOD = (y / 100)
                                    txtBackfaceOD.Text = gBackfaceOD.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtBackfaceOD.Text = gBackfaceOD.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtBackfaceOD.Text = gBackfaceOD.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtNozzleRefDia_gotfocus(sender As Object, e As EventArgs) Handles txtNozzleRefDia.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtNozzleRefDia
    End Sub

    Private Sub txtNozzleRefDia_TextChanged(sender As Object, e As EventArgs) Handles txtNozzleRefDia.TextChanged
        Dim arr As Integer = 0
        arr = txtNozzleRefDia.TextLength
        Dim st As String = ""

        st = txtNozzleRefDia.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtNozzleRefDia.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtNozzleRefDia.Text += ii(ht)
                    Next
                    If txtNozzleRefDia.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtNozzleRefDia.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001AE000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 AE 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gNozzleRefDIA = (y / 100)
                                    txtNozzleRefDia.Text = gNozzleRefDIA.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtNozzleRefDia.Text = gNozzleRefDIA.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtNozzleRefDia.Text = gNozzleRefDIA.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtShellID_gotfocus(sender As Object, e As EventArgs) Handles txtShellID.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtShellID
    End Sub
    Private Sub txtShellID_TextChanged(sender As Object, e As EventArgs) Handles txtShellID.TextChanged
        Dim arr As Integer = 0
        arr = txtShellID.TextLength
        Dim st As String = ""

        st = txtShellID.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtShellID.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtShellID.Text += ii(ht)
                    Next
                    If txtShellID.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtShellID.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001B0000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 B0 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gShellID = (y / 100)
                                    txtShellID.Text = gShellID.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtShellID.Text = gShellID.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtShellID.Text = gShellID.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtShellOD_gotfocus(sender As Object, e As EventArgs) Handles txtShellOD.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtShellOD
    End Sub
    Private Sub txtShellOD_TextChanged(sender As Object, e As EventArgs) Handles txtShellOD.TextChanged
        Dim arr As Integer = 0
        arr = txtShellOD.TextLength
        Dim st As String = ""

        st = txtShellOD.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtShellOD.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtShellOD.Text += ii(ht)
                    Next
                    If txtShellOD.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtShellOD.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001B2000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 B2 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gShellOD = (y / 100)
                                    txtShellOD.Text = gShellOD.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtShellOD.Text = gShellOD.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtShellOD.Text = gShellOD.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtBeadWidth_gotfocus(sender As Object, e As EventArgs) Handles txtBeadWidth.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtBeadWidth
    End Sub
    Private Sub txtBeadWidth_TextChanged(sender As Object, e As EventArgs) Handles txtBeadWidth.TextChanged
        Dim arr As Integer = 0
        arr = txtBeadWidth.TextLength
        Dim st As String = ""

        st = txtBeadWidth.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtBeadWidth.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtBeadWidth.Text += ii(ht)
                    Next
                    If txtBeadWidth.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtBeadWidth.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001D8000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 D8 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gBeadShift = (y / 100)
                                    txtBeadWidth.Text = gBeadShift.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtBeadWidth.Text = gBeadShift.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtBeadWidth.Text = gBeadShift.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtBeadShiftSpeed_gotfocus(sender As Object, e As EventArgs) Handles txtBeadShiftSpeed.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtBeadShiftSpeed
    End Sub
    Private Sub txtBeadShiftSpeed_TextChanged(sender As Object, e As EventArgs) Handles txtBeadShiftSpeed.TextChanged
        Dim arr As Integer = 0
        arr = txtBeadShiftSpeed.TextLength
        Dim st As String = ""

        st = txtBeadShiftSpeed.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtBeadShiftSpeed.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtBeadShiftSpeed.Text += ii(ht)
                    Next
                    If txtBeadShiftSpeed.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtBeadShiftSpeed.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001DA000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 DA 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gBeadShiftSpeed = (y / 100)
                                    txtBeadShiftSpeed.Text = gBeadShiftSpeed.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtBeadShiftSpeed.Text = gBeadShiftSpeed.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtBeadShiftSpeed.Text = gBeadShiftSpeed.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtSetCurr_gotfocus(sender As Object, e As EventArgs) Handles txtSetCurr.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtSetCurr
    End Sub
    Private Sub txtSetCurr_TextChanged(sender As Object, e As EventArgs) Handles txtSetCurr.TextChanged
        Dim arr As Integer = 0
        arr = txtSetCurr.TextLength
        Dim st As String = ""

        st = txtSetCurr.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtSetCurr.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtSetCurr.Text += ii(ht)
                    Next
                    If txtSetCurr.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtSetCurr.Text * 10
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001E0000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                            Threading.Thread.Sleep(500)

                            '/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E0 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetCurrent1 = (y / 10)
                                    txtSetCurr.Text = gSetCurrent1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtSetCurr.Text = gSetCurrent1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtSetCurr.Text = gSetCurrent1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtSetVol_gotfocus(sender As Object, e As EventArgs) Handles txtSetVol.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtSetVol
    End Sub
    Private Sub txtSetVol_TextChanged(sender As Object, e As EventArgs) Handles txtSetVol.TextChanged
        Dim arr As Integer = 0
        arr = txtSetVol.TextLength
        Dim st As String = ""

        st = txtSetVol.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtSetVol.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtSetVol.Text += ii(ht)
                    Next
                    If txtSetVol.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtSetVol.Text * 10
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001E2000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                            Threading.Thread.Sleep(500)

                            '/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E2 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetVoltage1 = (y / 10)
                                    txtSetVol.Text = gSetVoltage1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtSetVol.Text = gSetVoltage1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtSetVol.Text = gSetVoltage1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtSetWirefeed_gotfocus(sender As Object, e As EventArgs) Handles txtSetWirefeed.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtSetWirefeed
    End Sub
    Private Sub txtSetWirefeed_TextChanged(sender As Object, e As EventArgs) Handles txtSetWirefeed.TextChanged
        Dim arr As Integer = 0
        arr = txtSetWirefeed.TextLength
        Dim st As String = ""

        st = txtSetWirefeed.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtSetWirefeed.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtSetWirefeed.Text += ii(ht)
                    Next
                    If txtSetWirefeed.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtSetWirefeed.Text * 10
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001E4000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                            Threading.Thread.Sleep(500)
                            '/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E4 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetWFSpeed1 = (y / 10)
                                    txtSetWirefeed.Text = gSetWFSpeed1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtSetWirefeed.Text = gSetWFSpeed1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtSetWirefeed.Text = gSetWFSpeed1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub

    Private Sub txtWeldSpeed_gotfocus(sender As Object, e As EventArgs) Handles txtWeldSpeed.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtWeldSpeed
    End Sub
    Private Sub txtWeldSpeed_TextChanged(sender As Object, e As EventArgs) Handles txtWeldSpeed.TextChanged
        Dim arr As Integer = 0
        arr = txtWeldSpeed.TextLength
        Dim st As String = ""

        st = txtWeldSpeed.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtWeldSpeed.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtWeldSpeed.Text += ii(ht)
                    Next
                    If txtWeldSpeed.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtWeldSpeed.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001D6000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                            Threading.Thread.Sleep(500)
                            '/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 D6 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gWeldingSpeed = (y / 100)
                                    txtWeldSpeed.Text = gWeldingSpeed.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtWeldSpeed.Text = gWeldingSpeed.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtWeldSpeed.Text = gWeldingSpeed.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub

    '///////////////////// part 1/////////////
    Private Sub BtnPlusCurr_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusCurr.MouseDown
        'btnPlusCurr.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson
    End Sub

    Private Sub BtnPlusCurr_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusCurr.MouseUp
        'btnPlusCurr.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE
    End Sub

    Private Sub btnMinusCurr_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusCurr.MouseDown
        '     btnMinusCurr.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minuson
    End Sub

    Private Sub btnMinusCurr_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusCurr.MouseUp
        ''  btnMinusCurr.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minusE
    End Sub

    Private Sub btnPlusVol_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusVol.MouseDown
        'btnPlusVol.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson
    End Sub

    Private Sub btnPlusVol_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusVol.MouseUp
        'btnPlusVol.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE
    End Sub

    Private Sub btnMinusVol_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusVol.MouseDown
        'btnMinusVol.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minuson
    End Sub

    Private Sub btnMinusVol_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusVol.MouseUp
        'btnMinusVol.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minusE
    End Sub

    Private Sub btnPlusSetWirefeed_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusSetWirefeed.MouseDown
        'btnPlusSetWirefeed.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson
    End Sub

    Private Sub btnPlusSetWirefeed_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusSetWirefeed.MouseUp
        'btnPlusSetWirefeed.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE
    End Sub

    Private Sub btnMinusWirefeed_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusWirefeed.MouseDown
        'btnMinusWirefeed.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minuson
    End Sub

    Private Sub btnMinusWirefeed_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusWirefeed.MouseUp
        'btnMinusWirefeed.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minusE
    End Sub

    ''///////////////////// part 2     /////////////
    'Private Sub BtnPlusCurr2_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusCurr2.MouseDown
    '    btnPlusCurr2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson
    'End Sub

    'Private Sub BtnPlusCurr2_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusCurr2.MouseUp
    '    btnPlusCurr2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE
    'End Sub

    'Private Sub btnMinusCurr2_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusCurr2.MouseDown
    '    btnMinusCurr2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson
    'End Sub

    'Private Sub btnMinusCurr2_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusCurr2.MouseUp
    '    btnMinusCurr2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE
    'End Sub

    'Private Sub btnPlusVol2_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusVol2.MouseDown
    '    btnPlusVol2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson
    'End Sub

    'Private Sub btnPlusVol2_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusVol2.MouseUp
    '    btnPlusVol2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE
    'End Sub

    'Private Sub btnMinusVol2_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusVol2.MouseDown
    '    btnMinusVol2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson
    'End Sub

    'Private Sub btnMinusVol2_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusVol2.MouseUp
    '    btnMinusVol2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE
    'End Sub

    'Private Sub btnPlusSetWirefeed2_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusSetWirefeed2.MouseDown
    '    btnPlusSetWirefeed2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson
    'End Sub

    'Private Sub btnPlusSetWirefeed2_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusSetWirefeed2.MouseUp
    '    btnPlusSetWirefeed2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE
    'End Sub

    'Private Sub btnMinusWirefeed2_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusWirefeed2.MouseDown
    '    btnMinusWirefeed2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson
    'End Sub

    'Private Sub btnMinusWirefeed2_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusWirefeed2.MouseUp
    '    btnMinusWirefeed2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE
    'End Sub

    '///////// Weld Speed   ///////////
    Private Sub btnPlusWeldSpeed_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusWeldSpeed.MouseDown
        btnPlusWeldSpeed.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson
    End Sub

    Private Sub btnPlusWeldSpeed_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnPlusWeldSpeed.MouseUp
        btnPlusWeldSpeed.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE
    End Sub

    Private Sub btnMinusWeldSpeed_mousedown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusWeldSpeed.MouseDown
        btnMinusWeldSpeed.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson
    End Sub

    Private Sub btnMinusWeldSpeed_mouseup(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnMinusWeldSpeed.MouseUp
        btnMinusWeldSpeed.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE
    End Sub

    Private Sub BtnPlusCurr_Click(sender As Object, e As EventArgs) Handles btnPlusCurr.Click
        Try
            If isConnection = True Then
                btnPlusCurr.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson

                Dim t01 As Integer = (txtSetCurr.Text + gcurstep) * 10
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001E0000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)

                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E0 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gSetCurrent1 = (y / 10)
                        txtSetCurr.Text = gSetCurrent1.ToString()
                    End If
                End If
                btnPlusCurr.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE

            End If
        Catch ex As Exception
            MessageBox.Show("Set Current 1 plus write error, Error : " + ex.Message.ToString())

        End Try
    End Sub

    Private Sub BtnMinusCurr_Click(sender As Object, e As EventArgs) Handles btnMinusCurr.Click
        Try
            If isConnection = True Then
                btnMinusCurr.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minuson

                Dim t01 As Integer = (txtSetCurr.Text - gcurstep) * 10
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001E0000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)

                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E0 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gSetCurrent1 = (y / 10)
                        txtSetCurr.Text = gSetCurrent1.ToString()
                    End If
                End If
                btnMinusCurr.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minusE

            End If
        Catch ex As Exception
            MessageBox.Show("Set Current 1 Minus write error, Error : " + ex.Message.ToString())

        End Try

    End Sub

    Private Sub BtnPlusVol_Click(sender As Object, e As EventArgs) Handles btnPlusVol.Click
        Try
            If isConnection = True Then
                btnPlusVol.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson

                Dim t01 As Integer = (txtSetVol.Text + gvolstep) * 10
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001E2000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)

                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E2 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gSetVoltage1 = (y / 10)
                        txtSetVol.Text = gSetVoltage1.ToString()
                    End If
                End If
                btnPlusVol.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE

            End If
        Catch ex As Exception
            MessageBox.Show("Set Voltage 1 plus write error, Error : " + ex.Message.ToString())

        End Try

    End Sub

    Private Sub BtnMinusVol_Click(sender As Object, e As EventArgs) Handles btnMinusVol.Click
        Try
            If isConnection = True Then
                btnMinusVol.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minuson

                Dim t01 As Integer = (txtSetVol.Text - gvolstep) * 10
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001E2000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)

                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E2 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gSetVoltage1 = (y / 10)
                        txtSetVol.Text = gSetVoltage1.ToString()
                    End If
                End If
                btnMinusVol.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minusE

            End If
        Catch ex As Exception
            MessageBox.Show("Set Voltage 1 Minus write error, Error : " + ex.Message.ToString())

        End Try

    End Sub

    Private Sub BtnPlusSetWirefeed_Click(sender As Object, e As EventArgs) Handles btnPlusSetWirefeed.Click
        Try
            If isConnection = True Then
                btnPlusSetWirefeed.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson

                Dim t01 As Integer = (txtSetWirefeed.Text + gwfstep) * 10
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001E4000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)
                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E4 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gSetWFSpeed1 = (y / 10)
                        txtSetWirefeed.Text = gSetWFSpeed1.ToString()
                    End If
                End If
                btnPlusSetWirefeed.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE

            End If
        Catch ex As Exception
            MessageBox.Show("Set Wirefeed 1 plus write error, Error : " + ex.Message.ToString())

        End Try

    End Sub

    Private Sub BtnMinusWirefeed_Click(sender As Object, e As EventArgs) Handles btnMinusWirefeed.Click
        Try
            If isConnection = True Then
                btnMinusWirefeed.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minuson

                Dim t01 As Integer = (txtSetWirefeed.Text - gwfstep) * 10
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001E4000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)
                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E4 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gSetWFSpeed1 = (y / 10)
                        txtSetWirefeed.Text = gSetWFSpeed1.ToString()
                    End If
                End If
                btnMinusWirefeed.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minusE

            End If
        Catch ex As Exception
            MessageBox.Show("Set Wirefeed 1 Minus write error, Error : " + ex.Message.ToString())

        End Try

    End Sub


    Private Sub BtnPlusWeldSpeed_Click(sender As Object, e As EventArgs) Handles btnPlusWeldSpeed.Click
        Try
            If isConnection = True Then
                Dim t01 As Integer = (txtWeldSpeed.Text + gweldspeedstep) * 100
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001D6000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)
                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 D6 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gWeldingSpeed = (y / 100)
                        txtWeldSpeed.Text = gWeldingSpeed.ToString()
                    End If
                End If

            End If
        Catch ex As Exception
            MessageBox.Show("Set Weld Speed plus write error, Error : " + ex.Message.ToString())

        End Try

    End Sub

    Private Sub BtnMinusWeldSpeed_Click(sender As Object, e As EventArgs) Handles btnMinusWeldSpeed.Click
        Try
            If isConnection = True Then
                Dim t01 As Integer = (txtWeldSpeed.Text - gweldspeedstep) * 100
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001D6000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)
                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 D6 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gWeldingSpeed = (y / 100)
                        txtWeldSpeed.Text = gWeldingSpeed.ToString()
                    End If
                End If

            End If
        Catch ex As Exception
            MessageBox.Show("Set Weld Speed Minus write error, Error : " + ex.Message.ToString())

        End Try

    End Sub

    Private Sub btnPlusCurr2_Click(sender As Object, e As EventArgs) Handles btnPlusCurr2.Click
        Try
            If isConnection = True Then
                btnPlusCurr2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson

                Dim t01 As Integer = (txtSetCurr2.Text + gcurstep2) * 10
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001EA000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)

                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 EA 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gSetCurrent2 = (y / 10)
                        txtSetCurr2.Text = gSetCurrent2.ToString()
                    End If
                End If
                btnPlusCurr2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE

            End If
        Catch ex As Exception
            MessageBox.Show("Set Current 2 plus write error, Error : " + ex.Message.ToString())

        End Try
    End Sub

    Private Sub btnMinusCurr2_Click(sender As Object, e As EventArgs) Handles btnMinusCurr2.Click
        Try
            If isConnection = True Then
                btnMinusCurr2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minuson

                Dim t01 As Integer = (txtSetCurr2.Text - gcurstep2) * 10
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001EA000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)

                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 EA 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gSetCurrent2 = (y / 10)
                        txtSetCurr2.Text = gSetCurrent2.ToString()
                    End If
                End If
                btnMinusCurr2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minusE

            End If
        Catch ex As Exception
            MessageBox.Show("Set Current 2 Minus write error, Error : " + ex.Message.ToString())

        End Try

    End Sub

    Private Sub btnPlusVol2_Click(sender As Object, e As EventArgs) Handles btnPlusVol2.Click
        Try
            If isConnection = True Then
                btnPlusVol2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson

                Dim t01 As Integer = (txtSetVol2.Text + gvolstep2) * 10
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001EC000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)

                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 EC 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gSetVoltage2 = (y / 10)
                        txtSetVol2.Text = gSetVoltage2.ToString()
                    End If
                End If
                btnPlusVol2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE

            End If
        Catch ex As Exception
            MessageBox.Show("Set Voltage 2 plus write error, Error : " + ex.Message.ToString())

        End Try
    End Sub

    Private Sub btnMinusVol2_Click(sender As Object, e As EventArgs) Handles btnMinusVol2.Click
        Try
            If isConnection = True Then
                btnMinusVol2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minuson

                Dim t01 As Integer = (txtSetVol2.Text - gvolstep2) * 10
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001EC000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)

                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 EC 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gSetVoltage2 = (y / 10)
                        txtSetVol2.Text = gSetVoltage2.ToString()
                    End If
                End If
                btnMinusVol2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minusE

            End If
        Catch ex As Exception
            MessageBox.Show("Set Voltage 2 Minus write error, Error : " + ex.Message.ToString())

        End Try

    End Sub

    Private Sub btnPlusSetWirefeed2_Click(sender As Object, e As EventArgs) Handles btnPlusSetWirefeed2.Click
        Try
            If isConnection = True Then
                btnPlusSetWirefeed2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.pluson

                Dim t01 As Integer = (txtSetWirefeed2.Text + gwfstep2) * 10
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001EE000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)
                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 EE 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gSetWFSpeed2 = (y / 10)
                        txtSetWirefeed2.Text = gSetWFSpeed2.ToString()
                    End If
                End If
                btnPlusSetWirefeed2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.plusE

            End If
        Catch ex As Exception
            MessageBox.Show("Set Wirefeed 2 plus write error, Error : " + ex.Message.ToString())

        End Try

    End Sub

    Private Sub btnMinusWirefeed2_Click(sender As Object, e As EventArgs) Handles btnMinusWirefeed2.Click
        Try
            If isConnection = True Then
                btnMinusWirefeed2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minuson

                Dim t01 As Integer = (txtSetWirefeed2.Text - gwfstep2) * 10
                Dim t02 As String = SingleToHex(t01)
                Dim h1 As String = "00000000000B021001EE000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                tx = ""
                rx = ""

                tx = h1
                Dim verticalolread As String = TCPComA(tx, 100)
                'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                Threading.Thread.Sleep(500)
                '/////////   REad String //////////
                y = 0
                y1 = 0
                Dim plcinstrg As String = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 EE 00 02", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(0) = "02" And x1(1) = "03" Then
                        y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                        gSetWFSpeed2 = (y / 10)
                        txtSetWirefeed2.Text = gSetWFSpeed2.ToString()
                    End If
                End If
                btnMinusWirefeed2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.minusE

            End If
        Catch ex As Exception
            MessageBox.Show("Set Wirefeed 2 Minus write error, Error : " + ex.Message.ToString())

        End Try

    End Sub

    Private Sub txtSetCurr2_gotfocus(sender As Object, e As EventArgs) Handles txtSetCurr2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtSetCurr2
    End Sub

    Private Sub txtSetCurr2_TextChanged(sender As Object, e As EventArgs) Handles txtSetCurr2.TextChanged
        Dim arr As Integer = 0
        arr = txtSetCurr2.TextLength
        Dim st As String = ""

        st = txtSetCurr2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtSetCurr2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtSetCurr2.Text += ii(ht)
                    Next
                    If txtSetCurr2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtSetCurr2.Text * 10
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001EA000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                            Threading.Thread.Sleep(500)

                            '/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 EA 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetCurrent2 = (y / 10)
                                    txtSetCurr2.Text = gSetCurrent2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtSetCurr2.Text = gSetCurrent2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtSetCurr2.Text = gSetCurrent2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub

    Private Sub txtSetVol2_gotfocus(sender As Object, e As EventArgs) Handles txtSetVol2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtSetVol2
    End Sub

    Private Sub txtSetVol2_TextChanged(sender As Object, e As EventArgs) Handles txtSetVol2.TextChanged
        Dim arr As Integer = 0
        arr = txtSetVol2.TextLength
        Dim st As String = ""

        st = txtSetVol2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtSetVol2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtSetVol2.Text += ii(ht)
                    Next
                    If txtSetVol2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtSetVol2.Text * 10
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001EC000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                            Threading.Thread.Sleep(500)

                            '/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 EC 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetVoltage2 = (y / 10)
                                    txtSetVol2.Text = gSetVoltage2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtSetVol2.Text = gSetVoltage2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtSetVol2.Text = gSetVoltage2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub

    Private Sub txtSetWirefeed2_gotfocus(sender As Object, e As EventArgs) Handles txtSetWirefeed2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtSetWirefeed2
    End Sub

    Private Sub txtSetWirefeed2_TextChanged(sender As Object, e As EventArgs) Handles txtSetWirefeed2.TextChanged
        Dim arr As Integer = 0
        arr = txtSetWirefeed2.TextLength
        Dim st As String = ""

        st = txtSetWirefeed2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtSetWirefeed2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtSetWirefeed2.Text += ii(ht)
                    Next
                    If txtSetWirefeed2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtSetWirefeed2.Text * 10
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001EE000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)

                            Threading.Thread.Sleep(500)
                            '/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 EE 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(0) = "02" And x1(1) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetWFSpeed2 = (y / 10)
                                    txtSetWirefeed2.Text = gSetWFSpeed2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtSetWirefeed2.Text = gSetWFSpeed2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtSetWirefeed2.Text = gSetWFSpeed2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub


    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

    'Private Sub btnset_MouseDown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnSet.MouseDown
    '    btnSet.Image = Global.iotPIPECLEDING.My.Resources.btngreen
    '    If isConnection = True Then
    'tx = ""
    ' rx = ""

    '        tx = "00 00 00 00 00 06 02 05 00 AA FF 00"
    '        rx = TCPComA(tx, 10)
    '        'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)
    '    End If

    'End Sub
    'Private Sub btnset_MouseUp(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles btnSet.MouseUp
    '    btnSet.Image = Global.iotPIPECLEDING.My.Resources.btnblue
    '    If isConnection = True Then
    'tx = ""
    'rx = ""

    '        tx = "00 00 00 00 00 06 02 05 00 AA 00 00"
    '        rx = TCPComA(tx, 10)
    '        'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)
    '    End If
    'End Sub


    'Private Sub frmEssc_GotFocus(sender As Object, e As EventArgs) Handles Me.GotFocus
    '    Timer1.Enabled = True
    'End Sub

    'Private Sub frmEssc_LostFocus(sender As Object, e As EventArgs) Handles Me.LostFocus
    '    Timer1.Enabled = False
    'End Sub

    'Private Sub frmEssc_Activated(sender As Object, e As EventArgs) Handles Me.Activated
    '    Timer1.Enabled = True
    'End Sub
End Class