﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MDIParent1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnMain = New System.Windows.Forms.Button()
        Me.btnMentry = New System.Windows.Forms.Button()
        Me.btnDiag = New System.Windows.Forms.Button()
        Me.btnConsum = New System.Windows.Forms.Button()
        Me.btnWPS = New System.Windows.Forms.Button()
        Me.BtnAux = New System.Windows.Forms.Button()
        Me.btnPara = New System.Windows.Forms.Button()
        Me.PanelBtn = New System.Windows.Forms.Panel()
        Me.lblF = New System.Windows.Forms.Label()
        Me.lblL = New System.Windows.Forms.Label()
        Me.lblA = New System.Windows.Forms.Label()
        Me.lblH = New System.Windows.Forms.Label()
        Me.btnControls = New System.Windows.Forms.Button()
        Me.lblNetworkConnectivity = New System.Windows.Forms.Label()
        Me.lblStatusRX = New System.Windows.Forms.Label()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.btnJobData = New System.Windows.Forms.Button()
        Me.btnBatch = New System.Windows.Forms.Button()
        Me.btnWNote = New System.Windows.Forms.Button()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.tParalog = New System.Windows.Forms.Timer(Me.components)
        Me.PanelBtn.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnMain
        '
        Me.btnMain.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.btnMain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMain.Location = New System.Drawing.Point(0, 0)
        Me.btnMain.Name = "btnMain"
        Me.btnMain.Size = New System.Drawing.Size(90, 47)
        Me.btnMain.TabIndex = 0
        Me.btnMain.Text = "Main"
        Me.btnMain.UseVisualStyleBackColor = True
        '
        'btnMentry
        '
        Me.btnMentry.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.btnMentry.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMentry.Location = New System.Drawing.Point(690, 3)
        Me.btnMentry.Name = "btnMentry"
        Me.btnMentry.Size = New System.Drawing.Size(72, 47)
        Me.btnMentry.TabIndex = 1
        Me.btnMentry.Text = "MEntry"
        Me.btnMentry.UseVisualStyleBackColor = True
        '
        'btnDiag
        '
        Me.btnDiag.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.btnDiag.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDiag.Location = New System.Drawing.Point(766, 3)
        Me.btnDiag.Name = "btnDiag"
        Me.btnDiag.Size = New System.Drawing.Size(91, 47)
        Me.btnDiag.TabIndex = 2
        Me.btnDiag.Text = "Diagnosis"
        Me.btnDiag.UseVisualStyleBackColor = True
        '
        'btnConsum
        '
        Me.btnConsum.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.btnConsum.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnConsum.Enabled = False
        Me.btnConsum.Location = New System.Drawing.Point(577, 2)
        Me.btnConsum.Name = "btnConsum"
        Me.btnConsum.Size = New System.Drawing.Size(110, 47)
        Me.btnConsum.TabIndex = 3
        Me.btnConsum.Text = "Consumable"
        Me.btnConsum.UseVisualStyleBackColor = True
        '
        'btnWPS
        '
        Me.btnWPS.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.btnWPS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnWPS.Enabled = False
        Me.btnWPS.Location = New System.Drawing.Point(369, 1)
        Me.btnWPS.Name = "btnWPS"
        Me.btnWPS.Size = New System.Drawing.Size(56, 47)
        Me.btnWPS.TabIndex = 4
        Me.btnWPS.Text = "WDS"
        Me.btnWPS.UseVisualStyleBackColor = True
        '
        'BtnAux
        '
        Me.BtnAux.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.BtnAux.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnAux.Location = New System.Drawing.Point(289, 1)
        Me.BtnAux.Name = "BtnAux"
        Me.BtnAux.Size = New System.Drawing.Size(78, 47)
        Me.BtnAux.TabIndex = 5
        Me.BtnAux.Text = "Auxillary"
        Me.BtnAux.UseVisualStyleBackColor = True
        '
        'btnPara
        '
        Me.btnPara.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.btnPara.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPara.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnPara.Location = New System.Drawing.Point(860, 2)
        Me.btnPara.Name = "btnPara"
        Me.btnPara.Size = New System.Drawing.Size(74, 47)
        Me.btnPara.TabIndex = 6
        Me.btnPara.Text = "Para Setup"
        Me.btnPara.UseVisualStyleBackColor = True
        '
        'PanelBtn
        '
        Me.PanelBtn.Controls.Add(Me.lblF)
        Me.PanelBtn.Controls.Add(Me.lblL)
        Me.PanelBtn.Controls.Add(Me.lblA)
        Me.PanelBtn.Controls.Add(Me.lblH)
        Me.PanelBtn.Controls.Add(Me.btnControls)
        Me.PanelBtn.Controls.Add(Me.lblNetworkConnectivity)
        Me.PanelBtn.Controls.Add(Me.lblStatusRX)
        Me.PanelBtn.Controls.Add(Me.lblStatus)
        Me.PanelBtn.Controls.Add(Me.btnJobData)
        Me.PanelBtn.Controls.Add(Me.btnBatch)
        Me.PanelBtn.Controls.Add(Me.btnWNote)
        Me.PanelBtn.Controls.Add(Me.lblTime)
        Me.PanelBtn.Controls.Add(Me.btnPara)
        Me.PanelBtn.Controls.Add(Me.BtnAux)
        Me.PanelBtn.Controls.Add(Me.btnWPS)
        Me.PanelBtn.Controls.Add(Me.btnConsum)
        Me.PanelBtn.Controls.Add(Me.btnDiag)
        Me.PanelBtn.Controls.Add(Me.btnMentry)
        Me.PanelBtn.Controls.Add(Me.btnMain)
        Me.PanelBtn.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PanelBtn.Location = New System.Drawing.Point(0, 403)
        Me.PanelBtn.Name = "PanelBtn"
        Me.PanelBtn.Size = New System.Drawing.Size(1280, 50)
        Me.PanelBtn.TabIndex = 9
        '
        'lblF
        '
        Me.lblF.BackColor = System.Drawing.Color.DarkGray
        Me.lblF.Location = New System.Drawing.Point(992, 5)
        Me.lblF.Name = "lblF"
        Me.lblF.Size = New System.Drawing.Size(20, 47)
        Me.lblF.TabIndex = 76
        Me.lblF.Text = "F"
        Me.lblF.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblL
        '
        Me.lblL.BackColor = System.Drawing.Color.DarkGray
        Me.lblL.Location = New System.Drawing.Point(1019, 5)
        Me.lblL.Name = "lblL"
        Me.lblL.Size = New System.Drawing.Size(20, 47)
        Me.lblL.TabIndex = 75
        Me.lblL.Text = "L"
        Me.lblL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblA
        '
        Me.lblA.BackColor = System.Drawing.Color.DarkGray
        Me.lblA.Location = New System.Drawing.Point(965, 3)
        Me.lblA.Name = "lblA"
        Me.lblA.Size = New System.Drawing.Size(20, 47)
        Me.lblA.TabIndex = 74
        Me.lblA.Text = "A"
        Me.lblA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblH
        '
        Me.lblH.BackColor = System.Drawing.Color.DarkGray
        Me.lblH.Location = New System.Drawing.Point(938, 2)
        Me.lblH.Name = "lblH"
        Me.lblH.Size = New System.Drawing.Size(20, 47)
        Me.lblH.TabIndex = 73
        Me.lblH.Text = "H"
        Me.lblH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnControls
        '
        Me.btnControls.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.btnControls.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnControls.Location = New System.Drawing.Point(190, 0)
        Me.btnControls.Name = "btnControls"
        Me.btnControls.Size = New System.Drawing.Size(96, 47)
        Me.btnControls.TabIndex = 72
        Me.btnControls.Text = "Controls"
        Me.btnControls.UseVisualStyleBackColor = True
        '
        'lblNetworkConnectivity
        '
        Me.lblNetworkConnectivity.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblNetworkConnectivity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblNetworkConnectivity.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblNetworkConnectivity.Location = New System.Drawing.Point(1199, 5)
        Me.lblNetworkConnectivity.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblNetworkConnectivity.Name = "lblNetworkConnectivity"
        Me.lblNetworkConnectivity.Size = New System.Drawing.Size(73, 39)
        Me.lblNetworkConnectivity.TabIndex = 71
        Me.lblNetworkConnectivity.Text = "Network"
        Me.lblNetworkConnectivity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStatusRX
        '
        Me.lblStatusRX.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblStatusRX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblStatusRX.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblStatusRX.Location = New System.Drawing.Point(1172, 5)
        Me.lblStatusRX.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblStatusRX.Name = "lblStatusRX"
        Me.lblStatusRX.Size = New System.Drawing.Size(20, 39)
        Me.lblStatusRX.TabIndex = 70
        Me.lblStatusRX.Text = "2"
        Me.lblStatusRX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStatus
        '
        Me.lblStatus.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblStatus.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblStatus.Location = New System.Drawing.Point(1146, 5)
        Me.lblStatus.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(20, 39)
        Me.lblStatus.TabIndex = 69
        Me.lblStatus.Text = "1"
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnJobData
        '
        Me.btnJobData.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.btnJobData.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnJobData.Location = New System.Drawing.Point(93, 0)
        Me.btnJobData.Name = "btnJobData"
        Me.btnJobData.Size = New System.Drawing.Size(94, 47)
        Me.btnJobData.TabIndex = 13
        Me.btnJobData.Text = "Job Data"
        Me.btnJobData.UseVisualStyleBackColor = True
        '
        'btnBatch
        '
        Me.btnBatch.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.btnBatch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnBatch.Enabled = False
        Me.btnBatch.Location = New System.Drawing.Point(499, 1)
        Me.btnBatch.Name = "btnBatch"
        Me.btnBatch.Size = New System.Drawing.Size(75, 47)
        Me.btnBatch.TabIndex = 68
        Me.btnBatch.Text = "Allowed Batch"
        Me.btnBatch.UseVisualStyleBackColor = True
        '
        'btnWNote
        '
        Me.btnWNote.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnorg
        Me.btnWNote.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnWNote.Enabled = False
        Me.btnWNote.Location = New System.Drawing.Point(427, 0)
        Me.btnWNote.Name = "btnWNote"
        Me.btnWNote.Size = New System.Drawing.Size(70, 47)
        Me.btnWNote.TabIndex = 67
        Me.btnWNote.Text = "WelderNote"
        Me.btnWNote.UseVisualStyleBackColor = True
        '
        'lblTime
        '
        Me.lblTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTime.Location = New System.Drawing.Point(1045, 3)
        Me.lblTime.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(95, 44)
        Me.lblTime.TabIndex = 65
        Me.lblTime.Text = "now"
        Me.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(4, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(1166, 24)
        Me.MenuStrip1.TabIndex = 11
        Me.MenuStrip1.Text = "MenuStrip1"
        Me.MenuStrip1.Visible = False
        '
        'tParalog
        '
        '
        'MDIParent1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1280, 453)
        Me.ControlBox = False
        Me.Controls.Add(Me.PanelBtn)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MDIParent1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.PanelBtn.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnMain As System.Windows.Forms.Button
    Friend WithEvents btnMentry As System.Windows.Forms.Button
    Friend WithEvents btnDiag As System.Windows.Forms.Button
    Friend WithEvents btnConsum As System.Windows.Forms.Button
    Friend WithEvents btnWPS As System.Windows.Forms.Button
    Friend WithEvents BtnAux As System.Windows.Forms.Button
    Friend WithEvents btnPara As System.Windows.Forms.Button
    Friend WithEvents PanelBtn As System.Windows.Forms.Panel
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents lblTime As System.Windows.Forms.Label
    Friend WithEvents btnBatch As System.Windows.Forms.Button
    Friend WithEvents btnWNote As System.Windows.Forms.Button
    Friend WithEvents btnJobData As Button
    Friend WithEvents lblStatusRX As Label
    Friend WithEvents lblStatus As Label
    Friend WithEvents lblNetworkConnectivity As Label
    Friend WithEvents tParalog As Timer
    Friend WithEvents btnControls As Button
    Friend WithEvents lblH As Label
    Friend WithEvents lblA As Label
    Friend WithEvents lblF As Label
    Friend WithEvents lblL As Label
End Class
