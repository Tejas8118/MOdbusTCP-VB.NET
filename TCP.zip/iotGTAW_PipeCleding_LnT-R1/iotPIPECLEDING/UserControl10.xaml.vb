﻿

Public Class UserControl10
    Dim tx As String = ""
    Dim rx As String = ""

    Private Sub b1_Click(ByVal sender As Object, ByVal e As Windows.Input.TouchEventArgs) Handles wireout.TouchEnter
        ''b2.TouchEnter execution
        'Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/dnE.png"))
        'Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        'b2.Background = imgbrush

        'b1.TouchEnter execution
        Dim imgsrc1 As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/wireoutG.png"))
        Dim imgbrush1 As New System.Windows.Media.ImageBrush(imgsrc1)
        wireout.Background = imgbrush1

        If isConnection = True Then
            tx = ""
            rx = ""

            'b1.TouchEnter execution
            tx = "00 00 00 00 00 06 02 05 00 D4 FF 00"
            rx = TCPComA(tx, 10)
            'writeLog("|ESSCupR |TX:" & tx & " |RX:" & rx)
        End If
    End Sub
    Private Sub b1_Click1(sender As Object, e As Windows.Input.TouchEventArgs) Handles wireout.TouchLeave
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/wireout.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        wireout.Background = imgbrush

        If isConnection = True Then
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 D4 00 00"
            rx = TCPComA(tx, 10)
            'writeLog("|ESSCupR |TX:" & tx & " |RX:" & rx)

            Threading.Thread.Sleep(1000)


            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 D4 00 00"
            rx = TCPComA(tx, 10)
            'writeLog("|ESSCupR |TX:" & tx & " |RX:" & rx)

        End If
    End Sub



End Class
