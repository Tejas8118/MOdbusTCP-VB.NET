﻿'----------------------------------
' iotESSC for L&T
' by  trapasia DigiReach @ 2017
' Password for parameter setup screen
' 
'----------------------------------
Public Class frmParaPass
    'Declare Function Wow64DisableWow64FsRedirection Lib "kernel32" (ByRef oldvalue As Long) As Boolean
    'Declare Function Wow64EnableWow64FsRedirection Lib "kernel32" (ByRef oldvalue As Long) As Boolean
    'Private osk As String = "C:\Windows\System32\osk.exe"

    Private Sub txtPass_GotFocus(sender As Object, e As System.EventArgs) Handles txtPass.GotFocus
        psKB1.CurrTextBox = Me.txtPass
        psKB1.Visible = True
    End Sub

    Private Sub btnClose_Click(sender As System.Object, e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub


End Class