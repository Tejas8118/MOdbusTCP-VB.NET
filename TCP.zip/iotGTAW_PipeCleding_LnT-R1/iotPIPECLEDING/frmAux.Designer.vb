﻿Imports Microsoft.VisualBasic.PowerPacks

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAux
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAux))
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnDevice6 = New System.Windows.Forms.Button()
        Me.btnDevice5 = New System.Windows.Forms.Button()
        Me.btnDevice2 = New System.Windows.Forms.Button()
        Me.btnDevice7 = New System.Windows.Forms.Button()
        Me.btnDevice4 = New System.Windows.Forms.Button()
        Me.btnDevice1 = New System.Windows.Forms.Button()
        Me.btnDevice3 = New System.Windows.Forms.Button()
        Me.btnDevice9 = New System.Windows.Forms.Button()
        Me.btnDevice8 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Wrkb1 = New myControls.WRKB()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.RectangleShape = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.pnlPHS = New System.Windows.Forms.Panel()
        Me.HWPSONOFF2 = New System.Windows.Forms.Button()
        Me.ElementHost8 = New System.Windows.Forms.Integration.ElementHost()
        Me.Hwt21 = New iotPIPECLEDING.Hwt2()
        Me.btnSyncData = New System.Windows.Forms.Button()
        Me.ProgressBar3 = New System.Windows.Forms.ProgressBar()
        Me.ElementHost5 = New System.Windows.Forms.Integration.ElementHost()
        Me.Hwt12 = New iotPIPECLEDING.Hwt1()
        Me.HWPSONOFF1 = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.ShapeContainer2 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtWFSpeed2 = New System.Windows.Forms.TextBox()
        Me.txtWFStartDelay2 = New System.Windows.Forms.TextBox()
        Me.txtWFRetract2 = New System.Windows.Forms.TextBox()
        Me.btnWFONOFF2 = New System.Windows.Forms.Button()
        Me.ElementHost7 = New System.Windows.Forms.Integration.ElementHost()
        Me.Wft22 = New iotPIPECLEDING.Wft2()
        Me.ElementHost4 = New System.Windows.Forms.Integration.ElementHost()
        Me.WireoutB2 = New iotPIPECLEDING.WireoutB()
        Me.ElementHost3 = New System.Windows.Forms.Integration.ElementHost()
        Me.WireinB2 = New iotPIPECLEDING.WireinB()
        Me.ElementHost6 = New System.Windows.Forms.Integration.ElementHost()
        Me.Wft12 = New iotPIPECLEDING.Wft1()
        Me.ElementHost2 = New System.Windows.Forms.Integration.ElementHost()
        Me.UserControl102 = New iotPIPECLEDING.UserControl10()
        Me.ElementHost1 = New System.Windows.Forms.Integration.ElementHost()
        Me.UserControl92 = New iotPIPECLEDING.UserControl9()
        Me.txtWFRetract1 = New System.Windows.Forms.TextBox()
        Me.txtWFStartDelay1 = New System.Windows.Forms.TextBox()
        Me.txtWFSpeed1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnWFONOFF1 = New System.Windows.Forms.Button()
        Me.Panel3.SuspendLayout()
        Me.pnlPHS.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.btnDevice6)
        Me.Panel3.Controls.Add(Me.btnDevice5)
        Me.Panel3.Controls.Add(Me.btnDevice2)
        Me.Panel3.Controls.Add(Me.btnDevice7)
        Me.Panel3.Controls.Add(Me.btnDevice4)
        Me.Panel3.Controls.Add(Me.btnDevice1)
        Me.Panel3.Controls.Add(Me.btnDevice3)
        Me.Panel3.Controls.Add(Me.btnDevice9)
        Me.Panel3.Controls.Add(Me.btnDevice8)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Location = New System.Drawing.Point(515, 408)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(5)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(755, 346)
        Me.Panel3.TabIndex = 6
        '
        'btnDevice6
        '
        Me.btnDevice6.BackgroundImage = CType(resources.GetObject("btnDevice6.BackgroundImage"), System.Drawing.Image)
        Me.btnDevice6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDevice6.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDevice6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDevice6.Location = New System.Drawing.Point(514, 163)
        Me.btnDevice6.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDevice6.Name = "btnDevice6"
        Me.btnDevice6.Size = New System.Drawing.Size(165, 65)
        Me.btnDevice6.TabIndex = 32
        Me.btnDevice6.Tag = "0"
        Me.btnDevice6.Text = "Spare-1"
        Me.btnDevice6.UseVisualStyleBackColor = True
        '
        'btnDevice5
        '
        Me.btnDevice5.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.btnDevice5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDevice5.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDevice5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDevice5.Location = New System.Drawing.Point(272, 172)
        Me.btnDevice5.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDevice5.Name = "btnDevice5"
        Me.btnDevice5.Size = New System.Drawing.Size(165, 65)
        Me.btnDevice5.TabIndex = 31
        Me.btnDevice5.Tag = "0"
        Me.btnDevice5.Text = "Light"
        Me.btnDevice5.UseVisualStyleBackColor = True
        '
        'btnDevice2
        '
        Me.btnDevice2.BackgroundImage = CType(resources.GetObject("btnDevice2.BackgroundImage"), System.Drawing.Image)
        Me.btnDevice2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDevice2.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDevice2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDevice2.Location = New System.Drawing.Point(272, 67)
        Me.btnDevice2.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDevice2.Name = "btnDevice2"
        Me.btnDevice2.Size = New System.Drawing.Size(165, 65)
        Me.btnDevice2.TabIndex = 29
        Me.btnDevice2.Tag = "0"
        Me.btnDevice2.Text = "SPARE-4"
        Me.btnDevice2.UseVisualStyleBackColor = True
        '
        'btnDevice7
        '
        Me.btnDevice7.BackgroundImage = CType(resources.GetObject("btnDevice7.BackgroundImage"), System.Drawing.Image)
        Me.btnDevice7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDevice7.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDevice7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDevice7.Location = New System.Drawing.Point(52, 270)
        Me.btnDevice7.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDevice7.Name = "btnDevice7"
        Me.btnDevice7.Size = New System.Drawing.Size(165, 65)
        Me.btnDevice7.TabIndex = 28
        Me.btnDevice7.Tag = "0"
        Me.btnDevice7.Text = "Spare-2"
        Me.btnDevice7.UseVisualStyleBackColor = True
        '
        'btnDevice4
        '
        Me.btnDevice4.BackgroundImage = CType(resources.GetObject("btnDevice4.BackgroundImage"), System.Drawing.Image)
        Me.btnDevice4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDevice4.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDevice4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDevice4.Location = New System.Drawing.Point(52, 172)
        Me.btnDevice4.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDevice4.Name = "btnDevice4"
        Me.btnDevice4.Size = New System.Drawing.Size(165, 65)
        Me.btnDevice4.TabIndex = 27
        Me.btnDevice4.Tag = "0"
        Me.btnDevice4.Text = "Chiller"
        Me.btnDevice4.UseVisualStyleBackColor = True
        '
        'btnDevice1
        '
        Me.btnDevice1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.btnDevice1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDevice1.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDevice1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDevice1.Location = New System.Drawing.Point(52, 67)
        Me.btnDevice1.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDevice1.Name = "btnDevice1"
        Me.btnDevice1.Size = New System.Drawing.Size(165, 65)
        Me.btnDevice1.TabIndex = 26
        Me.btnDevice1.Tag = "0"
        Me.btnDevice1.Text = "SPARE-3"
        Me.btnDevice1.UseVisualStyleBackColor = True
        '
        'btnDevice3
        '
        Me.btnDevice3.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.btnDevice3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDevice3.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDevice3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDevice3.Location = New System.Drawing.Point(514, 67)
        Me.btnDevice3.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDevice3.Name = "btnDevice3"
        Me.btnDevice3.Size = New System.Drawing.Size(165, 65)
        Me.btnDevice3.TabIndex = 25
        Me.btnDevice3.Tag = "0"
        Me.btnDevice3.Text = "Spare-5"
        Me.btnDevice3.UseVisualStyleBackColor = True
        '
        'btnDevice9
        '
        Me.btnDevice9.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.btnDevice9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDevice9.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDevice9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDevice9.Location = New System.Drawing.Point(514, 270)
        Me.btnDevice9.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDevice9.Name = "btnDevice9"
        Me.btnDevice9.Size = New System.Drawing.Size(165, 65)
        Me.btnDevice9.TabIndex = 24
        Me.btnDevice9.Tag = "0"
        Me.btnDevice9.Text = "W/F-1 Remote"
        Me.btnDevice9.UseVisualStyleBackColor = True
        '
        'btnDevice8
        '
        Me.btnDevice8.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.btnDevice8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDevice8.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDevice8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDevice8.Location = New System.Drawing.Point(272, 270)
        Me.btnDevice8.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDevice8.Name = "btnDevice8"
        Me.btnDevice8.Size = New System.Drawing.Size(165, 65)
        Me.btnDevice8.TabIndex = 23
        Me.btnDevice8.Tag = "0"
        Me.btnDevice8.Text = "W/F-2 Remote"
        Me.btnDevice8.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.SkyBlue
        Me.Label2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(-1, 0)
        Me.Label2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(755, 43)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Auxiliary Control"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Wrkb1
        '
        Me.Wrkb1.CurrTextBox = Nothing
        Me.Wrkb1.Location = New System.Drawing.Point(632, 22)
        Me.Wrkb1.Margin = New System.Windows.Forms.Padding(5)
        Me.Wrkb1.Name = "Wrkb1"
        Me.Wrkb1.Size = New System.Drawing.Size(378, 312)
        Me.Wrkb1.TabIndex = 78
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape})
        Me.ShapeContainer1.Size = New System.Drawing.Size(782, 421)
        Me.ShapeContainer1.TabIndex = 34
        Me.ShapeContainer1.TabStop = False
        '
        'RectangleShape
        '
        Me.RectangleShape.Location = New System.Drawing.Point(229, 87)
        Me.RectangleShape.Name = "RectangleShape"
        Me.RectangleShape.Size = New System.Drawing.Size(75, 23)
        '
        'pnlPHS
        '
        Me.pnlPHS.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.pnlPHS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlPHS.Controls.Add(Me.HWPSONOFF2)
        Me.pnlPHS.Controls.Add(Me.ElementHost8)
        Me.pnlPHS.Controls.Add(Me.btnSyncData)
        Me.pnlPHS.Controls.Add(Me.ProgressBar3)
        Me.pnlPHS.Controls.Add(Me.ElementHost5)
        Me.pnlPHS.Controls.Add(Me.HWPSONOFF1)
        Me.pnlPHS.Controls.Add(Me.Label12)
        Me.pnlPHS.Controls.Add(Me.ShapeContainer2)
        Me.pnlPHS.Location = New System.Drawing.Point(14, 407)
        Me.pnlPHS.Margin = New System.Windows.Forms.Padding(5)
        Me.pnlPHS.Name = "pnlPHS"
        Me.pnlPHS.Size = New System.Drawing.Size(489, 347)
        Me.pnlPHS.TabIndex = 63
        '
        'HWPSONOFF2
        '
        Me.HWPSONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.hwp2off
        Me.HWPSONOFF2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.HWPSONOFF2.FlatAppearance.BorderSize = 0
        Me.HWPSONOFF2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.HWPSONOFF2.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HWPSONOFF2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.HWPSONOFF2.Location = New System.Drawing.Point(29, 194)
        Me.HWPSONOFF2.Margin = New System.Windows.Forms.Padding(4)
        Me.HWPSONOFF2.Name = "HWPSONOFF2"
        Me.HWPSONOFF2.Size = New System.Drawing.Size(128, 88)
        Me.HWPSONOFF2.TabIndex = 107
        Me.HWPSONOFF2.Tag = "0"
        Me.HWPSONOFF2.UseVisualStyleBackColor = True
        '
        'ElementHost8
        '
        Me.ElementHost8.Location = New System.Drawing.Point(189, 185)
        Me.ElementHost8.Name = "ElementHost8"
        Me.ElementHost8.Size = New System.Drawing.Size(123, 120)
        Me.ElementHost8.TabIndex = 106
        Me.ElementHost8.Text = "ElementHost8"
        Me.ElementHost8.Child = Me.Hwt21
        '
        'btnSyncData
        '
        Me.btnSyncData.BackgroundImage = CType(resources.GetObject("btnSyncData.BackgroundImage"), System.Drawing.Image)
        Me.btnSyncData.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnSyncData.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSyncData.ForeColor = System.Drawing.Color.Cornsilk
        Me.btnSyncData.Location = New System.Drawing.Point(349, 234)
        Me.btnSyncData.Name = "btnSyncData"
        Me.btnSyncData.Size = New System.Drawing.Size(120, 67)
        Me.btnSyncData.TabIndex = 105
        Me.btnSyncData.Text = "Syncronise Local Data"
        Me.btnSyncData.UseVisualStyleBackColor = True
        '
        'ProgressBar3
        '
        Me.ProgressBar3.Location = New System.Drawing.Point(7, 318)
        Me.ProgressBar3.Name = "ProgressBar3"
        Me.ProgressBar3.Size = New System.Drawing.Size(462, 23)
        Me.ProgressBar3.TabIndex = 104
        '
        'ElementHost5
        '
        Me.ElementHost5.Location = New System.Drawing.Point(189, 55)
        Me.ElementHost5.Name = "ElementHost5"
        Me.ElementHost5.Size = New System.Drawing.Size(123, 120)
        Me.ElementHost5.TabIndex = 31
        Me.ElementHost5.Text = "ElementHost5"
        Me.ElementHost5.Child = Me.Hwt12
        '
        'HWPSONOFF1
        '
        Me.HWPSONOFF1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.hwp1off
        Me.HWPSONOFF1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.HWPSONOFF1.FlatAppearance.BorderSize = 0
        Me.HWPSONOFF1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.HWPSONOFF1.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HWPSONOFF1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.HWPSONOFF1.Location = New System.Drawing.Point(20, 62)
        Me.HWPSONOFF1.Margin = New System.Windows.Forms.Padding(4)
        Me.HWPSONOFF1.Name = "HWPSONOFF1"
        Me.HWPSONOFF1.Size = New System.Drawing.Size(128, 88)
        Me.HWPSONOFF1.TabIndex = 29
        Me.HWPSONOFF1.Tag = "0"
        Me.HWPSONOFF1.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.SkyBlue
        Me.Label12.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label12.Location = New System.Drawing.Point(0, 0)
        Me.Label12.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(488, 43)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Hot Wire P/S Controls"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ShapeContainer2
        '
        Me.ShapeContainer2.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer2.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer2.Name = "ShapeContainer2"
        Me.ShapeContainer2.Size = New System.Drawing.Size(487, 345)
        Me.ShapeContainer2.TabIndex = 21
        Me.ShapeContainer2.TabStop = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.SkyBlue
        Me.Label1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(2, 1)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1243, 26)
        Me.Label1.TabIndex = 64
        Me.Label1.Text = "Wirefeed Controls"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Wrkb1)
        Me.Panel1.Controls.Add(Me.txtWFSpeed2)
        Me.Panel1.Controls.Add(Me.txtWFStartDelay2)
        Me.Panel1.Controls.Add(Me.txtWFRetract2)
        Me.Panel1.Controls.Add(Me.btnWFONOFF2)
        Me.Panel1.Controls.Add(Me.ElementHost7)
        Me.Panel1.Controls.Add(Me.ElementHost4)
        Me.Panel1.Controls.Add(Me.ElementHost3)
        Me.Panel1.Controls.Add(Me.ElementHost6)
        Me.Panel1.Controls.Add(Me.ElementHost2)
        Me.Panel1.Controls.Add(Me.ElementHost1)
        Me.Panel1.Controls.Add(Me.txtWFRetract1)
        Me.Panel1.Controls.Add(Me.txtWFStartDelay1)
        Me.Panel1.Controls.Add(Me.txtWFSpeed1)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.btnWFONOFF1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(12, 34)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1260, 354)
        Me.Panel1.TabIndex = 65
        '
        'txtWFSpeed2
        '
        Me.txtWFSpeed2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWFSpeed2.Location = New System.Drawing.Point(190, 252)
        Me.txtWFSpeed2.Name = "txtWFSpeed2"
        Me.txtWFSpeed2.Size = New System.Drawing.Size(100, 31)
        Me.txtWFSpeed2.TabIndex = 90
        Me.txtWFSpeed2.Text = "00000"
        Me.txtWFSpeed2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtWFStartDelay2
        '
        Me.txtWFStartDelay2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWFStartDelay2.Location = New System.Drawing.Point(326, 252)
        Me.txtWFStartDelay2.Name = "txtWFStartDelay2"
        Me.txtWFStartDelay2.Size = New System.Drawing.Size(100, 31)
        Me.txtWFStartDelay2.TabIndex = 89
        Me.txtWFStartDelay2.Text = "000"
        Me.txtWFStartDelay2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtWFRetract2
        '
        Me.txtWFRetract2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWFRetract2.Location = New System.Drawing.Point(463, 252)
        Me.txtWFRetract2.Name = "txtWFRetract2"
        Me.txtWFRetract2.Size = New System.Drawing.Size(100, 31)
        Me.txtWFRetract2.TabIndex = 88
        Me.txtWFRetract2.Text = "000"
        Me.txtWFRetract2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnWFONOFF2
        '
        Me.btnWFONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.WF2OFF
        Me.btnWFONOFF2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnWFONOFF2.FlatAppearance.BorderSize = 0
        Me.btnWFONOFF2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWFONOFF2.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWFONOFF2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnWFONOFF2.Location = New System.Drawing.Point(19, 225)
        Me.btnWFONOFF2.Margin = New System.Windows.Forms.Padding(4)
        Me.btnWFONOFF2.Name = "btnWFONOFF2"
        Me.btnWFONOFF2.Size = New System.Drawing.Size(123, 97)
        Me.btnWFONOFF2.TabIndex = 87
        Me.btnWFONOFF2.Tag = "0"
        Me.btnWFONOFF2.UseVisualStyleBackColor = True
        '
        'ElementHost7
        '
        Me.ElementHost7.Location = New System.Drawing.Point(642, 196)
        Me.ElementHost7.Name = "ElementHost7"
        Me.ElementHost7.Size = New System.Drawing.Size(118, 126)
        Me.ElementHost7.TabIndex = 86
        Me.ElementHost7.Text = "ElementHost7"
        Me.ElementHost7.Child = Me.Wft22
        '
        'ElementHost4
        '
        Me.ElementHost4.Location = New System.Drawing.Point(1074, 196)
        Me.ElementHost4.Name = "ElementHost4"
        Me.ElementHost4.Size = New System.Drawing.Size(121, 119)
        Me.ElementHost4.TabIndex = 85
        Me.ElementHost4.Text = "ElementHost4"
        Me.ElementHost4.Child = Me.WireoutB2
        '
        'ElementHost3
        '
        Me.ElementHost3.Location = New System.Drawing.Point(857, 196)
        Me.ElementHost3.Name = "ElementHost3"
        Me.ElementHost3.Size = New System.Drawing.Size(121, 119)
        Me.ElementHost3.TabIndex = 84
        Me.ElementHost3.Text = "ElementHost3"
        Me.ElementHost3.Child = Me.WireinB2
        '
        'ElementHost6
        '
        Me.ElementHost6.Location = New System.Drawing.Point(642, 39)
        Me.ElementHost6.Name = "ElementHost6"
        Me.ElementHost6.Size = New System.Drawing.Size(118, 126)
        Me.ElementHost6.TabIndex = 83
        Me.ElementHost6.Text = "ElementHost6"
        Me.ElementHost6.Child = Me.Wft12
        '
        'ElementHost2
        '
        Me.ElementHost2.Location = New System.Drawing.Point(1074, 39)
        Me.ElementHost2.Name = "ElementHost2"
        Me.ElementHost2.Size = New System.Drawing.Size(121, 119)
        Me.ElementHost2.TabIndex = 80
        Me.ElementHost2.Text = "ElementHost2"
        Me.ElementHost2.Child = Me.UserControl102
        '
        'ElementHost1
        '
        Me.ElementHost1.Location = New System.Drawing.Point(857, 39)
        Me.ElementHost1.Name = "ElementHost1"
        Me.ElementHost1.Size = New System.Drawing.Size(121, 119)
        Me.ElementHost1.TabIndex = 79
        Me.ElementHost1.Text = "ElementHost1"
        Me.ElementHost1.Child = Me.UserControl92
        '
        'txtWFRetract1
        '
        Me.txtWFRetract1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWFRetract1.Location = New System.Drawing.Point(463, 110)
        Me.txtWFRetract1.Name = "txtWFRetract1"
        Me.txtWFRetract1.Size = New System.Drawing.Size(100, 31)
        Me.txtWFRetract1.TabIndex = 74
        Me.txtWFRetract1.Text = "000"
        Me.txtWFRetract1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtWFStartDelay1
        '
        Me.txtWFStartDelay1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWFStartDelay1.Location = New System.Drawing.Point(326, 110)
        Me.txtWFStartDelay1.Name = "txtWFStartDelay1"
        Me.txtWFStartDelay1.Size = New System.Drawing.Size(100, 31)
        Me.txtWFStartDelay1.TabIndex = 73
        Me.txtWFStartDelay1.Text = "000"
        Me.txtWFStartDelay1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtWFSpeed1
        '
        Me.txtWFSpeed1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWFSpeed1.Location = New System.Drawing.Point(190, 110)
        Me.txtWFSpeed1.Name = "txtWFSpeed1"
        Me.txtWFSpeed1.Size = New System.Drawing.Size(100, 31)
        Me.txtWFSpeed1.TabIndex = 72
        Me.txtWFSpeed1.Text = "00000"
        Me.txtWFSpeed1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.ForeColor = System.Drawing.Color.Tomato
        Me.Label5.Location = New System.Drawing.Point(459, 45)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(120, 20)
        Me.Label5.TabIndex = 71
        Me.Label5.Text = "Retract(m)"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.ForeColor = System.Drawing.Color.Tomato
        Me.Label4.Location = New System.Drawing.Point(322, 39)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(131, 28)
        Me.Label4.TabIndex = 70
        Me.Label4.Text = "Start Delay(S)"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.ForeColor = System.Drawing.Color.Tomato
        Me.Label3.Location = New System.Drawing.Point(186, 43)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(130, 20)
        Me.Label3.TabIndex = 69
        Me.Label3.Text = "Speed(mm/m)"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnWFONOFF1
        '
        Me.btnWFONOFF1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.WF1OFF
        Me.btnWFONOFF1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnWFONOFF1.FlatAppearance.BorderSize = 0
        Me.btnWFONOFF1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWFONOFF1.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWFONOFF1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnWFONOFF1.Location = New System.Drawing.Point(19, 78)
        Me.btnWFONOFF1.Margin = New System.Windows.Forms.Padding(4)
        Me.btnWFONOFF1.Name = "btnWFONOFF1"
        Me.btnWFONOFF1.Size = New System.Drawing.Size(123, 97)
        Me.btnWFONOFF1.TabIndex = 65
        Me.btnWFONOFF1.Tag = "0"
        Me.btnWFONOFF1.UseVisualStyleBackColor = True
        '
        'frmAux
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(1280, 764)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.pnlPHS)
        Me.Controls.Add(Me.Panel3)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAux"
        Me.Panel3.ResumeLayout(False)
        Me.pnlPHS.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnDevice2 As System.Windows.Forms.Button
    Friend WithEvents btnDevice7 As System.Windows.Forms.Button
    Friend WithEvents btnDevice4 As System.Windows.Forms.Button
    Friend WithEvents btnDevice1 As System.Windows.Forms.Button
    Friend WithEvents btnDevice3 As System.Windows.Forms.Button
    Friend WithEvents btnDevice9 As System.Windows.Forms.Button
    Friend WithEvents btnDevice8 As System.Windows.Forms.Button
    Private WithEvents ShapeContainer1 As PowerPacks.ShapeContainer
    Private WithEvents RectangleShape10 As PowerPacks.RectangleShape
    Friend WithEvents btnDevice5 As Button
    Friend WithEvents ShapeContainer11 As ShapeContainer
    Private WithEvents RectangleShape As RectangleShape
    Friend WithEvents btnDevice6 As Button
    Friend WithEvents pnlPHS As Panel
    Friend WithEvents Label12 As Label
    Private WithEvents ShapeContainer2 As ShapeContainer
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents HWPSONOFF1 As Button
    Friend WithEvents btnWFONOFF1 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtWFSpeed1 As TextBox
    Friend WithEvents txtWFRetract1 As TextBox
    Friend WithEvents txtWFStartDelay1 As TextBox
    Friend WithEvents Wrkb1 As myControls.WRKB
    Friend UserControl91 As UserControl9
    Friend UserControl101 As UserControl10
    Friend WireinB1 As WireinB
    Friend WireoutB1 As WireoutB
    Friend Hwt11 As Hwt1
    Friend Wft11 As Wft1
    Friend Wft21 As Wft2
    Friend WithEvents ElementHost1 As Integration.ElementHost
    Friend UserControl92 As UserControl9
    Friend WithEvents ElementHost2 As Integration.ElementHost
    Friend UserControl102 As UserControl10
    Friend WithEvents ElementHost5 As Integration.ElementHost
    Friend Hwt12 As Hwt1
    Friend WithEvents ElementHost6 As Integration.ElementHost
    Friend Wft12 As Wft1
    Friend WithEvents btnSyncData As Button
    Friend WithEvents ProgressBar3 As ProgressBar
    Friend WithEvents ElementHost3 As Integration.ElementHost
    Friend WireinB2 As WireinB
    Friend WithEvents ElementHost4 As Integration.ElementHost
    Friend WireoutB2 As WireoutB
    Friend WithEvents ElementHost7 As Integration.ElementHost
    Friend Wft22 As Wft2
    Friend WithEvents ElementHost8 As Integration.ElementHost
    Friend Hwt21 As Hwt2
    Friend WithEvents HWPSONOFF2 As Button
    Friend WithEvents btnWFONOFF2 As Button
    Friend WithEvents txtWFSpeed2 As TextBox
    Friend WithEvents txtWFStartDelay2 As TextBox
    Friend WithEvents txtWFRetract2 As TextBox
End Class
