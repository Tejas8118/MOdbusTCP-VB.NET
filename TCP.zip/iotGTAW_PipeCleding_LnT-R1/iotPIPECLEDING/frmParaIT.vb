﻿Public Class frmParaIT
    Dim Cid As Integer = 0
    Dim Oid As Integer = 0

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        If gWeldingStart Then
            MessageBox.Show("Welding is going on, Please push local data after welding is off.")
        Else
            DataSync(ProgressBar2, 2) '2 is Manual
        End If
    End Sub

    Private Sub BtnSave1_Click(sender As System.Object, e As System.EventArgs) Handles BtnSave1.Click
        Using objCon As New dbClass
            Try
                If Cid = 0 Then
                    Dim q As String = "insert into device(shop,station,comportTX,comportRX,speed,parapass,machineIP,plcip,plcport) values (" &
                                        "'" & txtShop.Text & "','" & txtStation.Text & "'," & CInt(txtComTX.Text) & "," & CInt(txtComRX.Text) & ",'" & txtSpeed.Text & "','" & txtPass.Text & "','" & txtMachineSetIP.Text & "','" & txtplcsetip.Text & "','" & txtplcsetport.Text & "')"
                    objCon.ExecuteNonQuery(q, CommandType.Text)
                Else
                    Dim q As String = "update device set shop='" & txtShop.Text & "',station='" & txtStation.Text & "',comportTX=" & CInt(txtComTX.Text) & "" &
                                        ",comportRX=" & CInt(txtComRX.Text) & ",speed='" & txtSpeed.Text & "',parapass='" & txtPass.Text & "',machineIP='" & txtMachineSetIP.Text & "',plcip='" & txtplcsetip.Text & "',plcport='" & txtplcsetport.Text & "'  where id=" & Cid
                    objCon.ExecuteNonQuery(q, CommandType.Text)
                    gParaPass = txtPass.Text
                End If

                If Oid = 0 Then

                Else
                    Dim q As String = "update syspara set paralogintvl=" & txtPLI.Text & ",fwlogintval=" & txtFWLI.Text & "  where id=" & Oid
                    objCon.ExecuteNonQuery(q, CommandType.Text)
                End If

                getPara()

                Select Case MsgBox("Data has been Saved", MsgBoxStyle.OkOnly, "Message")
                    Case MsgBoxResult.Ok
                        Me.Close()
                End Select
            Catch ex As Exception
                MessageBox.Show("Error in BtnSave1_Click method of frmParaIT module, Error : " + ex.Message.ToString())
            End Try
        End Using
    End Sub

    Private Sub txtShop_GotFocus(sender As Object, e As System.EventArgs) Handles txtShop.GotFocus
        MyKB1.CurrTextBox = Me.txtShop
        MyKB1.Visible = True
    End Sub

    Private Sub txtSpeed_GotFocus(sender As Object, e As System.EventArgs) Handles txtSpeed.GotFocus
        MyKB1.CurrTextBox = Me.txtSpeed
        MyKB1.Visible = True
    End Sub

    Private Sub txtComRX_GotFocus(sender As Object, e As System.EventArgs) Handles txtComRX.GotFocus
        MyKB1.CurrTextBox = txtComRX
        MyKB1.Visible = True
    End Sub

    Private Sub txtComTX_GotFocus(sender As Object, e As System.EventArgs) Handles txtComTX.GotFocus
        MyKB1.CurrTextBox = Me.txtComTX
        MyKB1.Visible = True
    End Sub

    Private Sub txtFWLI_GotFocus(sender As Object, e As System.EventArgs) Handles txtFWLI.GotFocus
        MyKB1.CurrTextBox = txtFWLI
        MyKB1.Visible = True
    End Sub

    Private Sub txtPass_GotFocus(sender As Object, e As System.EventArgs) Handles txtPass.GotFocus
        MyKB1.CurrTextBox = txtPass
        MyKB1.Visible = True
    End Sub

    Private Sub txtPLI_GotFocus(sender As Object, e As System.EventArgs) Handles txtPLI.GotFocus
        MyKB1.CurrTextBox = txtPLI
        MyKB1.Visible = True
    End Sub

    Private Sub txtStation_GotFocus(sender As Object, e As System.EventArgs) Handles txtStation.GotFocus
        MyKB1.CurrTextBox = Me.txtStation
        MyKB1.Visible = True
    End Sub

    Private Sub frmParaIT_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Panel1.Top = (Me.Height - Panel1.Height) / 2
        Panel1.Left = (Me.Width - Panel1.Width) / 2
    End Sub

    Private Sub frmParaIT_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        fillform()
    End Sub
    Private Sub fillform()
        'objConn.dbConnect()
        'Dim sql As String = "select * from syspara"
        'Dim dt As DataTable
        'dt = objCon.ExecuteDataTable(sql, CommandType.Text)
        'For Each row As DataRow In dt.Rows
        '    Oid = row("id")
        '    txtPLI.Text = row("paralogintvl")
        '    txtFWLI.Text = row("fwlogintval")
        'Next

        'sql = "select * from device"
        'dt = objCon.ExecuteDataTable(sql, CommandType.Text)
        'For Each row As DataRow In dt.Rows
        '    Cid = row("id")
        '    txtShop.Text = row("shop")
        '    txtStation.Text = row("station")
        '    txtComTX.Text = row("comportTX")
        '    txtComRX.Text = row("comportRX")
        '    txtSpeed.Text = row("speed")
        '    txtPass.Text = row("parapass")
        'Next

        'Dim sql As String = "select * from syspara"
        'Dim dt As DataTable
        'dt = objCon.ExecuteDataTable(sql, CommandType.Text)

        Using objCon As New dbClass
            Try
                Using dt As DataTable = objCon.ExecuteDataTable("select * from syspara", CommandType.Text)
                    For Each row As DataRow In dt.Rows
                        Oid = row("id")
                        txtPLI.Text = row("paralogintvl")
                        txtFWLI.Text = row("fwlogintval")
                    Next
                End Using

                'sql = "select * from device"
                'dt = objCon.ExecuteDataTable(sql, CommandType.Text)

                Using dt As DataTable = objCon.ExecuteDataTable("select * from device", CommandType.Text)
                    For Each row As DataRow In dt.Rows
                        Cid = row("id")
                        txtShop.Text = row("shop")
                        txtStation.Text = row("station")
                        txtComTX.Text = row("comportTX")
                        txtComRX.Text = row("comportRX")
                        txtSpeed.Text = row("speed")
                        txtPass.Text = row("parapass")
                        txtMachineSetIP.Text = row("machineIP")
                        txtplcsetip.Text = row("plcip")
                        txtplcsetport.Text = row("plcport")
                    Next
                End Using

                'Showing Actual IP address of Local Machine
                Dim GetIPv4Address As String = String.Empty
                Dim strHostName As String = System.Net.Dns.GetHostName()
                Dim iphe As System.Net.IPHostEntry = System.Net.Dns.GetHostEntry(strHostName)

                For Each ipheal As System.Net.IPAddress In iphe.AddressList
                    If ipheal.AddressFamily = System.Net.Sockets.AddressFamily.InterNetwork Then
                        GetIPv4Address = ipheal.ToString()
                        If GetIPv4Address.Trim = gMachineIP.Trim Then
                            Exit For
                        End If
                    End If
                Next

                lblMachineActIP.Text = GetIPv4Address.Trim
            Catch ex As Exception
                MessageBox.Show("Error in fillform method of frmParaIT module, Error : " + ex.Message.ToString())
            End Try
        End Using

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub txtMachineSetIP_GotFocus(sender As Object, e As EventArgs) Handles txtMachineSetIP.GotFocus
        MyKB1.CurrTextBox = txtMachineSetIP
        MyKB1.Visible = True
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        WelderListSync(ProgressBar2)
    End Sub
End Class