﻿Public Class UserControl2
    Dim tx As String = ""
    Dim rx As String = ""

    Private Sub btnxysfwd_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btnXYSfwd.TouchEnter
        'btnXYSrev.TouchEnter execution
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/revE.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnXYSrev.Background = imgbrush

        'btnXYSfwd.TouchEnter execution
        Dim imgsrc1 As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/fwdon.png"))
        Dim imgbrush1 As New System.Windows.Media.ImageBrush(imgsrc1)
        btnXYSfwd.Background = imgbrush1

        If isConnection = True Then
            tx = ""
            rx = ""

            'btnXYSfwd.TouchEnter execution
            tx = "00 00 00 00 00 06 02 05 00 96 FF 00"
            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)
        End If

    End Sub

    Private Sub btnxysfwd_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btnXYSfwd.TouchLeave
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/fwdE.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnXYSfwd.Background = imgbrush

        If isConnection = True Then
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 96 00 00"
            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)

            Threading.Thread.Sleep(1000)
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 96 00 00"
            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)

        End If
    End Sub

    Private Sub btnxysrev_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btnXYSrev.TouchEnter
        'btnXYSfwd.TouchEnter execution
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/fwdE.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnXYSfwd.Background = imgbrush

        'btnXYSrev.TouchEnter execution
        Dim imgsrc1 As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/revon.png"))
        Dim imgbrush1 As New System.Windows.Media.ImageBrush(imgsrc1)
        btnXYSrev.Background = imgbrush1

        If isConnection = True Then
            tx = ""
            rx = ""

            'btnXYSrev.TouchEnter execution
            tx = "00 00 00 00 00 06 02 05 00 97 FF 00"
            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)
        End If
    End Sub

    Private Sub btnxysrev_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btnXYSrev.TouchLeave
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/revE.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnXYSrev.Background = imgbrush

        If isConnection = True Then
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 97 00 00"
            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)

            Threading.Thread.Sleep(1000)
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 97 00 00"
            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)

        End If
    End Sub

    'Private Sub btnxysup_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btnXYSup.TouchEnter
    '    'btnXYSdn.TouchEnter execution
    '    Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/dnE.png"))
    '    Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
    '    btnXYSdn.Background = imgbrush

    '    'btnXYSup.TouchEnter execution
    '    Dim imgsrc1 As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/upon.png"))
    '    Dim imgbrush1 As New System.Windows.Media.ImageBrush(imgsrc1)
    '    btnXYSup.Background = imgbrush1

    '    If isConnection = True Then
    '        tx = ""
    '        rx = ""

    '        'btnXYSup.TouchEnter execution
    '        tx = "02 05 00 99 FF 00 5C 26"
    '        rx = txComA(tx, 50)
    '        'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)
    '    End If
    'End Sub

    'Private Sub btnxysup_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btnXYSup.TouchLeave
    '    Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/upE.png"))
    '    Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
    '    btnXYSup.Background = imgbrush

    '    If isConnection = True Then
    '        tx = ""
    '        rx = ""

    '        tx = "02 05 00 99 00 00 1D D6"
    '        rx = txComA(tx, 50)
    '        'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)

    '        Threading.Thread.Sleep(1000)
    '        tx = ""
    '        rx = ""

    '        tx = "02 05 00 99 00 00 1D D6"
    '        rx = txComA(tx, 50)
    '        'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)

    '    End If
    'End Sub

    'Private Sub btnxysdn_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btnXYSdn.TouchEnter
    '    'btnXYSup.TouchEnter execution
    '    Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/upE.png"))
    '    Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
    '    ' btnXYSup.Background = imgbrush

    '    'btnXYSdn.TouchEnter execution
    '    Dim imgsrc1 As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/dnon.png"))
    '    Dim imgbrush1 As New System.Windows.Media.ImageBrush(imgsrc1)
    '    btnXYSdn.Background = imgbrush1

    '    If isConnection = True Then
    '        tx = ""
    '        rx = ""

    '        'btnXYSdn.TouchEnter execution
    '        tx = "02 05 00 98 FF 00 0D E6"
    '        rx = txComA(tx, 50)
    '        'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)
    '    End If
    'End Sub

    'Private Sub btnxysdn_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btnXYSdn.TouchLeave
    '    Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/dnE.png"))
    '    Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
    '    btnXYSdn.Background = imgbrush

    '    If isConnection = True Then
    '        tx = ""
    '        rx = ""
    '        tx = "02 05 00 98 00 00 4C 16"
    '        rx = txComA(tx, 50)
    '        'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)

    '        Threading.Thread.Sleep(1000)
    '        tx = ""
    '        rx = ""

    '        tx = "02 05 00 98 00 00 4C 16"
    '        rx = txComA(tx, 50)
    '        'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)


    '    End If
    'End Sub

    Private Sub Btnin_Click(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btnin.TouchEnter
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/in.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnin.Background = imgbrush

        If isConnection = True Then
            tx = ""
            rx = ""
            tx = "00 00 00 00 00 06 02 05 00 9B FF 00"

            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)
        End If


    End Sub

    Private Sub Btnin_Click1(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btnin.TouchLeave
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/in1.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnin.Background = imgbrush

        If isConnection = True Then
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 9B 00 00"
            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)

            Threading.Thread.Sleep(1000)
            tx = ""
            rx = ""
            tx = "00 00 00 00 00 06 02 05 00 9B 00 00"

            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)

        End If

    End Sub

    Private Sub Btnout_Click(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btnout.TouchEnter
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/out.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnout.Background = imgbrush

        If isConnection = True Then
            tx = ""
            rx = ""
            tx = "00 00 00 00 00 06 02 05 00 9A FF 00"

            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)
        End If

    End Sub

    Private Sub Btnout_Click1(ByVal sender As Object, ByVal e As System.Windows.Input.TouchEventArgs) Handles btnout.TouchLeave
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/out1.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        btnout.Background = imgbrush

        If isConnection = True Then
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 9A 00 00"
            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)

            Threading.Thread.Sleep(1000)
            tx = ""
            rx = ""
            tx = "00 00 00 00 00 06 02 05 00 9A 00 00"

            rx = TCPComA(tx, 10)
            'writeLog("|AuxMultiOn |TX:" & tx & "|RX:" & rx)

        End If

    End Sub

    Private Sub BtnXYSup_IsVisibleChanged(sender As Object, e As Windows.DependencyPropertyChangedEventArgs)

    End Sub
End Class
