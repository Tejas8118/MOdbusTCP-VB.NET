﻿Imports System.Reflection

'-------------------------------------------
' iotESSC for L&T
' by  trapasia DigiReach @ 2017
' getting Allowed Batch Nos from webservice 
'-------------------------------------------
Public Class frmBatch
    Private Sub frmWNote_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        Dim DGVVerticalScroll = dgv1.Controls.OfType(Of VScrollBar).SingleOrDefault
        Dim DGVHorizontalScroll = dgv1.Controls.OfType(Of HScrollBar).SingleOrDefault

        DGVVerticalScroll.Width = 100
        dgv1.EnableHeadersVisualStyles = False

        If gOpMode = "live" Then
            Dim err As String = ""
            Try
                Using myservice As New SQLDB()
                    'myservice.timeout = 2000
                    Dim z As DataTable = myservice.getAllowedBatch(gprojectno, err)
                    dgv1.DataSource = z
                End Using
            Catch ex As Exception
                MessageBox.Show("Error in frmWNote_Load method of frmBatch module, Error : " + ex.Message.ToString())
            End Try
        End If
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub dgv1_RowPostPaint(sender As Object, e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles dgv1.RowPostPaint
        Dim cLineNumber As Integer = e.RowIndex + 1
        Dim xLocation As Integer = 0

        Select Case cLineNumber.ToString.Length
            Case 1
                xLocation = 20
            Case 2
                xLocation = 15
            Case 3
                xLocation = 10
            Case 4
                xLocation = 5
            Case Else
                xLocation = 2
        End Select

        Using b As SolidBrush = New SolidBrush(dgv1.RowHeadersDefaultCellStyle.ForeColor)
            e.Graphics.DrawString(cLineNumber.ToString(System.Globalization.CultureInfo.CurrentUICulture),
                                   dgv1.DefaultCellStyle.Font,
                                   b,
                                   e.RowBounds.Location.X + xLocation,
                                   e.RowBounds.Location.Y + 2)
        End Using
    End Sub

    Private Sub frmBatch_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Me.Width = MDIParent1.Width - 100
        Me.Height = MDIParent1.Height - 150
        Me.Top = 30
        Me.Left = 50
        Panel1.Height = Me.Height - Panel2.Height - Label1.Height - 5
        Panel1.Width = Me.Width
        Panel2.Width = Me.Width
        Label1.Width = Me.Width
        Button1.Left = (Panel1.Width - Button1.Width) / 2
    End Sub

End Class