﻿'----------------------------------
' iotESSC for L&T
' by  trapasia DigiReach @ 2017
' calling webservices
'----------------------------------
Imports System.Data.SqlClient

Module modWeb
    'Dim myservice As New SQLDB()
    Public Function LocalDataCount() As Long
        Dim DataCount As Long = 0
        Try
            Using objCon As New dbClass
                'SAWT_OPERATOR_LOG_DETAIL
                Dim cnt1 = objCon.ExecuteScaller("select count(*) as cnt from GTAW_ABNORMALITY_DATA", CommandType.Text)
                DataCount = DataCount + cnt1

                'SAWT_OPERATOR_LOG_DETAIL
                Dim cnt2 = objCon.ExecuteScaller("select count(*) as cnt from GTAW_ARCH_LOG_DATA", CommandType.Text)
                DataCount = DataCount + cnt2

                'SAWT_OPERATOR_LOG_DETAIL
                Dim cnt3 = objCon.ExecuteScaller("select count(*) as cnt from GTAW_WDS_DATA", CommandType.Text)
                DataCount = DataCount + cnt3

                ''SAWT_OPERATOR_LOG_DETAIL
                'Dim cnt4 = objCon.ExecuteScaller("select count(*) as cnt from ESSC_FLUX_WEIGHT_DATA", CommandType.Text)
                'DataCount = DataCount + cnt4

                'SAWT_OPERATOR_LOG_DETAIL
                Dim cnt5 = objCon.ExecuteScaller("select count(*) as cnt from GTAW_OPERATOR_LOG_DATA", CommandType.Text)
                DataCount = DataCount + cnt5
            End Using
        Catch ex As Exception
        End Try
        Return DataCount
    End Function
    Public Function SaveOPLog(ByVal fonoff As Integer) As Integer
        Dim err As String = ""
        Dim retVal As Integer = 0
        Try
            Using objCon As New dbClass
                Using myservice As New SQLDB()

                    ERPLNDBConnectivity = myservice.checkERPLNDBConnectivity()
                    IOTDBConnectivity = myservice.checkIOTDBConnectivity()

                    gConSocket1 = 0
                    'myservice.timeout = 1000
                    retVal = myservice.insertOperatorLogDetail(Now(), gshop, gstation, gPROCESS, gpsno, gprojectno, gseamno, fonoff, 1, err)

                    If retVal = 0 Then
                        If gPROCESS = "GTAW" Then
                            objCon.ExecuteNonQuery("insert into GTAW_OPERATOR_LOG_DATA(edat,shop,stan,psno,cprj,seam,flag,scon) values  ('" & Now() & "'" &
                                  ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & fonoff & ",2)", CommandType.Text)
                            'ElseIf gPROCESS = "SMAW" Then
                            '    objCon.ExecuteNonQuery("insert into SMAW_OPERATOR_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon) values  ('" & Now() & "'" &
                            '               ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & fonoff & ",2)", CommandType.Text)
                        End If
                        retVal = 2
                    End If
                End Using
            End Using
        Catch ex As Exception
            gConSocket1 = 1
            gConSocket2 = 1
            Using objCon As New dbClass
                If gPROCESS = "GTAW" Then
                    objCon.ExecuteNonQuery("insert into GTAW_OPERATOR_LOG_DATA(edat,shop,stan,psno,cprj,seam,flag,scon) values  ('" & Now() & "'" &
                          ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & fonoff & ",2)", CommandType.Text)
                    'ElseIf gPROCESS = "SMAW" Then
                    '    objCon.ExecuteNonQuery("insert into SMAW_OPERATOR_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon) values  ('" & Now() & "'" &
                    '               ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & fonoff & ",2)", CommandType.Text)
                End If
                retVal = 2
            End Using

        End Try
        Return retVal
    End Function
    Public Function SaveArcLog(ByVal fonoff As Integer) As Integer
        Dim err As String = ""
        Dim retVal As Integer = 0
        'If Math.Round(gSmawcur, 0) > 0 Or Math.Round(gESSCcur, 0) > 0 Then
        Try
            Using objCon As New dbClass
                Using myservice As New SQLDB()

                    ERPLNDBConnectivity = myservice.checkERPLNDBConnectivity()
                    IOTDBConnectivity = myservice.checkIOTDBConnectivity()

                    gConSocket1 = 0
                    'myservice.timeout = 1000
                    retVal = myservice.insertArchLogDetail(Now(), gshop, gstation, gPROCESS, gpsno, gprojectno, gseamno, fonoff, 1, err)

                    If retVal = 0 Then
                        If gPROCESS = "GTAW" Then

                            objCon.ExecuteNonQuery("insert into GTAW_ARCH_LOG_DATA(edat, shop, stan, psno, cprj, seam, flag, scon) values  ('" & Now() & "'" &
                        ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & fonoff & ",2)", CommandType.Text)
                        ElseIf gPROCESS = "SMAW" Then
                            objCon.ExecuteNonQuery("insert into SMAW_ARCH_LOG_DETAIL(edat, shop, stan, psno, cprj, seam, flag, scon) values  ('" & Now() & "'" &
                            ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & fonoff & ",2)", CommandType.Text)
                        End If
                        retVal = 0
                    End If
                End Using
            End Using
        Catch ex As Exception
            gConSocket1 = 1
            gConSocket2 = 1

            Using objCon As New dbClass
                If gPROCESS = "GTAW" Then
                    objCon.ExecuteNonQuery("insert into GTAW_ARCH_LOG_DATA(edat, shop, stan, psno, cprj, seam, flag, scon) values  ('" & Now() & "'" &
                ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & fonoff & ",2)", CommandType.Text)
                ElseIf gPROCESS = "SMAW" Then
                    objCon.ExecuteNonQuery("insert into SMAW_ARCH_LOG_DETAIL(edat, shop, stan, psno, cprj, seam, flag, scon) values  ('" & Now() & "'" &
                    ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & fonoff & ",2)", CommandType.Text)
                End If
                retVal = 0
            End Using

        End Try
        'End If

        Return retVal
    End Function
    ''Check for nirav sir 
    Public Function SaveAbnLog(ByVal ParaType As Integer, ByVal ParaVal As Double, ByVal ParaMin As Double, ByVal ParaMax As Double) As Integer
        Dim err As String = ""
        Dim retVal As Integer = 0
        Try
            Using objCon As New dbClass
                Using myservice As New SQLDB()

                    ERPLNDBConnectivity = myservice.checkERPLNDBConnectivity()
                    IOTDBConnectivity = myservice.checkIOTDBConnectivity()

                    gConSocket1 = 0
                    'myservice.timeout = 1000

                    retVal = myservice.insertAbnormalityLogDetail(Now(), gshop, gstation, gPROCESS, gpsno, gprojectno, gseamno, ParaType, ParaVal, ParaMin, ParaMax, 1, err)

                    ''Check for nirav sir 
                    If retVal = 0 Then
                        If gPROCESS = "GTAW" Then
                            objCon.ExecuteNonQuery("insert into GTAW_ABNORMALITY_DATA(edat, shop, stan, psno, cprj, seam, type,valu,rmin,rmax, scon) values  ('" & Now() & "'" &
                   ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & ParaType & "," & ParaVal & "," & ParaMin & "," & ParaMax & ",2)", CommandType.Text)
                        ElseIf gPROCESS = "SMAW" Then
                            objCon.ExecuteNonQuery("insert into SMAW_ABNORMALITY_LOG_DETAIL(edat, shop, stan, psno, cprj, seam, type,valu,rmin,rmax, scon) values  ('" & Now() & "'" &
                      ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & ParaType & "," & ParaVal & "," & ParaMin & "," & ParaMax & ",2)", CommandType.Text)
                        End If
                        retVal = 0
                    End If
                End Using
            End Using
        Catch ex As Exception
            gConSocket1 = 1
            gConSocket2 = 1

            Using objCon As New dbClass
                ''Check for nirav sir 
                If gPROCESS = "GTAW" Then
                    objCon.ExecuteNonQuery("insert into GTAW_ABNORMALITY_DATA(edat, shop, stan, psno, cprj, seam, type,valu,rmin,rmax, scon) values  ('" & Now() & "'" &
               ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & ParaType & "," & ParaVal & "," & ParaMin & "," & ParaMax & ",2)", CommandType.Text)
                ElseIf gPROCESS = "SMAW" Then
                    objCon.ExecuteNonQuery("insert into SMAW_ABNORMALITY_LOG_DETAIL(edat, shop, stan, psno, cprj, seam, type,valu,rmin,rmax, scon) values  ('" & Now() & "'" &
                  ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & ParaType & "," & ParaVal & "," & ParaMin & "," & ParaMax & ",2)", CommandType.Text)
                End If
                retVal = 0
            End Using

        End Try
        Return retVal
    End Function


    'Public Function SaveFluxWghtLog(ByVal FluxWeight As Double) As Integer

    '    Dim err As String = ""
    '    Dim retVal As Integer = 0

    '    If Math.Round(gESSCcur, 0) > 0 Then
    '        Try
    '            Using objCon As New dbClass
    '                Using myservice As New SQLDB()

    '                    ERPLNDBConnectivity = myservice.checkERPLNDBConnectivity()
    '                    IOTDBConnectivity = myservice.checkIOTDBConnectivity()

    '                    gConSocket1 = 0
    '                    'myservice.timeout = 1000

    '                    retVal = myservice.insertFluxLogDetail(Now(), gshop, gstation, gPROCESS, gpsno, gprojectno, gseamno, FluxWeight, 1, err)

    '                    If retVal = 0 Then
    '                        objCon.ExecuteNonQuery("insert into ESSC_FLUX_WEIGHT_DATA(edat, shop, stan, psno, cprj, seam, fwht, scon) values  ('" & Now() & "'" &
    '                ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & FluxWeight & ",2)", CommandType.Text)

    '                        retVal = 0
    '                    End If
    '                End Using
    '            End Using
    '        Catch ex As Exception
    '            gConSocket1 = 1
    '            gConSocket2 = 1

    '            Using objCon As New dbClass
    '                objCon.ExecuteNonQuery("insert into ESSC_FLUX_WEIGHT_DATA(edat, shop, stan, psno, cprj, seam, fwht, scon) values  ('" & Now() & "'" &
    '            ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "'," & FluxWeight & ",2)", CommandType.Text)

    '                retVal = 0
    '            End Using

    '        End Try
    '    End If
    '    Return retVal
    'End Function

    ''Check for nirav sir 

    Public Function SaveLocalDataCountLog(ByVal LocalDataCount As Double, ByVal LastBuildDate As String) As Integer

        Dim err As String = ""
        Dim retVal As Integer = 0

        'If Math.Round(gESSCcur, 0) > 0 Then
        Try
            Using objCon As New dbClass
                Using myservice As New SQLDB()

                    retVal = myservice.insertUpdateLocalDataCount(gstation, Now(), LocalDataCount, LastBuildDate, err)

                End Using
            End Using
        Catch ex As Exception
        End Try
        'End If
        Return retVal
    End Function

    Public Function SaveParaLog(ByVal CurrentValue As Double, ByVal CurrentValue2 As Double, ByVal VoltageValue As Double, ByVal VoltageValue2 As Double, ByVal TravelSpeedValue As Double, ByVal consItem As String,
                                ByVal ConsBatch As String, ByVal FluxItem As String, ByVal FluxBatch As String, ByVal JobTemp As Double,
                                ByVal GasFlow As Double, ByVal GasFlow2 As Double, ByVal wirefeed As Double, ByVal wirefeed2 As Double, ByVal SpotNumber As Integer, ByVal GrindValue As Integer, ByVal GrindFillupvalue As Integer,
                                ByVal DepthValue As Double) As Integer

        Dim retVal As Integer = 0
        Dim err As String

        'If Math.Round(CurrentValue, 0) > 0 Or Math.Round(JobTemp, 0) > 0 Then
        Dim consi As String = ""
        Dim consb As String = ""
        Dim flxi As String = ""
        Dim flxb As String = ""

        Try
            Using objCon As New dbClass
                Using myservice As New SQLDB()

                    ERPLNDBConnectivity = myservice.checkERPLNDBConnectivity()
                    IOTDBConnectivity = myservice.checkIOTDBConnectivity()

                    gConSocket1 = 0
                    err = ""
                    'myservice.timeout = 2000

                    'Dim z As Data.DataTable = myservice.getBatchNo(gprojectno, gseamno, 1, err)
                    'For Each row As DataRow In z.Rows
                    '    consi = row("t_item").trim
                    '    consb = row("t_clot").trim
                    'Next row

                    'err = ""
                    ''myservice.timeout = 2000

                    'z = myservice.getBatchNo(gprojectno, gseamno, 2, err)
                    'For Each row As DataRow In z.Rows
                    '    flxi = row("t_item").trim
                    '    flxb = row("t_clot").trim
                    'Next row

                    Dim z As DataTable = myservice.getBatchNo(gprojectno, gseamno, 1, err)
                    If z.Rows.Count > 0 Then
                        For Each row As DataRow In z.Rows
                            consi = row("t_item").trim
                            consb = row("t_clot").trim
                        Next row
                    End If

                    err = ""
                    'myservice.timeout = 2000

                    Dim z1 As DataTable = myservice.getBatchNo(gprojectno, gseamno, 2, err)
                    If z1.Rows.Count > 0 Then
                        For Each row As DataRow In z1.Rows
                            flxi = row("t_item").trim
                            flxb = row("t_clot").trim
                        Next row
                    End If
                    ''Check for nirav sir 
                    'myservice.timeout = 1000
                    retVal = myservice.insertParamDataLogDetail(Now(), gshop, gstation, gPROCESS, gpsno, gprojectno, gseamno, gWPSno, gPass, glayer, 0, gPowersrc,
                                                                    CurrentValue, CurrentValue2, VoltageValue, VoltageValue2, TravelSpeedValue, consi, consb, flxi, flxb, JobTemp, gGTAWgasflow, gGTAWgasflow2, gGTAWwirefeed, gGTAWwirefeed2,
                                                                    SpotNumber, GrindValue, GrindFillupvalue, gdepth, gsubantdft, gsubdrvtrp, 1, err)

                    If retVal = 0 Then
                        ''Check for nirav sir 
                        If gPROCESS = "GTAW" Then
                            objCon.ExecuteNonQuery("insert into GTAW_WDS_DATA(edat,shop,stan,psno,cprj,seam,wpsn,pass,layer,pros,acdc,curn,curn2,volt,volt2,tspd,cons,cbat,flux,fbat,temp,gasflow,gasflow2,wirefeed,wirefeed2,spot,grind,grindfill,depth,antdrf,drivetrip,scon) values  ('" & Now() & "'" &
                        ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "','" & gWPSno & "','" & gPass & "','" & glayer & "','" & gPROCESS & "','" & gPowersrc & "','" & CurrentValue & "','" & CurrentValue2 & "'" &
                        ",'" & VoltageValue & ",'" & VoltageValue2 & "','" & TravelSpeedValue & "','" & consi & "','" & consb & "','" & flxi & "','" & flxb & "'" &
                        ",'" & JobTemp & "','" & gGTAWgasflow & "','" & gGTAWgasflow2 & "','" & gGTAWwirefeed & "','" & gGTAWwirefeed2 & "','" & gSportNo & "','" & gGrind & "','" & gGrindFillupvalue & "','" & gdepth & "','" & gsubantdft & "','" & gsubdrvtrp & "',2)", CommandType.Text)
                            '    ElseIf gPROCESS = "SMAW" Then
                            '        objCon.ExecuteNonQuery("insert into SMAW_DATA_CAP(edat,shop,stan,psno,cprj,seam,wpsn,pass,layer,pros,acdc,curn,volt,tspd,cons,cbat,flux,fbat,temp,ftmp,spot,grind,grindfill,depth,antdrf,drivetrip,scon) values  ('" & Now() & "'" &
                            '",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "','" & gWPSno & "','" & gPass & "','" & glayer & "','" & gLastWeldPositionAxis1 & "','" & gPROCESS & "', '0','" & CurrentValue & "'" &
                            '",'" & VoltageValue & "','" & TravelSpeedValue & "','" & consi & "','" & consb & "','" & flxi & "','" & flxb & "'" &
                            '",'" & JobTemp & "','" & FluxTemp & "','" & gSportNo & "','" & gGrind & "','" & gGrindFillupvalue & "','" & gdepth & "','" & gsubantdft & "','" & gsubdrvtrp & "',2)", CommandType.Text)
                        End If
                        retVal = 0
                    End If
                End Using
            End Using
        Catch ex As Exception
            gConSocket1 = 1
            gConSocket2 = 1

            Using objCon As New dbClass
                ''Check for nirav sir 
                If gPROCESS = "GTAW" Then
                    objCon.ExecuteNonQuery("insert into GTAW_WDS_DATA(edat,shop,stan,psno,cprj,seam,wpsn,pass,layer,pros,acdc,curn,curn2,volt,volt2,tspd,cons,cbat,flux,fbat,temp,gasflow,gasflow2,wirefeed,wirefeed2,spot,grind,grindfill,depth,antdrf,drivetrip,scon) values  ('" & Now() & "'" &
                        ",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "','" & gWPSno & "','" & gPass & "','" & glayer & "','" & gPROCESS & "','" & gPowersrc & "','" & CurrentValue & "','" & CurrentValue2 & "'" &
                        ",'" & VoltageValue & ",'" & VoltageValue2 & "','" & TravelSpeedValue & "','" & consi & "','" & consb & "','" & flxi & "','" & flxb & "'" &
                        ",'" & JobTemp & "','" & gGTAWgasflow & "','" & gGTAWgasflow2 & "','" & gGTAWwirefeed & "','" & gGTAWwirefeed2 & "','" & gSportNo & "','" & gGrind & "','" & gGrindFillupvalue & "','" & gdepth & "','" & gsubantdft & "','" & gsubdrvtrp & "',2)", CommandType.Text)
                    ' ElseIf gPROCESS = "SMAW" Then
                    '     objCon.ExecuteNonQuery("insert into SMAW_DATA_CAP(edat,shop,stan,psno,cprj,seam,wpsn,pass,layer,pros,acdc,curn,volt,tspd,cons,cbat,flux,fbat,temp,ftmp,spot,grind,grindfill,depth,antdrf,drivetrip,scon) values  ('" & Now() & "'" &
                    '",'" & gshop & "','" & gstation & "','" & gpsno & "','" & gprojectno & "','" & gseamno & "','" & gWPSno & "','" & gPass & "','" & glayer & "','" & gPROCESS & "', '0','" & CurrentValue & "'" &
                    '",'" & VoltageValue & "','" & TravelSpeedValue & "','" & consi & "','" & consb & "','" & flxi & "','" & flxb & "'" &
                    '",'" & JobTemp & "','" & FluxTemp & "','" & gSportNo & "','" & gGrind & "','" & gGrindFillupvalue & "','" & gdepth & "','" & gsubantdft & "','" & gsubdrvtrp & "',2)", CommandType.Text)
                End If
                retVal = 0
            End Using

        End Try
        'End If
        Return retVal
    End Function
    'Public Function procVal(ByVal proc As String) As Integer
    '    Dim retVal As Integer = 0
    '    Try
    '        retVal = getProcessValue(proc)
    '    Catch ex As Exception
    '        retVal = 0
    '    End Try
    '    Return retVal
    'End Function

    'Public Sub upWelder()

    '    'Dim myservice As New SQLDB()
    '    Dim Errstr As String = ""
    '    Try
    '        'Dim z As Data.DataTable = My.WebServices.SAWService.loadWelderDetail(Errstr)
    '        'For Each row As DataRow In z.Rows
    '        '    Dim cnt As Integer = objCon.ExecuteScaller("select count(*) as cnt from welderlist where csno='" & row.Item("t_csnn") & "' and psno='" & row.Item("t_psno").trim & "'", CommandType.Text)
    '        '    If cnt = 0 Then
    '        '        objCon.ExecuteNonQuery("insert into welderlist (csno,wname,psno,stmp) values ('" & row.Item("t_csnn").trim & "','" & row.Item("t_name").trim & "','" & row.Item("t_psno").trim & "','" & row.Item("t_stmp").trim & "')", CommandType.Text)
    '        '    End If
    '        'Next row

    '        Using objCon As New dbClass
    '            Using myservice As New SQLDB()
    '                'myservice.timeout = 1000
    '                Dim z As DataTable = myservice.loadWelderDetail(Errstr)

    '                For Each row As DataRow In z.Rows
    '                    Dim cnt As Integer = objCon.ExecuteScaller("select count(*) as cnt from welderlist where csno='" & row.Item("t_csnn") & "' and psno='" & row.Item("t_psno").trim & "'", CommandType.Text)
    '                    If cnt = 0 Then
    '                        objCon.ExecuteNonQuery("insert into welderlist (csno,wname,psno,stmp) values ('" & row.Item("t_csnn").trim & "','" & row.Item("t_name").trim & "','" & row.Item("t_psno").trim & "','" & row.Item("t_stmp").trim & "')", CommandType.Text)
    '                    End If
    '                Next row

    '            End Using
    '        End Using

    '    Catch ex As Exception

    '    End Try
    'End Sub

    Public Sub DataSync(ByRef pgbar As ProgressBar, ByVal method As Integer)
        Dim dt As DataTable
        Dim retVal As Integer = 0
        Dim err As String = ""
        Dim i As Integer = 0
        Dim RecordExist As Boolean = False
        Dim tx As String = ""
        Dim rx As String = ""

        Using objCon As New dbClass
            Using myservice As New SQLDB()
                'Check IOT DB Connectivity
                IOTDBConnectivity = myservice.checkIOTDBConnectivity()

                If IOTDBConnectivity Then

                    gLocalDataSync = True

                    'Weld ON Stop
                    If isConnection = True Then
                        tx = ""
                        rx = ""
                        tx = "02 05 00 D8 00 00 4D C2"
                        rx = txComA(tx, 10)
                        'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                    End If
                    objSC1.btnWELDA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.weldoff
                    objSC1.btnWELDA.Tag = 0

                    Try
                        dt = objCon.ExecuteDataTable("select * from GTAW_OPERATOR_LOG_DATA", CommandType.Text)
                        pgbar.Minimum = 0
                        pgbar.Maximum = dt.Rows.Count
                        For Each row As DataRow In dt.Rows
                            i = i + 1
                            pgbar.Value = i
                            'myservice.timeout = 1000
                            RecordExist = myservice.checkRecordExist("GTAW_OPERATOR_LOG_DATA", row("edat"), 0)
                            If RecordExist Then
                                objCon.ExecuteNonQuery("delete from GTAW_OPERATOR_LOG_DATA where id=" & row("id"), CommandType.Text)
                            Else
                                retVal = myservice.insertOperatorLogDetail(row("edat"), row("shop"), row("stan"), "GTAW", row("psno"), row("cprj"), row("seam"), row("flag"), row("scon"), err)
                                If retVal > 0 Then
                                    objCon.ExecuteNonQuery("delete from GTAW_OPERATOR_LOG_DATA where id=" & row("id"), CommandType.Text)
                                End If
                            End If
                        Next
                    Catch ex As Exception
                        'writeLog(ex.Message)
                        MessageBox.Show("Error from DataSync() method - GTAW_OPERATOR_LOG_DATA - of modWeb module, Error : " + ex.Message.ToString())
                    End Try

                    Try
                        dt = objCon.ExecuteDataTable("select * from SMAW_OPERATOR_LOG_DETAIL", CommandType.Text)
                        i = 0
                        pgbar.Minimum = 0
                        pgbar.Maximum = dt.Rows.Count
                        For Each row As DataRow In dt.Rows
                            'myservice.timeout = 1000
                            i = i + 1
                            pgbar.Value = i
                            RecordExist = myservice.checkRecordExist("SMAW_OPERATOR_LOG_DETAIL", row("edat"), 0)
                            If RecordExist Then
                                objCon.ExecuteNonQuery("delete  from SMAW_OPERATOR_LOG_DETAIL where id=" & row("id"), CommandType.Text)
                            Else
                                retVal = myservice.insertOperatorLogDetail(row("edat"), row("shop"), row("stan"), "SMAW", row("psno"), row("cprj"), row("seam"), row("flag"), row("scon"), err)
                                If retVal > 0 Then
                                    objCon.ExecuteNonQuery("delete  from SMAW_OPERATOR_LOG_DETAIL where id=" & row("id"), CommandType.Text)
                                End If
                            End If
                        Next
                    Catch ex As Exception
                        'writeLog(ex.Message)
                        MessageBox.Show("Error from DataSync() method - SMAW_OPERATOR_LOG_DETAIL - of modWeb module, Error : " + ex.Message.ToString())
                    End Try

                    Try
                        dt = objCon.ExecuteDataTable("select * from GTAW_ARCH_LOG_DATA", CommandType.Text)
                        i = 0
                        pgbar.Minimum = 0
                        pgbar.Maximum = dt.Rows.Count
                        For Each row As DataRow In dt.Rows
                            i = i + 1
                            pgbar.Value = i
                            'myservice.timeout = 1000
                            RecordExist = myservice.checkRecordExist("GTAW_ARCH_LOG_DATA", row("edat"), 0)
                            If RecordExist Then
                                objCon.ExecuteNonQuery("delete from GTAW_ARCH_LOG_DATA where id=" & row("id"), CommandType.Text)
                            Else
                                retVal = myservice.insertArchLogDetail(row("edat"), row("shop"), row("stan"), "GTAW", row("psno"), row("cprj"), row("seam"), row("flag"), row("scon"), err)
                                If retVal > 0 Then
                                    objCon.ExecuteNonQuery("delete from GTAW_ARCH_LOG_DATA where id=" & row("id"), CommandType.Text)
                                End If
                            End If
                        Next
                    Catch ex As Exception
                        'writeLog(ex.Message)
                        MessageBox.Show("Error from DataSync() method - GTAW_ARCH_LOG_DATA - of modWeb module, Error : " + ex.Message.ToString())
                    End Try

                    Try
                        dt = objCon.ExecuteDataTable("select * from SMAW_ARCH_LOG_DETAIL", CommandType.Text)
                        i = 0
                        pgbar.Minimum = 0
                        pgbar.Maximum = dt.Rows.Count
                        For Each row As DataRow In dt.Rows
                            i = i + 1
                            pgbar.Value = i
                            'myservice.timeout = 1000
                            RecordExist = myservice.checkRecordExist("SMAW_ARCH_LOG_DETAIL", row("edat"), 0)
                            If RecordExist Then
                                objCon.ExecuteNonQuery("delete from SMAW_ARCH_LOG_DETAIL where id=" & row("id"), CommandType.Text)
                            Else
                                retVal = myservice.insertArchLogDetail(row("edat"), row("shop"), row("stan"), "SMAW", row("psno"), row("cprj"), row("seam"), row("flag"), row("scon"), err)
                                If retVal > 0 Then
                                    objCon.ExecuteNonQuery("delete from SMAW_ARCH_LOG_DETAIL where id=" & row("id"), CommandType.Text)
                                End If
                            End If
                        Next
                    Catch ex As Exception
                        'writeLog(ex.Message)
                        MessageBox.Show("Error from DataSync() method - SMAW_ARCH_LOG_DETAIL - of modWeb module, Error : " + ex.Message.ToString())
                    End Try

                    Try
                        dt = objCon.ExecuteDataTable("select * from GTAW_ABNORMALITY_DATA", CommandType.Text)
                        'If dt.Rows.Count > 0 Then
                        '    myservice.insertAbnormalityLogDetail_BulkCopy(dt)
                        'End If
                        i = 0
                        pgbar.Minimum = 0
                        pgbar.Maximum = dt.Rows.Count
                        For Each row As DataRow In dt.Rows
                            i = i + 1
                            pgbar.Value = i
                            'myservice.timeout = 1000
                            RecordExist = myservice.checkRecordExist("GTAW_ABNORMALITY_DATA", row("edat"), row("type"))
                            If RecordExist Then
                                objCon.ExecuteNonQuery("delete from GTAW_ABNORMALITY_DATA where id=" & row("id"), CommandType.Text)
                            Else
                                retVal = myservice.insertAbnormalityLogDetail(row("edat"), row("shop"), row("stan"), "GTAW", row("psno"), row("cprj"), row("seam"), row("type"), row("valu"), row("rmin"), row("rmax"), row("scon"), err)
                                If retVal > 0 Then
                                    objCon.ExecuteNonQuery("delete from GTAW_ABNORMALITY_DATA where id=" & row("id"), CommandType.Text)
                                End If
                            End If
                        Next
                    Catch ex As Exception
                        'writeLog(ex.Message)
                        MessageBox.Show("Error from DataSync() method - GTAW_ABNORMALITY_DATA - of modWeb module, Error : " + ex.Message.ToString())
                    End Try

                    Try
                        dt = objCon.ExecuteDataTable("select * from SMAW_ABNORMALITY_LOG_DETAIL", CommandType.Text)
                        i = 0
                        pgbar.Minimum = 0
                        pgbar.Maximum = dt.Rows.Count
                        For Each row As DataRow In dt.Rows
                            i = i + 1
                            pgbar.Value = i
                            'myservice.timeout = 1000
                            RecordExist = myservice.checkRecordExist("SMAW_ABNORMALITY_LOG_DETAIL", row("edat"), row("type"))
                            If RecordExist Then
                                objCon.ExecuteNonQuery("delete from SMAW_ABNORMALITY_LOG_DETAIL where id=" & row("id"), CommandType.Text)
                            Else
                                retVal = myservice.insertAbnormalityLogDetail(row("edat"), row("shop"), row("stan"), "SMAW", row("psno"), row("cprj"), row("seam"), row("type"), row("valu"), row("rmin"), row("rmax"), row("scon"), err)
                                If retVal > 0 Then
                                    objCon.ExecuteNonQuery("delete from SMAW_ABNORMALITY_LOG_DETAIL where id=" & row("id"), CommandType.Text)
                                End If
                            End If
                        Next
                    Catch ex As Exception
                        'writeLog(ex.Message)
                        MessageBox.Show("Error from DataSync() method - SMAW_ABNORMALITY_LOG_DETAIL - of modWeb module, Error : " + ex.Message.ToString())
                    End Try

                    Try
                        dt = objCon.ExecuteDataTable("select * from GTAW_WDS_DATA", CommandType.Text)
                        i = 0
                        pgbar.Minimum = 0
                        pgbar.Maximum = dt.Rows.Count
                        For Each row As DataRow In dt.Rows
                            i = i + 1
                            pgbar.Value = i
                            'myservice.timeout = 1000
                            RecordExist = myservice.checkRecordExist("GTAW_WDS_DATA", row("edat"), 0)
                            If RecordExist Then
                                objCon.ExecuteNonQuery("delete from GTAW_WDS_DATA where id=" & row("id"), CommandType.Text)
                            Else
                                retVal = myservice.insertParamDataLogDetail(row("edat"), row("shop"), row("stan"), "ESSC", row("psno"), row("cprj"), row("seam"), row("wpsn"),
                                                                row("pass"), row("layer"), 0, row("acdc"), row("curn"), row("curn2"), row("volt"), row("volt2"), row("tspd"), row("cons"), row("cbat"),
                                                                row("flux"), row("fbat"), row("temp"), row("gasflow"), row("gasflow2"), row("wirefeed"), row("wirefeed2"), row("spot"), row("grind"), row("grindfill"),
                                                                row("depth"), row("antdrf"), row("drivetrip"), row("scon"), err)
                                If retVal > 0 Then
                                    objCon.ExecuteNonQuery("delete from GTAW_WDS_DATA where id=" & row("id"), CommandType.Text)
                                End If
                            End If
                        Next
                    Catch ex As Exception
                        'writeLog(ex.Message)
                        MessageBox.Show("Error from DataSync() method - GTAW_WDS_DATA - of modWeb module, Error : " + ex.Message.ToString())
                    End Try
                    '' Commented for pipecleding.....
                    'Try
                    '    dt = objCon.ExecuteDataTable("select * from SMAW_DATA_CAP", CommandType.Text)
                    '    i = 0
                    '    pgbar.Minimum = 0
                    '    pgbar.Maximum = dt.Rows.Count
                    '    For Each row As DataRow In dt.Rows
                    '        i = i + 1
                    '        pgbar.Value = i
                    '        'myservice.timeout = 1000
                    '        RecordExist = myservice.checkRecordExist("SMAW_DATA_CAP", row("edat"), 0)
                    '        If RecordExist Then
                    '            objCon.ExecuteNonQuery("delete from SMAW_DATA_CAP where id=" & row("id"), CommandType.Text)
                    '        Else
                    '            retVal = myservice.insertParamDataLogDetail(row("edat"), row("shop"), row("stan"), "SMAW", row("psno"), row("cprj"), row("seam"), row("wpsn"),
                    '                                            row("pass"), row("layer"), 0, row("acdc"), row("curn"), row("curn2"), row("volt"), row("volt2"), row("tspd"), row("cons"), row("cbat"),
                    '                                            row("flux"), row("fbat"), row("temp"), row("ftmp"), row("wirefeed"), row("wirefeed2"), row("spot"), row("grind"), row("grindfill"),
                    '                                            row("depth"), row("antdrf"), row("drivetrip"), row("scon"), err)
                    '            If retVal > 0 Then
                    '                objCon.ExecuteNonQuery("delete from SMAW_DATA_CAP where id=" & row("id"), CommandType.Text)
                    '            End If
                    '        End If
                    '    Next
                    'Catch ex As Exception
                    '    'writeLog(ex.Message)
                    '    MessageBox.Show("Error from DataSync() method - SMAW_DATA_CAP - of modWeb module, Error : " + ex.Message.ToString())
                    'End Try

                    'Try
                    '    i = 0
                    '    pgbar.Minimum = 0
                    '    Dim z As DataTable = myservice.loadWelderDetail(err)
                    '    pgbar.Maximum = z.Rows.Count
                    '    For Each row As DataRow In z.Rows
                    '        i = i + 1
                    '        pgbar.Value = i
                    '        Dim cnt As Integer = objCon.ExecuteScaller("select count(*) as cnt from welderlist where csno='" & row.Item("t_csnn") & "' and psno='" & row.Item("t_psno").trim & "'", CommandType.Text)
                    '        If cnt = 0 Then
                    '            objCon.ExecuteNonQuery("insert into welderlist (csno,wname,psno,stmp) values ('" & row.Item("t_csnn").trim & "','" & row.Item("t_name").trim & "','" & row.Item("t_psno").trim & "','" & row.Item("t_stmp").trim & "')", CommandType.Text)
                    '        End If
                    '    Next row

                    'Catch ex As Exception
                    '    'writeLog(ex.Message)
                    '    MessageBox.Show("Error from DataSync() method - loadWelderDetail - of modWeb module, Error : " + ex.Message.ToString())
                    'End Try
                    If method = 2 Then
                        MessageBoxEx.Show("Data Syncing Completed Successfully.", "Offline Data Sync", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString()
                    End If
                    gLocalDataSync = False
                Else
                    If method = 2 Then
                        MessageBoxEx.Show("Network is not available.", "DataSync", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString()
                    End If
                End If
            End Using
        End Using
    End Sub

    Public Sub WelderListSync(ByRef pgbar As ProgressBar)
        Dim retVal As Integer = 0
        Dim err As String = ""
        Dim i As Integer = 0
        Dim RecordExist As Boolean = False

        Using objCon As New dbClass
            Using myservice As New SQLDB()
                'Check IOT DB Connectivity
                IOTDBConnectivity = myservice.checkIOTDBConnectivity()

                If IOTDBConnectivity Then
                    Try
                        i = 0
                        pgbar.Minimum = 0
                        Dim z As DataTable = myservice.loadWelderDetail(err)
                        pgbar.Maximum = z.Rows.Count
                        For Each row As DataRow In z.Rows
                            i = i + 1
                            pgbar.Value = i
                            Dim cnt As Integer = objCon.ExecuteScaller("select count(*) as cnt from welderlist where csno='" & row.Item("t_csnn") & "' and psno='" & row.Item("t_psno").trim & "'", CommandType.Text)
                            If cnt = 0 Then
                                objCon.ExecuteNonQuery("insert into welderlist (csno,wname,psno,stmp) values ('" & row.Item("t_csnn").trim & "','" & row.Item("t_name").trim & "','" & row.Item("t_psno").trim & "','" & row.Item("t_stmp").trim & "')", CommandType.Text)
                            End If
                        Next row
                        MessageBoxEx.Show("Welder Data Syncing Completed Successfully.", "Welder Data Sync", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString()
                    Catch ex As Exception
                        'writeLog(ex.Message)
                        MessageBox.Show("Error from WelderListSync() method - loadWelderDetail - of modWeb module, Error : " + ex.Message.ToString())
                    End Try
                Else
                    MessageBoxEx.Show("Network is not available.", "DataSync", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString()
                End If
            End Using
        End Using
    End Sub
End Module
