﻿'----------------------------------
' iotESSC for L&T
' by  trapasia DigiReach @ 2017
' public functions/variables/Procedures
'----------------------------------
Imports System
Imports System.Text
Imports System.IO
Imports System.IO.Ports
Imports System.Net.Sockets
Imports System.Threading
Imports System.Configuration.ConfigurationManager
Module modSerial
    Public WithEvents mycomm As New SerialPort
    Public WithEvents mycommRX As New SerialPort
    Public miComPort As Integer = 5
    Public miComPortRX As Integer = 5
    Public txtBaudrate As String = "9600"
    Dim txtTimeout As String = "2000"
    Dim chkRTS As Integer = 1
    Dim chkDTR As Integer = 1
    Public gdisable As Integer = 0
    Public ghome As Integer = 0
    Public gsetdepth As Double = 0
    Public gmaterialflag As String = ""
    Public gshopno As String
    Public gcmbno As String
    Public gsubantdft As Integer
    Public gleft As Integer
    Public gleftcurrent As Integer
    Public grightcurrent As Integer
    Public gwfstep As Integer
    Public gwfstep2 As Integer
    Public gweldspeedstep As Integer
    Public gsubdrvtrp As Integer
    Public gstepmovement As Integer = 0
    Public gautoseton As Integer = 0
    Public gautosetoff As Integer = 0
    Dim chkEvents As Boolean = True
    Public isComOpen As Boolean = False
    Public isComOpenRX As Boolean = False
    Public isConnection As Boolean = False
    Public length As Integer = 0
    Public data As Integer = 0
    Public bytes(50) As Byte

    Public networkStream As NetworkStream
    Public tcpClient As New System.Net.Sockets.TcpClient()
    Public returndata As String = ""
    Public numberOfBytesRead As Integer = 0
    Dim chkAddCR As Boolean = False
    Dim txtBytes2Read As Integer = 8

    'Public objCon As New dbClass
    Public glogid As Integer
    Public gcsnno As String
    Public gshop As String
    Public gstation As String
    Public gPROCESS As String
    Public gnewseam As String
    Public gPowervalue As Integer = 0
    Public gstop As Integer = 0
    Public gsetstop As Integer = 0
    Public gwelder_nm As String
    Public gpsno As String
    Public gshortpass As String

    Public gsetesscpara As Integer = 0
    Public gprojectno As String
    Public gprojectname As String = ""
    Public gshopname As String
    Public gcmbname As String
    Public gseamno As String
    Public goldseam As String
    Public gcaws As String
    Public gclayer As String
    Public gWPSno As String
    Public gsize As String
    Public gPass As Integer
    Public glayer As Integer
    Public gComTX As Integer
    Public gComRX As Integer
    Public gSpeed As String
    Public gLogin As Boolean = False
    Public gConSocket1 As Integer = 0
    Public gConSocket2 As Integer = 0
    Public gMachine As String
    Public gclick As Integer = 0
    Public gstart As Integer = 0
    Public gAux As Boolean = False
    Public gJOBDATA As Boolean = False
    Public gcontrols As Boolean = False
    Public gDiag As Boolean = False
    Public objAux As New frmAux
    Public objJobData As New frmjobdata
    Public objcontrols As New frmcontrols
    Public objSC1 As New FrmSC1
    Public objDiag As New frmDiag
    Public objAngstatus As New frmAngstatus
    Public objdigstatus As New frmDigStatus

    Public gWeldingStart As Boolean = False
    Public gLocalDataSync As Boolean = False

    Public gRef As Integer = 0
    Public gSetspeedstep As Double
    Public gJobTemp As Double = 0.0
    Public gmcleft As Double = 0.0
    Public gmcright As Double = 0.0
    Public gESSCVolt As Double = 0.0
    Public gESSCcur As Double = 0.0
    Public gtrlspeed As Double = 0.0
    Public gSmawVolt As Double = 0.0
    Public gSmawcur As Double = 0.0
    Public gSfacespeed As Double = 0.0
    Public gleftspeec As Double = 0.0
    Public gDrift As Double = 0.0
    Public gfluxtemp As Double = 0.0
    Public gfluxwght As Double = 0.0
    Public gtrcspeed As Double = 0.0
    Public gfruwght As Double = 0.0
    Public gdepth As Double = 0.0
    Public gREFdepth As Double = 0.0
    Public gXmin As Double = 0.0
    Public gTRCon As Integer = 0
    Public gAntDFT As Integer = 0
    Public gDrvTRP As Integer = 0
    Public gLevel As Integer = 0
    Public gAlign As Integer = 0

    Public ghealthy As Integer = 0

    Public gburner As Integer = 0

    Public gstr As String = ""

    '-------------- DIGNOSIS VARIABLE

    '/////////////////////////////          DGIGITAL INPUT - DISPLAY          ////////////////////

    Public gDi1 As Integer = 0
    Public gDi2 As Integer = 0
    Public gDi3 As Integer = 0
    Public gDi4 As Integer = 0
    Public gDi5 As Integer = 0
    Public gDi6 As Integer = 0
    Public gDi7 As Integer = 0
    Public gDi8 As Integer = 0
    Public gDi9 As Integer = 0
    Public gDi10 As Integer = 0
    Public gDi11 As Integer = 0
    Public gDi12 As Integer = 0
    Public gDi13 As Integer = 0
    Public gDi14 As Integer = 0
    Public gDi15 As Integer = 0
    Public gDi16 As Integer = 0
    Public gDi17 As Integer = 0
    Public gDi18 As Integer = 0
    Public gDi19 As Integer = 0
    Public gDi20 As Integer = 0
    Public gDi21 As Integer = 0
    Public gDi22 As Integer = 0
    Public gDi23 As Integer = 0
    Public gDi24 As Integer = 0
    Public gDi25 As Integer = 0
    Public gDi26 As Integer = 0
    Public gDi27 As Integer = 0
    Public gDi28 As Integer = 0
    Public gDi29 As Integer = 0
    Public gDi30 As Integer = 0
    Public gDi31 As Integer = 0
    Public gDi32 As Integer = 0

    '-------------------        DIGITAL OUTPUT STATUS         -----------------------

    Public gDo1 As Integer = 0
    Public gDo2 As Integer = 0
    Public gDo3 As Integer = 0
    Public gDo4 As Integer = 0
    Public gDo5 As Integer = 0
    Public gDo6 As Integer = 0
    Public gDo7 As Integer = 0
    Public gDo8 As Integer = 0
    Public gDo9 As Integer = 0
    Public gDo10 As Integer = 0
    Public gDo11 As Integer = 0
    Public gDo12 As Integer = 0
    Public gDo13 As Integer = 0
    Public gDo14 As Integer = 0
    Public gDo15 As Integer = 0
    Public gDo16 As Integer = 0
    Public gDo17 As Integer = 0
    Public gDo18 As Integer = 0
    Public gDo19 As Integer = 0
    Public gDo20 As Integer = 0
    Public gDo21 As Integer = 0
    Public gDo22 As Integer = 0
    Public gDo23 As Integer = 0
    Public gDo24 As Integer = 0
    Public gDo25 As Integer = 0
    Public gDo26 As Integer = 0
    Public gDo27 As Integer = 0
    Public gDo28 As Integer = 0
    Public gDo29 As Integer = 0
    Public gDo30 As Integer = 0
    Public gDo31 As Integer = 0
    Public gDo32 As Integer = 0


    '----------------------- ANALOG INPUT  READ VALUES            -----------------------------------

    Public gGTAWCurr As Double = 0.0
    Public gGTAWVol As Double = 0.0
    Public gGTAWCurr2 As Double = 0.0
    Public gGTAWVol2 As Double = 0.0
    Public gGTAWjobtemp As Double = 0.0
    Public gGTAWgasflow As Double = 0.0
    Public gGTAWgasflow2 As Double = 0.0
    Public gGTAWTravelSpeed As Double = 0.0
    Public gAi8 As Double = 0.0
    Public gGTAWwirefeed As Double = 0.0
    Public gGTAWwirefeed2 As Double = 0.0

    '--------------------- ANALOG OUTPUT  VALUES --------------------------------
    Public gAo1 As Double = 0.0
    Public gAo2 As Double = 0.0
    Public gAo3 As Double = 0.0
    Public gAo4 As Double = 0.0
    Public gAo5 As Double = 0.0
    Public gAo6 As Double = 0.0
    Public gAo7 As Double = 0.0
    Public gAo8 As Double = 0.0


    ' ////////////////////////////    ANALOG INPUT SCALLING FACTOR         /////////////////////

    Public gMinScaleAi1 As Double = 0.0
    Public gMaxScalleAi1 As Double = 0.0
    Public gMinScaleAi2 As Double = 0.0
    Public gMaxScalleAi2 As Double = 0.0
    Public gMinScaleAi3 As Double = 0.0
    Public gMaxScalleAi3 As Double = 0.0
    Public gMinScaleAi4 As Double = 0.0
    Public gMaxScalleAi4 As Double = 0.0
    Public gMinScaleAi5 As Double = 0.0
    Public gMaxScalleAi5 As Double = 0.0
    Public gMinScaleAi6 As Double = 0.0
    Public gMaxScalleAi6 As Double = 0.0
    Public gMinScaleAi7 As Double = 0.0
    Public gMaxScalleAi7 As Double = 0.0
    Public gMinScaleAi8 As Double = 0.0
    Public gMaxScalleAi8 As Double = 0.0


    ' ////////////////////////////    ANALOG OUTPUT SCALLING FACTOR         /////////////////////

    Public gMinScalleAo1 As Double = 0.0
    Public gMaxScalleAo1 As Double = 0.0
    Public gMinScalleAo2 As Double = 0.0
    Public gMaxScalleAo2 As Double = 0.0
    Public gMinScalleAo3 As Double = 0.0
    Public gMaxScalleAo3 As Double = 0.0
    Public gMinScalleAo4 As Double = 0.0
    Public gMaxScalleAo4 As Double = 0.0
    Public gMinScalleAo5 As Double = 0.0
    Public gMaxScalleAo5 As Double = 0.0
    Public gMinScalleAo6 As Double = 0.0
    Public gMaxScalleAo6 As Double = 0.0
    Public gMinScalleAo7 As Double = 0.0
    Public gMaxScalleAo7 As Double = 0.0
    Public gMinScalleAo8 As Double = 0.0
    Public gMaxScalleAo8 As Double = 0.0




    ' //////////////////////////////////  /////////////////////

    ' //////////////////////////////////  FAULT  STATUS DISPLAY  /////////////////////

    Public gFault1 As Integer = 0
    Public gFault2 As Integer = 0
    Public gFault3 As Integer = 0
    Public gFault4 As Integer = 0
    Public gFault5 As Integer = 0
    Public gFault6 As Integer = 0
    Public gFault7 As Integer = 0
    Public gFault8 As Integer = 0
    Public gFault9 As Integer = 0
    Public gFault10 As Integer = 0
    Public gFault11 As Integer = 0
    Public gFault12 As Integer = 0
    Public gFault13 As Integer = 0
    Public gFault14 As Integer = 0
    Public gFault15 As Integer = 0
    Public gFault16 As Integer = 0
    Public gFault17 As Integer = 0
    Public gFault18 As Integer = 0
    Public gFault19 As Integer = 0
    Public gFault20 As Integer = 0
    Public gFault21 As Integer = 0
    Public gFault22 As Integer = 0
    Public gFault23 As Integer = 0
    Public gFault24 As Integer = 0
    Public gFault25 As Integer = 0
    Public gFault26 As Integer = 0
    Public gFault27 As Integer = 0
    Public gFault28 As Integer = 0
    Public gFault29 As Integer = 0
    Public gFault30 As Integer = 0

    ' /////////////////////////////  FAULT RESET  /////////////////////////////////////////

    Public gFAULT As Integer = 0
    Public gRESET As Integer = 0
    Public gALARM As Integer = 0

    ' /////////////////////////////  ALARMS /LIMITS-DISPLAYS   /////////////////////////////////////////

    Public gFLIimitAxis1 As Integer = 0
    Public gRLimitAxis1 As Integer = 0
    Public gFLIimitAxis2 As Integer = 0
    Public gRLimitAxis2 As Integer = 0
    Public gFLIimitAxis3 As Integer = 0
    Public gRLimitAxis3 As Integer = 0
    Public gFLIimitAxis4 As Integer = 0
    Public gRLimitAxis4 As Integer = 0
    Public gFLIimitAxis5 As Integer = 0
    Public gRLimitAxis5 As Integer = 0

    ' /////////////////////////////  SERVO FAULT CODES   /////////////////////////////////////////

    Public gErrorCodeSA1 As String = ""
    Public gErrorCodeSA2 As String = ""
    Public gErrorCodeSA3 As String = ""
    Public gErrorCodeSA4 As String = ""
    Public gErrorCodeSA5 As String = ""

    ' /////////////////////////////  AXIS CALIBRATION FACTORS   /////////////////////////////////////////
    Public gXFactorAxis1 As Integer = 0
    Public gYFactorAxis1 As Integer = 0
    Public gXFactorAxis2 As Integer = 0
    Public gYFactorAxis2 As Integer = 0
    Public gXFactorAxis3 As Integer = 0
    Public gYFactorAxis3 As Integer = 0
    Public gXFactorAxis4 As Integer = 0
    Public gYFactorAxis4 As Integer = 0
    Public gXFactorAxis5 As Integer = 0
    Public gYFactorAxis5 As Integer = 0

    ' /////////////////////////////  AXIS SOFTWARE LIMITS   /////////////////////////////////////////

    Public gSLFwdAxis1 As Double = 0.0
    Public gSLRevAxis1 As Double = 0.0
    Public gSLFwdAxis2 As Double = 0.0
    Public gSLRevAxis2 As Double = 0.0
    Public gSLFwdAxis3 As Double = 0.0
    Public gSLRevAxis3 As Double = 0.0
    Public gSLFwdAxis4 As Double = 0.0
    Public gSLRevAxis4 As Double = 0.0
    Public gSLFwdAxis5 As Double = 0.0
    Public gSLRevAxis5 As Double = 0.0

    ' /////////////////////////////  AXIS POSITION RESET   /////////////////////////////////////////

    Public gOprAxis1 As Integer = 0
    Public gOprAxis2 As Integer = 0
    Public gOprAxis3 As Integer = 0
    Public gOprAxis4 As Integer = 0
    Public gOprAxis5 As Integer = 0

    ' /////////////////////////////  AXIS HOME POSITION    /////////////////////////////////////////

    Public gHomePosAxis1 As Double = 0.0
    Public gHomePosAxis2 As Double = 0.0
    Public gHomePosAxis3 As Double = 0.0
    Public gHomePosAxis4 As Double = 0.0
    Public gHomePosAxis5 As Double = 0.0

    ' /////////////////////////////  MODE SELECTION    /////////////////////////////////////////

    Public gAutoManual As Integer = 0

    ' /////////////////////////////  SPEED SELECTION    /////////////////////////////////////////

    Public gRAPID As Integer = 0
    Public gSLOW As Integer = 0

    ' /////////////////////////////  SYSTEM MONITORING BITS    /////////////////////////////////////////

    Public gSystemHealthy As Integer = 0
    Public gAutoON As Integer = 0

    ' /////////////////////////////  MANUAL MODE-SPEED VALUES    /////////////////////////////////////////

    Public gManSpeedRapidAxis1 As Double = 0.0
    Public gManSpeedSlowAxis1 As Double = 0.0
    Public gManSpeedRapidAxis2 As Double = 0.0
    Public gManSpeedSlowAxis2 As Double = 0.0
    Public gManSpeedRapidAxis3 As Double = 0.0
    Public gManSpeedSlowAxis3 As Double = 0.0
    Public gManSpeedRapidAxis4 As Double = 0.0
    Public gManSpeedSlowAxis4 As Double = 0.0
    Public gManSpeedRapidAxis5 As Double = 0.0
    Public gManSpeedSlowAxis5 As Double = 0.0

    ' /////////////////////////////  AUTO MODE-SPEED VALUES    /////////////////////////////////////////

    Public gAutoSpeedAxis1 As Double = 0.0
    Public gAutoSpeedAxis2 As Double = 0.0
    Public gAutoSpeedAxis3 As Double = 0.0
    Public gAutoSpeedAxis4 As Double = 0.0
    Public gAutoSpeedAxis5 As Double = 0.0

    ' /////////////////////////////  AXIS SPEED DISPLAY    /////////////////////////////////////////

    Public gSpeedDisplayAxis1 As Double = 0.0
    Public gSpeedDisplayAxis2 As Double = 0.0
    Public gSpeedDisplayAxis3 As Double = 0.0
    Public gSpeedDisplayAxis4 As Double = 0.0
    Public gSpeedDisplayAxis5 As Double = 0.0

    ' /////////////////////////////  AXIS POSITION DISPLAY    /////////////////////////////////////////

    Public gPositionAxis1 As Double = 0.0
    Public gPositionAxis2 As Double = 0.0
    Public gPositionAxis3 As Double = 0.0
    Public gPositionAxis4 As Double = 0.0
    Public gPositionAxis5 As Double = 0.0

    ' /////////////////////////////  AXIS POSITION DISPLAY-LAST WELD   /////////////////////////////////////////

    Public gLastWeldPositionAxis1 As Double = 0.0
    Public gLastWeldPositionAxis2 As Double = 0.0
    Public gLastWeldPositionAxis3 As Double = 0.0
    Public gLastWeldPositionAxis4 As Double = 0.0
    Public gLastWeldPositionAxis5 As Double = 0.0

    ' /////////////////////////////  AVC BAND AND SPEED    /////////////////////////////////////////
    Public gAvcband1 As Double = 0.0
    Public gAvcband2 As Double = 0.0
    Public gAvcspeed1 As Double = 0.0
    Public gAvcspeed2 As Double = 0.0

    ' /////////////////////////////  MANUAL MODE-JOGGING COMMANDS   /////////////////////////////////////////

    Public gManFwdAxis1 As Integer = 0
    Public gManRevAxis1 As Integer = 0
    Public gManFwdAxis2 As Integer = 0
    Public gManRevAxis2 As Integer = 0
    Public gManFwdAxis3 As Integer = 0
    Public gManRevAxis3 As Integer = 0
    Public gManFwdAxis4 As Integer = 0
    Public gManRevAxis4 As Integer = 0
    Public gManFwdAxis5 As Integer = 0
    Public gManRevAxis5 As Integer = 0

    ' /////////////////////////////  AUXILLARY DEVICES ON-OFF COMMANDS   /////////////////////////////////////////

    Public gDevice1 As Integer = 0
    Public gDevice2 As Integer = 0
    Public gDevice3 As Integer = 0
    Public gDevice4 As Integer = 0
    Public gDevice5 As Integer = 0
    Public gDevice6 As Integer = 0
    Public gDevice7 As Integer = 0
    Public gDevice8 As Integer = 0
    Public gDevice9 As Integer = 0
    Public gDevice10 As Integer = 0

    ' /////////////////////////////  POWER SOURCE OPERATION   /////////////////////////////////////////

    Public gPowerSourceON As Integer = 0
    Public gPowerSourceOFF As Integer = 0
    Public gWeldingCycleStart As Integer = 0
    Public gWeldingCycleStop As Integer = 0
    Public gGasTestFluxFill1 As Integer = 0
    Public gWireIN1 As Integer = 0
    Public gWireOUT1 As Integer = 0
    Public gWireFeedOnOff1 As Integer = 0
    Public gHotWireOnOff1 As Integer = 0
    Public gAVCOnOff1 As Integer = 0
    Public gPS1Select As Integer = 0
    Public gPS2Select As Integer = 0
    Public gGasTestFluxFill2 As Integer = 0
    Public gWireIN2 As Integer = 0
    Public gWireOUT2 As Integer = 0
    Public gWireFeedOnOff2 As Integer = 0
    Public gHotWireOnOff2 As Integer = 0
    Public gAvcOnOff2 As Integer = 0


    ' /////////////////////////////  USER INPUTS-JOB DATA   /////////////////////////////////////////

    Public gPipeNozzleID As Double = 0.0
    Public gPipeNozzleOD As Double = 0.0
    Public gPipeNozzleLength As Double = 0.0
    Public gFlangeID As Double = 0.0
    Public gFlangeOD As Double = 0.0
    Public gBackfaceID As Double = 0.0
    Public gBackfaceOD As Double = 0.0
    Public gNozzleRefDIA As Double = 0.0
    Public gShellID As Double = 0.0
    Public gShellOD As Double = 0.0
    Public gBeadShift As Double = 0.0
    Public gBeadShiftSpeed As Double = 0.0

    Public gNozzlePipeIDONOFF As Integer = 0
    Public gFlangeOLOnOff As Integer = 0
    Public gBackFaceOLOnOff As Integer = 0

    ' /////////////////////////////  USER INPUTS-AUTO PROCESS SELECT   /////////////////////////////////////////

    Public gLinearCircular As Integer = 0
    Public gStepOnOff As Integer = 0
    Public gSpiralOnOff As Integer = 0
    Public gSagitaOnOff As Integer = 0
    Public gDryWeldRun As Integer = 0
    Public gTag1 As Integer = 0
    Public gTag2 As Integer = 0

    ' /////////////////////////////  USER INPUTS-WELDING PARAMETERS  /////////////////////////////////////////

    Public gWeldingSpeed As Double = 0.0


    Public gShiftDirectionUpDn As Integer = 0
    Public gShiftDirectionInOut As Integer = 0
    Public gShiftDirectionFwdRev As Integer = 0

    ' /////////////////////////////  USER INPUTS-PROCESS PARAMETERS  /////////////////////////////////////////
    Public gSetCurrent1 As Double = 0.0
    Public gSetVoltage1 As Double = 0.0
    Public gSetWFSpeed1 As Double = 0.0
    Public gSetWFStartDelay1 As Double = 0.0
    Public gSetWFRetractDistance1 As Double = 0.0
    Public gSetCurrent2 As Double = 0.0
    Public gSetVoltage2 As Double = 0.0
    Public gSetWFSpeed2 As Double = 0.0
    Public gSetWFStartDelay2 As Double = 0.0
    Public gSetWFRetractDistance2 As Double = 0.0

    ' /////////////////////////////  USER INPUTS-DELAY PARAMETERS  /////////////////////////////////////////

    Public gDelay1 As Double = 0.0
    Public gDelay2 As Double = 0.0
    Public gDelay3 As Double = 0.0
    Public gDelay4 As Double = 0.0
    Public gDelay5 As Double = 0.0
    Public gDelay6 As Double = 0.0
    Public gDelay7 As Double = 0.0
    Public gDelay8 As Double = 0.0
    Public gDelay9 As Double = 0.0
    Public gDelay10 As Double = 0.0

    ' /////////////////////////////  PROCESS MONITORING BITS  /////////////////////////////////////////

    Public gPmb1 As Integer = 0
    Public gPmb2 As Integer = 0
    Public gPmb3 As Integer = 0
    Public gPmb4 As Integer = 0
    Public gPmb5 As Integer = 0
    Public pmb5tag As Integer
    Public pmb1tag As Integer

    ''frm jobdata
    Public tagnozzle As Integer
    Public tagflange As Integer
    Public tagbackface As Integer

    '--------------------------------------------------------------------------------
    Public gspeedcam As String
    '------------------------------------------------------------

    ''  //////////////////   IMPORTANT PARAMETER  /////////////

    ''   /////////////  FRM CONSUM PARAMETER   //////////////////////////////////

    Public gParaPass As String = "0"
    Public gconsItem As String = ""
    Public gFluxItem As String = ""
    Public gConsBatch As String = ""
    Public gFluxBatch As String = ""
    Public gSportNo As Integer = 0
    Public gGrind As Integer = 0
    Public gGrindFillupvalue As Integer = 0

    '' ///////////////// Syspara Database
    Public gWCMin As Double
    Public gWCMax As Double
    Public gwcoffset As Integer
    Public gWVMin As Double
    Public gWVMax As Double
    Public gwvoffset As Integer
    Public gGTAWTRSMin As Double
    Public gGTAWTRSMax As Double
    Public gTRSoffset As Integer
    Public gJTMin As Double
    Public gJTMax As Double
    Public gjtoffset As Integer
    Public gGFMin As Double
    Public gGFMax As Double
    Public gGFoffset As Integer
    Public gfWMin As Double
    Public gfWMax As Double
    Public gfwoffset As Integer
    Public gWFmin As Double
    Public gWFmax As Double
    Public gWFoffset As Double
    Public gcurstep As Double
    Public gvolstep As Double
    Public gcurstep2 As Double
    Public gvolstep2 As Double
    Public gSetTemp As Double
    Public gSetTempPM As Double
    Public grollerCircum As Double = 0
    Public gSurfaceSpeed As Double = 0.001
    Public gPowersrc As Integer = 0
    Public gParaLogInt As Integer
    Public gFluxWghtLogInt As Integer
    Public gtrospeed As Double
    Public gtroslowspeed As Double
    Public gtrorapspeed As Double
    Public gxspeed As Double
    Public gxslowspeed As Double
    Public gxrapspeed As Double
    Public gyspeed As Double
    Public gyslowspeed As Double
    Public gyrapspeed As Double
    Public gstrcutslide As Double
    Public gstpoverwidth As Double

    Public grightmin As Integer
    Public grightmax As Integer
    Public grighcuroffset As Integer
    Public fs1 As StreamWriter

    Public phs As String = "man"
    Public ERPLNDBConnectivity As Boolean = False
    Public IOTDBConnectivity As Boolean = False
    Public gMachineIP As String = ""
    Public gPlcIP As String = ""
    Public gPlcPort As String = ""
    Public TRCON As Boolean = False

    Private Declare Sub keybd_event Lib "user32" (ByVal bVk As Byte,
                   ByVal bScan As Byte, _
                   ByVal dwFlags As Byte, _
                   ByVal dwExtraInfo As Byte)

    Private Const VK_RETURN As Byte = &HD
    Private Const KEYEVENTF_KEYDOWN As Byte = &H0
    Private Const KEYEVENTF_KEYUP As Byte = &H2

    Public gOpMode As String = Configuration.ConfigurationManager.AppSettings("OpMode").ToString()
    Public gExe As String = Configuration.ConfigurationManager.AppSettings("WPSexe").ToString()
    Public gMentry As String = Configuration.ConfigurationManager.AppSettings("mentry").ToString()
    Public gtest As String = Configuration.ConfigurationManager.AppSettings("test").ToString()


#Region "serialCom"
    Public Sub comOpen()
        mycomm = New SerialPort
        Try
            '// Setup parameters
            With mycomm
                .PortName = "COM" & miComPort
                .BaudRate = Int32.Parse(txtBaudrate)
                .DataBits = 8
                .StopBits = StopBits.One
                .Parity = Parity.None
                .ReadTimeout = Int32.Parse(txtTimeout)
                .WriteTimeout = Int32.Parse(txtTimeout)
            End With
            '// Initializes port
            mycomm.Open()
            '// Set state of RTS / DTS
            ''mycomm.Dtr = (chkDTR = CheckState.Checked)
            ''mycomm.Rts = (chkRTS = CheckState.Checked)
            ''If chkEvents Then mycomm.EnableEvents()
            ''chkEvents = True
        Catch Ex As Exception
            'MessageBox.Show("Error in comOpen method of modSerial module, Error : " + Ex.Message.ToString())
        Finally
            isComOpen = mycomm.IsOpen
        End Try
    End Sub
    Public Function checkCom() As Boolean
        Dim retVal As Boolean
        If mycomm.IsOpen Then
            retVal = True
        Else
            comOpen()
            retVal = isComOpen
        End If
        Return retVal
    End Function
    Public Function checkComRX() As Boolean
        Dim retVal As Boolean
        If mycommRX.IsOpen Then
            retVal = True
        Else
            comOpenRX()
            retVal = isComOpenRX
        End If
        Return retVal
    End Function
    Public Sub closeCom()
        chkEvents = False
        mycomm.Close()
        isComOpen = mycomm.IsOpen
    End Sub

    Public Sub resetCtrl()
        Try
            'If isConnection = True Then
            '    Dim tx As String = "0B 0F 00 10 00 08 01 00 BF 29"
            '    Dim rx As String = txComA(tx, 50)
            '    'writeLog("|ESSCon |TX:" & tx & " |RX:" & rx)
            '    tx = "15 0F 00 10 00 08 01 00 3F A9"
            '    rx = txComA(tx, 50)
            '    'writeLog("|ESSCon |TX:" & tx & " |RX:" & rx)
            '    tx = "1F 0F 00 10 00 08 01 00 BF D6"
            '    rx = txComA(tx, 50)
            '    'writeLog("|ESSCon |TX:" & tx & " |RX:" & rx)
            '    tx = "20 0F 00 10 00 08 01 00 FC 82"
            '    rx = txComA(tx, 50)
            '    'writeLog("|ESSCon |TX:" & tx & " |RX:" & rx)
            '    tx = "21 0F 00 10 00 08 01 00 3D 4E"
            '    rx = txComA(tx, 50)
            '    'writeLog("|ESSCon |TX:" & tx & " |RX:" & rx)
            '    tx = "29 0F 00 10 00 08 01 00 3C E8"
            '    rx = txComA(tx, 50)
            '    'writeLog("|ESSCon |TX:" & tx & " |RX:" & rx)
            'End If
        Catch ex As Exception
            'writeLog(ex.Message)
            MessageBox.Show("Error from resetCtrl() mehtod of frmPara form, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Public Function txComA(ByVal stx As String, ByVal sleep As Integer) As String
        Dim rx As String = ""
        Try
            Dim txbytes As Byte() = HexToByte(stx)  'stx.Split(" "c).Select(Function(n) Convert.ToByte(Convert.ToInt32(n, 16))).ToArray() 'HexToByte(stx) 
            mycomm.Write(txbytes, 0, txbytes.Length)
            Thread.Sleep(sleep)
            Dim bytes As Integer = mycomm.BytesToRead
            'create a byte array to hold the awaiting data  
            Dim comBuffer As Byte() = New Byte(bytes - 1) {}
            'read the data and store it
            mycomm.Read(comBuffer, 0, bytes)
            rx = ByteToHex(comBuffer)

            'writeLog("|txComA |TX:" & stx & "|RX:" & rx)
        Catch ex As Exception
            'MessageBox.Show("Error in txComA method of modSerail module, Error : " + ex.Message.ToString())
        End Try
        Return rx
    End Function

    'Public Function tx2ComA(ByVal stx As String) As String
    '    Try
    '        Dim txbytes As Byte() = HexToByte(stx)  'stx.Split(" "c).Select(Function(n) Convert.ToByte(Convert.ToInt32(n, 16))).ToArray() 'HexToByte(stx) 
    '        mycomm.Write(txbytes, 0, txbytes.Length)
    '    Catch ex As Exception
    '        MessageBox.Show("Error in tx2ComA method of modSerail module, Error : " + ex.Message.ToString())
    '    End Try
    '    Return ""
    'End Function

    'Public Function txComA(tx, 50)(ByVal stx As String) As String
    '    Try
    '        Dim txbytes As Byte() = HexToByte(stx)  'stx.Split(" "c).Select(Function(n) Convert.ToByte(Convert.ToInt32(n, 16))).ToArray() 'HexToByte(stx) 
    '        mycomm.Write(txbytes, 0, txbytes.Length)
    '        Thread.Sleep(50)
    '    Catch ex As Exception
    '        MessageBox.Show("Error in txComA(tx, 50) method of modSerail module, Error : " + ex.Message.ToString())
    '    End Try
    '    Return ""
    'End Function
#End Region
#Region "serialComRX"
    Public Sub comOpenRX()
        mycommRX = New SerialPort
        Try
            '// Setup parameters
            With mycommRX
                .PortName = "COM" & miComPortRX
                .BaudRate = Int32.Parse(txtBaudrate)
                .DataBits = 8
                .StopBits = StopBits.One
                .Parity = Parity.None
                .ReadTimeout = Int32.Parse(txtTimeout)
                .WriteTimeout = Int32.Parse(txtTimeout)
            End With
            '// Initializes port
            mycommRX.Open()
            '// Set state of RTS / DTS
            ''mycomm.Dtr = (chkDTR = CheckState.Checked)
            ''mycomm.Rts = (chkRTS = CheckState.Checked)
            ''If chkEvents Then mycomm.EnableEvents()
            ''chkEvents = True
        Catch Ex As Exception
            ''MessageBox.Show(Ex.Message, "Connection Error", MessageBoxButtons.OK)
            ' MessageBox.Show("Error in comOpenRX method of modSerail module, Error : " + Ex.Message.ToString())
        Finally
            isComOpenRX = mycommRX.IsOpen
        End Try
    End Sub
    Public Sub closeComRX()
        chkEvents = False
        mycommRX.Close()
        isComOpenRX = mycommRX.IsOpen
    End Sub

    Public Function txComRX(ByVal stx As String, ByVal sleep As Integer) As String
        Dim rx As String = ""

        Try
            'MessageBox.Show("stx = " + stx.ToString())

            Dim txbytes As Byte() = HexToByte(stx) 'stx.Split(" "c).Select(Function(n) Convert.ToByte(Convert.ToInt32(n, 16))).ToArray() 'HexToByte(stx) 
            mycommRX.Write(txbytes, 0, txbytes.Length)
            Thread.Sleep(sleep)
            Dim bytes As Integer = mycommRX.BytesToRead
            'create a byte array to hold the awaiting data
            Dim comBuffer As Byte() = New Byte(bytes - 1) {}
            'read the data and store it
            mycommRX.Read(comBuffer, 0, bytes)
            rx = ByteToHex(comBuffer)
        Catch ex As Exception
            MessageBox.Show("Error in txComRX method of modSerail module, Error : " + ex.Message.ToString() + ", String : " + stx.ToString())
        End Try
        Return rx
    End Function

    Public Sub TcpConnection()
        Try
            Dim tcpClient As New System.Net.Sockets.TcpClient()
            tcpClient.Connect(gPlcIP, gPlcPort)
            networkStream = tcpClient.GetStream()
            tcpClient.ReceiveTimeout = 500
            If networkStream.CanWrite And networkStream.CanRead Then
                isConnection = True
            Else
                isConnection = False
                tcpClient.Close()
            End If



        Catch ex As Exception
            Dim result1 As String = MessageBoxEx.Show("Error in TcpConnection method , Error : " + ex.Message.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 3, "").ToString

            '' MessageBox.Show("Error in TcpConnection method of MDIParent module, Error : " + ex.Message.ToString())
        End Try

    End Sub
    Public Function TCPComRX(ByVal stx As String, ByVal sleep As Integer) As String
        Dim rx As String = ""

        Try
            'MessageBox.Show("stx = " + stx.ToString())
            Dim sendBytes As Byte() = HexToByte(stx)
            networkStream.Write(sendBytes, 0, sendBytes.Length)
            networkStream.WriteTimeout = sleep
            networkStream.ReadTimeout = 3000
            length = tcpClient.ReceiveBufferSize
            'read the data and store it
            Do
                numberOfBytesRead = networkStream.Read(bytes, 0, bytes.Length)
            Loop While networkStream.DataAvailable
            rx = ByteToHex(bytes)
        Catch ex As Exception
            '' Dim result1 As String = MessageBoxEx.Show("Data Not Received : " + ex.Message.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
            'TcpConnection()
            '' MessageBox.Show("Error in Tcp Recieve method of modSerail module, Error : " + ex.Message.ToString() + ", String : " + stx.ToString())
        End Try
        Return rx
    End Function

    Public Function TCPComA(ByVal stx As String, ByVal sleep As Integer) As String
        Dim rx As String = ""
        Try
            Dim sendBytes As Byte() = HexToByte(stx)  'stx.Split(" "c).Select(Function(n) Convert.ToByte(Convert.ToInt32(n, 16))).ToArray() 'HexToByte(stx) 
            networkStream.Write(sendBytes, 0, sendBytes.Length)
            networkStream.WriteTimeout = sleep
            networkStream.ReadTimeout = 300
            ' Dim bytes As Integer = mycomm.BytesToRead
            'create a byte array to hold the awaiting data  
            length = tcpClient.ReceiveBufferSize
            'read the data and store it
            Do
                numberOfBytesRead = networkStream.Read(sendBytes, 0, sendBytes.Length)
            Loop While networkStream.DataAvailable
            rx = ByteToHex(sendBytes)

            'writeLog("|txComA |TX:" & stx & "|RX:" & rx)
        Catch ex As Exception
            'MessageBox.Show("Error in tCPComA method of modSerail module, Error : " + ex.Message.ToString())
            'TcpConnection()
        End Try
        Return rx
    End Function

#End Region
#Region "MiscFuncs"
    Public Sub msgboxautoclose(ByVal Message As String, Optional ByVal Style As MsgBoxStyle = Nothing, Optional ByVal title As String = Nothing, Optional ByVal delay As Integer = 5)
        Dim t As New Threading.Thread(AddressOf closeMsgbox)
        t.Start(delay) '5 second default delay
        MsgBox(Message, Style, title)
    End Sub
    Private Sub closeMsgbox(ByVal delay As Object)
        Threading.Thread.Sleep(CInt(delay) * 1000)
        ''AppActivate(Text)
        keybd_event(VK_RETURN, 0, KEYEVENTF_KEYDOWN, 0)
        keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0)
    End Sub

    'Public Sub getshop()
    '    Try
    '        Using objCon As New dbClass
    '            Using dt As DataTable = objCon.ExecuteDataTable("select * from device", CommandType.Text)
    '                For Each row As DataRow In dt.Rows
    '                    gshopno = row("gshopno")
    '                    gshopname = row("gshopname")
    '                    gcmbno = row("gcmbno")
    '                    gcmbname = row("gcmbname")
    '                Next
    '            End Using
    '        End Using
    '    Catch ex As Exception
    '        'writeLog(ex.Message)
    '        MessageBox.Show("Error from getshop() method, Error : " + ex.Message.ToString())
    '    End Try
    'End Sub

    Public Sub getPara()
        Try
            Using objCon As New dbClass
                Using dt As DataTable = objCon.ExecuteDataTable("select * from syspara", CommandType.Text)
                    For Each row As DataRow In dt.Rows
                        gWCMin = IIf(Convert.IsDBNull(row("wcmin")), "", row("wcmin"))
                        gWCMax = IIf(Convert.IsDBNull(row("wcmax")), "", row("wcmax"))
                        gWVMin = IIf(Convert.IsDBNull(row("wvmin")), "", row("wvmin"))
                        gWVMax = IIf(Convert.IsDBNull(row("wvmax")), "", row("wvmax"))
                        gGTAWTRSMin = IIf(Convert.IsDBNull(row("trsmin")), "", row("trsmin"))
                        gGTAWTRSMax = IIf(Convert.IsDBNull(row("trsmax")), "", row("trsmax"))
                        gJTMin = IIf(Convert.IsDBNull(row("jtmin")), "", row("jtmin"))
                        gJTMax = IIf(Convert.IsDBNull(row("jtmax")), "", row("jtmax"))
                        gGFMin = IIf(Convert.IsDBNull(row("gfmin")), "", row("gfmin"))
                        gGFMax = IIf(Convert.IsDBNull(row("gfmax")), "", row("gfmax"))
                        gcurstep = IIf(Convert.IsDBNull(row("curstep")), "", row("curstep"))
                        gvolstep = IIf(Convert.IsDBNull(row("volstep")), "", row("volstep"))
                        gcurstep2 = IIf(Convert.IsDBNull(row("curstep2")), "", row("curstep2"))
                        gvolstep2 = IIf(Convert.IsDBNull(row("volstep2")), "", row("volstep2"))
                        gSetTemp = IIf(Convert.IsDBNull(row("settemp")), "", row("settemp"))
                        gSetTempPM = IIf(Convert.IsDBNull(row("settemppm")), "", row("settemppm"))
                        gSetspeedstep = IIf(Convert.IsDBNull(row("speedstep")), "", row("speedstep"))
                        gParaLogInt = IIf(Convert.IsDBNull(row("paralogintvl")), "", row("paralogintvl"))
                        gFluxWghtLogInt = IIf(Convert.IsDBNull(row("fwlogintval")), "", row("fwlogintval"))
                        grollerCircum = IIf(Convert.IsDBNull(row("circrol")), "", row("circrol"))
                        gSurfaceSpeed = IIf(Convert.IsDBNull(row("srfspeed")), "", row("srfspeed"))
                        gwfstep = IIf(Convert.IsDBNull(row("wirefeedstep")), "", row("wirefeedstep"))
                        gwfstep2 = IIf(Convert.IsDBNull(row("wirefeedstep2")), "", row("wirefeedstep2"))
                        gweldspeedstep = IIf(Convert.IsDBNull(row("weldspeedstep")), "", row("weldspeedstep"))
                        gWFmin = IIf(Convert.IsDBNull(row("wfmin")), "", row("wfmin"))
                        gWFmax = IIf(Convert.IsDBNull(row("wfmax")), "", row("wfmax"))
                        grightmin = IIf(Convert.IsDBNull(row("righcurmin")), "", row("righcurmin"))
                        grightmax = IIf(Convert.IsDBNull(row("righcurmax")), "", row("righcurmax"))
                    Next
                End Using

                Using dt As DataTable = objCon.ExecuteDataTable("select * from device", CommandType.Text)
                    For Each row As DataRow In dt.Rows
                        gshop = IIf(Convert.IsDBNull(row("shop")), "", row("shop"))
                        gstation = IIf(Convert.IsDBNull(row("station")), "", row("station"))
                        gComTX = IIf(Convert.IsDBNull(row("comporttx")), "", row("comporttx"))
                        gComRX = IIf(Convert.IsDBNull(row("comportRX")), "", row("comportRX"))
                        gSpeed = IIf(Convert.IsDBNull(row("speed")), "", row("speed"))
                        gParaPass = IIf(Convert.IsDBNull(row("parapass")), "", row("parapass"))
                        gMachineIP = IIf(Convert.IsDBNull(row("machineIP")), "", row("machineIP"))
                        gPlcIP = IIf(Convert.IsDBNull(row("plcip")), "", row("plcip"))
                        gPlcPort = IIf(Convert.IsDBNull(row("plcport")), "", row("plcport"))
                    Next
                End Using
            End Using
        Catch ex As Exception
            'writeLog(ex.Message)
            MessageBox.Show("Error from getPara() method of modSerial module, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Public Sub getesscPara()
        Try
            Using objCon As New dbClass
                Using dt As DataTable = objCon.ExecuteDataTable("select * from esscpara", CommandType.Text)
                    For Each row As DataRow In dt.Rows
                        gtrospeed = row("trospeed")
                        gtroslowspeed = row("troslowspeed")
                        gtrorapspeed = row("trorapspeed")
                        gxspeed = row("xspeed")
                        gxslowspeed = row("xslowspeed")
                        gxrapspeed = row("xrapspeed")
                        gyspeed = row("yspeed")
                        gyslowspeed = row("yslowspeed")
                        gyrapspeed = row("yrapspeed")
                        gstrcutslide = row("strcutslide")
                        gstpoverwidth = row("stpoverwidth")
                    Next
                End Using
            End Using
        Catch ex As Exception
            'writeLog(ex.Message)
            MessageBox.Show("Error from getesscPara() method, Error : " + ex.Message.ToString())
        End Try
    End Sub

    Public Function getProcessValue(ByVal ProcessName As String) As Integer
        Dim ProcessValue As Integer = 0
        Select Case ProcessName
            Case "GTAW" : ProcessValue = 1
            Case "SMAW" : ProcessValue = 2
            Case "SAW" : ProcessValue = 3
            Case "ESW" : ProcessValue = 4
            Case "SASC" : ProcessValue = 5
            Case "FCAW" : ProcessValue = 6
            Case "GMAW" : ProcessValue = 7
            Case "PAW" : ProcessValue = 8
            Case "EBW" : ProcessValue = 9
            Case "GTAWP" : ProcessValue = 10
            Case "GMAWP" : ProcessValue = 11
            Case "SAWT" : ProcessValue = 12
            Case "OTHER" : ProcessValue = 13
            Case "HWGTW" : ProcessValue = 14
            Case "MMA" : ProcessValue = 15
        End Select
        Return ProcessValue
    End Function
    Public Function ComputeCrc(ByVal stx As String) As String

        Try
            'Dim data1 As Byte() = stx.Split(" "c).Select(Function(n) Convert.ToByte(Convert.ToInt32(n, 16))).ToArray() 'HexToByte(stx)
            Dim data As Byte() = HexToByte(stx)
            Dim CrcTable As UShort() = {&H0, &HC0C1, &HC181, &H140, &HC301, &H3C0,
               &H280, &HC241, &HC601, &H6C0, &H780, &HC741,
               &H500, &HC5C1, &HC481, &H440, &HCC01, &HCC0,
               &HD80, &HCD41, &HF00, &HCFC1, &HCE81, &HE40,
               &HA00, &HCAC1, &HCB81, &HB40, &HC901, &H9C0,
               &H880, &HC841, &HD801, &H18C0, &H1980, &HD941,
               &H1B00, &HDBC1, &HDA81, &H1A40, &H1E00, &HDEC1,
               &HDF81, &H1F40, &HDD01, &H1DC0, &H1C80, &HDC41,
               &H1400, &HD4C1, &HD581, &H1540, &HD701, &H17C0,
               &H1680, &HD641, &HD201, &H12C0, &H1380, &HD341,
               &H1100, &HD1C1, &HD081, &H1040, &HF001, &H30C0,
               &H3180, &HF141, &H3300, &HF3C1, &HF281, &H3240,
               &H3600, &HF6C1, &HF781, &H3740, &HF501, &H35C0,
               &H3480, &HF441, &H3C00, &HFCC1, &HFD81, &H3D40,
               &HFF01, &H3FC0, &H3E80, &HFE41, &HFA01, &H3AC0,
               &H3B80, &HFB41, &H3900, &HF9C1, &HF881, &H3840,
               &H2800, &HE8C1, &HE981, &H2940, &HEB01, &H2BC0,
               &H2A80, &HEA41, &HEE01, &H2EC0, &H2F80, &HEF41,
               &H2D00, &HEDC1, &HEC81, &H2C40, &HE401, &H24C0,
               &H2580, &HE541, &H2700, &HE7C1, &HE681, &H2640,
               &H2200, &HE2C1, &HE381, &H2340, &HE101, &H21C0,
               &H2080, &HE041, &HA001, &H60C0, &H6180, &HA141,
               &H6300, &HA3C1, &HA281, &H6240, &H6600, &HA6C1,
               &HA781, &H6740, &HA501, &H65C0, &H6480, &HA441,
               &H6C00, &HACC1, &HAD81, &H6D40, &HAF01, &H6FC0,
               &H6E80, &HAE41, &HAA01, &H6AC0, &H6B80, &HAB41,
               &H6900, &HA9C1, &HA881, &H6840, &H7800, &HB8C1,
               &HB981, &H7940, &HBB01, &H7BC0, &H7A80, &HBA41,
               &HBE01, &H7EC0, &H7F80, &HBF41, &H7D00, &HBDC1,
               &HBC81, &H7C40, &HB401, &H74C0, &H7580, &HB541,
               &H7700, &HB7C1, &HB681, &H7640, &H7200, &HB2C1,
               &HB381, &H7340, &HB101, &H71C0, &H7080, &HB041,
               &H5000, &H90C1, &H9181, &H5140, &H9301, &H53C0,
               &H5280, &H9241, &H9601, &H56C0, &H5780, &H9741,
               &H5500, &H95C1, &H9481, &H5440, &H9C01, &H5CC0,
               &H5D80, &H9D41, &H5F00, &H9FC1, &H9E81, &H5E40,
               &H5A00, &H9AC1, &H9B81, &H5B40, &H9901, &H59C0,
               &H5880, &H9841, &H8801, &H48C0, &H4980, &H8941,
               &H4B00, &H8BC1, &H8A81, &H4A40, &H4E00, &H8EC1,
               &H8F81, &H4F40, &H8D01, &H4DC0, &H4C80, &H8C41,
               &H4400, &H84C1, &H8581, &H4540, &H8701, &H47C0,
               &H4680, &H8641, &H8201, &H42C0, &H4380, &H8341,
               &H4100, &H81C1, &H8081, &H4040}


            Dim crc As UShort = &HFFFF

            For Each datum As Byte In data
                crc = CUShort((crc >> 8) Xor CrcTable((crc Xor datum) And &HFF))
            Next
            Dim dec As String = dec2Hex(crc)
            Dim ret As String = dec.Substring(2, 2) & dec.Substring(0, 2)
            Return ret
        Catch ex As Exception
            MessageBox.Show("Error in ComputeCrc() mehtod of modSerial module, Error : " + ex.Message.ToString())
        End Try
        Return ""
    End Function

    Public Function getRatio(ByVal sport As String) As Array
        Dim retArray(6) As String
        Try
            'Dim sql As String = "select multiplier,ratio,xmax,xmin,ymax,ymin from sensor_para where sport='" & sport & "'"
            'Dim dt As DataTable
            'dt = objCon.ExecuteDataTable(sql, CommandType.Text)

            Using objCon As New dbClass
                Using dt As DataTable = objCon.ExecuteDataTable("select multiplier,ratio,xmax,xmin,ymax,ymin from sensor_para where sport='" & sport & "'", CommandType.Text)
                    For Each row As DataRow In dt.Rows
                        retArray(0) = row("multiplier")
                        retArray(1) = row("ratio")
                        retArray(2) = row("xmax")
                        retArray(3) = row("xmin")
                        retArray(4) = row("ymax")
                        retArray(5) = row("ymin")
                    Next
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Error in getRatio() mehtod of modSerial module, Error : " + ex.Message.ToString())
        End Try
        Return retArray
    End Function

    Public Sub AutoCompleteCombo_KeyUp(ByVal cbo As ComboBox, ByVal e As KeyEventArgs)
        Dim sTypedText As String
        Dim iFoundIndex As Integer
        Dim oFoundItem As Object
        Dim sFoundText As String
        Dim sAppendText As String

        'Allow select keys without Autocompleting
        Select Case e.KeyCode
            Case Keys.Back, Keys.Left, Keys.Right, Keys.Up, Keys.Delete, Keys.Down
                Return
        End Select

        'Get the Typed Text and Find it in the list
        sTypedText = cbo.Text
        iFoundIndex = cbo.FindString(sTypedText)

        'If we found the Typed Text in the list then Autocomplete
        If iFoundIndex >= 0 Then

            'Get the Item from the list (Return Type depends if Datasource was bound 
            ' or List Created)
            oFoundItem = cbo.Items(iFoundIndex)

            'Use the ListControl.GetItemText to resolve the Name in case the Combo 
            ' was Data bound
            sFoundText = cbo.GetItemText(oFoundItem)

            'Append then found text to the typed text to preserve case
            sAppendText = sFoundText.Substring(sTypedText.Length)
            cbo.Text = sTypedText & sAppendText

            'Select the Appended Text
            cbo.SelectionStart = sTypedText.Length
            cbo.SelectionLength = sAppendText.Length

        End If

    End Sub
    Public Sub AutoCompleteCombo_Leave(ByVal cbo As ComboBox)
        Dim iFoundIndex As Integer

        iFoundIndex = cbo.FindStringExact(cbo.Text)

        cbo.SelectedIndex = iFoundIndex

    End Sub
#End Region
#Region "conversion"
    Public Function HexToByte(ByVal msg As String) As Byte()
        Dim _msg As String
        ''If msg.Length Mod 2 = 0 Then
        'remove any spaces from the string
        _msg = msg
        _msg = msg.Replace(" ", "")
        'create a byte array the length of the
        'divided by 2 (Hex is 2 characters in length)
        Dim comBuffer As Byte() = New Byte(_msg.Length / 2 - 1) {}
        For i As Integer = 0 To _msg.Length - 1 Step 2
            comBuffer(i / 2) = CByte(Convert.ToByte(_msg.Substring(i, 2), 16))
        Next
        Return comBuffer
        ''Else
        '' Return Nothing
        ''End If
    End Function
    Public Function ByteToHex(ByVal comByte As Byte()) As String
        'create a new StringBuilder object
        Dim builder As New StringBuilder(comByte.Length * 3)
        'loop through each byte in the array
        For Each data As Byte In comByte
            builder.Append(Convert.ToString(data, 16).PadLeft(2, "0"c).PadRight(3, " "c))
            'convert the byte to a string and add to the stringbuilder
        Next
        'return the converted value
        Return builder.ToString().ToUpper()
    End Function

    'Public Function toDec(ByVal strV As String) As String
    '    Dim retVal As String = ""
    '    Dim x() As String = strV.Split("-")
    '    Dim i As Integer
    '    Dim s As String
    '    For i = 0 To x.Length - 1
    '        s = Trim(x(i))
    '        retVal = retVal & "-" & CInt("&H" & s)
    '    Next
    '    toDec = retVal
    'End Function

    Function ReverseString(ByVal strString As String) As String

        Dim builder As New System.Text.StringBuilder(strString.Length)
        Dim index As Integer = strString.Length - 1
        While index >= 0
            builder.Append(strString.Chars(index))
            index = index - 1
        End While
        ReverseString = builder.ToString
    End Function

    Public Function hexa2dec(ByVal lStrHex As String) As Long
        hexa2dec = 0
        Dim numbers As New Dictionary(Of String, Integer) From {{"0", 0}, {"1", 1}, {"2", 2}, {"3", 3}, {"4", 4}, {"5", 5}, {"6", 6}, {"7", 7}, {"8", 8}, {"9", 9}, {"A", 10}, {"B", 11}, {"C", 12}, {"D", 13}, {"E", 14}, {"F", 15}}

        Dim lstrRevHex As String = Strings.StrReverse(lStrHex)
        ''Dim lstrRevHex As String = ReverseString(lStrHex.Trim())

        Dim LLngRetValue As Long
        For temp As Integer = 0 To lstrRevHex.Length - 1
            LLngRetValue += numbers(lstrRevHex(temp)) * Math.Pow(16, temp)
        Next
        hexa2dec = LLngRetValue
    End Function

    Public Function dec2Hex(ByVal lStrDec As Long) As String
        dec2Hex = ""
        Dim LLngRetValue As String
        LLngRetValue = Convert.ToString(lStrDec, 16).ToUpper
        If LLngRetValue.Length = 1 Then
            LLngRetValue = "000" & LLngRetValue
        End If
        If LLngRetValue.Length = 2 Then
            LLngRetValue = "00" & LLngRetValue
        End If
        If LLngRetValue.Length = 3 Then
            LLngRetValue = "0" & LLngRetValue
        End If

        dec2Hex = LLngRetValue.ToUpper()

    End Function
    Public Function dec2Hex2(ByVal lStrDec As Long) As String
        dec2Hex2 = ""
        Dim LLngRetValue As String
        LLngRetValue = Convert.ToString(lStrDec, 16).ToUpper
        If LLngRetValue.Length = 1 Then
            LLngRetValue = "00000" & LLngRetValue
        End If
        If LLngRetValue.Length = 2 Then
            LLngRetValue = "0000" & LLngRetValue
        End If
        If LLngRetValue.Length = 3 Then
            LLngRetValue = "000" & LLngRetValue
        End If
        If LLngRetValue.Length = 4 Then
            LLngRetValue = "00" & LLngRetValue
        End If
        If LLngRetValue.Length = 5 Then
            LLngRetValue = "0" & LLngRetValue
        End If
        dec2Hex2 = LLngRetValue.ToUpper()

    End Function
    Public Function dec2Hex1(ByVal lStrDec As Long) As String
        dec2Hex1 = ""
        Dim LLngRetValue As String
        LLngRetValue = Convert.ToString(lStrDec, 16).ToUpper
        If LLngRetValue.Length = 16 Then
            LLngRetValue = (LLngRetValue.Substring(8, 8))

            dec2Hex1 = LLngRetValue.ToUpper()
        Else
            If LLngRetValue.Length = 1 Then
                LLngRetValue = "0000000" & LLngRetValue
            End If
            If LLngRetValue.Length = 2 Then
                LLngRetValue = "000000" & LLngRetValue
            End If
            If LLngRetValue.Length = 3 Then
                LLngRetValue = "00000" & LLngRetValue
            End If
            If LLngRetValue.Length = 4 Then
                LLngRetValue = "0000" & LLngRetValue
            End If
            If LLngRetValue.Length = 5 Then
                LLngRetValue = "000" & LLngRetValue
            End If
            If LLngRetValue.Length = 6 Then
                LLngRetValue = "00" & LLngRetValue
            End If
            If LLngRetValue.Length = 7 Then
                LLngRetValue = "0" & LLngRetValue
            End If

            dec2Hex1 = LLngRetValue.ToUpper()

        End If

    End Function

    Public Function SingleToHex(ByVal Tmp As Single) As String
        Dim arr = BitConverter.GetBytes(Tmp)
        Array.Reverse(arr)
        Return BitConverter.ToString(arr).Replace("-", "")
    End Function

    'Public Function StrToHex(ByVal Data As String) As String
    '    Dim sVal As String
    '    Dim sHex As String = ""
    '    While Data.Length > 0
    '        sVal = Conversion.Hex(Strings.Asc(Data.Substring(0, 1).ToString()))
    '        Data = Data.Substring(1)
    '        If sVal.Length < 2 Then
    '            sHex = sHex & "0" & sVal
    '        Else
    '            sHex = sHex & sVal
    '        End If
    '    End While
    '    Return sHex
    'End Function

    Public Function HexToStr(ByVal Data As String) As String
        Dim com As String = ""
        Dim x As Integer = 0
        For x = 0 To Data.Length - 1 Step 2
            com &= ChrW(CInt("&H" & Data.Substring(x, 2)))
        Next
        Return com
    End Function

    Public Function Hex2Bin(ByVal HexNumber As String) As String
        Dim BinaryNumber As String = ""
        'Dim Number As Integer = CInt("&H" & HexNumber)
        'Do While Number > 0
        '    BinaryNumber = (Number Mod 2).ToString & BinaryNumber
        '    Number = Number \ 2
        'Loop
        'BinaryNumber = BinaryNumber.ToString().PadLeft(HexNumber.Length * 4, "0")

        BinaryNumber = Convert.ToString(CInt("&H" & HexNumber), 2).PadLeft(HexNumber.Length * 4, "0")
        Return BinaryNumber
    End Function

    Public Function BigEndianHexToSingle(s As String) As Single
        Dim bytes As New List(Of Byte)
        For i As Integer = s.Length - 2 To 0 Step -2
            bytes.Add(Convert.ToByte(s.Substring(i, 2), 16))
        Next
        Return BitConverter.ToSingle(bytes.ToArray, 0)
    End Function
#End Region
#Region "log"
    Public Sub openLog()
        Try
            If File.Exists("iotPIPECLEDINGlog.txt") = False Then
                fs1 = File.CreateText("iotPIPECLEDINGlog.txt")
                fs1.Close()
                fs1 = Nothing
            End If
            fs1 = File.AppendText("iotPIPECLEDINGlog.txt")

        Catch ex As Exception
            MessageBox.Show("Error during Opening log file, Error : " + ex.Message.ToString())
        End Try
    End Sub
    Public Sub closeLog()
        Try
            fs1.Close()
            fs1 = Nothing
        Catch ex As Exception
            MessageBox.Show("Error during closing log file, Error : " + ex.Message.ToString())
        End Try
    End Sub
    Public Sub writeLog(ByVal byteSTR As String)
        'Try
        '    fs1.Write(Format(Now(), "yyyyMMddHHmmss") & ":" & byteSTR & vbCrLf)
        'Catch ex As Exception
        '    ''Log(ex.ToString)
        'End Try

        Dim strFile As String = "log/iotPIPECLEDINGLog_" & DateTime.Today.ToString("dd-MMM-yyyy") & ".txt"
        Dim sw As StreamWriter

        Try
            If (Not File.Exists(strFile)) Then
                sw = File.CreateText(strFile)
                sw.WriteLine("Start Error Log for today")
            Else
                sw = File.AppendText(strFile)
            End If
            sw.WriteLine(Format(Now(), "yyyy-MM-dd HH:mm:ss.ffff") & ":" & byteSTR)
            sw.Close()
        Catch ex As IOException
            MessageBox.Show("Error writing to log file, Error : " + ex.Message.ToString())
        End Try
    End Sub
#End Region

End Module
