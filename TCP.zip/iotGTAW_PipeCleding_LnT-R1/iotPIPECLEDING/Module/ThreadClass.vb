'' <summary>
'' Delegate for the call back function
'' </summary>
''<param name="current">status message</param>
''' <remarks>Declare method with signature 'Sub [AnyMethodName](status as String)'</remarks>
Public Delegate Sub CallBackDelegate(ByVal p1 As String, ByVal p2 As String, ByVal p3 As String, ByVal p4 As String, ByVal p5 As String, ByVal p6 As String, ByVal p7 As String, ByVal p8 As String, ByVal p9 As String, ByVal auxinstr As String, ByVal trsinstr As String, ByVal driftinstr As String, ByVal plcinstr As String)

''' <summary>
''' The parameterless Thread function delegate
''' </summary>
''' <remarks></remarks>
Public Delegate Sub ThreadFunctionDelegate()

''' <summary>
''' Class to process any function in a thread
''' </summary>
''' <remarks>
''' This would be typically a function that connects to a Remote and updates a progress back to Form
''' or a function that monitors the disk for any changes in a database
''' or a hardware interupt monitoring
''' ...
''' </remarks>
Public Class CallBackThread
    Implements IDisposable

    Private m_BaseControl As Control                    'The Form/Control that implements the call back function
    Private m_ThreadFunction As ThreadFunctionDelegate  'The pointer to the function that implements the thread logic
    Private m_CallBackFunction As CallBackDelegate      'The pointer to the call back function

    Private m_Thread As Threading.Thread                'internal thread object
    Private m_disposedValue As Boolean = False          'internal falg to detect redundant calls
    Private m_startedValue As Boolean = False           'internal falg to detect redundant calls

    ''' <summary>
    ''' Instanciates the Call back thread
    ''' </summary>
    ''' <param name="caller">The Form/Control that implements the call back function</param>
    ''' <param name="threadMethod">The pointer to the function that implements the thread logic(use AddressOf() to assign)</param>
    ''' <param name="callbackFunction">The pointer to the call back function(use AddressOf() to assign)</param>
    ''' <remarks>Call 'Start' to start thread and use UpdateUI to send status messages to UI</remarks>
    Public Sub New(ByRef caller As Control, _
                    ByRef threadMethod As ThreadFunctionDelegate, _
                    ByRef callbackFunction As CallBackDelegate)
        m_BaseControl = caller
        m_ThreadFunction = threadMethod
        m_CallBackFunction = callbackFunction
        m_Thread = New Threading.Thread(AddressOf ThreadFunction)
    End Sub

    ''' <summary>
    ''' Starts the internal thread
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Start()
        If Not m_startedValue Then
            m_Thread.Start()
            m_startedValue = True
        Else
            Throw New Exception("Thread already started")
        End If
    End Sub

    Private Sub ThreadFunction()
        m_ThreadFunction.Invoke()
        m_startedValue = False
    End Sub

    '' <summary>
    '' Sends the status to the Form/Control that implements the Call back method.
    '' </summary>
    '' <param name="msg">the message to send</param>
    ''' <remarks></remarks>
    Public Sub UpdateUI(ByVal msg1 As String, ByVal msg2 As String, ByVal msg3 As String, ByVal msg4 As String, ByVal msg5 As String, ByVal msg6 As String, ByVal msg7 As String, ByVal msg8 As String, ByVal msg9 As String, ByVal msg10 As String, ByVal msg11 As String, ByVal msg12 As String, ByVal msg13 As String)
        Try
            If m_BaseControl IsNot Nothing AndAlso m_CallBackFunction IsNot Nothing Then
                m_BaseControl.Invoke(m_CallBackFunction, New Object() {msg1, msg2, msg3, msg4, msg5, msg6, msg7, msg8, msg9, msg10, msg11, msg12, msg13})
            End If
        Catch ex As Exception
            MessageBox.Show("Error in UpdateUI method, Exception : " + ex.Message.ToString())
        End Try
    End Sub

    ' IDisposable
    Protected Overridable Sub Dispose(ByVal disposing As Boolean)
        If Not Me.m_disposedValue Then
            If disposing Then
                ' TODO: free unmanaged resources when explicitly called
                If m_Thread.ThreadState <> Threading.ThreadState.Stopped Then
                    m_Thread.Abort()
                End If
            End If

            m_Thread = Nothing
            m_BaseControl = Nothing
            m_CallBackFunction = Nothing

        End If
        Me.m_disposedValue = True
    End Sub

#Region " IDisposable Support "
    ' This code added by Visual Basic to correctly implement the disposable pattern.
    Public Sub Dispose() Implements IDisposable.Dispose
        ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub
#End Region

End Class
