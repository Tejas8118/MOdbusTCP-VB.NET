Imports System.Data
Imports System.Data.OleDb
Imports System.Configuration.ConfigurationManager
Public Class dbClass : Implements IDisposable

    'Dim dbpath As String = Configuration.ConfigurationManager.AppSettings("DBSrc").ToString()
    'Dim DBPath As String = My.Application.Info.DirectoryPath & "\iotessc.Accdb"
    Dim DBPath As String = Configuration.ConfigurationManager.AppSettings("accdbPath").ToString() '& "\iotPIPECLEDING.Accdb"
    Public conAccess As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & DBPath & "" '' providerName='System.Data.OleDb'
    'Public conAccess As String = Configuration.ConfigurationManager.ConnectionStrings("accesscon").ToString()
    Public con As OleDbConnection
    Public pcoll As OleDbParameterCollection
    Public prodTitle As String = ""

    'Function dbConnect() As Boolean
    '    Try
    '        con = New OleDbConnection(conAccess)
    '        If con.State = ConnectionState.Open Then
    '            con.Close()
    '        End If
    '        con.Open()
    '        Return True
    '    Catch ex As OleDbException
    '        MessageBox.Show(ex.Message, prodTitle)
    '        Return False
    '    End Try
    'End Function

    'Sub dbDisConnect()
    '    Try
    '        con.Close()
    '    Catch ex As OleDbException
    '        MessageBox.Show(ex.Message, prodTitle)
    '        ''Console.WriteLine(ex.Message)
    '    End Try
    'End Sub

    Function getSchema() As DataTable
        'dbConnect()
        Dim dt As New DataTable

        Using con = New OleDbConnection(conAccess)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()

            dt = con.GetSchema("Tables")

            con.Close()
        End Using

        Return dt
    End Function

    'Function ExecuteDataSet(ByVal sql As String, ByVal Type As CommandType) As DataSet
    '    dbConnect()
    '    Dim ds As New DataSet
    '    Dim dt As New DataTable
    '    Dim adp As New OleDbDataAdapter
    '    Dim cmd As New OleDbCommand

    '    Dim tran As OleDbTransaction = con.BeginTransaction
    '    Try
    '        'Dim da As OleDb.OleDbDataAdapter = New OleDb.OleDbDataAdapter(sql, con)
    '        'da.Fill(ds)

    '        With cmd
    '            .Connection = con
    '            .CommandType = Type
    '            .CommandText = sql
    '            .Transaction = tran
    '            ''If .CommandType = CommandType.StoredProcedure Then
    '            If Not (pcoll Is Nothing) Then
    '                .Parameters.Clear()
    '                For Each sqlParm As OleDbParameter In pcoll
    '                    .Parameters.Add(sqlParm)
    '                Next
    '            End If
    '            ''End If
    '        End With
    '        adp = New OleDbDataAdapter(cmd)
    '        adp.Fill(ds)
    '        tran.Commit()
    '    Catch ex As OleDbException
    '        MessageBox.Show(ex.Message, ProdTitle)
    '        ''Console.WriteLine(ex.Message)
    '        tran.Rollback()
    '    End Try
    '    dbDisConnect()

    '    Return ds
    'End Function

    Function ExecuteDataTable(ByVal sql As String, ByVal Type As CommandType) As DataTable
        'dbConnect()
        Dim ds As New DataSet
        Dim dt As New DataTable
        'Dim cmd As New MySqlCommand
        'Dim adp As MySqlDataAdapter
        'Dim tran As MySqlTransaction = con.BeginTransaction
        'Try
        '    With cmd
        '        .Connection = con
        '        .CommandType = Type
        '        .CommandText = sql
        '        .Transaction = tran
        '        ' If .CommandType = CommandType.StoredProcedure Then
        '        If Not (pColl Is Nothing) Then
        '            .Parameters.Clear()
        '            For Each sqlParm As MySqlParameter In pColl
        '                .Parameters.Add(sqlParm)
        '            Next
        '        End If
        '        'End If
        '    End With
        '    adp = New MySqlDataAdapter(cmd)
        '    adp.Fill(ds)
        'Dim tran As OleDbTransaction = con.BeginTransaction
        Try
            'Dim da As OleDb.OleDbDataAdapter = New OleDb.OleDbDataAdapter(sql, con)
            'da.Fill(ds)
            'If ds.Tables.Count > 0 Then
            '    dt = ds.Tables(0)
            'Else
            '    dt = Nothing
            'End If
            'tran.Commit()
            Using con = New OleDbConnection(conAccess)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()

                Using da As New OleDbDataAdapter(sql, con)
                    da.Fill(ds)
                    If ds.Tables.Count > 0 Then
                        dt = ds.Tables(0)
                    Else
                        dt = Nothing
                    End If
                End Using

                con.Close()
            End Using

        Catch ex As OleDbException
            MessageBox.Show("Error in ExecuteDataTable method of ACCDB module, Error : " + ex.Message, prodTitle)
            ''Console.WriteLine(ex.Message)
            'tran.Rollback()
        End Try
        'dbDisConnect()

        Return dt

    End Function

    'Function ExecuteDataReader(ByVal sql As String, ByVal Type As CommandType) As OleDbDataReader
    '    'dbConnect()
    '    'Dim ds As New DataSet
    '    'Dim cmd As New OleDbCommand
    '    'Dim tran As OleDbTransaction = con.BeginTransaction
    '    Dim dr As OleDbDataReader
    '    Try
    '        'cmd.Connection = con
    '        'cmd.CommandType = Type
    '        'cmd.CommandText = sql
    '        'cmd.Transaction = tran
    '        'dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
    '        'tran.Commit()

    '        Using con = New OleDbConnection(conAccess)
    '            If con.State = ConnectionState.Open Then
    '                con.Close()
    '            End If
    '            con.Open()

    '            Using tran As OleDbTransaction = con.BeginTransaction()
    '                Using cmd = New OleDbCommand()
    '                    cmd.Connection = con
    '                    cmd.CommandType = Type
    '                    cmd.CommandText = sql
    '                    cmd.Transaction = tran
    '                    dr = cmd.ExecuteReader()
    '                    tran.Commit()
    '                End Using
    '            End Using
    '            'Return dr
    '            'con.Close()
    '        End Using

    '        Return dr

    '    Catch ex As OleDbException
    '        MessageBox.Show(ex.Message, prodTitle)
    '        ''Console.WriteLine(ex.Message)
    '        'tran.Rollback()
    '    End Try
    '    'dbDisConnect()

    '    Return Nothing

    'End Function

    'Function ExecuteInsert(ByVal sql As String, ByVal Type As CommandType) As Integer
    '    dbConnect()

    '    Dim bool As Boolean = False
    '    Dim id As Integer = 0
    '    Dim ds As New DataSet()
    '    Dim cmd As New OleDbCommand
    '    Dim tran As OleDbTransaction = con.BeginTransaction
    '    Try
    '        With cmd
    '            .Connection = con
    '            .CommandType = Type
    '            .CommandText = sql
    '            .Transaction = tran
    '            'If .CommandType = CommandType.StoredProcedure Then
    '            If Not (pcoll Is Nothing) Then
    '                .Parameters.Clear()
    '                For Each sqlParm As OleDbParameter In pcoll
    '                    .Parameters.Add(sqlParm)
    '                Next
    '            End If
    '            'End If
    '            bool = .ExecuteNonQuery
    '            If bool = True Then
    '                .CommandText = "Select @@Identity"
    '                id = .ExecuteScalar
    '            End If
    '            tran.Commit()
    '        End With
    '    Catch ex As OleDbException
    '        MessageBox.Show(ex.Message, prodTitle)
    '        ''Console.WriteLine(ex.Message)
    '        tran.Rollback()
    '    End Try
    '    dbDisConnect()

    '    Return id

    'End Function
    Function ExecuteNonQuery(ByVal sql As String, ByVal Type As CommandType) As Boolean
        'dbConnect()

        Dim bool As Boolean = False
        'Dim ds As New DataSet
        'Dim cmd As New OleDbCommand
        'Dim tran As OleDbTransaction = con.BeginTransaction

        Try
            'With cmd
            '    .Connection = con
            '    .CommandType = Type
            '    .CommandText = sql
            '    .Transaction = tran
            '    'If .CommandType = CommandType.StoredProcedure Then
            '    If Not (pcoll Is Nothing) Then
            '        .Parameters.Clear()
            '        For Each sqlParm As OleDbParameter In pcoll
            '            .Parameters.Add(sqlParm)
            '        Next
            '    End If
            '    'End If
            '    bool = .ExecuteNonQuery
            '    bool = True
            '    tran.Commit()
            'End With

            Using con = New OleDbConnection(conAccess)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                Using tran As OleDbTransaction = con.BeginTransaction()

                    Using cmd = New OleDbCommand()
                        cmd.Connection = con
                        cmd.CommandType = Type
                        cmd.CommandText = sql
                        cmd.Transaction = tran

                        If Not (pcoll Is Nothing) Then
                            cmd.Parameters.Clear()
                            For Each sqlParm As OleDbParameter In pcoll
                                cmd.Parameters.Add(sqlParm)
                            Next
                        End If
                        'End If
                        bool = cmd.ExecuteNonQuery()
                        bool = True
                        tran.Commit()
                    End Using
                End Using

                con.Close()
            End Using


        Catch ex As OleDbException
            MessageBox.Show("Error in ExecuteNonQuery method of ACCDB module, Error : " + ex.Message, prodTitle)
            ''Console.WriteLine(ex.Message)
            'tran.Rollback()
        End Try

        'dbDisConnect()

        Return bool

    End Function

    'Function addCommandParameter(ByVal Name As Object, ByVal Value As Object, ByVal MyDType As OleDbType, ByVal pDirection As System.Data.ParameterDirection) As OleDbParameter

    '    Try
    '        Dim p As OleDbParameter
    '        p = New OleDbParameter(CStr(Name), MyDType)
    '        p.Direction = pDirection
    '        p.Value = Value
    '        pcoll.Add(p)
    '    Catch ex As OleDbException
    '        MessageBox.Show(ex.Message, ProdTitle)
    '        ''Console.WriteLine(ex.Message)
    '    End Try
    '    Return Nothing
    'End Function

    Function ExecuteScaller(ByVal sql As String, ByVal Type As CommandType) As Object
        'Dim cmd As New OleDbCommand
        Dim strVal As Object = Nothing
        'dbConnect()
        'Dim tran As OleDbTransaction = con.BeginTransaction
        Try
            'With cmd
            '    .Connection = con
            '    .CommandType = Type
            '    .CommandText = sql
            '    .Transaction = tran
            '    'If .CommandType = CommandType.StoredProcedure Then
            '    If Not (pcoll Is Nothing) Then
            '        .Parameters.Clear()
            '        For Each sqlParm As OleDbParameter In pcoll
            '            .Parameters.Add(sqlParm)
            '        Next
            '    End If
            '    'End If
            'End With
            'strVal = cmd.ExecuteScalar()
            'Return strVal
            'tran.Commit()

            Using con = New OleDbConnection(conAccess)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                Using tran As OleDbTransaction = con.BeginTransaction()

                    Using cmd = New OleDbCommand()
                        cmd.Connection = con
                        cmd.CommandType = Type
                        cmd.CommandText = sql
                        cmd.Transaction = tran

                        If Not (pcoll Is Nothing) Then
                            cmd.Parameters.Clear()
                            For Each sqlParm As OleDbParameter In pcoll
                                cmd.Parameters.Add(sqlParm)
                            Next
                        End If
                        'End If
                        strVal = cmd.ExecuteScalar()
                        Return strVal
                        tran.Commit()
                    End Using
                End Using

                con.Close()
            End Using

        Catch ex As OleDbException
            MessageBox.Show("Error in ExecuteScaller method of ACCDB module, Error : " + ex.Message, prodTitle)
            ''Console.WriteLine(ex.Message)

            'tran.Rollback()
        End Try
        'dbDisConnect()

        Return Nothing
    End Function

#Region "IDisposable Support"
    Private disposedValue As Boolean ' To detect redundant calls

    ' IDisposable
    Protected Overridable Sub Dispose(disposing As Boolean)
        If Not disposedValue Then
            If disposing Then
                ' TODO: dispose managed state (managed objects).
            End If

            ' TODO: free unmanaged resources (unmanaged objects) and override Finalize() below.
            ' TODO: set large fields to null.
        End If
        disposedValue = True
    End Sub

    ' TODO: override Finalize() only if Dispose(disposing As Boolean) above has code to free unmanaged resources.
    'Protected Overrides Sub Finalize()
    '    ' Do not change this code.  Put cleanup code in Dispose(disposing As Boolean) above.
    '    Dispose(False)
    '    MyBase.Finalize()
    'End Sub

    ' This code added by Visual Basic to correctly implement the disposable pattern.
    Public Sub Dispose() Implements IDisposable.Dispose
        ' Do not change this code.  Put cleanup code in Dispose(disposing As Boolean) above.
        Dispose(True)
        ' TODO: uncomment the following line if Finalize() is overridden above.
        ' GC.SuppressFinalize(Me)
    End Sub
#End Region
End Class
