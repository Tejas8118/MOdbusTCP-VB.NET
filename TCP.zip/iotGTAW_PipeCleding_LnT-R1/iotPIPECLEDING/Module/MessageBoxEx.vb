Option Strict On

Public Class MessageBoxEx

    Public Shared Function Show(ByVal pMessage As String, _
                                ByVal pTitle As String, _
                                ByVal pButtons As MessageBoxButtons, _
                                ByVal pIcon As MessageBoxIcon, _
                                ByVal pDefault As MessageBoxDefaultButton, _
                                ByVal pLanguage As fMessageBox.enuLanguage, _
                                ByVal pTimeOut As Integer, _
                                ByVal pDontShowCode As String) As DialogResult
        Static hstCode As New Hashtable

        Dim blnShow As Boolean
        'Determine if we must show the MessageBox
        If pDontShowCode.Trim.Length = 0 Then
            blnShow = True
        Else
            'Check if the dialog has to be displayed
            If hstCode.Contains(pDontShowCode) Then
                blnShow = False
            Else
                blnShow = True
            End If
        End If

        If blnShow Then
            Dim p As New fMessageBox
            p.Message = pMessage
            p.lblTitle.Text = pTitle
            p.Language = pLanguage 'Must be set before Buttons
            p.Buttons = pButtons
            p.Icon = pIcon
            p.DefaultButton = pDefault
            p.ShowCheckBox = (pDontShowCode.Trim.Length > 0)
            p.TimeOut = pTimeOut

            Dim dlgResult As DialogResult = p.ShowDialog
            If p.chkDontShowAgain.Checked Then
                'Save the code not to show the dialog again
                hstCode.Add(pDontShowCode, pDontShowCode)
            End If
            Return dlgResult
        Else
            Return DialogResult.None
        End If
    End Function

End Class
