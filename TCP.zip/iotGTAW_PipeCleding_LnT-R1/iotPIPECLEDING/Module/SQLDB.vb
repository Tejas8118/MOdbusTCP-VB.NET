﻿Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Net.Mail
Imports iotPIPECLEDING.TokenGeneration
Imports iotPIPECLEDING.IOTWebService
Imports System.Net.NetworkInformation
Imports System.Net

Public Class SQLDB : Implements IDisposable

    Private ERPLNConn As String = ConfigurationManager.ConnectionStrings("ERPLNDSN").ToString()
    Private IOTConn As String = ConfigurationManager.ConnectionStrings("IOTDSN").ToString()
    Private IEMQSConn As String = ConfigurationManager.ConnectionStrings("IEMQSDSN").ToString()
    Private cmp As String = ConfigurationManager.AppSettings("cmp").ToString()
    Private timeout As String = ConfigurationManager.AppSettings("timeout").ToString()

    Public Function checkERPLNDBConnectivity() As Boolean
        Try
            If checkNetworkConnectivity() Then
                Dim ERPLNconnCheck As New SqlConnection(ERPLNConn)
                If ERPLNconnCheck.State = ConnectionState.Open Then
                    ERPLNconnCheck.Close()
                End If
                ERPLNconnCheck.Open()
                ERPLNconnCheck.Close()
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function checkIOTDBConnectivity() As Boolean
        Try
            If checkNetworkConnectivity() Then
                Dim IOTConnCheck As New SqlConnection(IOTConn)
                If IOTConnCheck.State = ConnectionState.Open Then
                    IOTConnCheck.Close()
                End If
                IOTConnCheck.Open()
                IOTConnCheck.Close()
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function checkNetworkConnectivity() As Boolean
        Try
            Dim GetIPv4Address As String = String.Empty
            Dim strHostName As String = System.Net.Dns.GetHostName()
            Dim iphe As System.Net.IPHostEntry = System.Net.Dns.GetHostEntry(strHostName)

            For Each ipheal As System.Net.IPAddress In iphe.AddressList
                If ipheal.AddressFamily = System.Net.Sockets.AddressFamily.InterNetwork Then
                    GetIPv4Address = ipheal.ToString()
                    If GetIPv4Address.Trim = gMachineIP.Trim Then
                        Return True
                    End If
                End If
            Next
        Catch ex As Exception
            Return False
        End Try
        Return False
    End Function


    Public Function getEmployeeDataFromCSN(ByVal RFIDCardNumber As String, ByRef ExceptionMessage As String) As DataTable
        Dim sql As String = ""
        Dim dt As DataTable = New DataTable()
        dt.TableName = "EmployeeDetail"

        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    'sql = "SELECT c.t_psno,c.t_name,b.t_stmp FROM tltsas999@cmp a with (nolock) JOIN tltwms001@cmp b with (nolock) ON a.t_user=b.t_psno JOIN tltcom001@cmp c with (nolock) ON a.t_user=c.t_psno WHERE a.t_csnn='" & RFIDCardNumber.Trim() & "' AND b.t_eval='1'"
                    sql = " Select distinct x.t_psno, x.t_name, x.t_stmp 
                            from 
                            (
                            -- INTERNAL WELDER WITH ERPLN WML
                            SELECT c.t_psno,c.t_name,t_stmp collate SQL_Latin1_General_CP1_CI_AS as t_stmp 
                            FROM tltsas999@cmp a with (nolock) 
                            JOIN tltwms001@cmp b with (nolock) ON a.t_user = b.t_psno
                            JOIN tltcom001@cmp c with (nolock) ON a.t_user = c.t_psno 
                            WHERE a.t_csnn='" & RFIDCardNumber.Trim() & "' AND b.t_eval='1'

                            union ALL

                            -- INTERNAL WELDER WITH IEMQS WML
                            SELECT c.t_psno,c.t_name,b.Stamp collate SQL_Latin1_General_CP1_CI_AS as t_stmp 
                            FROM tltsas999@cmp a with (nolock) 
                            JOIN [PHZPDSQL2K16\PHZPDSQL2K16].[IEMQS_PROD].dbo.QMS003 b with (nolock) ON a.t_user = b.WelderPSNo collate SQL_Latin1_General_CP1_CI_AS 
                            JOIN tltcom001@cmp c with (nolock) ON a.t_user = c.t_psno 
                            WHERE a.t_csnn='" & RFIDCardNumber.Trim() & "'  AND b.Evaluation='1'

                            UNION ALL

                            -- EXTERNAL WELDER WITH IEMQS WML
                            SELECT b.WelderPSNo collate SQL_Latin1_General_CP1_CI_AS as t_psno, b.Name + ' ' + b.Surname collate SQL_Latin1_General_CP1_CI_AS as t_name,b.Stamp collate SQL_Latin1_General_CP1_CI_AS as t_stmp 
                            FROM tltsas999@cmp a with (nolock) 
                            JOIN [PHZPDSQL2K16\PHZPDSQL2K16].[IEMQS_PROD].dbo.QMS004 b with (nolock) ON a.t_user = b.WelderPSNo collate SQL_Latin1_General_CP1_CI_AS 
                            WHERE a.t_csnn='" & RFIDCardNumber.Trim() & "' AND b.Evaluation='1'
                            ) x"
                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    dt.Load(cmd.ExecuteReader())
                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If

        Return dt
    End Function

    Public Function loadWelderDetail(ByRef ExceptionMessage As String) As DataTable
        Dim sql As String = ""
        Dim dt As DataTable = New DataTable()
        dt.TableName = "EmployeeDetail"

        Using con As SqlConnection = New SqlConnection(ERPLNConn)
            Try
                con.Open()
                'sql = "SELECT c.t_psno,c.t_name,b.t_stmp,a.t_csnn FROM tltsas999@cmp a with (nolock) JOIN tltwms001@cmp b with (nolock) ON a.t_user=b.t_psno " & " JOIN tltcom001@cmp c with (nolock) ON a.t_user=c.t_psno WHERE b.t_eval='1'"
                sql = " Select distinct x.t_psno, x.t_name, x.t_stmp, x.t_csnn 
                        from 
                        (
                        -- INTERNAL WELDER WITH ERPLN WML
                        SELECT c.t_psno,c.t_name,t_stmp collate SQL_Latin1_General_CP1_CI_AS as t_stmp,a.t_csnn 
                        FROM tltsas999@cmp a with (nolock) 
                        JOIN tltwms001@cmp b with (nolock) ON a.t_user = b.t_psno
                        JOIN tltcom001@cmp c with (nolock) ON a.t_user = c.t_psno 
                        WHERE b.t_eval='1'

                        union ALL

                        -- INTERNAL WELDER WITH IEMQS WML
                        SELECT c.t_psno,c.t_name,b.Stamp collate SQL_Latin1_General_CP1_CI_AS as t_stmp,a.t_csnn
                        FROM tltsas999@cmp a with (nolock) 
                        JOIN [PHZPDSQL2K16\PHZPDSQL2K16].[IEMQS_PROD].dbo.QMS003 b with (nolock) ON a.t_user = b.WelderPSNo collate SQL_Latin1_General_CP1_CI_AS 
                        JOIN tltcom001@cmp c with (nolock) ON a.t_user = c.t_psno 
                        WHERE b.Evaluation='1'

                        UNION ALL

                        -- EXTERNAL WELDER WITH IEMQS WML
                        SELECT b.WelderPSNo collate SQL_Latin1_General_CP1_CI_AS as t_psno, b.Name + ' ' + b.Surname collate SQL_Latin1_General_CP1_CI_AS as t_name,b.Stamp collate SQL_Latin1_General_CP1_CI_AS as t_stmp,a.t_csnn 
                        FROM tltsas999@cmp a with (nolock) 
                        JOIN [PHZPDSQL2K16\PHZPDSQL2K16].[IEMQS_PROD].dbo.QMS004 b with (nolock) ON a.t_user = b.WelderPSNo collate SQL_Latin1_General_CP1_CI_AS 
                        WHERE b.Evaluation='1'
                        ) x"
                sql = sql.Replace("@cmp", cmp)
                Dim cmd As SqlCommand = New SqlCommand(sql, con)
                dt.Load(cmd.ExecuteReader())
                cmd.Dispose()
                con.Close()
            Catch ex As Exception
                ExceptionMessage = ex.Message.ToString()
                'MessageBox.Show(ex.Message.ToString())
            End Try
        End Using

        Return dt
    End Function


    'Public Function getEmployeeNameFromPS(ByVal employeePSNO As String, ByRef ExceptionMessage As String) As DataTable
    '    Dim sql As String = ""
    '    Dim dt As DataTable = New DataTable()
    '    dt.TableName = "EmployeeDetail"

    '    Using con As SqlConnection = New SqlConnection(ERPLNConn)
    '        Try
    '            con.Open()
    '            sql = "SELECT t_psno,t_name FROM tltcom001@cmp with (nolock) WHERE t_psno='" & employeePSNO.Trim() & "'"
    '            sql = sql.Replace("@cmp", cmp)
    '            Dim cmd As SqlCommand = New SqlCommand(sql, con)
    '            dt.Load(cmd.ExecuteReader())
    '            cmd.Dispose()
    '            con.Close()
    '        Catch ex As Exception
    '            ExceptionMessage = ex.Message.ToString()
    '            'MessageBox.Show(ex.Message.ToString())
    '        End Try
    '    End Using

    '    Return dt
    'End Function


    Public Function getAllQMSProject(ByRef ExceptionMessage As String) As DataTable
        Dim sql As String = ""
        Dim dt As DataTable = New DataTable()
        dt.TableName = "QMSProjectDetail"
        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    sql = "select t_qprj, t_desc, t_qprj + ' # ' + t_desc as DisplayMember from ttclnt001@cmp with (nolock) WHERE t_qprj <> ''"
                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    dt.Load(cmd.ExecuteReader())

                    'Load IEMQS QMS Project Detail
                    Using con1 As SqlConnection = New SqlConnection(IEMQSConn)
                        Try
                            con1.Open()
                            sql = "select distinct QualityProject t_qprj, '' t_desc, QualityProject + ' # ' + '' as DisplayMember from SWP010"
                            Dim cmd1 As SqlCommand = New SqlCommand(sql, con1)
                            dt.Load(cmd1.ExecuteReader())

                            cmd1.Dispose()
                            con1.Close()
                        Catch ex As Exception
                            ExceptionMessage = ex.Message.ToString()
                        End Try
                    End Using

                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function


    Public Function getSeamFromProject(ByVal Project As String, ByVal processName As String, ByRef ExceptionMessage As String) As DataTable
        Dim sql As String = ""
        Dim dt As DataTable = New DataTable()
        dt.TableName = "SeamDetail"
        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()

                    Dim ProcessValue As Integer = getProcessValue(processName)

                    If ProcessValue = 1 Then
                        sql = "select distinct t_seam from tltwps024@cmp with (nolock) where t_cprj = '" & Project.Trim().ToString() & "' and t_proc = '" & ProcessValue.ToString() & "'"
                    End If

                    If sql <> "" Then
                        sql = sql.Replace("@cmp", cmp)
                        Dim cmd As SqlCommand = New SqlCommand(sql, con)
                        dt.Load(cmd.ExecuteReader())

                        'Load IEMQS Seam Detail
                        Using con1 As SqlConnection = New SqlConnection(IEMQSConn)
                            Try
                                con1.Open()
                                sql = "select distinct SeamNo t_seam from SWP010 where QualityProject = '" & Project.Trim().ToString() & "'"
                                Dim cmd1 As SqlCommand = New SqlCommand(sql, con1)
                                dt.Load(cmd1.ExecuteReader())

                                cmd1.Dispose()
                                con1.Close()
                            Catch ex As Exception
                                ExceptionMessage = ex.Message.ToString()
                            End Try
                        End Using

                        cmd.Dispose()
                    End If

                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function


    'Public Function getLNProjectFromQMSProject(ByVal Project As String, ByRef ExceptionMessage As String) As DataTable
    '    Dim sql As String = ""
    '    Dim dt As DataTable = New DataTable()
    '    dt.TableName = "ERPLNProject"

    '    Using con As SqlConnection = New SqlConnection(ERPLNConn)
    '        Try
    '            con.Open()
    '            sql = "select t_qprj, t_cprj, t_desc from ttclnt001@cmp with (nolock) where t_qprj = '" & Project.Trim() & "'"
    '            sql = sql.Replace("@cmp", cmp)
    '            Dim cmd As SqlCommand = New SqlCommand(sql, con)
    '            dt.Load(cmd.ExecuteReader())
    '            cmd.Dispose()
    '            con.Close()
    '        Catch ex As Exception
    '            ExceptionMessage = ex.Message.ToString()
    '            'MessageBox.Show(ex.Message.ToString())
    '        End Try
    '    End Using

    '    Return dt
    'End Function


    Public Function getBatchNo(ByVal Project As String, ByVal Seam As String, ByVal mode As String, ByRef ExceptionMessage As String) As DataTable
        Dim sql As String = ""
        Dim dt As DataTable = New DataTable()
        dt.TableName = "BatchDetail"
        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    If mode.Equals("1") Then
                        sql = " select top 1 t_item, t_clot from tltsas007@cmp with (nolock) where t_cprj = '" & Project & "' and t_seam = '" & Seam & "'" & " and substring(ltrim(rtrim(t_item)),3,1) <> 'F' order by t_isdt desc"
                    Else
                        sql = " select top 1 t_item, t_clot from tltsas007@cmp with (nolock) where t_cprj = '" & Project & "' and t_seam = '" & Seam & "'" & " and substring(ltrim(rtrim(t_item)),3,1) = 'F' order by t_isdt desc"
                    End If

                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    dt.Load(cmd.ExecuteReader())
                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function


    Public Function getSWPNotes(ByVal Project As String, ByRef ExceptionMessage As String) As DataTable
        Dim sql As String = ""
        Dim dt As DataTable = New DataTable()
        dt.TableName = "WPSNotesDetail"
        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    sql = "select t_note, t_desc from tltwps003@cmp with (nolock) where t_cprj = '" & Project & "'"
                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    dt.Load(cmd.ExecuteReader())
                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function


    Public Function getAllowedBatch(ByVal Project As String, ByRef ExceptionMessage As String) As DataTable
        Dim sql As String = ""
        Dim dt As DataTable = New DataTable()
        dt.TableName = "AllowedBatchDetail"
        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    sql = "select distinct a.t_item, b.t_dsca, a.t_batn, a.t_lotn from tltsas023180 a with (nolock) inner join ttcibd001180 b with (nolock) on a.t_item = b.t_item where a.t_cprj = '" & Project & "'"
                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    dt.Load(cmd.ExecuteReader())
                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function


    Public Function getWPSDetail(ByVal Project As String, ByVal Seam As String, ByRef ExceptionMessage As String) As DataTable
        Dim sql As String = ""
        Dim dt As DataTable = New DataTable()
        dt.TableName = "WPSDetail"
        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    sql = "select t_wpsn,t_wpsa,t_wpsb, t_wpsn + ' # ' + t_wpsa + ' # ' + t_wpsb as DisplayMember from ttclnt011@cmp with (nolock) where t_cprj ='" & Project & "' and t_seam='" & Seam & "'"
                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    dt.Load(cmd.ExecuteReader())

                    'Load IEMQS WPS Detail
                    Using con1 As SqlConnection = New SqlConnection(IEMQSConn)
                        Try
                            con1.Open()
                            sql = "select isnull(MainWPSNumber, '') t_wpsn, isnull(AlternateWPS1, '') t_wpsa, isnull(AlternateWPS2, '') t_wpsb, isnull(MainWPSNumber, '') + ' # ' + isnull(AlternateWPS1, '') + ' # ' + isnull(AlternateWPS2, '') as DisplayMember from SWP010 where QualityProject = '" & Project & "' and SeamNo = '" & Seam & "'"
                            Dim cmd1 As SqlCommand = New SqlCommand(sql, con1)
                            dt.Load(cmd1.ExecuteReader())

                            cmd1.Dispose()
                            con1.Close()
                        Catch ex As Exception
                            ExceptionMessage = ex.Message.ToString()
                        End Try
                    End Using

                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function

    Public Function insertAbnormalityLogDetail(ByVal entryDate As DateTime, ByVal shopName As String, ByVal stationName As String, ByVal processName As String, ByVal empPSNO As String, ByVal Project As String, ByVal Seam As String, ByVal paramType As Integer, ByVal paramValue As Double, ByVal paramMinRange As Double, ByVal paramMaxRange As Double, ByVal SQLcon As Integer, ByRef ExceptionMessage As String) As Integer
        Dim i As Integer = 0
        Dim sql As String = ""
        Dim eDate As String = ""
        Dim sdat As String = ""
        Dim shift As Integer = 0

        If IOTDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(IOTConn)
                Try
                    con.Open()
                    Dim format As String = "yyyy-MM-dd HH:mm:ss"
                    If SQLcon = 1 Then
                        eDate = DateTime.Now.ToString(format)
                    Else
                        eDate = entryDate.ToString(format)
                    End If

                    getShiftSDATValue(eDate, sdat, shift)
                    Dim ProcessValue As Integer = getProcessValue(processName)

                    If ProcessValue = 1 Then
                        sql = "insert into GTAW_ABNORMALITY_DATA(edat,shop,stan,psno,cprj,seam,type,valu,rmin,rmax,scon,sdat,shft) values(" +
                                "'" & eDate & "'," &
                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                "'" & Project & "','" & Seam & "','" & Int32.Parse(paramType.ToString()) & "'," &
                                "'" & Double.Parse(paramValue.ToString()) & "','" & Double.Parse(paramMinRange.ToString()) & "'," &
                                "'" & Double.Parse(paramMaxRange.ToString()) & "','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                "'" & sdat & "','" & Int32.Parse(shift.ToString()) & "')"
                    End If

                    If sql <> "" Then
                        Dim sc As SqlCommand = New SqlCommand(sql, con)
                        i = sc.ExecuteNonQuery()
                        sc.Dispose()
                    End If

                    con.Close()

                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return i
    End Function

    Public Function insertArchLogDetail(ByVal entryDate As DateTime, ByVal shopName As String, ByVal stationName As String, ByVal processName As String, ByVal empPSNO As String, ByVal Project As String, ByVal Seam As String, ByVal ArchOnOffFlag As Integer, ByVal SQLcon As Integer, ByRef ExceptionMessage As String) As Integer
        Dim i As Integer = 0
        Dim sql As String = ""
        Dim eDate As String = ""
        Dim sDate As String = ""
        Dim sdat As String = ""
        Dim Newsdat As String = ""
        Dim shift As Integer = 0
        Dim Newshift As Integer = 0
        Dim ArcDurationSec As Double = 0
        Dim WeldONShift As Integer = 0
        Dim WeldONDate As DateTime
        Dim ShiftStartDate As String = ""
        Dim FirstShiftStartDate As String = ""
        Dim FirstShiftEndDate As String = ""
        Dim SecondShiftStartDate As String = ""
        Dim SecondShiftEndDate As String = ""
        Dim ThirdShiftStartDate As String = ""
        Dim ThirdShiftEndDate As String = ""

        If IOTDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(IOTConn)
                Try
                    con.Open()
                    Dim format As String = "yyyy-MM-dd HH:mm:ss"
                    If SQLcon = 1 Then
                        eDate = DateTime.Now.ToString(format)
                        sDate = DateTime.Now.AddDays(-1).ToString(format)
                    Else
                        eDate = entryDate.ToString(format)
                        sDate = entryDate.AddDays(-1).ToString(format)
                    End If

                    getShiftSDATValue(eDate, sdat, shift)

                    Dim ProcessValue As Integer = getProcessValue(processName)

                    If ArchOnOffFlag = 2 Then
                        getPrevArcTime(eDate, sDate, shopName, stationName, ProcessValue, empPSNO, Project, Seam, ArcDurationSec, WeldONDate, WeldONShift, ExceptionMessage)
                        If WeldONShift > 0 Then
                            If shift <> WeldONShift Then
                                If ProcessValue = 1 Then

                                    If shift = 1 And WeldONShift = 3 Then

                                        'Log 3 Shift end and 1 shift start

                                        'OFF Transaction - Log 3 Shift End on Same Day
                                        ThirdShiftEndDate = eDate.Substring(0, 10) + " 06:59:59"
                                        getShiftSDATValue(ThirdShiftEndDate, Newsdat, Newshift)

                                        ArcDurationSec = (DateTime.Parse(ThirdShiftEndDate) - WeldONDate).TotalSeconds

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & ThirdShiftEndDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','2','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','" & Double.Parse(ArcDurationSec.ToString()) & "')"
                                        Dim sc1 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc1.ExecuteNonQuery()
                                        sc1.Dispose()

                                        'ON Transaction - Log 1 Shift Start on Same Day
                                        FirstShiftStartDate = eDate.Substring(0, 10) + " 07:00:00"
                                        getShiftSDATValue(FirstShiftStartDate, Newsdat, Newshift)

                                        ShiftStartDate = FirstShiftStartDate

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & FirstShiftStartDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','1','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','0')"
                                        Dim sc2 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc2.ExecuteNonQuery()
                                        sc2.Dispose()

                                    ElseIf shift = 1 And WeldONShift = 2 Then

                                        'Log 2 Shift end and 3 shift start

                                        'OFF Transaction - Log 2 Shift End of Weld ON Day (Previous Day)
                                        SecondShiftEndDate = WeldONDate.ToString(format).Substring(0, 10) + " 23:54:59"
                                        getShiftSDATValue(SecondShiftEndDate, Newsdat, Newshift)

                                        ArcDurationSec = (DateTime.Parse(SecondShiftEndDate) - WeldONDate).TotalSeconds

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & SecondShiftEndDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','2','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','" & Double.Parse(ArcDurationSec.ToString()) & "')"
                                        Dim sc1 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc1.ExecuteNonQuery()
                                        sc1.Dispose()

                                        'ON Transaction - Log 3 Shift Start of Weld ON Day (Previous Day)
                                        ThirdShiftStartDate = WeldONDate.ToString(format).Substring(0, 10) + " 23:55:00"
                                        getShiftSDATValue(ThirdShiftStartDate, Newsdat, Newshift)

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & ThirdShiftStartDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','1','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','0')"
                                        Dim sc2 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc2.ExecuteNonQuery()
                                        sc2.Dispose()

                                        'Log 3 Shift end and 1 shift start

                                        'OFF Transaction - Log 3 Shift End of Same Day 
                                        ThirdShiftEndDate = eDate.Substring(0, 10) + " 06:59:59"
                                        getShiftSDATValue(ThirdShiftEndDate, Newsdat, Newshift)

                                        ArcDurationSec = (DateTime.Parse(ThirdShiftEndDate) - DateTime.Parse(ThirdShiftStartDate)).TotalSeconds

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & ThirdShiftEndDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','2','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','" & Double.Parse(ArcDurationSec.ToString()) & "')"
                                        Dim sc3 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc3.ExecuteNonQuery()
                                        sc3.Dispose()

                                        'ON Transaction - Log 1 Shift Start of Same Day
                                        FirstShiftStartDate = eDate.Substring(0, 10) + " 07:00:00"
                                        getShiftSDATValue(FirstShiftStartDate, Newsdat, Newshift)

                                        ShiftStartDate = FirstShiftStartDate

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & FirstShiftStartDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','1','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','0')"
                                        Dim sc4 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc4.ExecuteNonQuery()
                                        sc4.Dispose()

                                    ElseIf shift = 2 And WeldONShift = 1 Then

                                        'Log 1 Shift end and 2 shift start

                                        'OFF Transaction - Log 1 Shift End 
                                        FirstShiftEndDate = eDate.Substring(0, 10) + " 15:24:59"
                                        getShiftSDATValue(FirstShiftEndDate, Newsdat, Newshift)

                                        ArcDurationSec = (DateTime.Parse(FirstShiftEndDate) - WeldONDate).TotalSeconds

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & FirstShiftEndDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','2','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','" & Double.Parse(ArcDurationSec.ToString()) & "')"
                                        Dim sc1 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc1.ExecuteNonQuery()
                                        sc1.Dispose()

                                        'Log 2 Shift start 
                                        SecondShiftStartDate = eDate.Substring(0, 10) + " 15:25:00"
                                        getShiftSDATValue(SecondShiftStartDate, Newsdat, Newshift)

                                        ShiftStartDate = SecondShiftStartDate

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & SecondShiftStartDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','1','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','0')"
                                        Dim sc2 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc2.ExecuteNonQuery()
                                        sc2.Dispose()

                                    ElseIf shift = 2 And WeldONShift = 3 Then

                                        'Log 3 Shift end and 1 shift start

                                        'OFF Transaction - Log 3 Shift End of Weld ON Day (Same Day)
                                        ThirdShiftEndDate = eDate.Substring(0, 10) + " 06:59:59"
                                        getShiftSDATValue(ThirdShiftEndDate, Newsdat, Newshift)

                                        ArcDurationSec = (DateTime.Parse(ThirdShiftEndDate) - WeldONDate).TotalSeconds

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & ThirdShiftEndDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','2','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','" & Double.Parse(ArcDurationSec.ToString()) & "')"
                                        Dim sc1 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc1.ExecuteNonQuery()
                                        sc1.Dispose()

                                        'ON Transaction - Log 1 Shift Start of Weld ON Day (Same Day)
                                        FirstShiftStartDate = eDate.Substring(0, 10) + " 07:00:00"
                                        getShiftSDATValue(FirstShiftStartDate, Newsdat, Newshift)

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & FirstShiftStartDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','1','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','0')"
                                        Dim sc2 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc2.ExecuteNonQuery()
                                        sc2.Dispose()

                                        'Log 1 Shift end and 2 shift start

                                        'OFF Transaction - Log 1 Shift End of Same Day 
                                        FirstShiftEndDate = eDate.Substring(0, 10) + " 13:24:59"
                                        getShiftSDATValue(FirstShiftEndDate, Newsdat, Newshift)

                                        ArcDurationSec = (DateTime.Parse(FirstShiftEndDate) - DateTime.Parse(FirstShiftStartDate)).TotalSeconds

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & FirstShiftEndDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','2','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','" & Double.Parse(ArcDurationSec.ToString()) & "')"
                                        Dim sc3 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc3.ExecuteNonQuery()
                                        sc3.Dispose()

                                        'ON Transaction - Log 2 Shift Start of Same Day
                                        SecondShiftStartDate = eDate.Substring(0, 10) + " 13:25:00"
                                        getShiftSDATValue(SecondShiftStartDate, Newsdat, Newshift)

                                        ShiftStartDate = SecondShiftStartDate

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & SecondShiftStartDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','1','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','0')"
                                        Dim sc4 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc4.ExecuteNonQuery()
                                        sc4.Dispose()

                                    ElseIf shift = 3 And WeldONShift = 2 Then

                                        'Log 2 Shift end and 3 shift start

                                        'OFF Transaction - Log 2 Shift End 
                                        SecondShiftEndDate = WeldONDate.ToString(format).Substring(0, 10) + " 23:54:59"
                                        getShiftSDATValue(SecondShiftEndDate, Newsdat, Newshift)

                                        ArcDurationSec = (DateTime.Parse(SecondShiftEndDate) - WeldONDate).TotalSeconds

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & SecondShiftEndDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','2','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','" & Double.Parse(ArcDurationSec.ToString()) & "')"
                                        Dim sc1 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc1.ExecuteNonQuery()
                                        sc1.Dispose()

                                        'ON Transaction - Log 3 Shift start 
                                        ThirdShiftStartDate = WeldONDate.ToString(format).Substring(0, 10) + " 23:55:00"
                                        getShiftSDATValue(ThirdShiftStartDate, Newsdat, Newshift)

                                        ShiftStartDate = ThirdShiftStartDate

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & ThirdShiftStartDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','1','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','0')"
                                        Dim sc2 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc2.ExecuteNonQuery()
                                        sc2.Dispose()

                                    ElseIf shift = 3 And WeldONShift = 1 Then

                                        'Log 1 Shift end and 2 shift start

                                        'OFF Transaction - Log 1 Shift End of Weld ON Day
                                        FirstShiftEndDate = WeldONDate.ToString(format).Substring(0, 10) + " 13:24:59"
                                        getShiftSDATValue(FirstShiftEndDate, Newsdat, Newshift)

                                        ArcDurationSec = (DateTime.Parse(FirstShiftEndDate) - WeldONDate).TotalSeconds

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & FirstShiftEndDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','2','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','" & Double.Parse(ArcDurationSec.ToString()) & "')"
                                        Dim sc1 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc1.ExecuteNonQuery()
                                        sc1.Dispose()

                                        'ON Transaction - Log 2 Shift Start of Weld ON Day
                                        SecondShiftStartDate = WeldONDate.ToString(format).Substring(0, 10) + " 13:25:00"
                                        getShiftSDATValue(SecondShiftStartDate, Newsdat, Newshift)

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & SecondShiftStartDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','1','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','0')"
                                        Dim sc2 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc2.ExecuteNonQuery()
                                        sc2.Dispose()

                                        'Log 2 Shift end and 3 shift start

                                        'OFF Transaction - Log 2 Shift End of Weld ON Day 
                                        SecondShiftEndDate = WeldONDate.ToString(format).Substring(0, 10) + " 23:54:59"
                                        getShiftSDATValue(SecondShiftEndDate, Newsdat, Newshift)

                                        ArcDurationSec = (DateTime.Parse(SecondShiftEndDate) - DateTime.Parse(SecondShiftStartDate)).TotalSeconds

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & SecondShiftEndDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','2','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','" & Double.Parse(ArcDurationSec.ToString()) & "')"
                                        Dim sc3 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc3.ExecuteNonQuery()
                                        sc3.Dispose()

                                        'ON Transaction - Log 3 Shift Start of Weld ON Day
                                        ThirdShiftStartDate = WeldONDate.ToString(format).Substring(0, 10) + " 23:55:00"
                                        getShiftSDATValue(ThirdShiftStartDate, Newsdat, Newshift)

                                        ShiftStartDate = ThirdShiftStartDate

                                        sql = "insert into GTAW_ARCH_LOG_DETAIL(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                                "'" & ThirdShiftStartDate & "'," &
                                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                                "'" & Project & "','" & Seam & "','1','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                                "'" & Newsdat & "','" & Newshift & "','0')"
                                        Dim sc4 As SqlCommand = New SqlCommand(sql, con)
                                        i = sc4.ExecuteNonQuery()
                                        sc4.Dispose()

                                    End If

                                    ArcDurationSec = (DateTime.Parse(eDate) - DateTime.Parse(ShiftStartDate)).TotalSeconds

                                End If
                            Else
                                ArcDurationSec = (DateTime.Parse(eDate) - WeldONDate).TotalSeconds
                            End If
                        End If
                    End If

                    If ProcessValue = 1 Then
                        sql = "insert into GTAW_ARCH_LOG_DATA(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft,arct) values(" &
                                "'" & eDate & "'," &
                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                "'" & Project & "','" & Seam & "','" & Int32.Parse(ArchOnOffFlag.ToString()) & "','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                "'" & sdat & "','" & Int32.Parse(shift.ToString()) & "','" & Double.Parse(ArcDurationSec.ToString()) & "')"
                    End If

                    If sql <> "" Then
                        Dim sc As SqlCommand = New SqlCommand(sql, con)
                        i = sc.ExecuteNonQuery()
                        sc.Dispose()
                    End If

                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return i
    End Function
    ''Check For Nirav sir
    Public Function insertParamDataLogDetail(ByVal entryDate As DateTime, ByVal shopName As String, ByVal stationName As String, ByVal processName As String, ByVal empPSNO As String,
                                             ByVal Project As String, ByVal Seam As String, ByVal WPSN As String, ByVal PassNo As String, ByVal LayerNo As String, ByVal ShortPass As Integer, ByVal ACDCFlag As Integer,
                                             ByVal CurrentValue As Double, ByVal CurrentValue2 As Double, ByVal VoltageValue As Double, ByVal VoltageValue2 As Double, ByVal TravelSpeedValue As Double,
                                             ByVal ConsItem As String, ByVal ConsBatch As String, ByVal FluxItem As String, ByVal FluxBatch As String, ByVal JobTemp As Double, ByVal GasFlow As Double, ByVal GasFlow2 As Double, ByVal WireFeed As Double, ByVal WireFeed2 As Double,
                                             ByVal SpotNumber As Integer, ByVal GrindValue As Integer, ByVal GrindFillupValue As Integer, ByVal DepthValue As Double,
                                             ByVal AntiDriftValue As Double, ByVal DriveTripValue As Double, ByVal SQLcon As Integer, ByRef ExceptionMessage As String) As Integer
        Dim i As Integer = 0
        Dim sql As String = ""
        Dim eDate As String = ""
        Dim sdat As String = ""
        Dim shift As Integer = 0

        If IOTDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(IOTConn)
                Try
                    con.Open()
                    Dim format As String = "yyyy-MM-dd HH:mm:ss"
                    If SQLcon = 1 Then
                        eDate = DateTime.Now.ToString(format)
                    Else
                        eDate = entryDate.ToString(format)
                    End If

                    getShiftSDATValue(eDate, sdat, shift)
                    Dim ProcessValue As Integer = getProcessValue(processName)

                    If ProcessValue = 1 Then
                        sql = "insert into GTAW_WDS_DATA(edat,shop,stan,psno,cprj,seam,wpsn,pass,layer,pros,acdc,curn,curn2,volt,volt2,tspd,cons,cbat,flux,fbat,temp,gasflow,gasflow2,wirefeed,wirefeed2,scon,sdat,shft) values(" &
                                "'" & eDate & "'," &
                                "'" & shopName & "'," &
                                "'" & stationName & "'," &
                                "'" & empPSNO & "'," &
                                "'" & Project & "'," &
                                "'" & Seam & "'," &
                                "'" & WPSN & "'," &
                                "'" & PassNo & "'," &
                                "'" & LayerNo & "', " &
                                "'" & processName & "'," &
                                "'" & Int32.Parse(IIf(ACDCFlag.ToString().Trim() = "", "0", ACDCFlag.ToString())) & "'," &
                                "'" & Double.Parse(IIf(CurrentValue.ToString().Trim() = "", "0", CurrentValue.ToString())) & "', " &
                                 "'" & Double.Parse(IIf(CurrentValue2.ToString().Trim() = "", "0", CurrentValue2.ToString())) & "', " &
                                "'" & Double.Parse(IIf(VoltageValue.ToString().Trim() = "", "0", VoltageValue.ToString())) & "', " &
                                 "'" & Double.Parse(IIf(VoltageValue2.ToString().Trim() = "", "0", VoltageValue2.ToString())) & "', " &
                                "'" & Double.Parse(IIf(TravelSpeedValue.ToString().Trim() = "", "0", TravelSpeedValue.ToString())) & "', " &
                                "'" & ConsItem & "'," &
                                "'" & ConsBatch & "'," &
                                "'" & FluxItem & "'," &
                                "'" & FluxBatch & "'," &
                                "'" & Double.Parse(IIf(JobTemp.ToString().Trim() = "", "0", JobTemp.ToString())) & "', " &
                                "'" & Double.Parse(IIf(GasFlow.ToString().Trim() = "", "0", GasFlow.ToString())) & "', " &
                                "'" & Double.Parse(IIf(GasFlow2.ToString().Trim() = "", "0", GasFlow2.ToString())) & "', " &
                                 "'" & Double.Parse(IIf(WireFeed.ToString().Trim() = "", "0", WireFeed.ToString())) & "', " &
                                 "'" & Double.Parse(IIf(WireFeed2.ToString().Trim() = "", "0", WireFeed2.ToString())) & "', " &
                                "'" & Int32.Parse(SQLcon.ToString()) & "'," &
                                "'" & sdat & "'," &
                                "'" & Int32.Parse(IIf(shift.ToString().Trim() = "", "0", shift.ToString())) & "')"
                    End If

                    If sql <> "" Then
                        Dim sc As SqlCommand = New SqlCommand(sql, con)
                        i = sc.ExecuteNonQuery()
                        sc.Dispose()
                    End If

                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return i
    End Function


    Public Function insertUpdateLocalDataCount(ByVal stationName As String, ByVal entryDate As DateTime, ByVal LocalDataCount As Integer, ByVal LastBuildDate As String, ByRef ExceptionMessage As String) As Integer
        Dim i As Integer = 0
        Dim cnt As Integer = 0
        Dim sql As String = ""
        Dim eDate As String = ""
        Dim sdat As String = ""
        Dim shift As Integer = 0
        Dim fluxConsumption As Double = 0

        If IOTDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(IOTConn)
                Try
                    con.Open()
                    Dim format As String = "yyyy-MM-dd HH:mm:ss"

                    sql = "select count(*) cnt from IOT_STN_LOCAL_DATA_COUNT where stan = '" & stationName & "'"
                    Dim sc As SqlCommand = New SqlCommand(sql, con)
                    cnt = sc.ExecuteScalar()

                    If cnt = 0 Then
                        sql = "insert into IOT_STN_LOCAL_DATA_COUNT(stan,edat,lcnt,cvrn) values('" & stationName & "','" & entryDate.ToString(format) & "','" & LocalDataCount & "','" & LastBuildDate & "')"
                        Dim sc1 As SqlCommand = New SqlCommand(sql, con)
                        i = sc1.ExecuteNonQuery()
                        sc1.Dispose()
                    Else
                        sql = "update IOT_STN_LOCAL_DATA_COUNT Set edat = '" & entryDate.ToString(format) & "', lcnt = '" & LocalDataCount & "', cvrn = '" & LastBuildDate & "' where stan = '" & stationName & "'"
                        Dim sc1 As SqlCommand = New SqlCommand(sql, con)
                        i = sc1.ExecuteNonQuery()
                        sc1.Dispose()
                    End If

                    sc.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If

        Return i
    End Function

    Public Function insertOperatorLogDetail(ByVal entryDate As DateTime, ByVal shopName As String, ByVal stationName As String, ByVal processName As String, ByVal empPSNO As String, ByVal Project As String, ByVal Seam As String, ByVal OperatorLoginFlag As Integer, ByVal SQLcon As Integer, ByRef ExceptionMessage As String) As Integer
        Dim i As Integer = 0
        Dim sql As String = ""
        Dim eDate As String = ""
        Dim sdat As String = ""
        Dim shift As Integer = 0

        If IOTDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(IOTConn)
                Try
                    con.Open()
                    Dim format As String = "yyyy-MM-dd HH:mm:ss"
                    If SQLcon = 1 Then
                        eDate = DateTime.Now.ToString(format)
                    Else
                        eDate = entryDate.ToString(format)
                    End If

                    getShiftSDATValue(eDate, sdat, shift)
                    Dim ProcessValue As Integer = getProcessValue(processName)

                    If ProcessValue = 1 Then
                        sql = "insert into GTAW_OPERATOR_LOG_DATA(edat,shop,stan,psno,cprj,seam,flag,scon,sdat,shft) values(" &
                                "'" & eDate & "'," &
                                "'" & shopName & "','" & stationName & "','" & empPSNO & "'," &
                                "'" & Project & "','" & Seam & "','" & Int32.Parse(OperatorLoginFlag.ToString()) & "','" & Int32.Parse(SQLcon.ToString()) & "'," &
                                "'" & sdat & "','" & Int32.Parse(shift.ToString()) & "')"
                    End If

                    If sql <> "" Then
                        Dim sc As SqlCommand = New SqlCommand(sql, con)
                        i = sc.ExecuteNonQuery()
                        sc.Dispose()
                    End If

                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return i
    End Function

    Public Function getLayerDetail(ByVal Project As String, ByVal Seam As String, ByVal wpsNo As String, ByVal processName As String, ByRef ExceptionMessage As String) As DataTable
        Dim sql As String = ""
        Dim dt As DataTable = New DataTable()
        dt.TableName = "LayerDetail"

        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    sql = "select t_wjtyp from ttclnt011@cmp with (nolock) where t_cprj ='" & Project & "' and t_seam='" & Seam & "'"
                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    Dim sdr As SqlDataReader = cmd.ExecuteReader()
                    If sdr.HasRows Then
                        While sdr.Read()
                            Dim WJTYP As Integer = Int32.Parse(sdr(0).ToString())
                            If WJTYP = 2 OrElse WJTYP = 4 Then
                                dt.Clear()
                                dt.Columns.Add("t_layr")
                                dt.Rows.Add(New Object() {"BARRIER"})
                                dt.Rows.Add(New Object() {"SUBSEQUENT"})
                            Else
                                sql = ""
                                dt.Clear()
                                Dim ProcessValue As Integer = getProcessValue(processName)
                                sql = "select distinct(t_layr) from tltwps017@cmp with (nolock) where t_wpsn='" & wpsNo & "' and t_pros='" & ProcessValue & "'"
                                sql = sql.Replace("@cmp", cmp)
                                Dim cmd1 As SqlCommand = New SqlCommand(sql, con)
                                dt.Load(cmd1.ExecuteReader())
                                cmd1.Dispose()
                            End If
                        End While
                    End If
                    sdr.Close()
                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function


    Public Function getConsumableAWSDetail(ByVal Project As String, ByVal Seam As String, ByVal wpsNo As String, ByVal processName As String, ByVal Layer As String, ByRef ExceptionMessage As String) As DataTable
        Dim sql As String = ""
        Dim dt As DataTable = New DataTable()
        dt.TableName = "ConsumableAWSDetail"

        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    Dim ProcessValue As Integer = getProcessValue(processName)
                    sql = "select * from tltwps024@cmp with (nolock) where  t_cprj='" & Project & "' and t_wpsn='" & wpsNo & "' and t_seam='" & Seam & "' and t_proc='" & ProcessValue & "'"
                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    Dim sdr As SqlDataReader = cmd.ExecuteReader()
                    If sdr.HasRows Then
                        dt.Clear()
                        dt.Columns.Add("t_caws")
                        While sdr.Read()
                            If sdr("t_lsq1").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_con1").ToString().Trim() <> "" Then
                                    dt.Rows.Add(New Object() {sdr("t_con1").ToString()})
                                End If
                            End If

                            If sdr("t_lsq2").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_con2").ToString().Trim() <> "" Then
                                    dt.Rows.Add(New Object() {sdr("t_con2").ToString()})
                                End If
                            End If

                            If sdr("t_lsq3").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_con3").ToString().Trim() <> "" Then
                                    dt.Rows.Add(New Object() {sdr("t_con3").ToString()})
                                End If
                            End If

                            If sdr("t_lsq4").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_con4").ToString().Trim() <> "" Then
                                    dt.Rows.Add(New Object() {sdr("t_con4").ToString()})
                                End If
                            End If

                            If sdr("t_lsq5").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_con5").ToString().Trim() <> "" Then
                                    dt.Rows.Add(New Object() {sdr("t_con5").ToString()})
                                End If
                            End If

                            If sdr("t_lsq6").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_con6").ToString().Trim() <> "" Then
                                    dt.Rows.Add(New Object() {sdr("t_con6").ToString()})
                                End If
                            End If

                            If sdr("t_lsq7").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_con7").ToString().Trim() <> "" Then
                                    dt.Rows.Add(New Object() {sdr("t_con7").ToString()})
                                End If
                            End If

                            If sdr("t_lsq8").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_con8").ToString().Trim() <> "" Then
                                    dt.Rows.Add(New Object() {sdr("t_con8").ToString()})
                                End If
                            End If
                        End While
                    End If
                    sdr.Close()
                    cmd.Dispose()
                    con.Close()

                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function


    Public Function getFluxAWSDetail(ByVal Project As String, ByVal Seam As String, ByVal wpsNo As String, ByVal processName As String, ByVal Layer As String, ByRef ExceptionMessage As String) As DataTable
        Dim sql As String = ""
        Dim dt As DataTable = New DataTable()
        dt.TableName = "FluxAWSDetail"

        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    Dim ProcessValue As Integer = getProcessValue(processName)
                    sql = "select * from tltwps024@cmp with (nolock) where  t_cprj='" & Project & "' and t_wpsn='" & wpsNo & "' and t_seam='" & Seam & "' and t_proc='" & ProcessValue & "'"
                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    Dim sdr As SqlDataReader = cmd.ExecuteReader()
                    If sdr.HasRows Then
                        dt.Clear()
                        dt.Columns.Add("t_faws")
                        While sdr.Read()
                            If sdr("t_lsq1").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_flx1").ToString().Trim() <> "" Then
                                    If sdr("t_flx1").ToString().Equals("NA") Then
                                    Else
                                        dt.Rows.Add(New Object() {sdr("t_flx1").ToString()})
                                    End If
                                End If
                            End If

                            If sdr("t_lsq2").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_flx2").ToString().Trim() <> "" Then
                                    If sdr("t_flx2").ToString().Equals("NA") Then
                                    Else
                                        dt.Rows.Add(New Object() {sdr("t_flx2").ToString()})
                                    End If
                                End If
                            End If

                            If sdr("t_lsq3").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_flx3").ToString().Trim() <> "" Then
                                    If sdr("t_flx3").ToString().Equals("NA") Then
                                    Else
                                        dt.Rows.Add(New Object() {sdr("t_flx3").ToString()})
                                    End If
                                End If
                            End If

                            If sdr("t_lsq4").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_flx4").ToString().Trim() <> "" Then
                                    If sdr("t_flx4").ToString().Equals("NA") Then
                                    Else
                                        dt.Rows.Add(New Object() {sdr("t_flx4").ToString()})
                                    End If
                                End If
                            End If

                            If sdr("t_lsq5").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_flx5").ToString().Trim() <> "" Then
                                    If sdr("t_flx5").ToString().Equals("NA") Then
                                    Else
                                        dt.Rows.Add(New Object() {sdr("t_flx5").ToString()})
                                    End If
                                End If
                            End If

                            If sdr("t_lsq6").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_flx6").ToString().Trim() <> "" Then
                                    If sdr("t_flx6").ToString().Equals("NA") Then
                                    Else
                                        dt.Rows.Add(New Object() {sdr("t_flx6").ToString()})
                                    End If
                                End If
                            End If

                            If sdr("t_lsq7").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_flx7").ToString().Trim() <> "" Then
                                    If sdr("t_flx7").ToString().Equals("NA") Then
                                    Else
                                        dt.Rows.Add(New Object() {sdr("t_flx7").ToString()})
                                    End If
                                End If
                            End If

                            If sdr("t_lsq8").ToString().Trim().Equals(Layer, StringComparison.InvariantCultureIgnoreCase) Then
                                If sdr("t_flx8").ToString().Trim() <> "" Then
                                    If sdr("t_flx8").ToString().Equals("NA") Then
                                    Else
                                        dt.Rows.Add(New Object() {sdr("t_flx8").ToString()})
                                    End If
                                End If
                            End If
                        End While
                    End If
                    sdr.Close()
                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function


    Public Function getConsumableSizeDetail(ByVal Project As String, ByVal Seam As String, ByVal wpsNo As String, ByVal processName As String, ByVal Layer As String, ByVal consumableAWS As String, ByRef ExceptionMessage As String) As DataTable
        Dim sql As String = ""
        Dim dt As DataTable = New DataTable()
        dt.TableName = "ConsumableSizeDetail"

        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    Dim ProcessValue As Integer = getProcessValue(processName)
                    sql = "select * from tltwps024@cmp with (nolock) where  t_cprj='" & Project & "' and t_wpsn='" & wpsNo & "' and t_seam='" & Seam & "' and t_proc='" & ProcessValue & "'"
                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    Dim sdr As SqlDataReader = cmd.ExecuteReader()
                    If sdr.HasRows Then
                        dt.Clear()
                        dt.Columns.Add("t_csiz")
                        While sdr.Read()
                            If sdr("t_con1").ToString().Trim() = consumableAWS.Trim() Then
                                If checkConsumableAWSSize(consumableAWS.Trim(), sdr("t_siz1").ToString(), ExceptionMessage) Then
                                    dt.Rows.Add(New Object() {sdr("t_siz1").ToString()})
                                End If
                            End If

                            If sdr("t_con2").ToString().Trim() = consumableAWS.Trim() Then
                                If checkConsumableAWSSize(consumableAWS.Trim(), sdr("t_siz2").ToString(), ExceptionMessage) Then
                                    dt.Rows.Add(New Object() {sdr("t_siz2").ToString()})
                                End If
                            End If

                            If sdr("t_con3").ToString().Trim() = consumableAWS.Trim() Then
                                If checkConsumableAWSSize(consumableAWS.Trim(), sdr("t_siz3").ToString(), ExceptionMessage) Then
                                    dt.Rows.Add(New Object() {sdr("t_siz3").ToString()})
                                End If
                            End If

                            If sdr("t_con4").ToString().Trim() = consumableAWS.Trim() Then
                                If checkConsumableAWSSize(consumableAWS.Trim(), sdr("t_siz4").ToString(), ExceptionMessage) Then
                                    dt.Rows.Add(New Object() {sdr("t_siz4").ToString()})
                                End If
                            End If

                            If sdr("t_con5").ToString().Trim() = consumableAWS.Trim() Then
                                If checkConsumableAWSSize(consumableAWS.Trim(), sdr("t_siz5").ToString(), ExceptionMessage) Then
                                    dt.Rows.Add(New Object() {sdr("t_siz5").ToString()})
                                End If
                            End If

                            If sdr("t_con6").ToString().Trim() = consumableAWS.Trim() Then
                                If checkConsumableAWSSize(consumableAWS.Trim(), sdr("t_siz6").ToString(), ExceptionMessage) Then
                                    dt.Rows.Add(New Object() {sdr("t_siz6").ToString()})
                                End If
                            End If

                            If sdr("t_con7").ToString().Trim() = consumableAWS.Trim() Then
                                If checkConsumableAWSSize(consumableAWS.Trim(), sdr("t_siz7").ToString(), ExceptionMessage) Then
                                    dt.Rows.Add(New Object() {sdr("t_siz7").ToString()})
                                End If
                            End If

                            If sdr("t_con8").ToString().Trim() = consumableAWS.Trim() Then
                                If checkConsumableAWSSize(consumableAWS.Trim(), sdr("t_siz8").ToString(), ExceptionMessage) Then
                                    dt.Rows.Add(New Object() {sdr("t_siz8").ToString()})
                                End If
                            End If
                        End While
                    End If
                    sdr.Close()
                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function

    Public Function checkConsumableAWSSize(ByVal consumableAWS As String, ByVal consumableSize As String, ByRef ExceptionMessage As String) As Boolean
        Dim sql1 As String = ""

        Using con As SqlConnection = New SqlConnection(ERPLNConn)
            Try
                con.Open()
                sql1 = "select * from tltwps016@cmp with (nolock) where t_awsn='" & consumableAWS & "' and t_edia='" & consumableSize & "'"
                sql1 = sql1.Replace("@cmp", cmp)
                Dim cmd1 As SqlCommand = New SqlCommand(sql1, con)
                Dim sdr1 As SqlDataReader = cmd1.ExecuteReader()
                If sdr1.HasRows Then
                    sdr1.Close()
                    cmd1.Dispose()
                    con.Close()
                    Return True
                Else
                    sdr1.Close()
                    cmd1.Dispose()
                    con.Close()
                    Return False
                End If
            Catch ex As Exception
                ExceptionMessage = ex.Message.ToString()
                'MessageBox.Show(ex.Message.ToString())
            End Try
        End Using

        Return False
    End Function


    Public Function getERPLNProjectNumber(ByVal Project As String, ByRef ExceptionMessage As String) As DataTable
        Dim dt As DataTable = New DataTable()
        dt.TableName = "ERPLNProject"

        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    Dim sql As String = ""
                    sql = "select t_cprj from ttclnt001@cmp with (nolock) where t_qprj='" & Project & "'"
                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    dt.Load(cmd.ExecuteReader())
                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If

        Return dt
    End Function


    Public Function getEmployeeLocation(ByVal employeePSNO As String, ByRef ExceptionMessage As String) As DataTable
        Dim dt As DataTable = New DataTable()
        dt.TableName = "EmployeeLocation"

        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    Dim sql As String = ""
                    sql = "SELECT t_psno, t_name, t_loca FROM tltcom001@cmp with (nolock) WHERE t_psno='" & employeePSNO.Trim() & "'"
                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    dt.Load(cmd.ExecuteReader())
                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If

        Return dt
    End Function


    Public Function getShopDetail() As DataTable
        Dim dt As DataTable = New DataTable()
        dt.TableName = "ShopNoDetail"

        If IOTDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(IOTConn)
                Try
                    con.Open()
                    Dim sql As String = ""
                    sql = "SELECT shop_no, shop_name, shop_no  + ' # ' + shop_name as DisplayMember FROM ShopMaster"
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    dt.Load(cmd.ExecuteReader())
                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function


    Public Function getCMBDetail(ByVal ShopNo As String) As DataTable
        Dim dt As DataTable = New DataTable()
        dt.TableName = "CMBNoDetail"

        If IOTDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(IOTConn)
                Try
                    con.Open()
                    Dim sql As String = ""
                    sql = "SELECT cmb_no, cmb_name, cmb_no + ' # ' + cmb_name as DisplayMember FROM CMBMaster where shop_no = '" & ShopNo.Trim() & "'"
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    dt.Load(cmd.ExecuteReader())
                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function


    Public Function getWDSDetail(ByVal Project As String, ByVal Seam As String, ByVal processName As String) As DataTable
        Dim dt As DataTable = New DataTable()
        dt.TableName = "WDSDetail"

        If IOTDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(IOTConn)
                Try
                    con.Open()
                    Dim ProcessValue As Integer = getProcessValue(processName)
                    Dim sql As String = ""
                    If ProcessValue = 1 Then
                        sql = " select cprj, seam, pass, min(edat) as 'Start DateTime', max(edat) as 'End DateTime', " & " convert(varchar(5),DateDiff(s, min(edat), max(edat))/3600)+':'+convert(varchar(5),DateDiff(s, min(edat), max(edat))%3600/60) as [hh:mm] " & " from GTAW_WDS_DATA " & " where cprj = '" & Project & "' and seam = '" & Seam & "' " & " group by cprj, seam, pass " & " order by cprj, seam, convert(int, pass) desc"
                    End If

                    If sql <> "" Then
                        Dim cmd As SqlCommand = New SqlCommand(sql, con)
                        dt.Load(cmd.ExecuteReader())
                        cmd.Dispose()
                    End If

                    con.Close()
                Catch ex As Exception
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function


    Public Function getConsumableItemDetail(ByVal EmployeeLocation As String, ByVal ERPLNProject As String, ByVal consumableAWS As String, ByVal consumableSize As String, ByRef ExceptionMessage As String) As DataTable
        Dim dt As DataTable = New DataTable()
        dt.TableName = "ConsumableItemDetail"

        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    Dim mitm As String = "         " & ERPLNProject & "-" + EmployeeLocation.Substring(0, 1) & "-" & "WMR"
                    Dim sql As String = ""
                    sql = " select * from ttcibd001@cmp with (nolock) where t_ctyp = (select t_ctyp from tltsas040@cmp with (nolock) where t_ityp='1') " & " and t_dscb='" & consumableAWS & "'and t_dscc='" & consumableSize & "'and t_item in(select t_sitm from ttibom010@cmp with (nolock) " & " where t_mitm = '" & mitm & "')"
                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    Dim sdr As SqlDataReader = cmd.ExecuteReader()
                    If sdr.HasRows Then
                        dt.Clear()
                        dt.Columns.Add("t_item")
                        dt.Columns.Add("t_dsca")
                        dt.Columns.Add("DisplayMember")
                        While sdr.Read()
                            Dim str As String = sdr("t_item").ToString()
                            str = str.Trim()
                            Dim ch As Char = str.ElementAt(2)
                            If ch <> "F"c Then
                                dt.Rows.Add(New Object() {sdr("t_item").ToString(), sdr("t_dsca").ToString(), sdr("t_item").ToString() & " # " + sdr("t_dsca").ToString()})
                            End If
                        End While
                    End If
                    sdr.Close()
                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    MessageBox.Show("Error in getConsumableItemDetail method of SQLDB module, Error : " + ex.Message.ToString())
                End Try
            End Using
        End If

        Return dt
    End Function


    Public Function getFluxItemDetail(ByVal EmployeeLocation As String, ByVal ERPLNProject As String, ByVal fluxAWS As String, ByRef ExceptionMessage As String) As DataTable
        Dim dt As DataTable = New DataTable()
        dt.TableName = "FluxItemDetail"

        If ERPLNDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Try
                    con.Open()
                    Dim mitm As String = "         " & ERPLNProject & "-" + EmployeeLocation.Substring(0, 1) & "-" & "WMR"
                    Dim sql As String = ""
                    sql = " select t_item, t_dsca from ttcibd001@cmp with (nolock) where t_ctyp = (select t_ctyp from tltsas040@cmp with (nolock) " & " where t_ityp='1') and t_dscb='" & fluxAWS & "' and t_item in(select t_sitm from ttibom010@cmp with (nolock) " & " where t_mitm = '" & mitm & "')"
                    sql = sql.Replace("@cmp", cmp)
                    Dim cmd As SqlCommand = New SqlCommand(sql, con)
                    Dim sdr As SqlDataReader = cmd.ExecuteReader()
                    If sdr.HasRows Then
                        dt.Clear()
                        dt.Columns.Add("t_item")
                        dt.Columns.Add("t_dsca")
                        dt.Columns.Add("DisplayMember")
                        While sdr.Read()
                            Dim str As String = sdr("t_item").ToString()
                            str = str.Trim()
                            Dim ch As Char = str.ElementAt(2)
                            If ch = "F"c Then
                                dt.Rows.Add(New Object() {sdr("t_item").ToString(), sdr("t_dsca").ToString(), sdr("t_item").ToString() & " # " + sdr("t_dsca").ToString()})
                            End If
                        End While
                    End If
                    sdr.Close()
                    cmd.Dispose()
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    MessageBox.Show("Error in getFluxItemDetail method of SQLDB module, Error : " + ex.Message.ToString())
                End Try
            End Using
        End If
        Return dt
    End Function


    Public Function generateToken(ByVal EmployeeLocation As String, ByVal employeePSNO As String, ByVal Project As String, ByVal Seam As String, ByVal wpsNo As String, ByVal processName As String, ByVal Layer As String, ByVal consumableSize As String, ByVal consumableItem As String, ByVal fluxItem As String, ByVal materialFlag As Integer, ByVal stationNo As String, ByVal shopNo As String, ByVal CMBNo As String, ByRef TokenResult As String) As Boolean
        Try

            Dim token As String = ""
            Dim locationEU As String = ""
            Dim service As SasWeldConsIssueTokenWiseService = New SasWeldConsIssueTokenWiseService()
            service.Timeout = Int32.Parse(timeout)
            Dim request As SASTokenGenerationRequestType = New SASTokenGenerationRequestType()
            Dim response As SASTokenGenerationResponseType = New SASTokenGenerationResponseType()
            Dim ctrlArea As SASTokenGenerationRequestTypeControlArea = New SASTokenGenerationRequestTypeControlArea()
            ctrlArea.processingScope = processingScope.request
            Dim dataArea As SASTokenGenerationRequestTypeSasWeldConsIssueTokenWise = New SASTokenGenerationRequestTypeSasWeldConsIssueTokenWise()
            Dim sql1 As String = ""
            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                con.Open()
                sql1 = "select t_dimx, t_eunt from tltwms000@cmp with (nolock) where t_dimx='" & EmployeeLocation & "' "
                sql1 = sql1.Replace("@cmp", cmp)
                Dim cmd1 As SqlCommand = New SqlCommand(sql1, con)
                Dim sdr1 As SqlDataReader = cmd1.ExecuteReader()
                If sdr1.HasRows Then
                    While sdr1.Read()
                        locationEU = sdr1("t_eunt").ToString()
                    End While
                End If
                sdr1.Close()
                cmd1.Dispose()
                con.Close()
            End Using

            dataArea.locationEu = locationEU
            dataArea.empNumber = employeePSNO
            dataArea.qmsProject = Project
            dataArea.seam1 = Seam
            dataArea.wpsNumber = wpsNo
            Dim ProcessValue As Integer = getProcessValue(processName)
            dataArea.weldingProcessSpecified = True
            Select Case ProcessValue
                Case 1
                    dataArea.weldingProcess = ltwpswprocess.Item1
                Case 2
                    dataArea.weldingProcess = ltwpswprocess.Item2
                Case 3
                    dataArea.weldingProcess = ltwpswprocess.Item3
                Case 4
                    dataArea.weldingProcess = ltwpswprocess.Item4
                Case 5
                    dataArea.weldingProcess = ltwpswprocess.Item5
                Case 6
                    dataArea.weldingProcess = ltwpswprocess.Item6
                Case 7
                    dataArea.weldingProcess = ltwpswprocess.Item7
                Case 8
                    dataArea.weldingProcess = ltwpswprocess.Item8
                Case 9
                    dataArea.weldingProcess = ltwpswprocess.Item9
                Case 10
                    dataArea.weldingProcess = ltwpswprocess.Item10
                Case 11
                    dataArea.weldingProcess = ltwpswprocess.Item11
                Case 12
                    dataArea.weldingProcess = ltwpswprocess.Item12
                Case 13
                    dataArea.weldingProcess = ltwpswprocess.Item13
                Case 14
                    dataArea.weldingProcess = ltwpswprocess.Item14
                Case 15
                    dataArea.weldingProcess = ltwpswprocess.Item15
            End Select

            dataArea.couponSpecified = True
            dataArea.coupon = ltwmsplpi.Item1
            dataArea.pipeOD = ""
            dataArea.position = ""
            dataArea.depositeThikness = ""
            dataArea.grooveTypeSpecified = True
            dataArea.grooveType = ltwpspenetra.Item3
            dataArea.storeNo = "0"
            dataArea.tokenNumber = ""
            dataArea.layer = Layer
            dataArea.size = consumableSize
            consumableItem = "         " & consumableItem.Trim()
            fluxItem = "         " & fluxItem.Trim()
            dataArea.consItemCode = consumableItem
            dataArea.fluxItemCode = fluxItem
            request.ControlArea = ctrlArea
            request.DataArea = New SASTokenGenerationRequestTypeSasWeldConsIssueTokenWise(0) {}
            request.DataArea(0) = dataArea
            response = service.SASTokenGeneration(request)
            TokenResult = response.DataArea(0).result
            token = response.DataArea(0).tokenNumber
            Dim ch As String = TokenResult.Substring(0, 1)
            If ch.Equals("0") Then
                TokenResult = token

                Dim sendmailobj As New IOTWebService.SAWService()
                sendmailobj.sendMail(stationNo, shopNo, CMBNo, employeePSNO, Project, Seam, wpsNo, processName, consumableItem, fluxItem, token)

                ''Turn on Hooter
                'Dim host As String = ConfigurationManager.AppSettings("HttpServer").ToString()
                'Dim param As String = "pin" & ConfigurationManager.AppSettings("LightPin") & "=LOW"
                'HitGetRequest(host, param)

                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show("Error while generating Token, Error : " + ex.Message.ToString())
        End Try
        Return True
    End Function

    'Private Sub HitGetRequest(ByVal host As String, ByVal param As String)
    '    Dim ping As Ping = New Ping()
    '    Dim reply = ping.Send(host)
    '    If reply.Status = IPStatus.Success Then
    '        Try
    '            Dim request As HttpWebRequest = CType(WebRequest.Create("http://" & host & "/?" & param), HttpWebRequest)
    '            request.Method = "GET"
    '            request.Timeout = 20000
    '            Using response = request.GetResponse()
    '            End Using
    '        Catch ex As Exception
    '            MessageBox.Show("Error : " + ex.ToString())
    '        End Try
    '    Else
    '        MessageBox.Show(host & " IP not reachable !!")
    '    End If
    'End Sub

    Public Function sendMail(ByVal stationNo As String, ByVal shopNo As String, ByVal CMBNo As String, ByVal employeePSNO As String, ByVal Project As String, ByVal Seam As String, ByVal wpsNo As String, ByVal processName As String, ByVal consumableItem As String, ByVal fluxItem As String, ByVal token As String) As Boolean
        Try
            Dim mailFrom As String = "", mailTo As String = "", mailSubject As String = "", mailBody As String = "", sql1 As String = "", employeeName As String = "", consItemDesc As String = "", fluxItemDesc As String = ""
            Dim smtpClient As SmtpClient = New SmtpClient("172.27.14.246")
            smtpClient.UseDefaultCredentials = False
            Dim mail As MailMessage = New MailMessage()
            mail.IsBodyHtml = True
            mail.From = New MailAddress("niravkumar.patwa@larsentoubro.com")
            Using con As SqlConnection = New SqlConnection(IOTConn)
                Dim cmd1 As SqlCommand
                Dim sdr1 As SqlDataReader
                con.Open()
                sql1 = ""
                sql1 = "select psno, email from MailRecipientMaster where category = 'Token' and type = 'to' "
                cmd1 = New SqlCommand(sql1, con)
                sdr1 = cmd1.ExecuteReader()
                If sdr1.HasRows Then
                    While sdr1.Read()
                        mail.[To].Add(New MailAddress(sdr1("email").ToString()))
                    End While
                End If

                sql1 = ""
                sql1 = "select psno, email from MailRecipientMaster where category = 'Token' and type = 'cc' "
                cmd1 = New SqlCommand(sql1, con)
                sdr1 = cmd1.ExecuteReader()
                If sdr1.HasRows Then
                    While sdr1.Read()
                        mail.CC.Add(New MailAddress(sdr1("email").ToString()))
                    End While
                End If
                sdr1.Close()
                cmd1.Dispose()
                con.Close()
            End Using

            Using con As SqlConnection = New SqlConnection(ERPLNConn)
                Dim cmd1 As SqlCommand
                Dim sdr1 As SqlDataReader
                con.Open()
                sql1 = ""
                sql1 = "SELECT t_psno, t_name FROM tltcom001@cmp with (nolock) WHERE t_psno='" & employeePSNO & "'"
                sql1 = sql1.Replace("@cmp", cmp)
                cmd1 = New SqlCommand(sql1, con)
                sdr1 = cmd1.ExecuteReader()
                If sdr1.HasRows Then
                    While sdr1.Read()
                        employeeName = sdr1("t_name").ToString()
                    End While
                End If

                sql1 = ""
                sql1 = "select t_item, t_dsca from ttcibd001@cmp with (nolock) WHERE t_item='" & consumableItem & "'"
                sql1 = sql1.Replace("@cmp", cmp)
                cmd1 = New SqlCommand(sql1, con)
                sdr1 = cmd1.ExecuteReader()
                If sdr1.HasRows Then
                    While sdr1.Read()
                        consItemDesc = sdr1("t_dsca").ToString()
                    End While
                End If

                sql1 = ""
                sql1 = "select t_item, t_dsca from ttcibd001@cmp with (nolock) WHERE t_item='" & fluxItem & "'"
                sql1 = sql1.Replace("@cmp", cmp)
                cmd1 = New SqlCommand(sql1, con)
                sdr1 = cmd1.ExecuteReader()
                If sdr1.HasRows Then
                    While sdr1.Read()
                        fluxItemDesc = sdr1("t_dsca").ToString()
                    End While
                End If
                sdr1.Close()
                cmd1.Dispose()
                con.Close()
            End Using

            mailSubject = "Consumable Requirement From IOT Station " & stationNo & " against Token Number " & token & " generated by Welder " & employeeName & " "
            mailBody = " <table border=1 cellpadding=0 cellspacing=0 >"
            mailBody += "<tr><td><b> IOT Station </b></td><td> " & stationNo & " </td> </tr>"
            mailBody += "<tr><td><b> Shop Number </b></td><td> " & shopNo & " </td> </tr>"
            mailBody += "<tr><td><b> CMB Number </b></td><td> " & CMBNo & " </td> </tr>"
            mailBody += "<tr><td><b> Welder ID </b></td><td> " & employeePSNO & "</td> </tr>"
            mailBody += "<tr><td><b> Welder Name </b></td><td> " & employeeName & "</td> </tr>"
            mailBody += "<tr><td><b> Project </b></td><td> " & Project & "</td> </tr>"
            mailBody += "<tr><td><b> Seam </b></td><td> " & Seam & "</td> </tr>"
            mailBody += "<tr><td><b> WPS </b></td><td> " & wpsNo & "</td> </tr>"
            mailBody += "<tr><td><b> Process </b></td><td> " & processName & "</td> </tr>"
            mailBody += "<tr><td><b> Token Number </b></td><td> " & token & "</td> </tr>"
            mailBody += "<tr><td><b> Consumable Item </b></td><td> " & consumableItem & "</td> </tr>"
            mailBody += "<tr><td><b> Consumable Item Desc </b></td><td> " & consItemDesc & "</td> </tr>"
            mailBody += "<tr><td><b> Flux Item </b></td><td> " & fluxItem & "</td> </tr>"
            mailBody += "<tr><td><b> Flux Item Desc </b></td><td> " & fluxItemDesc & "</td> </tr>"
            mailBody += "</table>"
            mail.Subject = mailSubject
            mail.Body = mailBody
            smtpClient.Send(mail)
            Return True
        Catch ex As Exception
            MessageBox.Show("Error in sendMail method of SQLDB Module, Error : " + ex.Message.ToString())
        End Try

        Return False
    End Function

    Public Function getProcessValue(ByVal ProcessName As String) As Integer
        Dim ProcessValue As Integer = 0
        Select Case ProcessName
            Case "GTAW"
                ProcessValue = 1
            Case "SMAW"
                ProcessValue = 2
            Case "SAW"
                ProcessValue = 3
            Case "ESW"
                ProcessValue = 4
            Case "ESSC"
                ProcessValue = 4
            Case "SASC"
                ProcessValue = 5
            Case "FCAW"
                ProcessValue = 6
            Case "GMAW"
                ProcessValue = 7
            Case "PAW"
                ProcessValue = 8
            Case "EBW"
                ProcessValue = 9
            Case "GTAWP"
                ProcessValue = 10
            Case "GMAWP"
                ProcessValue = 11
            Case "SAWT"
                ProcessValue = 12
            Case "OTHER"
                ProcessValue = 13
            Case "HWGTW"
                ProcessValue = 14
            Case "MMA"
                ProcessValue = 15
        End Select

        Return ProcessValue
    End Function

    Public Sub getShiftSDATValue(ByVal eDate As String, ByRef sdat As String, ByRef shift As Integer)
        If DateTime.Parse(eDate).Ticks >= DateTime.Parse(eDate.Substring(0, 10) & " 07:00:00").Ticks AndAlso DateTime.Parse(eDate).Ticks < DateTime.Parse(eDate.Substring(0, 10) & " 15:25:00").Ticks Then
            sdat = DateTime.Parse(eDate).Date.ToString("yyyyMMdd") & "070000"
            shift = 1
        ElseIf DateTime.Parse(eDate).Ticks >= DateTime.Parse(eDate.Substring(0, 10) & " 15:25:00").Ticks AndAlso DateTime.Parse(eDate).Ticks < DateTime.Parse(eDate.Substring(0, 10) & " 23:55:00").Ticks Then
            sdat = DateTime.Parse(eDate).Date.ToString("yyyyMMdd") & "152500"
            shift = 2
        ElseIf DateTime.Parse(eDate).Ticks >= DateTime.Parse(eDate.Substring(0, 10) & " 23:55:00").Ticks AndAlso DateTime.Parse(eDate).Ticks <= DateTime.Parse(eDate.Substring(0, 10) & " 23:59:59").Ticks Then
            sdat = DateTime.Parse(eDate).Date.ToString("yyyyMMdd") & "235500"
            shift = 3
        ElseIf DateTime.Parse(eDate).Ticks >= DateTime.Parse(eDate.Substring(0, 10) & " 00:00:00").Ticks AndAlso DateTime.Parse(eDate).Ticks < DateTime.Parse(eDate.Substring(0, 10) & " 07:00:00").Ticks Then
            sdat = DateTime.Parse(eDate).AddDays(-1).Date.ToString("yyyyMMdd") & "235500"
            shift = 3
        End If
    End Sub

    Public Sub getPrevArcTime(ByVal eDate As String, ByVal sDate As String, ByVal shopName As String, ByVal stationName As String, ByVal ProcessValue As Integer, ByVal empPSNO As String, ByVal Project As String, ByVal Seam As String, ByRef ArcDurationSec As Double, ByRef WeldONDate As DateTime, ByRef WeldONShift As Integer, ByRef ExceptionMessage As String)
        Dim sql As String = ""
        Dim reader As SqlDataReader
        Dim onlineDate As DateTime
        Dim localDate As DateTime
        Dim OnlineDateFound As Boolean = False
        Dim LocalDateFound As Boolean = False
        Dim OnlineWeldONShift As Integer = 0
        Dim LocalWeldONShift As Integer = 0
        Dim LocalWeldONsdat As String = ""

        If IOTDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(IOTConn)
                Try
                    con.Open()

                    If ProcessValue = 1 Then
                        sql = "select top 1 edat, shft from GTAW_ARCH_LOG_DETAIL where edat > '" & sDate & "' and edat < '" & eDate & "' and shop = '" & shopName & "' and stan = '" & stationName & "' and psno = '" & empPSNO & "' and cprj = '" & Project & "' and seam = '" & Seam & "' order by edat desc"
                    End If

                    If sql <> "" Then
                        Dim sc As SqlCommand = New SqlCommand(sql, con)
                        reader = sc.ExecuteReader()
                        reader.Read()
                        If reader.HasRows Then
                            onlineDate = Convert.ToDateTime(reader.GetValue(0).ToString())
                            OnlineWeldONShift = Convert.ToInt16(reader.GetValue(1).ToString())
                            OnlineDateFound = True
                            '    ArcDurationSec = (DateTime.Parse(eDate) - DateTime.Parse(reader.GetValue(0).ToString())).TotalSeconds
                            'Else
                            '    ArcDurationSec = 0
                        Else
                            OnlineDateFound = False
                        End If

                        reader.Close()
                        sc.Dispose()
                    End If
                    con.Close()
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using

            'Get Latest value from local database
            Using objCon As New dbClass
                Try
                    Using dt As DataTable = objCon.ExecuteDataTable("select top 1 edat from GTAW_ARCH_LOG_DETAIL where format(edat, 'yyyy-mm-dd hh:nn:ss') > '" & sDate & "' and format(edat, 'yyyy-mm-dd hh:nn:ss') < '" & eDate & "' and shop = '" & shopName & "' and stan = '" & stationName & "' and psno = '" & empPSNO & "' and cprj = '" & Project & "' and seam = '" & Seam & "' order by edat desc", CommandType.Text)
                        If dt.Rows.Count > 0 Then
                            For Each row As DataRow In dt.Rows
                                localDate = Convert.ToDateTime(row("edat").ToString().Trim())
                                getShiftSDATValue(localDate, LocalWeldONsdat, LocalWeldONShift)
                                LocalDateFound = True
                            Next
                        Else
                            LocalDateFound = False
                        End If
                    End Using
                Catch ex As Exception
                    ExceptionMessage = ex.Message.ToString()
                End Try
            End Using

            'Compare two date and find previous shift
            If onlineDate.Ticks > localDate.Ticks Then
                WeldONDate = onlineDate
                WeldONShift = OnlineWeldONShift
            Else
                WeldONDate = localDate
                WeldONShift = LocalWeldONShift
            End If
        End If
    End Sub

    Public Function checkRecordExist(ByVal tableName As String, ByVal entryDate As DateTime, ByVal type As Integer) As Boolean
        Dim RecordExist As Boolean = False
        Dim sql As String = ""
        Dim eDate As String = ""
        Dim reader As SqlDataReader

        If IOTDBConnectivity Then
            Using con As SqlConnection = New SqlConnection(IOTConn)
                Try
                    con.Open()
                    Dim format As String = "yyyy-MM-dd HH:mm:ss"
                    eDate = entryDate.ToString(format)

                    If tableName = "GTAW_ABNORMALITY_DATA" Then
                        sql = "select edat from " & tableName & " where edat = '" & eDate & "' and type = '" & type & "'"
                    Else
                        sql = "select edat from " & tableName & " where edat = '" & eDate & "'"
                    End If

                    If sql <> "" Then
                        Dim sc As SqlCommand = New SqlCommand(sql, con)
                        reader = sc.ExecuteReader()
                        reader.Read()
                        If reader.HasRows Then
                            RecordExist = True
                        End If
                        reader.Close()
                        sc.Dispose()
                    End If

                    con.Close()

                Catch ex As Exception
                    'MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
        End If
        Return RecordExist
    End Function


    Public Function insertAbnormalityLogDetail_BulkCopy(ByVal dt As DataTable)
        Dim i As Integer = 0
        Dim sql As String = ""
        Dim eDate As String = ""
        Dim sdat As String = ""
        Dim shift As Integer = 0

        Using con As SqlConnection = New SqlConnection(IOTConn)

            con.Open()
            Using bulkCopy As New SqlBulkCopy(con)
                Try
                    bulkCopy.DestinationTableName = "GTAW_ABNORMALITY_LOG_DETAIL_STAG"

                    bulkCopy.ColumnMappings.Add(dt.Columns(1).ColumnName.ToString(), "edat")
                    bulkCopy.ColumnMappings.Add(dt.Columns(2).ColumnName.ToString(), "shop")
                    bulkCopy.ColumnMappings.Add(dt.Columns(3).ColumnName.ToString(), "stan")
                    bulkCopy.ColumnMappings.Add(dt.Columns(4).ColumnName.ToString(), "psno")
                    bulkCopy.ColumnMappings.Add(dt.Columns(5).ColumnName.ToString(), "cprj")
                    bulkCopy.ColumnMappings.Add(dt.Columns(6).ColumnName.ToString(), "seam")
                    bulkCopy.ColumnMappings.Add(dt.Columns(7).ColumnName.ToString(), "type")
                    bulkCopy.ColumnMappings.Add(dt.Columns(8).ColumnName.ToString(), "valu")
                    bulkCopy.ColumnMappings.Add(dt.Columns(9).ColumnName.ToString(), "rmin")
                    bulkCopy.ColumnMappings.Add(dt.Columns(10).ColumnName.ToString(), "rmax")
                    bulkCopy.ColumnMappings.Add(dt.Columns(11).ColumnName.ToString(), "scon")

                    bulkCopy.WriteToServer(dt)
                Catch ex As Exception
                    MessageBox.Show(ex.Message.ToString())
                End Try
            End Using
            con.Close()

        End Using
        Return i
    End Function

#Region "IDisposable Support"
    Private disposedValue As Boolean ' To detect redundant calls

    ' IDisposable
    Protected Overridable Sub Dispose(disposing As Boolean)
        If Not disposedValue Then
            If disposing Then
                ' TODO: dispose managed state (managed objects).
            End If

            ' TODO: free unmanaged resources (unmanaged objects) and override Finalize() below.
            ' TODO: set large fields to null.
        End If
        disposedValue = True
    End Sub

    ' TODO: override Finalize() only if Dispose(disposing As Boolean) above has code to free unmanaged resources.
    'Protected Overrides Sub Finalize()
    '    ' Do not change this code.  Put cleanup code in Dispose(disposing As Boolean) above.
    '    Dispose(False)
    '    MyBase.Finalize()
    'End Sub

    ' This code added by Visual Basic to correctly implement the disposable pattern.
    Public Sub Dispose() Implements IDisposable.Dispose
        ' Do not change this code.  Put cleanup code in Dispose(disposing As Boolean) above.
        Dispose(True)
        ' TODO: uncomment the following line if Finalize() is overridden above.
        ' GC.SuppressFinalize(Me)
    End Sub
#End Region

End Class
