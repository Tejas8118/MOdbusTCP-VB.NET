﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CmbProcess = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.CmbWedpol = New System.Windows.Forms.ComboBox()
        Me.cmbWPS = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbSeam = New System.Windows.Forms.ComboBox()
        Me.cmbPrj = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtSeam = New System.Windows.Forms.TextBox()
        Me.txtProject = New System.Windows.Forms.TextBox()
        Me.txtPSNo = New System.Windows.Forms.TextBox()
        Me.txtWName = New System.Windows.Forms.TextBox()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.txtStation = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtWPSNo = New System.Windows.Forms.TextBox()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.CmbProcess)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.CmbWedpol)
        Me.Panel1.Controls.Add(Me.cmbWPS)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.cmbSeam)
        Me.Panel1.Controls.Add(Me.cmbPrj)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.txtSeam)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.txtPSNo)
        Me.Panel1.Controls.Add(Me.txtWName)
        Me.Panel1.Controls.Add(Me.btnNext)
        Me.Panel1.Controls.Add(Me.txtStation)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.txtWPSNo)
        Me.Panel1.Location = New System.Drawing.Point(12, 10)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1276, 678)
        Me.Panel1.TabIndex = 1
        '
        'CmbProcess
        '
        Me.CmbProcess.Font = New System.Drawing.Font("Arial Narrow", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbProcess.FormattingEnabled = True
        Me.CmbProcess.Items.AddRange(New Object() {"3.5", "4", "5"})
        Me.CmbProcess.Location = New System.Drawing.Point(261, 154)
        Me.CmbProcess.Name = "CmbProcess"
        Me.CmbProcess.Size = New System.Drawing.Size(480, 34)
        Me.CmbProcess.TabIndex = 36
        '
        'Label10
        '
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label10.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label10.Location = New System.Drawing.Point(747, 154)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(233, 34)
        Me.Label10.TabIndex = 35
        Me.Label10.Text = "Welding Polarity"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'CmbWedpol
        '
        Me.CmbWedpol.AllowDrop = True
        Me.CmbWedpol.Font = New System.Drawing.Font("Arial Narrow", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbWedpol.FormattingEnabled = True
        Me.CmbWedpol.IntegralHeight = False
        Me.CmbWedpol.Location = New System.Drawing.Point(986, 154)
        Me.CmbWedpol.MaxDropDownItems = 10
        Me.CmbWedpol.Name = "CmbWedpol"
        Me.CmbWedpol.Size = New System.Drawing.Size(253, 34)
        Me.CmbWedpol.TabIndex = 34
        '
        'cmbWPS
        '
        Me.cmbWPS.Font = New System.Drawing.Font("Arial Narrow", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbWPS.FormattingEnabled = True
        Me.cmbWPS.IntegralHeight = False
        Me.cmbWPS.Location = New System.Drawing.Point(261, 382)
        Me.cmbWPS.MaxDropDownItems = 10
        Me.cmbWPS.Name = "cmbWPS"
        Me.cmbWPS.Size = New System.Drawing.Size(978, 34)
        Me.cmbWPS.TabIndex = 32
        Me.cmbWPS.Visible = False
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label2.Location = New System.Drawing.Point(22, 382)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(233, 34)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "WPS No."
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmbSeam
        '
        Me.cmbSeam.Font = New System.Drawing.Font("Arial Narrow", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbSeam.FormattingEnabled = True
        Me.cmbSeam.IntegralHeight = False
        Me.cmbSeam.Location = New System.Drawing.Point(261, 334)
        Me.cmbSeam.MaxDropDownItems = 10
        Me.cmbSeam.Name = "cmbSeam"
        Me.cmbSeam.Size = New System.Drawing.Size(978, 34)
        Me.cmbSeam.TabIndex = 29
        Me.cmbSeam.Visible = False
        '
        'cmbPrj
        '
        Me.cmbPrj.Font = New System.Drawing.Font("Arial Narrow", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbPrj.FormattingEnabled = True
        Me.cmbPrj.IntegralHeight = False
        Me.cmbPrj.Location = New System.Drawing.Point(261, 289)
        Me.cmbPrj.MaxDropDownItems = 10
        Me.cmbPrj.Name = "cmbPrj"
        Me.cmbPrj.Size = New System.Drawing.Size(978, 34)
        Me.cmbPrj.TabIndex = 28
        Me.cmbPrj.Visible = False
        '
        'Label9
        '
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label9.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label9.Location = New System.Drawing.Point(22, 334)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(233, 34)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "Seam No."
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label6.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label6.Location = New System.Drawing.Point(22, 289)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(233, 34)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = "Project No"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label7.Location = New System.Drawing.Point(22, 243)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(233, 33)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Welder P.S.No."
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label4.Location = New System.Drawing.Point(22, 199)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(233, 32)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Welder Name"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label5.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label5.Location = New System.Drawing.Point(22, 153)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(233, 34)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "Process"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Arial", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label3.Location = New System.Drawing.Point(22, 109)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(233, 32)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Station"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtSeam
        '
        Me.txtSeam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSeam.Font = New System.Drawing.Font("Arial Narrow", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSeam.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSeam.Location = New System.Drawing.Point(261, 334)
        Me.txtSeam.Name = "txtSeam"
        Me.txtSeam.Size = New System.Drawing.Size(978, 32)
        Me.txtSeam.TabIndex = 15
        '
        'txtProject
        '
        Me.txtProject.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtProject.Font = New System.Drawing.Font("Arial Narrow", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProject.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtProject.Location = New System.Drawing.Point(261, 290)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.Size = New System.Drawing.Size(978, 32)
        Me.txtProject.TabIndex = 14
        '
        'txtPSNo
        '
        Me.txtPSNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPSNo.Enabled = False
        Me.txtPSNo.Font = New System.Drawing.Font("Arial Narrow", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPSNo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.txtPSNo.Location = New System.Drawing.Point(261, 244)
        Me.txtPSNo.Name = "txtPSNo"
        Me.txtPSNo.Size = New System.Drawing.Size(978, 32)
        Me.txtPSNo.TabIndex = 13
        '
        'txtWName
        '
        Me.txtWName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWName.Enabled = False
        Me.txtWName.Font = New System.Drawing.Font("Arial Narrow", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtWName.Location = New System.Drawing.Point(261, 199)
        Me.txtWName.Name = "txtWName"
        Me.txtWName.Size = New System.Drawing.Size(978, 32)
        Me.txtWName.TabIndex = 12
        '
        'btnNext
        '
        Me.btnNext.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btnNext.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.btnNext.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnNext.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNext.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnNext.Location = New System.Drawing.Point(1063, 593)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(173, 64)
        Me.btnNext.TabIndex = 10
        Me.btnNext.Text = "Continue"
        Me.btnNext.UseVisualStyleBackColor = False
        '
        'txtStation
        '
        Me.txtStation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStation.Enabled = False
        Me.txtStation.Font = New System.Drawing.Font("Arial Narrow", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStation.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtStation.Location = New System.Drawing.Point(261, 109)
        Me.txtStation.Name = "txtStation"
        Me.txtStation.Size = New System.Drawing.Size(978, 32)
        Me.txtStation.TabIndex = 7
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.logo
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox1.Location = New System.Drawing.Point(3, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1268, 65)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'txtWPSNo
        '
        Me.txtWPSNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWPSNo.Font = New System.Drawing.Font("Arial Narrow", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWPSNo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWPSNo.Location = New System.Drawing.Point(261, 383)
        Me.txtWPSNo.Name = "txtWPSNo"
        Me.txtWPSNo.Size = New System.Drawing.Size(978, 32)
        Me.txtWPSNo.TabIndex = 33
        '
        'frmPS
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(1292, 700)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmPS"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmOne"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtStation As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtSeam As System.Windows.Forms.TextBox
    Friend WithEvents txtProject As System.Windows.Forms.TextBox
    Friend WithEvents txtPSNo As System.Windows.Forms.TextBox
    Friend WithEvents txtWName As System.Windows.Forms.TextBox
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents cmbSeam As System.Windows.Forms.ComboBox
    Friend WithEvents cmbPrj As System.Windows.Forms.ComboBox
    Friend WithEvents cmbWPS As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtWPSNo As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents CmbWedpol As ComboBox
    Friend WithEvents CmbProcess As ComboBox
End Class
