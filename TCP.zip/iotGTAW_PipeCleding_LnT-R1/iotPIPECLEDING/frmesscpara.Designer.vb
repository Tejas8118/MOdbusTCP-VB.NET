﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmesscpara
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmesscpara))
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btntrorap = New System.Windows.Forms.Button()
        Me.btntroslow = New System.Windows.Forms.Button()
        Me.MyKB1 = New myControls.myKB()
        Me.BtnClose = New System.Windows.Forms.Button()
        Me.BtnSave = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtxrapspeed = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtstpoverwidth = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtstrcutslide = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtyrapspeed = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtyslowspeed = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtyspeed = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtxslowspeed = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtxspeed = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.txttrorapspeed = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.txttroslowspeed = New System.Windows.Forms.TextBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.txttrospeed = New System.Windows.Forms.TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel6.Controls.Add(Me.Label18)
        Me.Panel6.Controls.Add(Me.Label6)
        Me.Panel6.Controls.Add(Me.Button11)
        Me.Panel6.Controls.Add(Me.Button10)
        Me.Panel6.Controls.Add(Me.Button9)
        Me.Panel6.Controls.Add(Me.Button8)
        Me.Panel6.Controls.Add(Me.Button7)
        Me.Panel6.Controls.Add(Me.Button6)
        Me.Panel6.Controls.Add(Me.Button5)
        Me.Panel6.Controls.Add(Me.Button4)
        Me.Panel6.Controls.Add(Me.Button3)
        Me.Panel6.Controls.Add(Me.btntrorap)
        Me.Panel6.Controls.Add(Me.btntroslow)
        Me.Panel6.Controls.Add(Me.MyKB1)
        Me.Panel6.Controls.Add(Me.BtnClose)
        Me.Panel6.Controls.Add(Me.BtnSave)
        Me.Panel6.Controls.Add(Me.Label17)
        Me.Panel6.Controls.Add(Me.Label16)
        Me.Panel6.Controls.Add(Me.txtxrapspeed)
        Me.Panel6.Controls.Add(Me.Label15)
        Me.Panel6.Controls.Add(Me.Label10)
        Me.Panel6.Controls.Add(Me.txtstpoverwidth)
        Me.Panel6.Controls.Add(Me.Label11)
        Me.Panel6.Controls.Add(Me.txtstrcutslide)
        Me.Panel6.Controls.Add(Me.Label12)
        Me.Panel6.Controls.Add(Me.txtyrapspeed)
        Me.Panel6.Controls.Add(Me.Label13)
        Me.Panel6.Controls.Add(Me.txtyslowspeed)
        Me.Panel6.Controls.Add(Me.Label14)
        Me.Panel6.Controls.Add(Me.txtyspeed)
        Me.Panel6.Controls.Add(Me.Label9)
        Me.Panel6.Controls.Add(Me.txtxslowspeed)
        Me.Panel6.Controls.Add(Me.Label8)
        Me.Panel6.Controls.Add(Me.txtxspeed)
        Me.Panel6.Controls.Add(Me.Label7)
        Me.Panel6.Controls.Add(Me.Label5)
        Me.Panel6.Controls.Add(Me.Label4)
        Me.Panel6.Controls.Add(Me.Label3)
        Me.Panel6.Controls.Add(Me.Label2)
        Me.Panel6.Controls.Add(Me.Label1)
        Me.Panel6.Controls.Add(Me.Label37)
        Me.Panel6.Controls.Add(Me.Label38)
        Me.Panel6.Controls.Add(Me.txttrorapspeed)
        Me.Panel6.Controls.Add(Me.Label44)
        Me.Panel6.Controls.Add(Me.Label50)
        Me.Panel6.Controls.Add(Me.txttroslowspeed)
        Me.Panel6.Controls.Add(Me.Label51)
        Me.Panel6.Controls.Add(Me.Label52)
        Me.Panel6.Controls.Add(Me.txttrospeed)
        Me.Panel6.Controls.Add(Me.Label53)
        Me.Panel6.Location = New System.Drawing.Point(14, 12)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(1138, 536)
        Me.Panel6.TabIndex = 65
        '
        'Button11
        '
        Me.Button11.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button11.Location = New System.Drawing.Point(969, 318)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(54, 35)
        Me.Button11.TabIndex = 140
        Me.Button11.Text = "Set"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button10.Location = New System.Drawing.Point(969, 273)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(54, 35)
        Me.Button10.TabIndex = 139
        Me.Button10.Text = "Set"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button9.Location = New System.Drawing.Point(439, 314)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(54, 35)
        Me.Button9.TabIndex = 138
        Me.Button9.Text = "Set"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button8.Location = New System.Drawing.Point(440, 274)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(54, 35)
        Me.Button8.TabIndex = 137
        Me.Button8.Text = "Set"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button7.Location = New System.Drawing.Point(814, 182)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(54, 35)
        Me.Button7.TabIndex = 136
        Me.Button7.Text = "Set"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button6.Location = New System.Drawing.Point(962, 139)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(54, 35)
        Me.Button6.TabIndex = 135
        Me.Button6.Text = "Set"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button5.Location = New System.Drawing.Point(962, 96)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(54, 35)
        Me.Button5.TabIndex = 134
        Me.Button5.Text = "Set"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button4.Location = New System.Drawing.Point(964, 49)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(54, 35)
        Me.Button4.TabIndex = 133
        Me.Button4.Text = "Set"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button3.Location = New System.Drawing.Point(426, 139)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(54, 35)
        Me.Button3.TabIndex = 132
        Me.Button3.Text = "Set"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btntrorap
        '
        Me.btntrorap.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.btntrorap.Location = New System.Drawing.Point(426, 95)
        Me.btntrorap.Name = "btntrorap"
        Me.btntrorap.Size = New System.Drawing.Size(54, 35)
        Me.btntrorap.TabIndex = 131
        Me.btntrorap.Text = "Set"
        Me.btntrorap.UseVisualStyleBackColor = True
        '
        'btntroslow
        '
        Me.btntroslow.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.btntroslow.Location = New System.Drawing.Point(426, 48)
        Me.btntroslow.Name = "btntroslow"
        Me.btntroslow.Size = New System.Drawing.Size(54, 35)
        Me.btntroslow.TabIndex = 130
        Me.btntroslow.Text = "Set"
        Me.btntroslow.UseVisualStyleBackColor = True
        '
        'MyKB1
        '
        Me.MyKB1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MyKB1.CurrTextBox = Nothing
        Me.MyKB1.Location = New System.Drawing.Point(23, 356)
        Me.MyKB1.Margin = New System.Windows.Forms.Padding(2)
        Me.MyKB1.Name = "MyKB1"
        Me.MyKB1.Size = New System.Drawing.Size(864, 175)
        Me.MyKB1.TabIndex = 129
        '
        'BtnClose
        '
        Me.BtnClose.BackgroundImage = CType(resources.GetObject("BtnClose.BackgroundImage"), System.Drawing.Image)
        Me.BtnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClose.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnClose.Location = New System.Drawing.Point(920, 458)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(185, 73)
        Me.BtnClose.TabIndex = 124
        Me.BtnClose.Text = "Cancel"
        Me.BtnClose.UseVisualStyleBackColor = True
        '
        'BtnSave
        '
        Me.BtnSave.BackgroundImage = CType(resources.GetObject("BtnSave.BackgroundImage"), System.Drawing.Image)
        Me.BtnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSave.ForeColor = System.Drawing.Color.Cornsilk
        Me.BtnSave.Location = New System.Drawing.Point(920, 364)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(185, 73)
        Me.BtnSave.TabIndex = 123
        Me.BtnSave.Text = "Save"
        Me.BtnSave.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label17.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label17.Location = New System.Drawing.Point(426, 179)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(247, 35)
        Me.Label17.TabIndex = 128
        Me.Label17.Text = "7. Strip Cutter Slide Speed"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(903, 140)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(47, 35)
        Me.Label16.TabIndex = 127
        Me.Label16.Text = "mm"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtxrapspeed
        '
        Me.txtxrapspeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtxrapspeed.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtxrapspeed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtxrapspeed.Location = New System.Drawing.Point(821, 49)
        Me.txtxrapspeed.Name = "txtxrapspeed"
        Me.txtxrapspeed.Size = New System.Drawing.Size(81, 35)
        Me.txtxrapspeed.TabIndex = 126
        Me.txtxrapspeed.Text = "0"
        '
        'Label15
        '
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label15.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label15.Location = New System.Drawing.Point(580, 94)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(234, 35)
        Me.Label15.TabIndex = 125
        Me.Label15.Text = "5. Y Slide Slow Speed"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(917, 318)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(46, 35)
        Me.Label10.TabIndex = 122
        Me.Label10.Text = "mm"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtstpoverwidth
        '
        Me.txtstpoverwidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtstpoverwidth.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstpoverwidth.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtstpoverwidth.Location = New System.Drawing.Point(836, 318)
        Me.txtstpoverwidth.Name = "txtstpoverwidth"
        Me.txtstpoverwidth.Size = New System.Drawing.Size(81, 35)
        Me.txtstpoverwidth.TabIndex = 121
        Me.txtstpoverwidth.Text = "0"
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(917, 273)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(46, 35)
        Me.Label11.TabIndex = 120
        Me.Label11.Text = "mm"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtstrcutslide
        '
        Me.txtstrcutslide.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtstrcutslide.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstrcutslide.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtstrcutslide.Location = New System.Drawing.Point(681, 180)
        Me.txtstrcutslide.Name = "txtstrcutslide"
        Me.txtstrcutslide.Size = New System.Drawing.Size(81, 35)
        Me.txtstrcutslide.TabIndex = 119
        Me.txtstrcutslide.Text = "0"
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(387, 313)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(46, 35)
        Me.Label12.TabIndex = 118
        Me.Label12.Text = "mm"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtyrapspeed
        '
        Me.txtyrapspeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtyrapspeed.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtyrapspeed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtyrapspeed.Location = New System.Drawing.Point(822, 140)
        Me.txtyrapspeed.Name = "txtyrapspeed"
        Me.txtyrapspeed.Size = New System.Drawing.Size(81, 35)
        Me.txtyrapspeed.TabIndex = 117
        Me.txtyrapspeed.Text = "0"
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(388, 272)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(46, 35)
        Me.Label13.TabIndex = 116
        Me.Label13.Text = "mm"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtyslowspeed
        '
        Me.txtyslowspeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtyslowspeed.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtyslowspeed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtyslowspeed.Location = New System.Drawing.Point(822, 94)
        Me.txtyslowspeed.Name = "txtyslowspeed"
        Me.txtyslowspeed.Size = New System.Drawing.Size(81, 35)
        Me.txtyslowspeed.TabIndex = 115
        Me.txtyslowspeed.Text = "0"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(762, 180)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(46, 35)
        Me.Label14.TabIndex = 114
        Me.Label14.Text = "mm"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtyspeed
        '
        Me.txtyspeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtyspeed.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtyspeed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtyspeed.Location = New System.Drawing.Point(306, 313)
        Me.txtyspeed.Name = "txtyspeed"
        Me.txtyspeed.Size = New System.Drawing.Size(81, 35)
        Me.txtyspeed.TabIndex = 113
        Me.txtyspeed.Text = "0"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(903, 94)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(47, 35)
        Me.Label9.TabIndex = 112
        Me.Label9.Text = "mm"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtxslowspeed
        '
        Me.txtxslowspeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtxslowspeed.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtxslowspeed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtxslowspeed.Location = New System.Drawing.Point(292, 139)
        Me.txtxslowspeed.Name = "txtxslowspeed"
        Me.txtxslowspeed.Size = New System.Drawing.Size(81, 35)
        Me.txtxslowspeed.TabIndex = 111
        Me.txtxslowspeed.Text = "0"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(902, 49)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(47, 35)
        Me.Label8.TabIndex = 110
        Me.Label8.Text = "mm"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtxspeed
        '
        Me.txtxspeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtxspeed.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtxspeed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtxspeed.Location = New System.Drawing.Point(307, 272)
        Me.txtxspeed.Name = "txtxspeed"
        Me.txtxspeed.Size = New System.Drawing.Size(81, 35)
        Me.txtxspeed.TabIndex = 109
        Me.txtxspeed.Text = "0"
        '
        'Label7
        '
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label7.Location = New System.Drawing.Point(583, 318)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(247, 35)
        Me.Label7.TabIndex = 108
        Me.Label7.Text = "11. Step Overlapping Width"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label5.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label5.Location = New System.Drawing.Point(583, 271)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(245, 35)
        Me.Label5.TabIndex = 106
        Me.Label5.Text = "10. Trolley Speed"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label4.Location = New System.Drawing.Point(53, 313)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(247, 35)
        Me.Label4.TabIndex = 105
        Me.Label4.Text = "9. Y Slide Speed"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label3.Location = New System.Drawing.Point(52, 271)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(247, 35)
        Me.Label3.TabIndex = 104
        Me.Label3.Text = "8. X Slide Speed"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label2.Location = New System.Drawing.Point(580, 139)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(234, 35)
        Me.Label2.TabIndex = 103
        Me.Label2.Text = "6. Y Slide Rapid Speed"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label1.Location = New System.Drawing.Point(581, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(234, 35)
        Me.Label1.TabIndex = 102
        Me.Label1.Text = "4. X Slide Rapid Speed"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label37
        '
        Me.Label37.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label37.Location = New System.Drawing.Point(0, 0)
        Me.Label37.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(1136, 38)
        Me.Label37.TabIndex = 82
        Me.Label37.Text = "For ESSC Parameter Setting"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label38
        '
        Me.Label38.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(373, 139)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(47, 35)
        Me.Label38.TabIndex = 74
        Me.Label38.Text = "mm"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txttrorapspeed
        '
        Me.txttrorapspeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttrorapspeed.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttrorapspeed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txttrorapspeed.Location = New System.Drawing.Point(292, 93)
        Me.txttrorapspeed.Name = "txttrorapspeed"
        Me.txttrorapspeed.Size = New System.Drawing.Size(81, 35)
        Me.txttrorapspeed.TabIndex = 73
        Me.txttrorapspeed.Text = "0"
        '
        'Label44
        '
        Me.Label44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label44.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label44.Location = New System.Drawing.Point(52, 138)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(234, 35)
        Me.Label44.TabIndex = 72
        Me.Label44.Text = "3. X Slide Slow Speed"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label50
        '
        Me.Label50.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(373, 93)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(47, 35)
        Me.Label50.TabIndex = 69
        Me.Label50.Text = "mm"
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txttroslowspeed
        '
        Me.txttroslowspeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttroslowspeed.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttroslowspeed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txttroslowspeed.Location = New System.Drawing.Point(292, 48)
        Me.txttroslowspeed.Name = "txttroslowspeed"
        Me.txttroslowspeed.Size = New System.Drawing.Size(81, 35)
        Me.txttroslowspeed.TabIndex = 68
        Me.txttroslowspeed.Text = "0"
        '
        'Label51
        '
        Me.Label51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label51.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label51.Location = New System.Drawing.Point(52, 92)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(234, 35)
        Me.Label51.TabIndex = 67
        Me.Label51.Text = "2. Trolley Rapid Speed"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label52
        '
        Me.Label52.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(373, 48)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(47, 35)
        Me.Label52.TabIndex = 64
        Me.Label52.Text = "mm"
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txttrospeed
        '
        Me.txttrospeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttrospeed.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttrospeed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txttrospeed.Location = New System.Drawing.Point(836, 273)
        Me.txttrospeed.Name = "txttrospeed"
        Me.txttrospeed.Size = New System.Drawing.Size(81, 35)
        Me.txttrospeed.TabIndex = 63
        Me.txttrospeed.Text = "0"
        '
        'Label53
        '
        Me.Label53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label53.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label53.Location = New System.Drawing.Point(52, 48)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(234, 35)
        Me.Label53.TabIndex = 62
        Me.Label53.Text = "1. Trolley Slow Speed"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(1, 219)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(557, 38)
        Me.Label6.TabIndex = 141
        Me.Label6.Text = "When Anti-drift tracking on"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label18.Location = New System.Drawing.Point(581, 219)
        Me.Label18.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(557, 38)
        Me.Label18.TabIndex = 142
        Me.Label18.Text = "When step overlay auto mode is on"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmesscpara
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1162, 560)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel6)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmesscpara"
        Me.Text = "frmesscpara"
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label10 As Label
    Friend WithEvents txtstpoverwidth As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txtstrcutslide As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txtyrapspeed As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtyslowspeed As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents txtyspeed As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtxslowspeed As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtxspeed As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents txttrorapspeed As TextBox
    Friend WithEvents Label44 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents txttroslowspeed As TextBox
    Friend WithEvents Label51 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents txttrospeed As TextBox
    Friend WithEvents Label53 As Label
    Friend WithEvents BtnSave As Button
    Friend WithEvents BtnClose As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents txtxrapspeed As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents MyKB1 As myControls.myKB
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents btntrorap As Button
    Friend WithEvents btntroslow As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Label18 As Label
    Friend WithEvents Label6 As Label
End Class
