﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmParaIT
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmParaIT))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.MyKB1 = New myControls.myKB()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.lblMachineActIP = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtMachineSetIP = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.txtFWLI = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtPLI = New System.Windows.Forms.TextBox()
        Me.txtPass = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.txtComRX = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.BtnSave1 = New System.Windows.Forms.Button()
        Me.txtSpeed = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtComTX = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtStation = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.txtShop = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtplcsetip = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtplcsetport = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Panel1.Controls.Add(Me.MyKB1)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1173, 716)
        Me.Panel1.TabIndex = 66
        '
        'MyKB1
        '
        Me.MyKB1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MyKB1.CurrTextBox = Nothing
        Me.MyKB1.Location = New System.Drawing.Point(141, 497)
        Me.MyKB1.Margin = New System.Windows.Forms.Padding(2)
        Me.MyKB1.Name = "MyKB1"
        Me.MyKB1.Size = New System.Drawing.Size(864, 194)
        Me.MyKB1.TabIndex = 68
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel2.Controls.Add(Me.txtplcsetport)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.txtplcsetip)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Button3)
        Me.Panel2.Controls.Add(Me.lblMachineActIP)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.txtMachineSetIP)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.Button1)
        Me.Panel2.Controls.Add(Me.ProgressBar2)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Location = New System.Drawing.Point(567, 22)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(438, 453)
        Me.Panel2.TabIndex = 67
        '
        'Button3
        '
        Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), System.Drawing.Image)
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.Cornsilk
        Me.Button3.Location = New System.Drawing.Point(175, 49)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(250, 73)
        Me.Button3.TabIndex = 115
        Me.Button3.Text = "Syncronise Welder List"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'lblMachineActIP
        '
        Me.lblMachineActIP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMachineActIP.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMachineActIP.ForeColor = System.Drawing.Color.DarkBlue
        Me.lblMachineActIP.Location = New System.Drawing.Point(175, 229)
        Me.lblMachineActIP.Name = "lblMachineActIP"
        Me.lblMachineActIP.Size = New System.Drawing.Size(260, 35)
        Me.lblMachineActIP.TabIndex = 114
        Me.lblMachineActIP.Text = "Machine Actual IP"
        Me.lblMachineActIP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label2.Location = New System.Drawing.Point(4, 229)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(165, 35)
        Me.Label2.TabIndex = 113
        Me.Label2.Text = "Machine Actual IP"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtMachineSetIP
        '
        Me.txtMachineSetIP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMachineSetIP.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMachineSetIP.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtMachineSetIP.Location = New System.Drawing.Point(175, 189)
        Me.txtMachineSetIP.Name = "txtMachineSetIP"
        Me.txtMachineSetIP.Size = New System.Drawing.Size(260, 35)
        Me.txtMachineSetIP.TabIndex = 112
        '
        'Label1
        '
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label1.Location = New System.Drawing.Point(4, 189)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(165, 35)
        Me.Label1.TabIndex = 111
        Me.Label1.Text = "Machine Set IP"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button1
        '
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Cornsilk
        Me.Button1.Location = New System.Drawing.Point(4, 49)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(154, 73)
        Me.Button1.TabIndex = 94
        Me.Button1.Text = "Syncronise Data"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Location = New System.Drawing.Point(3, 129)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(432, 23)
        Me.ProgressBar2.TabIndex = 93
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.Location = New System.Drawing.Point(0, 0)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(438, 38)
        Me.Label9.TabIndex = 82
        Me.Label9.Text = "Local Database"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel4.Controls.Add(Me.Button2)
        Me.Panel4.Controls.Add(Me.Label38)
        Me.Panel4.Controls.Add(Me.Label37)
        Me.Panel4.Controls.Add(Me.Label36)
        Me.Panel4.Controls.Add(Me.txtFWLI)
        Me.Panel4.Controls.Add(Me.Label34)
        Me.Panel4.Controls.Add(Me.txtPLI)
        Me.Panel4.Controls.Add(Me.txtPass)
        Me.Panel4.Controls.Add(Me.Label44)
        Me.Panel4.Controls.Add(Me.txtComRX)
        Me.Panel4.Controls.Add(Me.Label32)
        Me.Panel4.Controls.Add(Me.BtnSave1)
        Me.Panel4.Controls.Add(Me.txtSpeed)
        Me.Panel4.Controls.Add(Me.Label30)
        Me.Panel4.Controls.Add(Me.txtComTX)
        Me.Panel4.Controls.Add(Me.Label31)
        Me.Panel4.Controls.Add(Me.Label29)
        Me.Panel4.Controls.Add(Me.txtStation)
        Me.Panel4.Controls.Add(Me.Label33)
        Me.Panel4.Controls.Add(Me.txtShop)
        Me.Panel4.Controls.Add(Me.Label35)
        Me.Panel4.Location = New System.Drawing.Point(141, 22)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(418, 453)
        Me.Panel4.TabIndex = 66
        '
        'Button2
        '
        Me.Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), System.Drawing.Image)
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.Cornsilk
        Me.Button2.Location = New System.Drawing.Point(161, 371)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(142, 73)
        Me.Button2.TabIndex = 96
        Me.Button2.Text = "Cancel"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label38
        '
        Me.Label38.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(346, 330)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(59, 35)
        Me.Label38.TabIndex = 105
        Me.Label38.Text = "Sec"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label37
        '
        Me.Label37.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(346, 290)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(59, 35)
        Me.Label37.TabIndex = 104
        Me.Label37.Text = "Sec"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label36
        '
        Me.Label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label36.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label36.Location = New System.Drawing.Point(13, 330)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(225, 35)
        Me.Label36.TabIndex = 103
        Me.Label36.Text = "Flux Wght LogInterval "
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtFWLI
        '
        Me.txtFWLI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFWLI.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFWLI.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFWLI.Location = New System.Drawing.Point(244, 330)
        Me.txtFWLI.Name = "txtFWLI"
        Me.txtFWLI.Size = New System.Drawing.Size(103, 35)
        Me.txtFWLI.TabIndex = 102
        Me.txtFWLI.Text = "120"
        '
        'Label34
        '
        Me.Label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label34.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label34.Location = New System.Drawing.Point(13, 290)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(225, 35)
        Me.Label34.TabIndex = 101
        Me.Label34.Text = "Para LogInterval"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtPLI
        '
        Me.txtPLI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPLI.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPLI.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPLI.Location = New System.Drawing.Point(244, 290)
        Me.txtPLI.Name = "txtPLI"
        Me.txtPLI.Size = New System.Drawing.Size(103, 35)
        Me.txtPLI.TabIndex = 100
        Me.txtPLI.Text = "120"
        '
        'txtPass
        '
        Me.txtPass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPass.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPass.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPass.Location = New System.Drawing.Point(172, 250)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPass.Size = New System.Drawing.Size(233, 35)
        Me.txtPass.TabIndex = 96
        '
        'Label44
        '
        Me.Label44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label44.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label44.Location = New System.Drawing.Point(13, 250)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(152, 35)
        Me.Label44.TabIndex = 95
        Me.Label44.Text = "Password"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtComRX
        '
        Me.txtComRX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtComRX.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtComRX.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtComRX.Location = New System.Drawing.Point(172, 170)
        Me.txtComRX.Name = "txtComRX"
        Me.txtComRX.Size = New System.Drawing.Size(233, 35)
        Me.txtComRX.TabIndex = 91
        Me.txtComRX.Text = "2"
        '
        'Label32
        '
        Me.Label32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label32.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label32.Location = New System.Drawing.Point(13, 170)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(152, 35)
        Me.Label32.TabIndex = 90
        Me.Label32.Text = "COM Port RX"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'BtnSave1
        '
        Me.BtnSave1.BackgroundImage = CType(resources.GetObject("BtnSave1.BackgroundImage"), System.Drawing.Image)
        Me.BtnSave1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSave1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSave1.ForeColor = System.Drawing.Color.Cornsilk
        Me.BtnSave1.Location = New System.Drawing.Point(13, 370)
        Me.BtnSave1.Name = "BtnSave1"
        Me.BtnSave1.Size = New System.Drawing.Size(142, 73)
        Me.BtnSave1.TabIndex = 87
        Me.BtnSave1.Text = "Save"
        Me.BtnSave1.UseVisualStyleBackColor = True
        '
        'txtSpeed
        '
        Me.txtSpeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSpeed.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSpeed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpeed.Location = New System.Drawing.Point(172, 210)
        Me.txtSpeed.Name = "txtSpeed"
        Me.txtSpeed.Size = New System.Drawing.Size(233, 35)
        Me.txtSpeed.TabIndex = 86
        Me.txtSpeed.Text = "9600"
        '
        'Label30
        '
        Me.Label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label30.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label30.Location = New System.Drawing.Point(13, 210)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(152, 35)
        Me.Label30.TabIndex = 85
        Me.Label30.Text = "Speed"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtComTX
        '
        Me.txtComTX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtComTX.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtComTX.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtComTX.Location = New System.Drawing.Point(172, 130)
        Me.txtComTX.Name = "txtComTX"
        Me.txtComTX.Size = New System.Drawing.Size(233, 35)
        Me.txtComTX.TabIndex = 84
        Me.txtComTX.Text = "1"
        '
        'Label31
        '
        Me.Label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label31.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label31.Location = New System.Drawing.Point(13, 130)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(152, 35)
        Me.Label31.TabIndex = 83
        Me.Label31.Text = "COM Port TX"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label29.Location = New System.Drawing.Point(0, 0)
        Me.Label29.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(418, 38)
        Me.Label29.TabIndex = 82
        Me.Label29.Text = "For Station"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtStation
        '
        Me.txtStation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStation.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStation.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtStation.Location = New System.Drawing.Point(171, 89)
        Me.txtStation.Name = "txtStation"
        Me.txtStation.Size = New System.Drawing.Size(234, 35)
        Me.txtStation.TabIndex = 68
        '
        'Label33
        '
        Me.Label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label33.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label33.Location = New System.Drawing.Point(13, 89)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(152, 35)
        Me.Label33.TabIndex = 67
        Me.Label33.Text = "Station"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtShop
        '
        Me.txtShop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtShop.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShop.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtShop.Location = New System.Drawing.Point(171, 49)
        Me.txtShop.Name = "txtShop"
        Me.txtShop.Size = New System.Drawing.Size(234, 35)
        Me.txtShop.TabIndex = 63
        '
        'Label35
        '
        Me.Label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label35.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label35.Location = New System.Drawing.Point(13, 49)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(152, 35)
        Me.Label35.TabIndex = 62
        Me.Label35.Text = "Shop No"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtplcsetip
        '
        Me.txtplcsetip.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtplcsetip.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtplcsetip.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtplcsetip.Location = New System.Drawing.Point(175, 304)
        Me.txtplcsetip.Name = "txtplcsetip"
        Me.txtplcsetip.Size = New System.Drawing.Size(260, 35)
        Me.txtplcsetip.TabIndex = 117
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label3.Location = New System.Drawing.Point(4, 304)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(165, 35)
        Me.Label3.TabIndex = 116
        Me.Label3.Text = "Plc Set IP"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtplcsetport
        '
        Me.txtplcsetport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtplcsetport.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtplcsetport.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtplcsetport.Location = New System.Drawing.Point(175, 352)
        Me.txtplcsetport.Name = "txtplcsetport"
        Me.txtplcsetport.Size = New System.Drawing.Size(260, 35)
        Me.txtplcsetport.TabIndex = 119
        '
        'Label4
        '
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label4.Location = New System.Drawing.Point(4, 352)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(165, 35)
        Me.Label4.TabIndex = 118
        Me.Label4.Text = "Plc Set Port"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmParaIT
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(1197, 740)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmParaIT"
        Me.Text = "frmParaIT"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents MyKB1 As myControls.myKB
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ProgressBar2 As System.Windows.Forms.ProgressBar
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents txtFWLI As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents txtPLI As System.Windows.Forms.TextBox
    Friend WithEvents txtPass As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents txtComRX As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents BtnSave1 As System.Windows.Forms.Button
    Friend WithEvents txtSpeed As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents txtComTX As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtStation As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents txtShop As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents lblMachineActIP As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtMachineSetIP As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents txtplcsetip As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtplcsetport As TextBox
    Friend WithEvents Label4 As Label
End Class
