﻿Public Class frmwds
    Private Sub frmwds_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim DGVVerticalScroll = dgv1.Controls.OfType(Of VScrollBar).SingleOrDefault
        Dim DGVHorizontalScroll = dgv1.Controls.OfType(Of HScrollBar).SingleOrDefault

        DGVVerticalScroll.Width = 100
        dgv1.EnableHeadersVisualStyles = False

        If gOpMode = "live" Then
            Using myservice As New SQLDB()
                Try
                    'myservice.timeout = 2000
                    Dim err As String = ""
                    Dim z As DataTable = myservice.getWDSDetail(gprojectno, gseamno, gPROCESS)
                    dgv1.DataSource = z
                Catch ex As Exception
                    MessageBox.Show("Error in frmwds_Load method of frmfds module, Error : " + ex.Message.ToString())
                End Try
            End Using
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
    Private Sub dgv1_RowPostPaint(sender As Object, e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs)
        Dim cLineNumber As Integer = e.RowIndex + 1
        Dim xLocation As Integer = 0

        Select Case cLineNumber.ToString.Length
            Case 1
                xLocation = 20
            Case 2
                xLocation = 15
            Case 3
                xLocation = 10
            Case 4
                xLocation = 5
            Case Else
                xLocation = 2
        End Select

        Using b As SolidBrush = New SolidBrush(dgv1.RowHeadersDefaultCellStyle.ForeColor)
            e.Graphics.DrawString(cLineNumber.ToString(System.Globalization.CultureInfo.CurrentUICulture),
                                   dgv1.DefaultCellStyle.Font,
                                   b,
                                   e.RowBounds.Location.X + xLocation,
                                   e.RowBounds.Location.Y + 2)
        End Using
    End Sub
    Private Sub frmwds_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Me.Width = MDIParent1.Width - 100
        Me.Height = MDIParent1.Height - 150
        Me.Top = 30
        Me.Left = 50
        Panel1.Height = Me.Height - Panel2.Height - Label1.Height - 5
        Panel1.Width = Me.Width
        Panel2.Width = Me.Width
        Label1.Width = Me.Width
        Button1.Left = (Panel1.Width - Button1.Width) / 2
    End Sub
End Class