﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmalarm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmalarm))
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.txtFWmax = New System.Windows.Forms.TextBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.txtFWmin = New System.Windows.Forms.TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtrightmax = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.txtrightmin = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtWFmax = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtWFmin = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.txtGFmax = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.txtGFmin = New System.Windows.Forms.TextBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtJTMax = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtJTMin = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtTRSMax = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtTRSMin = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtWVMax = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtWVMin = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtWCMax = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtWCMin = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnClose = New System.Windows.Forms.Button()
        Me.BtnSave = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.MyKB1 = New myControls.myKB()
        Me.Panel2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel2.Controls.Add(Me.Label44)
        Me.Panel2.Controls.Add(Me.Label50)
        Me.Panel2.Controls.Add(Me.Label51)
        Me.Panel2.Controls.Add(Me.txtFWmax)
        Me.Panel2.Controls.Add(Me.Label52)
        Me.Panel2.Controls.Add(Me.txtFWmin)
        Me.Panel2.Controls.Add(Me.Label53)
        Me.Panel2.Controls.Add(Me.Label41)
        Me.Panel2.Controls.Add(Me.Label40)
        Me.Panel2.Controls.Add(Me.Label33)
        Me.Panel2.Controls.Add(Me.Label34)
        Me.Panel2.Controls.Add(Me.Label35)
        Me.Panel2.Controls.Add(Me.txtrightmax)
        Me.Panel2.Controls.Add(Me.Label37)
        Me.Panel2.Controls.Add(Me.txtrightmin)
        Me.Panel2.Controls.Add(Me.Label38)
        Me.Panel2.Controls.Add(Me.Label25)
        Me.Panel2.Controls.Add(Me.Label26)
        Me.Panel2.Controls.Add(Me.Label29)
        Me.Panel2.Controls.Add(Me.txtWFmax)
        Me.Panel2.Controls.Add(Me.Label30)
        Me.Panel2.Controls.Add(Me.txtWFmin)
        Me.Panel2.Controls.Add(Me.Label31)
        Me.Panel2.Controls.Add(Me.Label45)
        Me.Panel2.Controls.Add(Me.Label46)
        Me.Panel2.Controls.Add(Me.Label47)
        Me.Panel2.Controls.Add(Me.txtGFmax)
        Me.Panel2.Controls.Add(Me.Label48)
        Me.Panel2.Controls.Add(Me.txtGFmin)
        Me.Panel2.Controls.Add(Me.Label49)
        Me.Panel2.Controls.Add(Me.Label28)
        Me.Panel2.Controls.Add(Me.Label27)
        Me.Panel2.Controls.Add(Me.Label24)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Controls.Add(Me.Label18)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.txtJTMax)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.txtJTMin)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.txtTRSMax)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.txtTRSMin)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.txtWVMax)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.txtWVMin)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.txtWCMax)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.txtWCMin)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Panel1)
        Me.Panel2.Location = New System.Drawing.Point(12, 7)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(879, 431)
        Me.Panel2.TabIndex = 63
        '
        'Label44
        '
        Me.Label44.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(695, 373)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(68, 35)
        Me.Label44.TabIndex = 140
        Me.Label44.Text = "Deg"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label50
        '
        Me.Label50.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(435, 373)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(68, 35)
        Me.Label50.TabIndex = 139
        Me.Label50.Text = "Deg"
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label51
        '
        Me.Label51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label51.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label51.Location = New System.Drawing.Point(509, 373)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(67, 35)
        Me.Label51.TabIndex = 138
        Me.Label51.Text = "Max:"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtFWmax
        '
        Me.txtFWmax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFWmax.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFWmax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFWmax.Location = New System.Drawing.Point(580, 373)
        Me.txtFWmax.Name = "txtFWmax"
        Me.txtFWmax.Size = New System.Drawing.Size(116, 35)
        Me.txtFWmax.TabIndex = 137
        Me.txtFWmax.Text = "0"
        '
        'Label52
        '
        Me.Label52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label52.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label52.Location = New System.Drawing.Point(251, 373)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(67, 35)
        Me.Label52.TabIndex = 136
        Me.Label52.Text = "Min"
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtFWmin
        '
        Me.txtFWmin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFWmin.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFWmin.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFWmin.Location = New System.Drawing.Point(321, 373)
        Me.txtFWmin.Name = "txtFWmin"
        Me.txtFWmin.Size = New System.Drawing.Size(115, 35)
        Me.txtFWmin.TabIndex = 135
        Me.txtFWmin.Text = "0"
        '
        'Label53
        '
        Me.Label53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label53.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label53.Location = New System.Drawing.Point(13, 373)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(234, 35)
        Me.Label53.TabIndex = 134
        Me.Label53.Text = "8.  -------"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(587, 52)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(100, 24)
        Me.Label41.TabIndex = 131
        Me.Label41.Text = "Maximum"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(322, 52)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(95, 24)
        Me.Label40.TabIndex = 130
        Me.Label40.Text = "Minimum"
        '
        'Label33
        '
        Me.Label33.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(695, 330)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(68, 35)
        Me.Label33.TabIndex = 127
        Me.Label33.Text = "Deg"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label34
        '
        Me.Label34.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(435, 330)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(68, 35)
        Me.Label34.TabIndex = 126
        Me.Label34.Text = "Deg"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label35
        '
        Me.Label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label35.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label35.Location = New System.Drawing.Point(509, 330)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(67, 35)
        Me.Label35.TabIndex = 125
        Me.Label35.Text = "Max:"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtrightmax
        '
        Me.txtrightmax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtrightmax.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrightmax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtrightmax.Location = New System.Drawing.Point(580, 330)
        Me.txtrightmax.Name = "txtrightmax"
        Me.txtrightmax.Size = New System.Drawing.Size(116, 35)
        Me.txtrightmax.TabIndex = 124
        Me.txtrightmax.Text = "0"
        '
        'Label37
        '
        Me.Label37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label37.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label37.Location = New System.Drawing.Point(251, 330)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(67, 35)
        Me.Label37.TabIndex = 123
        Me.Label37.Text = "Min"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtrightmin
        '
        Me.txtrightmin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtrightmin.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrightmin.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtrightmin.Location = New System.Drawing.Point(321, 330)
        Me.txtrightmin.Name = "txtrightmin"
        Me.txtrightmin.Size = New System.Drawing.Size(115, 35)
        Me.txtrightmin.TabIndex = 122
        Me.txtrightmin.Text = "0"
        '
        'Label38
        '
        Me.Label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label38.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label38.Location = New System.Drawing.Point(13, 330)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(234, 35)
        Me.Label38.TabIndex = 121
        Me.Label38.Text = "7.  -----"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(695, 286)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(68, 35)
        Me.Label25.TabIndex = 118
        Me.Label25.Text = "Deg"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(435, 286)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(68, 35)
        Me.Label26.TabIndex = 117
        Me.Label26.Text = "Deg"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label29
        '
        Me.Label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label29.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label29.Location = New System.Drawing.Point(509, 286)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(67, 35)
        Me.Label29.TabIndex = 116
        Me.Label29.Text = "Max:"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtWFmax
        '
        Me.txtWFmax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWFmax.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWFmax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWFmax.Location = New System.Drawing.Point(580, 286)
        Me.txtWFmax.Name = "txtWFmax"
        Me.txtWFmax.Size = New System.Drawing.Size(116, 35)
        Me.txtWFmax.TabIndex = 115
        Me.txtWFmax.Text = "0"
        '
        'Label30
        '
        Me.Label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label30.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label30.Location = New System.Drawing.Point(251, 286)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(67, 35)
        Me.Label30.TabIndex = 114
        Me.Label30.Text = "Min"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtWFmin
        '
        Me.txtWFmin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWFmin.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWFmin.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWFmin.Location = New System.Drawing.Point(321, 286)
        Me.txtWFmin.Name = "txtWFmin"
        Me.txtWFmin.Size = New System.Drawing.Size(115, 35)
        Me.txtWFmin.TabIndex = 113
        Me.txtWFmin.Text = "0"
        '
        'Label31
        '
        Me.Label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label31.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label31.Location = New System.Drawing.Point(13, 286)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(234, 35)
        Me.Label31.TabIndex = 112
        Me.Label31.Text = "6. Wire Feed"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label45
        '
        Me.Label45.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(695, 243)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(68, 35)
        Me.Label45.TabIndex = 97
        Me.Label45.Text = "Deg"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label46
        '
        Me.Label46.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(435, 243)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(68, 35)
        Me.Label46.TabIndex = 96
        Me.Label46.Text = "Deg"
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label47
        '
        Me.Label47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label47.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label47.Location = New System.Drawing.Point(509, 243)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(67, 35)
        Me.Label47.TabIndex = 95
        Me.Label47.Text = "Max:"
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtGFmax
        '
        Me.txtGFmax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtGFmax.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGFmax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtGFmax.Location = New System.Drawing.Point(580, 243)
        Me.txtGFmax.Name = "txtGFmax"
        Me.txtGFmax.Size = New System.Drawing.Size(116, 35)
        Me.txtGFmax.TabIndex = 94
        Me.txtGFmax.Text = "0"
        '
        'Label48
        '
        Me.Label48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label48.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label48.Location = New System.Drawing.Point(251, 243)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(67, 35)
        Me.Label48.TabIndex = 93
        Me.Label48.Text = "Min"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtGFmin
        '
        Me.txtGFmin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtGFmin.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGFmin.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtGFmin.Location = New System.Drawing.Point(321, 243)
        Me.txtGFmin.Name = "txtGFmin"
        Me.txtGFmin.Size = New System.Drawing.Size(115, 35)
        Me.txtGFmin.TabIndex = 92
        Me.txtGFmin.Text = "0"
        '
        'Label49
        '
        Me.Label49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label49.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label49.Location = New System.Drawing.Point(13, 243)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(234, 35)
        Me.Label49.TabIndex = 91
        Me.Label49.Text = "5. Gas Flow"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(695, 203)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(68, 35)
        Me.Label28.TabIndex = 90
        Me.Label28.Text = "Deg"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(695, 163)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(68, 35)
        Me.Label27.TabIndex = 89
        Me.Label27.Text = "mm/min"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(695, 122)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(68, 35)
        Me.Label24.TabIndex = 88
        Me.Label24.Text = "Volts"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(435, 203)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(68, 35)
        Me.Label21.TabIndex = 87
        Me.Label21.Text = "Deg"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(435, 163)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(68, 35)
        Me.Label18.TabIndex = 86
        Me.Label18.Text = "mm/min"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(435, 122)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(68, 35)
        Me.Label17.TabIndex = 85
        Me.Label17.Text = "Volts"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(695, 81)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(68, 35)
        Me.Label16.TabIndex = 84
        Me.Label16.Text = "Amp"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(435, 81)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(68, 35)
        Me.Label15.TabIndex = 83
        Me.Label15.Text = "Amp"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(879, 38)
        Me.Label1.TabIndex = 82
        Me.Label1.Text = "For Alarm/Offset Setup"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label11.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label11.Location = New System.Drawing.Point(509, 203)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(67, 35)
        Me.Label11.TabIndex = 81
        Me.Label11.Text = "Max:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtJTMax
        '
        Me.txtJTMax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtJTMax.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtJTMax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtJTMax.Location = New System.Drawing.Point(580, 203)
        Me.txtJTMax.Name = "txtJTMax"
        Me.txtJTMax.Size = New System.Drawing.Size(116, 35)
        Me.txtJTMax.TabIndex = 80
        Me.txtJTMax.Text = "0"
        '
        'Label12
        '
        Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label12.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label12.Location = New System.Drawing.Point(251, 203)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(67, 35)
        Me.Label12.TabIndex = 79
        Me.Label12.Text = "Min"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtJTMin
        '
        Me.txtJTMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtJTMin.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtJTMin.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtJTMin.Location = New System.Drawing.Point(321, 203)
        Me.txtJTMin.Name = "txtJTMin"
        Me.txtJTMin.Size = New System.Drawing.Size(115, 35)
        Me.txtJTMin.TabIndex = 78
        Me.txtJTMin.Text = "0"
        '
        'Label13
        '
        Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label13.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label13.Location = New System.Drawing.Point(13, 203)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(234, 35)
        Me.Label13.TabIndex = 77
        Me.Label13.Text = "4. Job Temperature"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label8.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label8.Location = New System.Drawing.Point(509, 163)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(67, 35)
        Me.Label8.TabIndex = 76
        Me.Label8.Text = "Max:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtTRSMax
        '
        Me.txtTRSMax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTRSMax.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRSMax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTRSMax.Location = New System.Drawing.Point(580, 163)
        Me.txtTRSMax.Name = "txtTRSMax"
        Me.txtTRSMax.Size = New System.Drawing.Size(116, 35)
        Me.txtTRSMax.TabIndex = 75
        Me.txtTRSMax.Text = "0"
        '
        'Label9
        '
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label9.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label9.Location = New System.Drawing.Point(251, 163)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 35)
        Me.Label9.TabIndex = 74
        Me.Label9.Text = "Min"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtTRSMin
        '
        Me.txtTRSMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTRSMin.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRSMin.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTRSMin.Location = New System.Drawing.Point(321, 163)
        Me.txtTRSMin.Name = "txtTRSMin"
        Me.txtTRSMin.Size = New System.Drawing.Size(115, 35)
        Me.txtTRSMin.TabIndex = 73
        Me.txtTRSMin.Text = "0"
        '
        'Label10
        '
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label10.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label10.Location = New System.Drawing.Point(13, 163)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(234, 35)
        Me.Label10.TabIndex = 72
        Me.Label10.Text = "3. Travel Speed"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label5.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label5.Location = New System.Drawing.Point(509, 122)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 35)
        Me.Label5.TabIndex = 71
        Me.Label5.Text = "Max:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtWVMax
        '
        Me.txtWVMax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWVMax.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWVMax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWVMax.Location = New System.Drawing.Point(580, 122)
        Me.txtWVMax.Name = "txtWVMax"
        Me.txtWVMax.Size = New System.Drawing.Size(116, 35)
        Me.txtWVMax.TabIndex = 70
        Me.txtWVMax.Text = "0"
        '
        'Label6
        '
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label6.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label6.Location = New System.Drawing.Point(251, 122)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(67, 35)
        Me.Label6.TabIndex = 69
        Me.Label6.Text = "Min"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtWVMin
        '
        Me.txtWVMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWVMin.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWVMin.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWVMin.Location = New System.Drawing.Point(321, 122)
        Me.txtWVMin.Name = "txtWVMin"
        Me.txtWVMin.Size = New System.Drawing.Size(115, 35)
        Me.txtWVMin.TabIndex = 68
        Me.txtWVMin.Text = "0"
        '
        'Label7
        '
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label7.Location = New System.Drawing.Point(13, 122)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(234, 35)
        Me.Label7.TabIndex = 67
        Me.Label7.Text = "2. Welding Voltage"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label4.Location = New System.Drawing.Point(509, 81)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(67, 35)
        Me.Label4.TabIndex = 66
        Me.Label4.Text = "Max:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtWCMax
        '
        Me.txtWCMax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWCMax.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWCMax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWCMax.Location = New System.Drawing.Point(580, 81)
        Me.txtWCMax.Name = "txtWCMax"
        Me.txtWCMax.Size = New System.Drawing.Size(116, 35)
        Me.txtWCMax.TabIndex = 65
        Me.txtWCMax.Text = "0"
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label2.Location = New System.Drawing.Point(251, 81)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 35)
        Me.Label2.TabIndex = 64
        Me.Label2.Text = "Min"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtWCMin
        '
        Me.txtWCMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWCMin.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWCMin.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWCMin.Location = New System.Drawing.Point(321, 81)
        Me.txtWCMin.Name = "txtWCMin"
        Me.txtWCMin.Size = New System.Drawing.Size(115, 35)
        Me.txtWCMin.TabIndex = 63
        Me.txtWCMin.Text = "0"
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label3.Location = New System.Drawing.Point(13, 81)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(234, 35)
        Me.Label3.TabIndex = 62
        Me.Label3.Text = "1. Welding Current"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel1
        '
        Me.Panel1.Location = New System.Drawing.Point(-63, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(939, 426)
        Me.Panel1.TabIndex = 133
        '
        'BtnClose
        '
        Me.BtnClose.BackgroundImage = CType(resources.GetObject("BtnClose.BackgroundImage"), System.Drawing.Image)
        Me.BtnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClose.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnClose.Location = New System.Drawing.Point(17, 120)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(185, 73)
        Me.BtnClose.TabIndex = 99
        Me.BtnClose.Text = "Cancel"
        Me.BtnClose.UseVisualStyleBackColor = True
        '
        'BtnSave
        '
        Me.BtnSave.BackgroundImage = CType(resources.GetObject("BtnSave.BackgroundImage"), System.Drawing.Image)
        Me.BtnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSave.ForeColor = System.Drawing.Color.Cornsilk
        Me.BtnSave.Location = New System.Drawing.Point(17, 41)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(185, 73)
        Me.BtnSave.TabIndex = 98
        Me.BtnSave.Text = "Save"
        Me.BtnSave.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel4.Controls.Add(Me.Label39)
        Me.Panel4.Controls.Add(Me.BtnSave)
        Me.Panel4.Controls.Add(Me.BtnClose)
        Me.Panel4.Location = New System.Drawing.Point(897, 7)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(227, 431)
        Me.Panel4.TabIndex = 65
        '
        'Label39
        '
        Me.Label39.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label39.Location = New System.Drawing.Point(0, 0)
        Me.Label39.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(418, 38)
        Me.Label39.TabIndex = 82
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel5.Controls.Add(Me.MyKB1)
        Me.Panel5.Location = New System.Drawing.Point(12, 444)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1112, 189)
        Me.Panel5.TabIndex = 66
        '
        'MyKB1
        '
        Me.MyKB1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MyKB1.CurrTextBox = Nothing
        Me.MyKB1.Location = New System.Drawing.Point(143, 7)
        Me.MyKB1.Margin = New System.Windows.Forms.Padding(2)
        Me.MyKB1.Name = "MyKB1"
        Me.MyKB1.Size = New System.Drawing.Size(864, 175)
        Me.MyKB1.TabIndex = 0
        '
        'frmalarm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1184, 672)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel2)
        Me.Name = "frmalarm"
        Me.Text = "frmalarm"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label45 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents txtGFmax As TextBox
    Friend WithEvents Label48 As Label
    Friend WithEvents txtGFmin As TextBox
    Friend WithEvents Label49 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents txtJTMax As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txtJTMin As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtTRSMax As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtTRSMin As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtWVMax As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtWVMin As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtWCMax As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtWCMin As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents BtnClose As Button
    Friend WithEvents BtnSave As Button
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents txtrightmax As TextBox
    Friend WithEvents Label37 As Label
    Friend WithEvents txtrightmin As TextBox
    Friend WithEvents Label38 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents txtWFmax As TextBox
    Friend WithEvents Label30 As Label
    Friend WithEvents txtWFmin As TextBox
    Friend WithEvents Label31 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label39 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents MyKB1 As myControls.myKB
    Friend WithEvents Label41 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label44 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents txtFWmax As TextBox
    Friend WithEvents Label52 As Label
    Friend WithEvents txtFWmin As TextBox
    Friend WithEvents Label53 As Label
End Class
