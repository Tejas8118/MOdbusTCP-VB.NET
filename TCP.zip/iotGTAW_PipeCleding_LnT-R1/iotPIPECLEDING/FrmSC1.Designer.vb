﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmSC1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmSC1))
        Me.RectangleShape66 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape10 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.ShapeContainer6 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.ShapeContainer4 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.RectangleShape7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape9 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.tParalog = New System.Windows.Forms.Timer(Me.components)
        Me.btnesscoff = New System.Windows.Forms.Button()
        Me.btnesscon = New System.Windows.Forms.Button()
        Me.Weldingpass = New System.Windows.Forms.Panel()
        Me.btnpassok = New System.Windows.Forms.Button()
        Me.txtPass = New System.Windows.Forms.TextBox()
        Me.btnpassdn = New System.Windows.Forms.Button()
        Me.btnpassup = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.panelPara = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblAi8 = New System.Windows.Forms.TextBox()
        Me.lblGasflow2 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblJobTemp2 = New System.Windows.Forms.TextBox()
        Me.txtTRC1speed = New System.Windows.Forms.Label()
        Me.LblTRAVELSPEED = New System.Windows.Forms.TextBox()
        Me.lblVoltage2 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.lblGASFLOW = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblVoltage = New System.Windows.Forms.TextBox()
        Me.lblCurrent2 = New System.Windows.Forms.TextBox()
        Me.lblCurrent = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.PanelTRC = New System.Windows.Forms.Panel()
        Me.lblSpiral = New System.Windows.Forms.Label()
        Me.lblSagita = New System.Windows.Forms.Label()
        Me.lblNozzle = New System.Windows.Forms.Label()
        Me.lblBackface = New System.Windows.Forms.Label()
        Me.lblStep = New System.Windows.Forms.Label()
        Me.lblFlange = New System.Windows.Forms.Label()
        Me.lblRPOS = New System.Windows.Forms.TextBox()
        Me.lblAPOS = New System.Windows.Forms.TextBox()
        Me.lblTPOS = New System.Windows.Forms.TextBox()
        Me.lblALASTPOS = New System.Windows.Forms.TextBox()
        Me.lblTLASTPOS = New System.Windows.Forms.TextBox()
        Me.lblRLASTPOS = New System.Windows.Forms.TextBox()
        Me.lblRSPEED = New System.Windows.Forms.TextBox()
        Me.lblASPEED = New System.Windows.Forms.TextBox()
        Me.lblXPOS = New System.Windows.Forms.TextBox()
        Me.lblXLASTPOS = New System.Windows.Forms.TextBox()
        Me.lblTSPEED = New System.Windows.Forms.TextBox()
        Me.lblXSPEED = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblLocalDataPushStatus = New System.Windows.Forms.TextBox()
        Me.pBar = New System.Windows.Forms.ProgressBar()
        Me.lblLocalDataCount = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblLastBuildDate = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtIP = New System.Windows.Forms.Label()
        Me.txtStationNumber = New System.Windows.Forms.Label()
        Me.lblIP = New System.Windows.Forms.Label()
        Me.lblStationNumber = New System.Windows.Forms.Label()
        Me.txtpsno = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtwname = New System.Windows.Forms.Label()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnlayerok = New System.Windows.Forms.Button()
        Me.txtlayer = New System.Windows.Forms.TextBox()
        Me.btnlayerdn = New System.Windows.Forms.Button()
        Me.btnlayerup = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.lblpmb1 = New System.Windows.Forms.Label()
        Me.lblpmb4 = New System.Windows.Forms.Label()
        Me.lblpmb3 = New System.Windows.Forms.Label()
        Me.lblpmb5 = New System.Windows.Forms.Label()
        Me.lblpmb2 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.lblalarm = New System.Windows.Forms.Label()
        Me.lblfaulty = New System.Windows.Forms.Label()
        Me.lblAuto = New System.Windows.Forms.Label()
        Me.LblHealthy = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.btnresume = New System.Windows.Forms.Button()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.btnstop = New System.Windows.Forms.Button()
        Me.btnstart = New System.Windows.Forms.Button()
        Me.btndryweldrun = New System.Windows.Forms.Button()
        Me.btntag2 = New System.Windows.Forms.Button()
        Me.btntag1 = New System.Windows.Forms.Button()
        Me.btnauto = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.btnWELDB = New System.Windows.Forms.Button()
        Me.btnWIREFEEDB = New System.Windows.Forms.Button()
        Me.btnHOTWIREB = New System.Windows.Forms.Button()
        Me.btnAVCB = New System.Windows.Forms.Button()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.btnWELDA = New System.Windows.Forms.Button()
        Me.btnWIREFEEDA = New System.Windows.Forms.Button()
        Me.btnHOTWIREA = New System.Windows.Forms.Button()
        Me.btnAVCA = New System.Windows.Forms.Button()
        Me.Weldingpass.SuspendLayout()
        Me.panelPara.SuspendLayout()
        Me.PanelTRC.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'RectangleShape66
        '
        Me.RectangleShape66.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.RectangleShape66.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape66.BorderColor = System.Drawing.Color.DarkSalmon
        Me.RectangleShape66.BorderWidth = 2
        Me.RectangleShape66.CornerRadius = 5
        Me.RectangleShape66.FillColor = System.Drawing.SystemColors.Highlight
        Me.RectangleShape66.FillGradientStyle = Microsoft.VisualBasic.PowerPacks.FillGradientStyle.Horizontal
        Me.RectangleShape66.Location = New System.Drawing.Point(9, 40)
        Me.RectangleShape66.Name = "RectangleShape66"
        Me.RectangleShape66.Size = New System.Drawing.Size(337, 316)
        '
        'RectangleShape10
        '
        Me.RectangleShape10.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.RectangleShape10.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape10.BorderColor = System.Drawing.Color.DarkSalmon
        Me.RectangleShape10.BorderWidth = 2
        Me.RectangleShape10.CornerRadius = 5
        Me.RectangleShape10.FillColor = System.Drawing.SystemColors.Highlight
        Me.RectangleShape10.FillGradientStyle = Microsoft.VisualBasic.PowerPacks.FillGradientStyle.Horizontal
        Me.RectangleShape10.Location = New System.Drawing.Point(9, 40)
        Me.RectangleShape10.Name = "RectangleShape10"
        Me.RectangleShape10.Size = New System.Drawing.Size(105, 316)
        '
        'RectangleShape2
        '
        Me.RectangleShape2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.RectangleShape2.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape2.BorderColor = System.Drawing.Color.DarkSalmon
        Me.RectangleShape2.BorderWidth = 2
        Me.RectangleShape2.CornerRadius = 5
        Me.RectangleShape2.FillColor = System.Drawing.SystemColors.Highlight
        Me.RectangleShape2.FillGradientStyle = Microsoft.VisualBasic.PowerPacks.FillGradientStyle.Horizontal
        Me.RectangleShape2.Location = New System.Drawing.Point(130, 40)
        Me.RectangleShape2.Name = "RectangleShape2"
        Me.RectangleShape2.Size = New System.Drawing.Size(410, 316)
        '
        'ShapeContainer6
        '
        Me.ShapeContainer6.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer6.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer6.Name = "ShapeContainer6"
        Me.ShapeContainer6.Size = New System.Drawing.Size(145, 372)
        Me.ShapeContainer6.TabIndex = 21
        Me.ShapeContainer6.TabStop = False
        '
        'ShapeContainer4
        '
        Me.ShapeContainer4.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer4.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer4.Name = "ShapeContainer4"
        Me.ShapeContainer4.Size = New System.Drawing.Size(136, 372)
        Me.ShapeContainer4.TabIndex = 11
        Me.ShapeContainer4.TabStop = False
        '
        'RectangleShape7
        '
        Me.RectangleShape7.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.RectangleShape7.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape7.BorderColor = System.Drawing.Color.DarkSalmon
        Me.RectangleShape7.BorderWidth = 2
        Me.RectangleShape7.CornerRadius = 5
        Me.RectangleShape7.FillColor = System.Drawing.SystemColors.Highlight
        Me.RectangleShape7.FillGradientStyle = Microsoft.VisualBasic.PowerPacks.FillGradientStyle.Horizontal
        Me.RectangleShape7.Location = New System.Drawing.Point(9, 40)
        Me.RectangleShape7.Name = "RectangleShape7"
        Me.RectangleShape7.Size = New System.Drawing.Size(390, 316)
        '
        'RectangleShape9
        '
        Me.RectangleShape9.Location = New System.Drawing.Point(0, 0)
        Me.RectangleShape9.Name = ""
        Me.RectangleShape9.Size = New System.Drawing.Size(0, 0)
        '
        'RectangleShape8
        '
        Me.RectangleShape8.Location = New System.Drawing.Point(0, 0)
        Me.RectangleShape8.Name = ""
        Me.RectangleShape8.Size = New System.Drawing.Size(0, 0)
        '
        'RectangleShape3
        '
        Me.RectangleShape3.Location = New System.Drawing.Point(0, 0)
        Me.RectangleShape3.Name = ""
        Me.RectangleShape3.Size = New System.Drawing.Size(0, 0)
        '
        'tParalog
        '
        '
        'btnesscoff
        '
        Me.btnesscoff.BackColor = System.Drawing.Color.Transparent
        Me.btnesscoff.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnesscoff.Enabled = False
        Me.btnesscoff.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight
        Me.btnesscoff.FlatAppearance.BorderSize = 0
        Me.btnesscoff.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green
        Me.btnesscoff.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnesscoff.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnesscoff.Location = New System.Drawing.Point(21, 79)
        Me.btnesscoff.Margin = New System.Windows.Forms.Padding(6)
        Me.btnesscoff.Name = "btnesscoff"
        Me.btnesscoff.Size = New System.Drawing.Size(98, 98)
        Me.btnesscoff.TabIndex = 13
        Me.btnesscoff.UseVisualStyleBackColor = False
        '
        'btnesscon
        '
        Me.btnesscon.BackColor = System.Drawing.Color.Transparent
        Me.btnesscon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnesscon.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight
        Me.btnesscon.FlatAppearance.BorderSize = 0
        Me.btnesscon.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green
        Me.btnesscon.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnesscon.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnesscon.Location = New System.Drawing.Point(21, 206)
        Me.btnesscon.Margin = New System.Windows.Forms.Padding(6)
        Me.btnesscon.Name = "btnesscon"
        Me.btnesscon.Size = New System.Drawing.Size(98, 98)
        Me.btnesscon.TabIndex = 14
        Me.btnesscon.UseVisualStyleBackColor = False
        '
        'Weldingpass
        '
        Me.Weldingpass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Weldingpass.Controls.Add(Me.btnpassok)
        Me.Weldingpass.Controls.Add(Me.txtPass)
        Me.Weldingpass.Controls.Add(Me.btnpassdn)
        Me.Weldingpass.Controls.Add(Me.btnpassup)
        Me.Weldingpass.Controls.Add(Me.Label14)
        Me.Weldingpass.Location = New System.Drawing.Point(277, 1)
        Me.Weldingpass.Name = "Weldingpass"
        Me.Weldingpass.Size = New System.Drawing.Size(280, 125)
        Me.Weldingpass.TabIndex = 30
        '
        'btnpassok
        '
        Me.btnpassok.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnpassok.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnpassok.Enabled = False
        Me.btnpassok.Location = New System.Drawing.Point(107, 91)
        Me.btnpassok.Name = "btnpassok"
        Me.btnpassok.Size = New System.Drawing.Size(71, 31)
        Me.btnpassok.TabIndex = 54
        Me.btnpassok.Text = "OK"
        Me.btnpassok.UseVisualStyleBackColor = False
        '
        'txtPass
        '
        Me.txtPass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPass.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPass.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtPass.Location = New System.Drawing.Point(105, 41)
        Me.txtPass.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.Size = New System.Drawing.Size(77, 46)
        Me.txtPass.TabIndex = 53
        Me.txtPass.Text = "0"
        Me.txtPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnpassdn
        '
        Me.btnpassdn.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.btnpassdn.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.dnD
        Me.btnpassdn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnpassdn.Enabled = False
        Me.btnpassdn.FlatAppearance.BorderSize = 0
        Me.btnpassdn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpassdn.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpassdn.Location = New System.Drawing.Point(10, 46)
        Me.btnpassdn.Margin = New System.Windows.Forms.Padding(2)
        Me.btnpassdn.Name = "btnpassdn"
        Me.btnpassdn.Size = New System.Drawing.Size(68, 62)
        Me.btnpassdn.TabIndex = 52
        Me.btnpassdn.UseVisualStyleBackColor = False
        '
        'btnpassup
        '
        Me.btnpassup.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.btnpassup.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.upD
        Me.btnpassup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnpassup.Enabled = False
        Me.btnpassup.FlatAppearance.BorderSize = 0
        Me.btnpassup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpassup.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpassup.Location = New System.Drawing.Point(205, 46)
        Me.btnpassup.Margin = New System.Windows.Forms.Padding(2)
        Me.btnpassup.Name = "btnpassup"
        Me.btnpassup.Size = New System.Drawing.Size(68, 62)
        Me.btnpassup.TabIndex = 51
        Me.btnpassup.UseVisualStyleBackColor = False
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.SkyBlue
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label14.Location = New System.Drawing.Point(1, 2)
        Me.Label14.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(277, 32)
        Me.Label14.TabIndex = 50
        Me.Label14.Text = "Welding PASS No"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'panelPara
        '
        Me.panelPara.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.panelPara.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panelPara.Controls.Add(Me.Label2)
        Me.panelPara.Controls.Add(Me.lblAi8)
        Me.panelPara.Controls.Add(Me.lblGasflow2)
        Me.panelPara.Controls.Add(Me.Label3)
        Me.panelPara.Controls.Add(Me.lblJobTemp2)
        Me.panelPara.Controls.Add(Me.txtTRC1speed)
        Me.panelPara.Controls.Add(Me.LblTRAVELSPEED)
        Me.panelPara.Controls.Add(Me.lblVoltage2)
        Me.panelPara.Controls.Add(Me.Label22)
        Me.panelPara.Controls.Add(Me.lblGASFLOW)
        Me.panelPara.Controls.Add(Me.Label17)
        Me.panelPara.Controls.Add(Me.Label1)
        Me.panelPara.Controls.Add(Me.Label12)
        Me.panelPara.Controls.Add(Me.lblVoltage)
        Me.panelPara.Controls.Add(Me.lblCurrent2)
        Me.panelPara.Controls.Add(Me.lblCurrent)
        Me.panelPara.Controls.Add(Me.Label7)
        Me.panelPara.Controls.Add(Me.Label8)
        Me.panelPara.Controls.Add(Me.Label9)
        Me.panelPara.Location = New System.Drawing.Point(2, 6)
        Me.panelPara.Margin = New System.Windows.Forms.Padding(6)
        Me.panelPara.Name = "panelPara"
        Me.panelPara.Size = New System.Drawing.Size(245, 402)
        Me.panelPara.TabIndex = 10
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label2.Location = New System.Drawing.Point(9, 329)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 22)
        Me.Label2.TabIndex = 49
        Me.Label2.Text = "SPARE"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAi8
        '
        Me.lblAi8.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAi8.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAi8.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAi8.Location = New System.Drawing.Point(135, 324)
        Me.lblAi8.Margin = New System.Windows.Forms.Padding(2)
        Me.lblAi8.Name = "lblAi8"
        Me.lblAi8.Size = New System.Drawing.Size(93, 32)
        Me.lblAi8.TabIndex = 48
        Me.lblAi8.Text = "0000.0"
        '
        'lblGasflow2
        '
        Me.lblGasflow2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblGasflow2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGasflow2.ForeColor = System.Drawing.SystemColors.Info
        Me.lblGasflow2.Location = New System.Drawing.Point(135, 243)
        Me.lblGasflow2.Name = "lblGasflow2"
        Me.lblGasflow2.Size = New System.Drawing.Size(93, 31)
        Me.lblGasflow2.TabIndex = 47
        Me.lblGasflow2.Text = "0000.0"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label3.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Label3.Location = New System.Drawing.Point(9, 248)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 22)
        Me.Label3.TabIndex = 46
        Me.Label3.Text = "GAS FLOW-2"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblJobTemp2
        '
        Me.lblJobTemp2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblJobTemp2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJobTemp2.ForeColor = System.Drawing.SystemColors.Info
        Me.lblJobTemp2.Location = New System.Drawing.Point(135, 283)
        Me.lblJobTemp2.Margin = New System.Windows.Forms.Padding(2)
        Me.lblJobTemp2.Name = "lblJobTemp2"
        Me.lblJobTemp2.Size = New System.Drawing.Size(93, 32)
        Me.lblJobTemp2.TabIndex = 45
        Me.lblJobTemp2.Text = "0000.0"
        '
        'txtTRC1speed
        '
        Me.txtTRC1speed.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTRC1speed.ForeColor = System.Drawing.Color.DarkBlue
        Me.txtTRC1speed.Location = New System.Drawing.Point(9, 365)
        Me.txtTRC1speed.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.txtTRC1speed.Name = "txtTRC1speed"
        Me.txtTRC1speed.Size = New System.Drawing.Size(112, 22)
        Me.txtTRC1speed.TabIndex = 44
        Me.txtTRC1speed.Text = "TRAVEL SPEED"
        Me.txtTRC1speed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblTRAVELSPEED
        '
        Me.LblTRAVELSPEED.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.LblTRAVELSPEED.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTRAVELSPEED.ForeColor = System.Drawing.SystemColors.Info
        Me.LblTRAVELSPEED.Location = New System.Drawing.Point(135, 360)
        Me.LblTRAVELSPEED.Margin = New System.Windows.Forms.Padding(2)
        Me.LblTRAVELSPEED.Name = "LblTRAVELSPEED"
        Me.LblTRAVELSPEED.Size = New System.Drawing.Size(93, 32)
        Me.LblTRAVELSPEED.TabIndex = 43
        Me.LblTRAVELSPEED.Text = "0000.0"
        '
        'lblVoltage2
        '
        Me.lblVoltage2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblVoltage2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVoltage2.ForeColor = System.Drawing.SystemColors.Info
        Me.lblVoltage2.Location = New System.Drawing.Point(135, 161)
        Me.lblVoltage2.Margin = New System.Windows.Forms.Padding(2)
        Me.lblVoltage2.Name = "lblVoltage2"
        Me.lblVoltage2.Size = New System.Drawing.Size(93, 32)
        Me.lblVoltage2.TabIndex = 42
        Me.lblVoltage2.Text = "0000.0"
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label22.Location = New System.Drawing.Point(9, 161)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(112, 22)
        Me.Label22.TabIndex = 41
        Me.Label22.Text = "VOLTAGE-2"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGASFLOW
        '
        Me.lblGASFLOW.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblGASFLOW.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGASFLOW.ForeColor = System.Drawing.SystemColors.Info
        Me.lblGASFLOW.Location = New System.Drawing.Point(135, 201)
        Me.lblGASFLOW.Margin = New System.Windows.Forms.Padding(2)
        Me.lblGASFLOW.Name = "lblGASFLOW"
        Me.lblGASFLOW.Size = New System.Drawing.Size(93, 32)
        Me.lblGASFLOW.TabIndex = 40
        Me.lblGASFLOW.Text = "0000.0"
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label17.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label17.Location = New System.Drawing.Point(9, 288)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(112, 22)
        Me.Label17.TabIndex = 37
        Me.Label17.Text = "JOB TEMP"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Label1.Location = New System.Drawing.Point(9, 203)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 22)
        Me.Label1.TabIndex = 39
        Me.Label1.Text = "GAS FLOW-1"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.SkyBlue
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label12.Location = New System.Drawing.Point(-1, -1)
        Me.Label12.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(245, 35)
        Me.Label12.TabIndex = 15
        Me.Label12.Text = "Parameters"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblVoltage
        '
        Me.lblVoltage.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblVoltage.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVoltage.ForeColor = System.Drawing.SystemColors.Info
        Me.lblVoltage.Location = New System.Drawing.Point(135, 79)
        Me.lblVoltage.Margin = New System.Windows.Forms.Padding(2)
        Me.lblVoltage.Name = "lblVoltage"
        Me.lblVoltage.Size = New System.Drawing.Size(93, 32)
        Me.lblVoltage.TabIndex = 33
        Me.lblVoltage.Text = "0000.0"
        '
        'lblCurrent2
        '
        Me.lblCurrent2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblCurrent2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrent2.ForeColor = System.Drawing.SystemColors.Info
        Me.lblCurrent2.Location = New System.Drawing.Point(135, 119)
        Me.lblCurrent2.Margin = New System.Windows.Forms.Padding(2)
        Me.lblCurrent2.Name = "lblCurrent2"
        Me.lblCurrent2.Size = New System.Drawing.Size(93, 32)
        Me.lblCurrent2.TabIndex = 32
        Me.lblCurrent2.Text = "0000.0"
        '
        'lblCurrent
        '
        Me.lblCurrent.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblCurrent.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrent.ForeColor = System.Drawing.SystemColors.Info
        Me.lblCurrent.Location = New System.Drawing.Point(135, 40)
        Me.lblCurrent.Margin = New System.Windows.Forms.Padding(2)
        Me.lblCurrent.Name = "lblCurrent"
        Me.lblCurrent.Size = New System.Drawing.Size(93, 32)
        Me.lblCurrent.TabIndex = 31
        Me.lblCurrent.Text = "0000.0"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label7.Location = New System.Drawing.Point(9, 89)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(112, 22)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "VOLTAGE-1"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label8.Location = New System.Drawing.Point(9, 124)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(112, 22)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "CURRENT-2"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label9.Location = New System.Drawing.Point(9, 47)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(112, 22)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "CURRENT-1"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PanelTRC
        '
        Me.PanelTRC.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PanelTRC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PanelTRC.Controls.Add(Me.lblSpiral)
        Me.PanelTRC.Controls.Add(Me.lblSagita)
        Me.PanelTRC.Controls.Add(Me.lblNozzle)
        Me.PanelTRC.Controls.Add(Me.lblBackface)
        Me.PanelTRC.Controls.Add(Me.lblStep)
        Me.PanelTRC.Controls.Add(Me.lblFlange)
        Me.PanelTRC.Controls.Add(Me.lblRPOS)
        Me.PanelTRC.Controls.Add(Me.lblAPOS)
        Me.PanelTRC.Controls.Add(Me.lblTPOS)
        Me.PanelTRC.Controls.Add(Me.lblALASTPOS)
        Me.PanelTRC.Controls.Add(Me.lblTLASTPOS)
        Me.PanelTRC.Controls.Add(Me.lblRLASTPOS)
        Me.PanelTRC.Controls.Add(Me.lblRSPEED)
        Me.PanelTRC.Controls.Add(Me.lblASPEED)
        Me.PanelTRC.Controls.Add(Me.lblXPOS)
        Me.PanelTRC.Controls.Add(Me.lblXLASTPOS)
        Me.PanelTRC.Controls.Add(Me.lblTSPEED)
        Me.PanelTRC.Controls.Add(Me.lblXSPEED)
        Me.PanelTRC.Controls.Add(Me.Label19)
        Me.PanelTRC.Controls.Add(Me.Label16)
        Me.PanelTRC.Controls.Add(Me.Label15)
        Me.PanelTRC.Controls.Add(Me.Label13)
        Me.PanelTRC.Controls.Add(Me.Label11)
        Me.PanelTRC.Controls.Add(Me.Label6)
        Me.PanelTRC.Controls.Add(Me.Label5)
        Me.PanelTRC.Controls.Add(Me.Label4)
        Me.PanelTRC.Location = New System.Drawing.Point(253, 6)
        Me.PanelTRC.Margin = New System.Windows.Forms.Padding(6)
        Me.PanelTRC.Name = "PanelTRC"
        Me.PanelTRC.Size = New System.Drawing.Size(441, 402)
        Me.PanelTRC.TabIndex = 12
        '
        'lblSpiral
        '
        Me.lblSpiral.Image = Global.iotPIPECLEDING.My.Resources.Resources.spiral1
        Me.lblSpiral.Location = New System.Drawing.Point(259, 356)
        Me.lblSpiral.Name = "lblSpiral"
        Me.lblSpiral.Size = New System.Drawing.Size(87, 30)
        Me.lblSpiral.TabIndex = 52
        '
        'lblSagita
        '
        Me.lblSagita.Image = Global.iotPIPECLEDING.My.Resources.Resources.sagita1
        Me.lblSagita.Location = New System.Drawing.Point(350, 353)
        Me.lblSagita.Name = "lblSagita"
        Me.lblSagita.Size = New System.Drawing.Size(87, 30)
        Me.lblSagita.TabIndex = 51
        Me.lblSagita.Visible = False
        '
        'lblNozzle
        '
        Me.lblNozzle.Image = Global.iotPIPECLEDING.My.Resources.Resources.nozzle1
        Me.lblNozzle.Location = New System.Drawing.Point(157, 306)
        Me.lblNozzle.Name = "lblNozzle"
        Me.lblNozzle.Size = New System.Drawing.Size(87, 30)
        Me.lblNozzle.TabIndex = 50
        '
        'lblBackface
        '
        Me.lblBackface.Image = Global.iotPIPECLEDING.My.Resources.Resources.backface1
        Me.lblBackface.Location = New System.Drawing.Point(286, 304)
        Me.lblBackface.Name = "lblBackface"
        Me.lblBackface.Size = New System.Drawing.Size(87, 30)
        Me.lblBackface.TabIndex = 49
        Me.lblBackface.Visible = False
        '
        'lblStep
        '
        Me.lblStep.Image = Global.iotPIPECLEDING.My.Resources.Resources.step1
        Me.lblStep.Location = New System.Drawing.Point(47, 359)
        Me.lblStep.Name = "lblStep"
        Me.lblStep.Size = New System.Drawing.Size(87, 30)
        Me.lblStep.TabIndex = 48
        '
        'lblFlange
        '
        Me.lblFlange.Image = Global.iotPIPECLEDING.My.Resources.Resources.flange1
        Me.lblFlange.Location = New System.Drawing.Point(14, 306)
        Me.lblFlange.Name = "lblFlange"
        Me.lblFlange.Size = New System.Drawing.Size(87, 30)
        Me.lblFlange.TabIndex = 47
        Me.lblFlange.Visible = False
        '
        'lblRPOS
        '
        Me.lblRPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblRPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblRPOS.Location = New System.Drawing.Point(196, 236)
        Me.lblRPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblRPOS.Name = "lblRPOS"
        Me.lblRPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblRPOS.TabIndex = 46
        Me.lblRPOS.Text = "0000.0"
        '
        'lblAPOS
        '
        Me.lblAPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAPOS.Location = New System.Drawing.Point(197, 179)
        Me.lblAPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblAPOS.Name = "lblAPOS"
        Me.lblAPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblAPOS.TabIndex = 45
        Me.lblAPOS.Text = "0000.0"
        '
        'lblTPOS
        '
        Me.lblTPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblTPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblTPOS.Location = New System.Drawing.Point(197, 127)
        Me.lblTPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblTPOS.Name = "lblTPOS"
        Me.lblTPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblTPOS.TabIndex = 44
        Me.lblTPOS.Text = "0000.0"
        '
        'lblALASTPOS
        '
        Me.lblALASTPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblALASTPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblALASTPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblALASTPOS.Location = New System.Drawing.Point(317, 179)
        Me.lblALASTPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblALASTPOS.Name = "lblALASTPOS"
        Me.lblALASTPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblALASTPOS.TabIndex = 43
        Me.lblALASTPOS.Text = "0000.0"
        '
        'lblTLASTPOS
        '
        Me.lblTLASTPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblTLASTPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTLASTPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblTLASTPOS.Location = New System.Drawing.Point(317, 127)
        Me.lblTLASTPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblTLASTPOS.Name = "lblTLASTPOS"
        Me.lblTLASTPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblTLASTPOS.TabIndex = 42
        Me.lblTLASTPOS.Text = "0000.0"
        '
        'lblRLASTPOS
        '
        Me.lblRLASTPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblRLASTPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRLASTPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblRLASTPOS.Location = New System.Drawing.Point(315, 236)
        Me.lblRLASTPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblRLASTPOS.Name = "lblRLASTPOS"
        Me.lblRLASTPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblRLASTPOS.TabIndex = 41
        Me.lblRLASTPOS.Text = "0000.0"
        '
        'lblRSPEED
        '
        Me.lblRSPEED.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblRSPEED.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRSPEED.ForeColor = System.Drawing.SystemColors.Info
        Me.lblRSPEED.Location = New System.Drawing.Point(77, 236)
        Me.lblRSPEED.Margin = New System.Windows.Forms.Padding(2)
        Me.lblRSPEED.Name = "lblRSPEED"
        Me.lblRSPEED.Size = New System.Drawing.Size(93, 32)
        Me.lblRSPEED.TabIndex = 40
        Me.lblRSPEED.Text = "0000.0"
        '
        'lblASPEED
        '
        Me.lblASPEED.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblASPEED.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblASPEED.ForeColor = System.Drawing.SystemColors.Info
        Me.lblASPEED.Location = New System.Drawing.Point(81, 179)
        Me.lblASPEED.Margin = New System.Windows.Forms.Padding(2)
        Me.lblASPEED.Name = "lblASPEED"
        Me.lblASPEED.Size = New System.Drawing.Size(93, 32)
        Me.lblASPEED.TabIndex = 39
        Me.lblASPEED.Text = "0000.0"
        '
        'lblXPOS
        '
        Me.lblXPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblXPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblXPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblXPOS.Location = New System.Drawing.Point(199, 69)
        Me.lblXPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblXPOS.Name = "lblXPOS"
        Me.lblXPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblXPOS.TabIndex = 38
        Me.lblXPOS.Text = "0000.0"
        '
        'lblXLASTPOS
        '
        Me.lblXLASTPOS.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblXLASTPOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblXLASTPOS.ForeColor = System.Drawing.SystemColors.Info
        Me.lblXLASTPOS.Location = New System.Drawing.Point(317, 69)
        Me.lblXLASTPOS.Margin = New System.Windows.Forms.Padding(2)
        Me.lblXLASTPOS.Name = "lblXLASTPOS"
        Me.lblXLASTPOS.Size = New System.Drawing.Size(93, 32)
        Me.lblXLASTPOS.TabIndex = 37
        Me.lblXLASTPOS.Text = "0000.0"
        '
        'lblTSPEED
        '
        Me.lblTSPEED.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblTSPEED.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTSPEED.ForeColor = System.Drawing.SystemColors.Info
        Me.lblTSPEED.Location = New System.Drawing.Point(81, 127)
        Me.lblTSPEED.Margin = New System.Windows.Forms.Padding(2)
        Me.lblTSPEED.Name = "lblTSPEED"
        Me.lblTSPEED.Size = New System.Drawing.Size(93, 32)
        Me.lblTSPEED.TabIndex = 34
        Me.lblTSPEED.Text = "0000.0"
        '
        'lblXSPEED
        '
        Me.lblXSPEED.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblXSPEED.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblXSPEED.ForeColor = System.Drawing.SystemColors.Info
        Me.lblXSPEED.Location = New System.Drawing.Point(81, 69)
        Me.lblXSPEED.Margin = New System.Windows.Forms.Padding(2)
        Me.lblXSPEED.Name = "lblXSPEED"
        Me.lblXSPEED.Size = New System.Drawing.Size(93, 32)
        Me.lblXSPEED.TabIndex = 32
        Me.lblXSPEED.Text = "0000.0"
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label19.Location = New System.Drawing.Point(320, 44)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(82, 24)
        Me.Label19.TabIndex = 14
        Me.Label19.Text = "LAST POS."
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label16.Location = New System.Drawing.Point(205, 43)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(77, 22)
        Me.Label16.TabIndex = 13
        Me.Label16.Text = "POSITION"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label15.Location = New System.Drawing.Point(98, 40)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(55, 24)
        Me.Label15.TabIndex = 12
        Me.Label15.Text = "SPEED"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label13.Location = New System.Drawing.Point(9, 244)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(54, 18)
        Me.Label13.TabIndex = 11
        Me.Label13.Text = "R-AXIS"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label11.Location = New System.Drawing.Point(9, 189)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(54, 18)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "A-AXIS"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label6.Location = New System.Drawing.Point(9, 135)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 18)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "T-AXIS"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label5.Location = New System.Drawing.Point(9, 76)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 18)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "X-AXIS"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.SkyBlue
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(1, 0)
        Me.Label4.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(439, 35)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Axis  Position"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.lblLocalDataPushStatus)
        Me.Panel2.Controls.Add(Me.pBar)
        Me.Panel2.Controls.Add(Me.lblLocalDataCount)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.lblLastBuildDate)
        Me.Panel2.Controls.Add(Me.Label25)
        Me.Panel2.Controls.Add(Me.Weldingpass)
        Me.Panel2.Controls.Add(Me.txtIP)
        Me.Panel2.Controls.Add(Me.txtStationNumber)
        Me.Panel2.Controls.Add(Me.lblIP)
        Me.Panel2.Controls.Add(Me.lblStationNumber)
        Me.Panel2.Controls.Add(Me.txtpsno)
        Me.Panel2.Controls.Add(Me.Label18)
        Me.Panel2.Controls.Add(Me.Label20)
        Me.Panel2.Controls.Add(Me.txtwname)
        Me.Panel2.Controls.Add(Me.btnLogout)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Controls.Add(Me.btnLogin)
        Me.Panel2.Location = New System.Drawing.Point(700, 6)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(6)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(565, 402)
        Me.Panel2.TabIndex = 29
        '
        'lblLocalDataPushStatus
        '
        Me.lblLocalDataPushStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLocalDataPushStatus.ForeColor = System.Drawing.Color.Red
        Me.lblLocalDataPushStatus.Location = New System.Drawing.Point(13, 344)
        Me.lblLocalDataPushStatus.Name = "lblLocalDataPushStatus"
        Me.lblLocalDataPushStatus.Size = New System.Drawing.Size(538, 23)
        Me.lblLocalDataPushStatus.TabIndex = 75
        Me.lblLocalDataPushStatus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.lblLocalDataPushStatus.Visible = False
        '
        'pBar
        '
        Me.pBar.Location = New System.Drawing.Point(13, 367)
        Me.pBar.Name = "pBar"
        Me.pBar.Size = New System.Drawing.Size(538, 23)
        Me.pBar.TabIndex = 74
        Me.pBar.Visible = False
        '
        'lblLocalDataCount
        '
        Me.lblLocalDataCount.AutoSize = True
        Me.lblLocalDataCount.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold)
        Me.lblLocalDataCount.ForeColor = System.Drawing.Color.Crimson
        Me.lblLocalDataCount.Location = New System.Drawing.Point(148, 258)
        Me.lblLocalDataCount.Name = "lblLocalDataCount"
        Me.lblLocalDataCount.Size = New System.Drawing.Size(126, 16)
        Me.lblLocalDataCount.TabIndex = 73
        Me.lblLocalDataCount.Text = "Local Data Count"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold)
        Me.Label10.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label10.Location = New System.Drawing.Point(10, 258)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(134, 16)
        Me.Label10.TabIndex = 72
        Me.Label10.Text = "Local Data Count :"
        '
        'lblLastBuildDate
        '
        Me.lblLastBuildDate.AutoSize = True
        Me.lblLastBuildDate.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold)
        Me.lblLastBuildDate.ForeColor = System.Drawing.Color.Crimson
        Me.lblLastBuildDate.Location = New System.Drawing.Point(148, 239)
        Me.lblLastBuildDate.Name = "lblLastBuildDate"
        Me.lblLastBuildDate.Size = New System.Drawing.Size(113, 16)
        Me.lblLastBuildDate.TabIndex = 71
        Me.lblLastBuildDate.Text = "Last Build Date"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold)
        Me.Label25.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label25.Location = New System.Drawing.Point(23, 239)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(121, 16)
        Me.Label25.TabIndex = 70
        Me.Label25.Text = "Last Build Date :"
        '
        'txtIP
        '
        Me.txtIP.AutoSize = True
        Me.txtIP.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold)
        Me.txtIP.ForeColor = System.Drawing.Color.Crimson
        Me.txtIP.Location = New System.Drawing.Point(148, 219)
        Me.txtIP.Name = "txtIP"
        Me.txtIP.Size = New System.Drawing.Size(108, 16)
        Me.txtIP.TabIndex = 69
        Me.txtIP.Text = "IP / Host Name"
        '
        'txtStationNumber
        '
        Me.txtStationNumber.AutoSize = True
        Me.txtStationNumber.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold)
        Me.txtStationNumber.ForeColor = System.Drawing.Color.Crimson
        Me.txtStationNumber.Location = New System.Drawing.Point(148, 198)
        Me.txtStationNumber.Name = "txtStationNumber"
        Me.txtStationNumber.Size = New System.Drawing.Size(116, 16)
        Me.txtStationNumber.TabIndex = 68
        Me.txtStationNumber.Text = "Station Number"
        '
        'lblIP
        '
        Me.lblIP.AutoSize = True
        Me.lblIP.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold)
        Me.lblIP.ForeColor = System.Drawing.Color.DarkBlue
        Me.lblIP.Location = New System.Drawing.Point(28, 219)
        Me.lblIP.Name = "lblIP"
        Me.lblIP.Size = New System.Drawing.Size(116, 16)
        Me.lblIP.TabIndex = 67
        Me.lblIP.Text = "IP / Host Name :"
        '
        'lblStationNumber
        '
        Me.lblStationNumber.AutoSize = True
        Me.lblStationNumber.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold)
        Me.lblStationNumber.ForeColor = System.Drawing.Color.DarkBlue
        Me.lblStationNumber.Location = New System.Drawing.Point(20, 198)
        Me.lblStationNumber.Name = "lblStationNumber"
        Me.lblStationNumber.Size = New System.Drawing.Size(124, 16)
        Me.lblStationNumber.TabIndex = 66
        Me.lblStationNumber.Text = "Station Number :"
        '
        'txtpsno
        '
        Me.txtpsno.AutoSize = True
        Me.txtpsno.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold)
        Me.txtpsno.ForeColor = System.Drawing.Color.Crimson
        Me.txtpsno.Location = New System.Drawing.Point(146, 178)
        Me.txtpsno.Name = "txtpsno"
        Me.txtpsno.Size = New System.Drawing.Size(45, 16)
        Me.txtpsno.TabIndex = 44
        Me.txtpsno.Text = "PSNo"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold)
        Me.Label18.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label18.Location = New System.Drawing.Point(87, 178)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(57, 16)
        Me.Label18.TabIndex = 43
        Me.Label18.Text = "PS No :"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold)
        Me.Label20.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label20.Location = New System.Drawing.Point(35, 159)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(109, 16)
        Me.Label20.TabIndex = 42
        Me.Label20.Text = "Welder Name :"
        '
        'txtwname
        '
        Me.txtwname.AutoSize = True
        Me.txtwname.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Bold)
        Me.txtwname.ForeColor = System.Drawing.Color.Crimson
        Me.txtwname.Location = New System.Drawing.Point(145, 159)
        Me.txtwname.Name = "txtwname"
        Me.txtwname.Size = New System.Drawing.Size(101, 16)
        Me.txtwname.TabIndex = 41
        Me.txtwname.Text = "Welder Name"
        '
        'btnLogout
        '
        Me.btnLogout.BackColor = System.Drawing.Color.Gray
        Me.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnLogout.Enabled = False
        Me.btnLogout.Font = New System.Drawing.Font("Arial", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogout.Location = New System.Drawing.Point(306, 283)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(218, 52)
        Me.btnLogout.TabIndex = 40
        Me.btnLogout.Text = "Log Off"
        Me.btnLogout.UseVisualStyleBackColor = False
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.SkyBlue
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label21.Location = New System.Drawing.Point(-1, 128)
        Me.Label21.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(562, 27)
        Me.Label21.TabIndex = 4
        Me.Label21.Text = "Login Display"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnLogin
        '
        Me.btnLogin.BackColor = System.Drawing.Color.SkyBlue
        Me.btnLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnLogin.Font = New System.Drawing.Font("Arial", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogin.ForeColor = System.Drawing.Color.Black
        Me.btnLogin.Location = New System.Drawing.Point(32, 284)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(218, 52)
        Me.btnLogin.TabIndex = 39
        Me.btnLogin.Text = "Log In"
        Me.btnLogin.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnlayerok)
        Me.Panel3.Controls.Add(Me.txtlayer)
        Me.Panel3.Controls.Add(Me.btnlayerdn)
        Me.Panel3.Controls.Add(Me.btnlayerup)
        Me.Panel3.Controls.Add(Me.Label23)
        Me.Panel3.Location = New System.Drawing.Point(701, 12)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(270, 125)
        Me.Panel3.TabIndex = 31
        '
        'btnlayerok
        '
        Me.btnlayerok.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnlayerok.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnlayerok.Enabled = False
        Me.btnlayerok.Location = New System.Drawing.Point(98, 91)
        Me.btnlayerok.Name = "btnlayerok"
        Me.btnlayerok.Size = New System.Drawing.Size(71, 31)
        Me.btnlayerok.TabIndex = 83
        Me.btnlayerok.Text = "OK"
        Me.btnlayerok.UseVisualStyleBackColor = False
        '
        'txtlayer
        '
        Me.txtlayer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtlayer.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlayer.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtlayer.Location = New System.Drawing.Point(95, 41)
        Me.txtlayer.Margin = New System.Windows.Forms.Padding(2)
        Me.txtlayer.Name = "txtlayer"
        Me.txtlayer.Size = New System.Drawing.Size(77, 46)
        Me.txtlayer.TabIndex = 82
        Me.txtlayer.Text = "0"
        Me.txtlayer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnlayerdn
        '
        Me.btnlayerdn.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.btnlayerdn.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.dnD
        Me.btnlayerdn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnlayerdn.Enabled = False
        Me.btnlayerdn.FlatAppearance.BorderSize = 0
        Me.btnlayerdn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlayerdn.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnlayerdn.Location = New System.Drawing.Point(8, 46)
        Me.btnlayerdn.Margin = New System.Windows.Forms.Padding(2)
        Me.btnlayerdn.Name = "btnlayerdn"
        Me.btnlayerdn.Size = New System.Drawing.Size(68, 62)
        Me.btnlayerdn.TabIndex = 81
        Me.btnlayerdn.UseVisualStyleBackColor = False
        '
        'btnlayerup
        '
        Me.btnlayerup.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.btnlayerup.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.upD
        Me.btnlayerup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnlayerup.Enabled = False
        Me.btnlayerup.FlatAppearance.BorderSize = 0
        Me.btnlayerup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlayerup.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnlayerup.Location = New System.Drawing.Point(192, 46)
        Me.btnlayerup.Margin = New System.Windows.Forms.Padding(2)
        Me.btnlayerup.Name = "btnlayerup"
        Me.btnlayerup.Size = New System.Drawing.Size(68, 62)
        Me.btnlayerup.TabIndex = 80
        Me.btnlayerup.UseVisualStyleBackColor = False
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.SkyBlue
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label23.Location = New System.Drawing.Point(0, 2)
        Me.Label23.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(268, 32)
        Me.Label23.TabIndex = 79
        Me.Label23.Text = "Layer No"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Panel6)
        Me.Panel1.Controls.Add(Me.Panel5)
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.PanelTRC)
        Me.Panel1.Controls.Add(Me.panelPara)
        Me.Panel1.Location = New System.Drawing.Point(3, 6)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1270, 740)
        Me.Panel1.TabIndex = 0
        '
        'Panel6
        '
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.lblpmb1)
        Me.Panel6.Controls.Add(Me.lblpmb4)
        Me.Panel6.Controls.Add(Me.lblpmb3)
        Me.Panel6.Controls.Add(Me.lblpmb5)
        Me.Panel6.Controls.Add(Me.lblpmb2)
        Me.Panel6.Controls.Add(Me.Label32)
        Me.Panel6.Controls.Add(Me.lblalarm)
        Me.Panel6.Controls.Add(Me.lblfaulty)
        Me.Panel6.Controls.Add(Me.lblAuto)
        Me.Panel6.Controls.Add(Me.LblHealthy)
        Me.Panel6.Location = New System.Drawing.Point(4, 416)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(453, 320)
        Me.Panel6.TabIndex = 34
        '
        'lblpmb1
        '
        Me.lblpmb1.Image = Global.iotPIPECLEDING.My.Resources.Resources.pmb1gray
        Me.lblpmb1.Location = New System.Drawing.Point(32, 132)
        Me.lblpmb1.Name = "lblpmb1"
        Me.lblpmb1.Size = New System.Drawing.Size(94, 86)
        Me.lblpmb1.TabIndex = 21
        '
        'lblpmb4
        '
        Me.lblpmb4.Image = Global.iotPIPECLEDING.My.Resources.Resources.pmb4gray
        Me.lblpmb4.Location = New System.Drawing.Point(102, 225)
        Me.lblpmb4.Name = "lblpmb4"
        Me.lblpmb4.Size = New System.Drawing.Size(98, 84)
        Me.lblpmb4.TabIndex = 20
        '
        'lblpmb3
        '
        Me.lblpmb3.Image = Global.iotPIPECLEDING.My.Resources.Resources.pmb3gray
        Me.lblpmb3.Location = New System.Drawing.Point(342, 127)
        Me.lblpmb3.Name = "lblpmb3"
        Me.lblpmb3.Size = New System.Drawing.Size(98, 84)
        Me.lblpmb3.TabIndex = 19
        '
        'lblpmb5
        '
        Me.lblpmb5.Image = Global.iotPIPECLEDING.My.Resources.Resources.pmb5gray
        Me.lblpmb5.Location = New System.Drawing.Point(268, 221)
        Me.lblpmb5.Name = "lblpmb5"
        Me.lblpmb5.Size = New System.Drawing.Size(98, 84)
        Me.lblpmb5.TabIndex = 18
        '
        'lblpmb2
        '
        Me.lblpmb2.Image = Global.iotPIPECLEDING.My.Resources.Resources.pmb2gray
        Me.lblpmb2.Location = New System.Drawing.Point(187, 127)
        Me.lblpmb2.Name = "lblpmb2"
        Me.lblpmb2.Size = New System.Drawing.Size(98, 84)
        Me.lblpmb2.TabIndex = 17
        '
        'Label32
        '
        Me.Label32.BackColor = System.Drawing.Color.SkyBlue
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label32.Location = New System.Drawing.Point(0, 2)
        Me.Label32.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(452, 35)
        Me.Label32.TabIndex = 16
        Me.Label32.Text = "Status Monitoring"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblalarm
        '
        Me.lblalarm.Image = Global.iotPIPECLEDING.My.Resources.Resources.lgray
        Me.lblalarm.Location = New System.Drawing.Point(372, 55)
        Me.lblalarm.Name = "lblalarm"
        Me.lblalarm.Size = New System.Drawing.Size(55, 56)
        Me.lblalarm.TabIndex = 3
        '
        'lblfaulty
        '
        Me.lblfaulty.Image = Global.iotPIPECLEDING.My.Resources.Resources.fG
        Me.lblfaulty.Location = New System.Drawing.Point(277, 52)
        Me.lblfaulty.Name = "lblfaulty"
        Me.lblfaulty.Size = New System.Drawing.Size(55, 56)
        Me.lblfaulty.TabIndex = 2
        '
        'lblAuto
        '
        Me.lblAuto.Image = Global.iotPIPECLEDING.My.Resources.Resources.AG
        Me.lblAuto.Location = New System.Drawing.Point(177, 46)
        Me.lblAuto.Name = "lblAuto"
        Me.lblAuto.Size = New System.Drawing.Size(55, 56)
        Me.lblAuto.TabIndex = 1
        '
        'LblHealthy
        '
        Me.LblHealthy.Image = Global.iotPIPECLEDING.My.Resources.Resources.hgray
        Me.LblHealthy.Location = New System.Drawing.Point(59, 46)
        Me.LblHealthy.Name = "LblHealthy"
        Me.LblHealthy.Size = New System.Drawing.Size(55, 56)
        Me.LblHealthy.TabIndex = 0
        '
        'Panel5
        '
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.btnresume)
        Me.Panel5.Controls.Add(Me.Label29)
        Me.Panel5.Controls.Add(Me.btnstop)
        Me.Panel5.Controls.Add(Me.btnstart)
        Me.Panel5.Controls.Add(Me.btndryweldrun)
        Me.Panel5.Controls.Add(Me.btntag2)
        Me.Panel5.Controls.Add(Me.btntag1)
        Me.Panel5.Controls.Add(Me.btnauto)
        Me.Panel5.Controls.Add(Me.Label28)
        Me.Panel5.Location = New System.Drawing.Point(463, 584)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(802, 152)
        Me.Panel5.TabIndex = 33
        '
        'btnresume
        '
        Me.btnresume.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.resumeb
        Me.btnresume.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnresume.FlatAppearance.BorderSize = 0
        Me.btnresume.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnresume.Location = New System.Drawing.Point(684, 37)
        Me.btnresume.Name = "btnresume"
        Me.btnresume.Size = New System.Drawing.Size(95, 90)
        Me.btnresume.TabIndex = 73
        Me.btnresume.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(309, 14)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(144, 26)
        Me.Label29.TabIndex = 71
        Me.Label29.Text = "OPERATION"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnstop
        '
        Me.btnstop.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.stopE
        Me.btnstop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnstop.FlatAppearance.BorderSize = 0
        Me.btnstop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnstop.Location = New System.Drawing.Point(569, 37)
        Me.btnstop.Name = "btnstop"
        Me.btnstop.Size = New System.Drawing.Size(100, 95)
        Me.btnstop.TabIndex = 70
        Me.btnstop.UseVisualStyleBackColor = True
        '
        'btnstart
        '
        Me.btnstart.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.startE
        Me.btnstart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnstart.FlatAppearance.BorderSize = 0
        Me.btnstart.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnstart.Location = New System.Drawing.Point(458, 37)
        Me.btnstart.Name = "btnstart"
        Me.btnstart.Size = New System.Drawing.Size(100, 95)
        Me.btnstart.TabIndex = 69
        Me.btnstart.UseVisualStyleBackColor = True
        '
        'btndryweldrun
        '
        Me.btndryweldrun.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.dryrun
        Me.btndryweldrun.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btndryweldrun.FlatAppearance.BorderSize = 0
        Me.btndryweldrun.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndryweldrun.Location = New System.Drawing.Point(308, 61)
        Me.btndryweldrun.Name = "btndryweldrun"
        Me.btndryweldrun.Size = New System.Drawing.Size(129, 58)
        Me.btndryweldrun.TabIndex = 68
        Me.btndryweldrun.UseVisualStyleBackColor = True
        '
        'btntag2
        '
        Me.btntag2.BackgroundImage = CType(resources.GetObject("btntag2.BackgroundImage"), System.Drawing.Image)
        Me.btntag2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btntag2.FlatAppearance.BorderSize = 0
        Me.btntag2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btntag2.Location = New System.Drawing.Point(17, 83)
        Me.btntag2.Name = "btntag2"
        Me.btntag2.Size = New System.Drawing.Size(126, 60)
        Me.btntag2.TabIndex = 67
        Me.btntag2.UseVisualStyleBackColor = True
        '
        'btntag1
        '
        Me.btntag1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.tag1
        Me.btntag1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btntag1.FlatAppearance.BorderSize = 0
        Me.btntag1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btntag1.Location = New System.Drawing.Point(17, 7)
        Me.btntag1.Name = "btntag1"
        Me.btntag1.Size = New System.Drawing.Size(126, 60)
        Me.btntag1.TabIndex = 66
        Me.btntag1.UseVisualStyleBackColor = True
        '
        'btnauto
        '
        Me.btnauto.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.off
        Me.btnauto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnauto.FlatAppearance.BorderSize = 0
        Me.btnauto.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnauto.Location = New System.Drawing.Point(167, 61)
        Me.btnauto.Name = "btnauto"
        Me.btnauto.Size = New System.Drawing.Size(117, 58)
        Me.btnauto.TabIndex = 65
        Me.btnauto.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(154, 14)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(155, 26)
        Me.Label28.TabIndex = 64
        Me.Label28.Text = "AUTO MODE"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.btnWELDB)
        Me.Panel4.Controls.Add(Me.btnWIREFEEDB)
        Me.Panel4.Controls.Add(Me.btnHOTWIREB)
        Me.Panel4.Controls.Add(Me.btnAVCB)
        Me.Panel4.Controls.Add(Me.Label24)
        Me.Panel4.Controls.Add(Me.Label26)
        Me.Panel4.Controls.Add(Me.btnWELDA)
        Me.Panel4.Controls.Add(Me.btnWIREFEEDA)
        Me.Panel4.Controls.Add(Me.btnHOTWIREA)
        Me.Panel4.Controls.Add(Me.btnAVCA)
        Me.Panel4.Location = New System.Drawing.Point(463, 416)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(802, 162)
        Me.Panel4.TabIndex = 30
        '
        'btnWELDB
        '
        Me.btnWELDB.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.weldoff
        Me.btnWELDB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnWELDB.FlatAppearance.BorderSize = 0
        Me.btnWELDB.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWELDB.Location = New System.Drawing.Point(124, 90)
        Me.btnWELDB.Name = "btnWELDB"
        Me.btnWELDB.Size = New System.Drawing.Size(136, 60)
        Me.btnWELDB.TabIndex = 67
        Me.btnWELDB.UseVisualStyleBackColor = True
        '
        'btnWIREFEEDB
        '
        Me.btnWIREFEEDB.BackgroundImage = CType(resources.GetObject("btnWIREFEEDB.BackgroundImage"), System.Drawing.Image)
        Me.btnWIREFEEDB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnWIREFEEDB.FlatAppearance.BorderSize = 0
        Me.btnWIREFEEDB.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWIREFEEDB.Location = New System.Drawing.Point(290, 88)
        Me.btnWIREFEEDB.Name = "btnWIREFEEDB"
        Me.btnWIREFEEDB.Size = New System.Drawing.Size(136, 60)
        Me.btnWIREFEEDB.TabIndex = 66
        Me.btnWIREFEEDB.UseVisualStyleBackColor = True
        '
        'btnHOTWIREB
        '
        Me.btnHOTWIREB.BackgroundImage = CType(resources.GetObject("btnHOTWIREB.BackgroundImage"), System.Drawing.Image)
        Me.btnHOTWIREB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnHOTWIREB.FlatAppearance.BorderSize = 0
        Me.btnHOTWIREB.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHOTWIREB.Location = New System.Drawing.Point(456, 91)
        Me.btnHOTWIREB.Name = "btnHOTWIREB"
        Me.btnHOTWIREB.Size = New System.Drawing.Size(136, 60)
        Me.btnHOTWIREB.TabIndex = 65
        Me.btnHOTWIREB.UseVisualStyleBackColor = True
        '
        'btnAVCB
        '
        Me.btnAVCB.BackgroundImage = CType(resources.GetObject("btnAVCB.BackgroundImage"), System.Drawing.Image)
        Me.btnAVCB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnAVCB.FlatAppearance.BorderSize = 0
        Me.btnAVCB.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAVCB.Location = New System.Drawing.Point(623, 91)
        Me.btnAVCB.Name = "btnAVCB"
        Me.btnAVCB.Size = New System.Drawing.Size(136, 60)
        Me.btnAVCB.TabIndex = 64
        Me.btnAVCB.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(6, 107)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(108, 26)
        Me.Label24.TabIndex = 63
        Me.Label24.Text = "HEAD-B "
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(6, 23)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(108, 26)
        Me.Label26.TabIndex = 62
        Me.Label26.Text = "HEAD-A "
        '
        'btnWELDA
        '
        Me.btnWELDA.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.weldoff
        Me.btnWELDA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnWELDA.FlatAppearance.BorderSize = 0
        Me.btnWELDA.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWELDA.Location = New System.Drawing.Point(124, 6)
        Me.btnWELDA.Name = "btnWELDA"
        Me.btnWELDA.Size = New System.Drawing.Size(136, 60)
        Me.btnWELDA.TabIndex = 61
        Me.btnWELDA.UseVisualStyleBackColor = True
        '
        'btnWIREFEEDA
        '
        Me.btnWIREFEEDA.BackgroundImage = CType(resources.GetObject("btnWIREFEEDA.BackgroundImage"), System.Drawing.Image)
        Me.btnWIREFEEDA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnWIREFEEDA.FlatAppearance.BorderSize = 0
        Me.btnWIREFEEDA.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWIREFEEDA.Location = New System.Drawing.Point(290, 6)
        Me.btnWIREFEEDA.Name = "btnWIREFEEDA"
        Me.btnWIREFEEDA.Size = New System.Drawing.Size(136, 60)
        Me.btnWIREFEEDA.TabIndex = 59
        Me.btnWIREFEEDA.UseVisualStyleBackColor = True
        '
        'btnHOTWIREA
        '
        Me.btnHOTWIREA.BackgroundImage = CType(resources.GetObject("btnHOTWIREA.BackgroundImage"), System.Drawing.Image)
        Me.btnHOTWIREA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnHOTWIREA.FlatAppearance.BorderSize = 0
        Me.btnHOTWIREA.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHOTWIREA.Location = New System.Drawing.Point(456, 6)
        Me.btnHOTWIREA.Name = "btnHOTWIREA"
        Me.btnHOTWIREA.Size = New System.Drawing.Size(136, 60)
        Me.btnHOTWIREA.TabIndex = 57
        Me.btnHOTWIREA.UseVisualStyleBackColor = True
        '
        'btnAVCA
        '
        Me.btnAVCA.BackgroundImage = CType(resources.GetObject("btnAVCA.BackgroundImage"), System.Drawing.Image)
        Me.btnAVCA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnAVCA.FlatAppearance.BorderSize = 0
        Me.btnAVCA.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAVCA.Location = New System.Drawing.Point(623, 6)
        Me.btnAVCA.Name = "btnAVCA"
        Me.btnAVCA.Size = New System.Drawing.Size(136, 60)
        Me.btnAVCA.TabIndex = 55
        Me.btnAVCA.UseVisualStyleBackColor = True
        '
        'FrmSC1
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(1276, 750)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmSC1"
        Me.ShowIcon = False
        Me.Weldingpass.ResumeLayout(False)
        Me.Weldingpass.PerformLayout()
        Me.panelPara.ResumeLayout(False)
        Me.panelPara.PerformLayout()
        Me.PanelTRC.ResumeLayout(False)
        Me.PanelTRC.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnesscon As System.Windows.Forms.Button
    Friend WithEvents btnesscoff As System.Windows.Forms.Button
    Friend WithEvents tParalog As System.Windows.Forms.Timer

    Private WithEvents RectangleShape2 As PowerPacks.RectangleShape
    Private WithEvents RectangleShape3 As PowerPacks.RectangleShape
    Private WithEvents RectangleShape7 As PowerPacks.RectangleShape
    Private WithEvents RectangleShape8 As PowerPacks.RectangleShape
    Private WithEvents RectangleShape9 As PowerPacks.RectangleShape
    Private WithEvents RectangleShape10 As PowerPacks.RectangleShape
    'Private WithEvents RectangleShape13 As PowerPacks.RectangleShape
    Private WithEvents RectangleShape66 As PowerPacks.RectangleShape

    'Private WithEvents ShapeContainer1 As PowerPacks.ShapeContainer
    Private WithEvents ShapeContainer2 As PowerPacks.ShapeContainer
    Private WithEvents ShapeContainer4 As PowerPacks.ShapeContainer
    'Private WithEvents ShapeContainer5 As PowerPacks.ShapeContainer
    Private WithEvents ShapeContainer6 As PowerPacks.ShapeContainer
    Friend WithEvents Weldingpass As Panel
    Friend WithEvents btnpassok As Button
    Friend WithEvents txtPass As TextBox
    Friend WithEvents btnpassdn As Button
    Friend WithEvents btnpassup As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents panelPara As Panel
    Friend WithEvents lblGasflow2 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lblJobTemp2 As TextBox
    Friend WithEvents txtTRC1speed As Label
    Friend WithEvents LblTRAVELSPEED As TextBox
    Friend WithEvents lblVoltage2 As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents lblGASFLOW As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents lblVoltage As TextBox
    Friend WithEvents lblCurrent2 As TextBox
    Friend WithEvents lblCurrent As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents PanelTRC As Panel
    Friend WithEvents lblRPOS As TextBox
    Friend WithEvents lblAPOS As TextBox
    Friend WithEvents lblTPOS As TextBox
    Friend WithEvents lblALASTPOS As TextBox
    Friend WithEvents lblTLASTPOS As TextBox
    Friend WithEvents lblRLASTPOS As TextBox
    Friend WithEvents lblRSPEED As TextBox
    Friend WithEvents lblASPEED As TextBox
    Friend WithEvents lblXPOS As TextBox
    Friend WithEvents lblXLASTPOS As TextBox
    Friend WithEvents lblTSPEED As TextBox
    Friend WithEvents lblXSPEED As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents btnlayerok As Button
    Friend WithEvents txtlayer As TextBox
    Friend WithEvents btnlayerdn As Button
    Friend WithEvents btnlayerup As Button
    Friend WithEvents Label23 As Label
    Friend WithEvents lblLocalDataCount As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents lblLastBuildDate As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents txtIP As Label
    Friend WithEvents txtStationNumber As Label
    Friend WithEvents lblIP As Label
    Friend WithEvents lblStationNumber As Label
    Friend WithEvents txtpsno As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents txtwname As Label
    Friend WithEvents btnLogout As Button
    Friend WithEvents Label21 As Label
    Friend WithEvents btnLogin As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents btnAVCA As Button

    Friend WithEvents btnHOTWIREA As Button
    Friend WithEvents btnWIREFEEDA As Button
    Friend WithEvents btnWELDA As Button
    Friend WithEvents Label26 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label28 As Label
    Friend WithEvents btndryweldrun As Button
    Friend WithEvents btntag2 As Button
    Friend WithEvents btntag1 As Button
    Friend WithEvents btnauto As Button
    Friend WithEvents btnstop As Button
    Friend WithEvents btnstart As Button
    Friend WithEvents Label29 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents LblHealthy As Label
    Friend WithEvents lblalarm As Label
    Friend WithEvents lblfaulty As Label
    Friend WithEvents lblAuto As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents lblpmb1 As Label
    Friend WithEvents lblpmb4 As Label
    Friend WithEvents lblpmb3 As Label
    Friend WithEvents lblpmb5 As Label
    Friend WithEvents lblpmb2 As Label
    Friend WithEvents lblFlange As Label
    Friend WithEvents lblSpiral As Label
    Friend WithEvents lblSagita As Label
    Friend WithEvents lblNozzle As Label
    Friend WithEvents lblBackface As Label
    Friend WithEvents lblStep As Label
    Friend WithEvents btnresume As Button
    Friend WithEvents lblLocalDataPushStatus As TextBox
    Friend WithEvents pBar As ProgressBar
    Friend WithEvents Label24 As Label
    Friend WithEvents btnWIREFEEDB As Button
    Friend WithEvents btnHOTWIREB As Button
    Friend WithEvents btnAVCB As Button
    Friend WithEvents btnWELDB As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents lblAi8 As TextBox
End Class
