﻿Public Class frmDigStatus
    Dim tejas As Integer = 0
    Dim green As Color = Color.LightGreen
    Dim red As Color = Color.MistyRose

    Dim plcinstrg As String = ""
    Dim y As Integer = 0 '
    Dim y1 As Double
    Dim colorarr() As Color = {Color.Silver, Color.Green}


    Private Sub Btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Timer1.Stop()
        Timer1.Enabled = False
        Me.Close()
    End Sub

    Private Sub FrmDigStatus_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '' Dim testDialog As New frmDigStatus
        Me.WindowState = FormWindowState.Maximized

        Timer1.Enabled = True
        Timer1.Start()
    End Sub
    Private Sub frmDigstatus_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Panel6.Left = (Me.Width - Panel6.Width) / 2
        Panel6.Top = (Me.Height - Panel6.Height) / 2
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try

            '//////////////////////// First Option  ////////////////////////////////

            '-------------------       DIGITAL INPUT STATUS  ---------------------- 

            ' ALL READ CONTINUS
            If isConnection = True Then

                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 03 84 00 10", 50)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(6) = "02" And x1(7) = "01" Then

                        Dim bin As String = ReverseString(Hex2Bin(x1(10) & x1(9)))
                        Dim digits1() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        ''p1 = digits1(0) & ":" & digits1(1) & ":" & digits1(2) & ":" & digits1(3) & ":" & digits1(4) & ":" & digits1(5) & ":" & digits1(6) & ":" & digits1(7) & ":" & digits1(8) & ":" & digits1(9) & ":" & digits1(10) & ":" & digits1(11) & ":" & digits1(12) & ":" & digits1(13) & ":" & digits1(14) & ":" & digits1(15)
                        tejas = 1

                        Me.lblDi1.BackColor = colorarr(digits1(0))
                        Me.lblDi2.BackColor = colorarr(digits1(1))
                        Me.lblDi3.BackColor = colorarr(digits1(2))
                        Me.lblDi4.BackColor = colorarr(digits1(3))
                        Me.lblDi5.BackColor = colorarr(digits1(4))
                        Me.lblDi6.BackColor = colorarr(digits1(5))
                        Me.lblDi7.BackColor = colorarr(digits1(6))
                        Me.lblDi8.BackColor = colorarr(digits1(7))
                        Me.lblDi9.BackColor = colorarr(digits1(8))
                        Me.lblDi10.BackColor = colorarr(digits1(9))
                        Me.lblDi11.BackColor = colorarr(digits1(10))
                        Me.lblDi12.BackColor = colorarr(digits1(11))
                        Me.lblDi13.BackColor = colorarr(digits1(12))
                        Me.lblDi14.BackColor = colorarr(digits1(13))
                        Me.lblDi15.BackColor = colorarr(digits1(14))
                        Me.lblDi16.BackColor = colorarr(digits1(15))

                    End If
                End If

                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 03 94 00 10", 50)
                Dim x2() As String = plcinstrg.Split(" "c)
                If x2.Count >= 8 Then
                    If x2(6) = "02" And x2(7) = "01" Then


                        Dim bin As String = ReverseString(Hex2Bin(x2(10) & x2(9)))
                        Dim digits2() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        ''P2 = digits2(0) & ":" & digits2(1) & ":" & digits2(2) & ":" & digits2(3) & ":" & digits2(4) & ":" & digits2(5) & ":" & digits2(6) & ":" & digits2(7) & ":" & digits2(8) & ":" & digits2(9) & ":" & digits2(10) & ":" & digits2(11) & ":" & digits2(12) & ":" & digits2(13) & ":" & digits2(14) & ":" & digits2(15)
                        tejas = 2
                        Me.lblDi17.BackColor = colorarr(digits2(0))
                        Me.lblDi18.BackColor = colorarr(digits2(1))
                        Me.lblDi19.BackColor = colorarr(digits2(2))
                        Me.lblDi20.BackColor = colorarr(digits2(3))
                        Me.lblDi21.BackColor = colorarr(digits2(4))
                        Me.lblDi22.BackColor = colorarr(digits2(5))
                        Me.lblDi23.BackColor = colorarr(digits2(6))
                        Me.lblDi24.BackColor = colorarr(digits2(7))
                        Me.lblDi25.BackColor = colorarr(digits2(8))
                        Me.lblDi26.BackColor = colorarr(digits2(9))
                        Me.lblDi27.BackColor = colorarr(digits2(10))
                        Me.lblDi28.BackColor = colorarr(digits2(11))
                        Me.lblDi29.BackColor = colorarr(digits2(12))
                        Me.lblDi30.BackColor = colorarr(digits2(13))
                        Me.lblDi31.BackColor = colorarr(digits2(14))
                        Me.lblDi32.BackColor = colorarr(digits2(15))

                    End If
                End If

                ''''''''''''''''''''  DIGITAL OUTPUT READ   ''''''''''''''''''''''''''''''''''''''

                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 03 B6 00 10", 50)
                Dim x3() As String = plcinstrg.Split(" "c)
                If x3.Count >= 8 Then
                    If x3(6) = "02" And x3(7) = "01" Then


                        Dim bin As String = ReverseString(Hex2Bin(x3(10) & x3(9)))
                        Dim digits3() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        '' p3 = digits3(0) & ":" & digits3(1) & ":" & digits3(2) & ":" & digits3(3) & ":" & digits3(4) & ":" & digits3(5) & ":" & digits3(6) & ":" & digits3(7) & ":" & digits3(8) & ":" & digits3(9) & ":" & digits3(10) & ":" & digits3(11) & ":" & digits3(12) & ":" & digits3(13) & ":" & digits3(14) & ":" & digits3(15)
                        tejas = 3
                        Me.lblDO1.BackColor = colorarr(digits3(0))
                        Me.lblDO2.BackColor = colorarr(digits3(1))
                        Me.lblDO3.BackColor = colorarr(digits3(2))
                        Me.lblDO4.BackColor = colorarr(digits3(3))
                        Me.lblDO5.BackColor = colorarr(digits3(4))
                        Me.lblDO6.BackColor = colorarr(digits3(5))
                        Me.lblDO7.BackColor = colorarr(digits3(6))
                        Me.lblDO8.BackColor = colorarr(digits3(7))
                        Me.lblDO9.BackColor = colorarr(digits3(8))
                        Me.lblDO10.BackColor = colorarr(digits3(9))
                        Me.lblDO11.BackColor = colorarr(digits3(10))
                        Me.lblDO12.BackColor = colorarr(digits3(11))
                        Me.lblDO13.BackColor = colorarr(digits3(12))
                        Me.lblDO14.BackColor = colorarr(digits3(13))
                        Me.lblDO15.BackColor = colorarr(digits3(14))
                        Me.lblDO16.BackColor = colorarr(digits3(15))

                    End If
                End If

                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 03 C6 00 10", 50)
                Dim x4() As String = plcinstrg.Split(" "c)
                If x4.Count >= 8 Then
                    If x4(6) = "02" And x4(7) = "01" Then


                        Dim bin As String = ReverseString(Hex2Bin(x4(10) & x4(9)))
                        Dim digits4() As Integer = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        ' p4 = digits4(0) & ":" & digits4(1) & ":" & digits4(2) & ":" & digits4(3) & ":" & digits4(4) & ":" & digits4(5) & ":" & digits4(6) & ":" & digits4(7) & ":" & digits4(8) & ":" & digits4(9) & ":" & digits4(10) & ":" & digits4(11) & ":" & digits4(12) & ":" & digits4(13) & ":" & digits4(14) & ":" & digits4(15)
                        tejas = 4
                        Me.lblDO17.BackColor = colorarr(digits4(0))
                        Me.lblDO18.BackColor = colorarr(digits4(1))
                        Me.lblDO19.BackColor = colorarr(digits4(2))
                        Me.lblDO20.BackColor = colorarr(digits4(3))
                        Me.lblDO21.BackColor = colorarr(digits4(4))
                        Me.lblDO22.BackColor = colorarr(digits4(5))
                        Me.lblDO23.BackColor = colorarr(digits4(6))
                        Me.lblDO24.BackColor = colorarr(digits4(7))
                        Me.lblDO25.BackColor = colorarr(digits4(8))
                        Me.lblDO26.BackColor = colorarr(digits4(9))
                        Me.lblDO27.BackColor = colorarr(digits4(10))
                        Me.lblDO28.BackColor = colorarr(digits4(11))
                        Me.lblDO29.BackColor = colorarr(digits4(12))
                        Me.lblDO30.BackColor = colorarr(digits4(13))
                        Me.lblDO31.BackColor = colorarr(digits4(14))
                        Me.lblDO32.BackColor = colorarr(digits4(15))

                    End If
                End If

            End If

            ''///////////  Second Option  ////////////////////////////

            '''''''''''''    Digital Input ''''''''''''''''''''
            'Me.lblDi1.BackColor = colorarr(gDi1)
            'Me.lblDi2.BackColor = colorarr(gDi2)
            'Me.lblDi3.BackColor = colorarr(gDi3)
            'Me.lblDi4.BackColor = colorarr(gDi4)
            'Me.lblDi5.BackColor = colorarr(gDi5)
            'Me.lblDi6.BackColor = colorarr(gDi6)
            'Me.lblDi7.BackColor = colorarr(gDi7)
            'Me.lblDi8.BackColor = colorarr(gDi8)
            'Me.lblDi9.BackColor = colorarr(gDi9)
            'Me.lblDi10.BackColor = colorarr(gDi10)
            'Me.lblDi11.BackColor = colorarr(gDi11)
            'Me.lblDi12.BackColor = colorarr(gDi12)
            'Me.lblDi13.BackColor = colorarr(gDi13)
            'Me.lblDi14.BackColor = colorarr(gDi14)
            'Me.lblDi15.BackColor = colorarr(gDi15)
            'Me.lblDi16.BackColor = colorarr(gDi16)
            'Me.lblDi17.BackColor = colorarr(gDi17)
            'Me.lblDi18.BackColor = colorarr(gDi18)
            'Me.lblDi19.BackColor = colorarr(gDi19)
            'Me.lblDi20.BackColor = colorarr(gDi20)
            'Me.lblDi21.BackColor = colorarr(gDi21)
            'Me.lblDi22.BackColor = colorarr(gDi22)
            'Me.lblDi23.BackColor = colorarr(gDi23)
            'Me.lblDi24.BackColor = colorarr(gDi24)
            'Me.lblDi25.BackColor = colorarr(gDi25)
            'Me.lblDi26.BackColor = colorarr(gDi26)
            'Me.lblDi27.BackColor = colorarr(gDi27)
            'Me.lblDi28.BackColor = colorarr(gDi28)
            'Me.lblDi29.BackColor = colorarr(gDi29)
            'Me.lblDi30.BackColor = colorarr(gDi30)
            'Me.lblDi31.BackColor = colorarr(gDi31)
            'Me.lblDi32.BackColor = colorarr(gDi32)


            ''''//////////////////   Digital output  ////////////////


            'Me.lblDO1.BackColor = colorarr(gDo1)
            'Me.lblDO2.BackColor = colorarr(gDo2)
            'Me.lblDO3.BackColor = colorarr(gDo3)
            'Me.lblDO4.BackColor = colorarr(gDo4)
            'Me.lblDO5.BackColor = colorarr(gDo5)
            'Me.lblDO6.BackColor = colorarr(gDo6)
            'Me.lblDO7.BackColor = colorarr(gDo7)
            'Me.lblDO8.BackColor = colorarr(gDo8)
            'Me.lblDO9.BackColor = colorarr(gDo9)
            'Me.lblDO10.BackColor = colorarr(gDo10)
            'Me.lblDO11.BackColor = colorarr(gDo11)
            'Me.lblDO12.BackColor = colorarr(gDo12)
            'Me.lblDO13.BackColor = colorarr(gDo13)
            'Me.lblDO14.BackColor = colorarr(gDo14)
            'Me.lblDO15.BackColor = colorarr(gDo15)
            'Me.lblDO16.BackColor = colorarr(gDo16)
            'Me.lblDO17.BackColor = colorarr(gDo17)
            'Me.lblDO18.BackColor = colorarr(gDo18)
            'Me.lblDO19.BackColor = colorarr(gDo19)
            'Me.lblDO20.BackColor = colorarr(gDo20)
            'Me.lblDO21.BackColor = colorarr(gDo21)
            'Me.lblDO22.BackColor = colorarr(gDo22)
            'Me.lblDO23.BackColor = colorarr(gDo23)
            'Me.lblDO24.BackColor = colorarr(gDo24)
            'Me.lblDO25.BackColor = colorarr(gDo25)
            'Me.lblDO26.BackColor = colorarr(gDo26)
            'Me.lblDO27.BackColor = colorarr(gDo27)
            'Me.lblDO28.BackColor = colorarr(gDo28)
            'Me.lblDO29.BackColor = colorarr(gDo29)
            'Me.lblDO30.BackColor = colorarr(gDo30)
            'Me.lblDO31.BackColor = colorarr(gDo31)
            'Me.lblDO32.BackColor = colorarr(gDo32)

        Catch ex As Exception
            MessageBox.Show("Error during Timer1_Tick method of frmDigi Status module, Error : " + ex.Message.ToString() + tejas.tostring())
        End Try
    End Sub

    Private Sub Panel6_Paint(sender As Object, e As PaintEventArgs) Handles Panel6.Paint

    End Sub

    Private Sub Label90_Click(sender As Object, e As EventArgs) Handles Label90.Click

    End Sub
End Class