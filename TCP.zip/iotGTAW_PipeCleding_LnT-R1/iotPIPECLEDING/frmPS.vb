﻿'---------------------------------------------------------------------
' iotESSC for L&T
' by  trapasia DigiReach @ 2017
' project/seam/wpsno is taken from last values saved in local database
' Project/seam and WPS selection for successfull logged user
' pass is set to 1 for new project
'---------------------------------------------------------------------
Imports System.Data
Imports System.Data.OleDb

Public Class frmPS
    Dim project As Integer = 0

    Private Sub frmOne_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        'getshop()
        'txtShop.Text = gshop
        txtStation.Text = gstation
        txtWName.Text = gwelder_nm
        'txtProcess.Text = gPROCESS
        txtPSNo.Text = gpsno
        txtProject.Text = gprojectno & " # " & gprojectname
        txtSeam.Text = gseamno
        txtWPSNo.Text = gWPSno
        'cmbSize.SelectedText = gsize

        'If gshopno = "0" Then
        '    txtsno.Text = "Select Shop no"
        'Else
        '    txtsno.Text = gshopno & " # " & gshopname
        'End If

        'If gcmbno = "0" Then
        '    txtcmbno.Text = "Select CMB no"
        'Else
        '    txtcmbno.Text = gcmbno & " # " & gcmbname
        'End If

        Dim cmb As New Dictionary(Of String, String)()
        cmb.Add("1", "AC")
        cmb.Add("2", "DC")
        'cmb.Add("2", "DC EP")
        'cmb.Add("3", "DC EN")

        CmbWedpol.DataSource = New BindingSource(cmb, Nothing)
        CmbWedpol.DisplayMember = "Value"
        CmbWedpol.ValueMember = "Key"

        CmbWedpol.Text = "DC"
        CmbWedpol.Enabled = False

        Dim cmbb As New Dictionary(Of String, String)()
        cmbb.Add("1", "GTAW")

        CmbProcess.DataSource = New BindingSource(cmbb, Nothing)
        CmbProcess.DisplayMember = "Value"
        CmbProcess.ValueMember = "Key"
    End Sub


    Private Sub btnNext_Click(sender As System.Object, e As System.EventArgs) Handles btnNext.Click
        Dim cmbshopv As String = 0
        Dim cmbv As String = 0

        Using objCon As New dbClass
            Try
                If project = 1 Then
                    If cmbPrj.SelectedValue <> "" And cmbSeam.SelectedValue <> "" And cmbWPS.SelectedValue <> "" Then
                        Dim pn As String = cmbPrj.Text
                        Dim x() As String = pn.Split("#")

                        gprojectname = x(1).Trim()

                        If CmbProcess.SelectedValue = 1 Then
                            gPROCESS = "GTAW"
                            gMachine = "GTAW"
                        End If

                        gPowersrc = CmbWedpol.SelectedValue

                        If CmbWedpol.SelectedValue = 3 Then
                            gPowersrc = 2
                            gPowervalue = 3
                        End If
                        If CmbWedpol.SelectedValue = 2 Then
                            gPowersrc = 2
                            gPowervalue = 2
                        End If
                        If CmbWedpol.SelectedValue = 1 Then
                            gPowersrc = 1
                            gPowervalue = 1
                        End If

                        'If Cmbshopno.SelectedValue = "" Then
                        '    gshopname = 0
                        'Else
                        '    Dim pn1 As String = Cmbshopno.Text
                        '    Dim x1() As String = pn1.Split("#")
                        '    cmbshopv = Cmbshopno.SelectedValue
                        '    gshopname = x1(1).Trim()
                        'End If

                        'If Cmbno.SelectedValue = "" Then
                        '    gcmbname = 0
                        'Else
                        '    Dim pn2 As String = Cmbno.Text
                        '    Dim x2() As String = pn2.Split("#")
                        '    cmbv = Cmbno.SelectedValue
                        '    gcmbname = x2(1).Trim()
                        'End If

                        objCon.ExecuteNonQuery("UPDATE device set passno=0,process='" & gPROCESS & "',projectno='" & cmbPrj.SelectedValue & "',projectname='" & gprojectname & "',seamno='" & cmbSeam.SelectedValue & "',wpsno='" & cmbWPS.SelectedValue & "' where csnno='" & gcsnno & "'", CommandType.Text)

                        gprojectno = cmbPrj.SelectedValue
                        gseamno = cmbSeam.SelectedValue
                        gnewseam = cmbSeam.SelectedValue

                        gPowersrc = CmbWedpol.SelectedValue
                        If CmbWedpol.SelectedValue = 3 Then
                            gPowersrc = 2
                            gPowervalue = 3
                        End If

                        gWPSno = cmbWPS.SelectedValue
                        'size = cmbSize.SelectedText
                        'gshopno = Cmbshopno.SelectedValue
                        'gcmbno = Cmbno.SelectedValue
                        txtWPSNo.Text = gWPSno
                        'gPROCESS = txtProcess.Text
                        gPass = 1
                        glayer = 1

                        Dim dd As Integer = SaveOPLog(1)
                        If goldseam <> gnewseam Then
                            objCon.ExecuteNonQuery("UPDATE syspara set wcmin=0,wcmax=0,wvmin=0,wvmax=0,trsmax=0,trsmin=0,jtmax=0,jtmin=0,gfmin=0,gfmax=0,wfmin=0,wfmax=0", CommandType.Text)
                        End If

                        'Dim OBJ As New frmPass
                        'OBJ.Show()
                        'OBJ.MdiParent = MDIParent1
                        Me.Close()
                    Else
                        Dim result As String = MessageBoxEx.Show("Select Project,Seam and WPS. ", "Project Selection Confirmation", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString
                    End If
                Else

                    Dim result As String = MessageBoxEx.Show("Continue with this Project/Seam ? ", "Project Selection Confirmation", System.Windows.Forms.MessageBoxButtons.YesNo, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString
                    Select Case result
                        Case "Yes"
                            objCon.ExecuteNonQuery("UPDATE device set process='" & gPROCESS & "' where csnno='" & gcsnno & "'", CommandType.Text)
                            gPowersrc = CmbWedpol.SelectedValue
                            If CmbWedpol.SelectedValue = 3 Then
                                gPowersrc = 2
                                gPowervalue = 3
                            End If
                            If CmbWedpol.SelectedValue = 2 Then
                                gPowersrc = 2
                                gPowervalue = 2
                            End If
                            If CmbWedpol.SelectedValue = 1 Then
                                gPowersrc = 1
                                gPowervalue = 1
                            End If
                            If CmbProcess.SelectedValue = 1 Then
                                gPROCESS = "GTAW"
                                gMachine = "GTAW"
                            End If

                            Dim dd As Integer = SaveOPLog(1)
                            'Dim OBJ As New frmPass
                            'OBJ.Show()
                            'OBJ.MdiParent = MDIParent1
                            Me.Close()
                        Case "No"

                            If gOpMode = "live" Then
                                If getProject() = 1 Then

                                    'Check IOT DB Connectivity
                                    Using myservice As New SQLDB()
                                        IOTDBConnectivity = myservice.checkIOTDBConnectivity()
                                    End Using

                                    getShopno()
                                    'getcmbno()

                                    project = 1
                                    If CmbProcess.SelectedValue = 1 Then
                                        gPROCESS = "GTAW"
                                        gMachine = "GTAW"
                                    End If

                                    cmbPrj.Visible = True
                                    cmbSeam.Visible = True
                                    cmbWPS.Visible = True
                                    txtSeam.Visible = False
                                    txtProject.Visible = False
                                    txtWPSNo.Visible = False
                                    'txtsno.Visible = False
                                    'txtcmbno.Visible = False
                                    'Cmbshopno.Visible = True
                                    'Cmbno.Visible = True
                                    goldseam = gseamno

                                End If
                            End If
                    End Select
                End If
            Catch ex As Exception
                MessageBox.Show("Error from btnNext_Click() method of frmPS form, Error : " + ex.Message.ToString())
            End Try
        End Using
    End Sub
    Private Function getProject() As Integer
        Dim retval As Integer = 0
        Dim err As String = ""

        Using myservice As New SQLDB()
            Try
                'myservice.Timeout = 2000

                Dim z As DataTable = myservice.getAllQMSProject(err)
                cmbPrj.Items.Clear()
                cmbSeam.Items.Clear()
                cmbWPS.Items.Clear()

                'Dim disValue As String = ""
                'Dim fldValue As String = ""

                'Dim citems As DataTable = New DataTable()
                'citems.Columns.Add("Display")
                'citems.Columns.Add("Value")

                'Dim itemRow1 As DataRow = citems.NewRow()

                'itemRow1("Display") = "Select Project"
                'itemRow1("Value") = ""
                'citems.Rows.Add(itemRow1)

                'For Each row As DataRow In z.Rows
                '    Dim itemRow As DataRow = citems.NewRow()
                '    itemRow("Display") = row.Item("t_qprj").trim & " # " & row.Item("t_desc").trim
                '    itemRow("Value") = row.Item("t_qprj").trim
                '    citems.Rows.Add(itemRow)
                'Next row

                'cmbPrj.DisplayMember = "Display"
                'cmbPrj.ValueMember = "Value"
                'cmbPrj.DataSource = citems
                'cmbPrj.SelectedValue = ""

                If z.Rows.Count > 0 Then
                    Dim dr As DataRow = z.NewRow()
                    dr("t_qprj") = ""
                    dr("t_desc") = ""
                    dr("DisplayMember") = "Select Project"
                    z.Rows.InsertAt(dr, 0)

                    cmbPrj.DisplayMember = "DisplayMember"
                    cmbPrj.ValueMember = "t_qprj"
                    cmbPrj.DataSource = z
                    'cmbPrj.SelectedValue = ""
                    cmbPrj.SelectedIndex = 0
                End If
            Catch ex As Exception
                MessageBox.Show("Error from getProject() method of frmPS form, Error : " + ex.Message.ToString())
                retval = 0
            End Try
        End Using

        retval = 1
        Return retval
    End Function
    Private Function getShopno() As Integer
        Dim retval As Integer = 0
        Dim err As String = ""

        Using myservice As New SQLDB()
            Try
                'myservice.Timeout = 2000

                Dim z As DataTable = myservice.getShopDetail()
                'Cmbshopno.Items.Clear()

                'Dim disValue As String = ""
                'Dim fldValue As String = ""

                'Dim citems As DataTable = New DataTable()
                'citems.Columns.Add("Display")
                'citems.Columns.Add("Value")

                'Dim itemRow1 As DataRow = citems.NewRow()
                'itemRow1("Display") = "Select shop no."
                'itemRow1("Value") = ""
                'citems.Rows.Add(itemRow1)

                'For Each row As DataRow In z.Rows
                '    Dim itemRow As DataRow = citems.NewRow()
                '    itemRow("Display") = row.Item("shop_no").trim & " # " & row.Item("shop_name").trim
                '    itemRow("Value") = row.Item("shop_no").trim
                '    citems.Rows.Add(itemRow)
                'Next row
                If z.Rows.Count > 0 Then
                    Dim dr As DataRow = z.NewRow()
                    dr("shop_no") = ""
                    dr("shop_name") = ""
                    dr("DisplayMember") = "Select Shop"
                    z.Rows.InsertAt(dr, 0)

                    'Cmbshopno.DisplayMember = "DisplayMember"
                    'Cmbshopno.ValueMember = "shop_no"
                    'Cmbshopno.DataSource = z
                    'Cmbshopno.SelectedValue = ""
                    'Cmbshopno.SelectedIndex = 0
                End If
                retval = 1
            Catch ex As Exception
                MessageBox.Show("Error from getShopno() method of frmPS form, Error : " + ex.Message.ToString())
                retval = 0
            End Try
        End Using


        Return retval
    End Function

    'Private Function getcmbno() As Integer
    '    Dim retval As Integer = 0
    '    Dim err As String = ""

    '    Using myservice As New SQLDB()
    '        Try
    '            'myservice.Timeout = 2000

    '            Dim z As DataTable = myservice.getCMBDetail()
    '            Cmbno.Items.Clear()

    '            'Dim disValue As String = ""
    '            'Dim fldValue As String = ""

    '            'Dim citems As DataTable = New DataTable()
    '            'citems.Columns.Add("Display")
    '            'citems.Columns.Add("Value")

    '            'Dim itemRow1 As DataRow = citems.NewRow()
    '            'itemRow1("Display") = "Select CMB no."
    '            'itemRow1("Value") = ""
    '            'citems.Rows.Add(itemRow1)

    '            'For Each row As DataRow In z.Rows
    '            '    Dim itemRow As DataRow = citems.NewRow()
    '            '    itemRow("Display") = row.Item("cmb_no").trim & " # " & row.Item("cmb_name").trim
    '            '    itemRow("Value") = row.Item("cmb_no").trim
    '            '    citems.Rows.Add(itemRow)
    '            'Next row

    '            If z.Rows.Count > 0 Then
    '                Dim dr As DataRow = z.NewRow()
    '                dr("cmb_no") = ""
    '                dr("cmb_name") = ""
    '                dr("DisplayMember") = "Select CMB"
    '                z.Rows.InsertAt(dr, 0)

    '                Cmbno.DisplayMember = "DisplayMember"
    '                Cmbno.ValueMember = "cmb_no"
    '                Cmbno.DataSource = z
    '                'Cmbno.SelectedValue = ""
    '                Cmbno.SelectedIndex = 0
    '            End If
    '            retval = 1
    '        Catch ex As Exception
    '            MessageBox.Show("Error from getcmbno() method of frmPS form, Error : " + ex.Message.ToString())
    '            retval = 0
    '        End Try
    '    End Using

    '    Return retval
    'End Function

    Private Sub cmbPrj_KeyUp(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles cmbPrj.KeyUp
        AutoCompleteCombo_KeyUp(cmbPrj, e)
    End Sub

    Private Sub cmbPrj_Leave(sender As Object, e As System.EventArgs) Handles cmbPrj.Leave
        Dim recRowView As DataRowView

        AutoCompleteCombo_Leave(cmbPrj)

        'OPTIONAL: Now you can  do some extra handling if you want

        'Get the Selected Record from my Data Bound Combo (Return Type is DataRowView)
        recRowView = cmbPrj.SelectedItem
        If recRowView Is Nothing Then Exit Sub

        'Display the Name Info (Row Type comes from my bound Dataset)
        ''recName = recRowView.Row
        ''lblAccountNum.Text = recName.AccountNum
        ''lblCompanyName.Text = recName.CompanyName
    End Sub

    Private Sub cmbPrj_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbPrj.SelectedValueChanged
        If gOpMode = "live" Then
            'If cmbPrj.SelectedValue <> "" Then
            If cmbPrj.SelectedIndex > 0 Then
                Using myservice As New SQLDB()
                    Dim err As String = ""
                    'myservice.Timeout = 2000

                    Dim z As DataTable = myservice.getSeamFromProject(cmbPrj.SelectedValue, gPROCESS, err)
                    ''txtSeam.Text = z.ToString
                    'Dim disValue As String = ""
                    'Dim fldValue As String = ""

                    'Dim citems As DataTable = New DataTable()
                    'citems.Columns.Add("Display")
                    'citems.Columns.Add("Value")

                    'Dim itemRow1 As DataRow = citems.NewRow()
                    'itemRow1("Display") = "Select Seam No"
                    'itemRow1("Value") = ""
                    'citems.Rows.Add(itemRow1)

                    'For Each row As DataRow In z.Rows
                    '    Dim itemRow As DataRow = citems.NewRow()
                    '    itemRow("Display") = row.Item("t_seam").trim
                    '    itemRow("Value") = row.Item("t_seam").trim
                    '    citems.Rows.Add(itemRow)
                    'Next row

                    Dim dr As DataRow = z.NewRow()
                    dr("t_seam") = "Select Seam "
                    z.Rows.InsertAt(dr, 0)

                    cmbSeam.DisplayMember = "t_seam"
                    cmbSeam.ValueMember = "t_seam"
                    cmbSeam.DataSource = z
                    'cmbSeam.SelectedValue = ""
                    cmbSeam.SelectedIndex = 0

                End Using
            End If
        End If
    End Sub

    Private Sub Label8_Click(sender As System.Object, e As System.EventArgs) 

    End Sub

    Private Sub frmPS_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Panel1.Top = 10
        Panel1.Left = (Me.Width - Panel1.Width) / 2
    End Sub

    Private Sub cmbSeam_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbSeam.SelectedValueChanged
        If gOpMode = "live" Then
            'If cmbSeam.SelectedValue <> "" Then
            If cmbSeam.SelectedIndex > 0 Then
                Using myservice As New SQLDB()
                    Dim err As String = ""
                    'myservice.Timeout = 2000

                    Dim z As DataTable = myservice.getWPSDetail(cmbPrj.SelectedValue, cmbSeam.SelectedValue, err)
                    ''txtSeam.Text = z.ToString

                    'Dim disValue As String = ""
                    'Dim fldValue As String = ""

                    'Dim citems As DataTable = New DataTable()
                    'citems.Columns.Add("Display")
                    'citems.Columns.Add("Value")

                    'Dim itemRow1 As DataRow = citems.NewRow()
                    'itemRow1("Display") = "Select WPS No"
                    'itemRow1("Value") = ""
                    'citems.Rows.Add(itemRow1)

                    'For Each row As DataRow In z.Rows
                    '    Dim itemRow As DataRow = citems.NewRow()
                    '    itemRow("Display") = row.Item("t_wpsn").trim & " " & row.Item("t_wpsa").trim & " " & row.Item("t_wpsb").trim
                    '    itemRow("Value") = row.Item("t_wpsn").trim
                    '    citems.Rows.Add(itemRow)
                    'Next row

                    Dim dr As DataRow = z.NewRow()
                    dr("t_wpsn") = ""
                    dr("t_wpsa") = ""
                    dr("t_wpsb") = ""
                    dr("DisplayMember") = "Select WPS "
                    z.Rows.InsertAt(dr, 0)

                    cmbWPS.DisplayMember = "DisplayMember"
                    cmbWPS.ValueMember = "t_wpsn"
                    cmbWPS.DataSource = z
                    'cmbWPS.SelectedValue = ""
                    cmbWPS.SelectedIndex = 0
                End Using
            End If
        End If
    End Sub

    Private Sub CmbWedpol_select(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmbWedpol.Click
        Dim key As String = DirectCast(CmbWedpol.SelectedItem, KeyValuePair(Of String, String)).Key
        Dim value As String = DirectCast(CmbWedpol.SelectedItem, KeyValuePair(Of String, String)).Value
    End Sub

    Private Sub CmbProcess1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmbProcess.Click
        Dim keyy As String = DirectCast(CmbProcess.SelectedItem, KeyValuePair(Of String, String)).Key
        Dim value As String = DirectCast(CmbProcess.SelectedItem, KeyValuePair(Of String, String)).Value
    End Sub



    'Private Sub CmbProcess2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmbProcess.DropDownClosed

    '    If CmbProcess.SelectedValue = 2 Then
    '        CmbWedpol.Text = "DC"
    '        CmbWedpol.Enabled = False
    '    End If

    '    If CmbProcess.SelectedValue = 1 Then
    '        CmbWedpol.Text = "DC"
    '        CmbWedpol.Enabled = False
    '    End If
    'End Sub
End Class