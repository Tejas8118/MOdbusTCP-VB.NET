﻿Imports System.Configuration
Imports System.Data.OleDb
Imports System.Net
Imports System.Net.NetworkInformation
'----------------------------------
' iotESSC for L&T
' by  trapasia DigiReach @ 2017
' Auxiliary Form loaded with application start, Hide/show method used 
' to keep operational status
'----------------------------------
Public Class frmAux
    Dim rs As New Resizer
    Dim phs As String = "man"
    Dim tx As String = ""
    Dim rx As String = ""
    Dim dr As OleDbDataReader
    Dim wcmax1, wvmax1, wsmax1, ftmax1, jtmax1 As String

    Dim plcinstrg As String = ""
    Dim digits1() As Integer
    Dim digits2() As Integer
    Dim digits3() As Integer
    Dim digits4() As Integer
    Dim digits5() As Integer
    Dim digits6() As Integer
    Dim digits7() As Integer
    Dim digits8() As Integer
    Dim digits9() As Integer
    Dim digits10() As Integer

    Dim errno As Integer = 0

    Dim y As Integer = 0
    Dim y1 As Double = 0.0

    Private Sub frmAux_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        rs.FindAllControls(Me)
        Me.WindowState = FormWindowState.Maximized
        'tScreenupd.Interval = 1000
        'tScreenupd.Enabled = True
        'tFlog.Interval = gFluxWghtLogInt * 1000
        'tFlog.Enabled = True
        Wrkb1.Visible = False


    End Sub
    Private Sub Frmaux_Activated(sender As Object, e As System.EventArgs) Handles Me.Activated
        '/////////   Analog And Togle read Function ////////////////////
        Togleread()
        Analogread()
    End Sub
    Private Sub FrmAux_GotFocus(sender As Object, e As System.EventArgs) Handles Me.GotFocus
        ''  MessageBox.Show("hii")
    End Sub
    Public Sub Togleread()

        Try
            errno = 0
            If isConnection = True Then


                '//////////////   Device 1TO 10 ////////////////
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 00 82 00 0A", 80)
                Dim x1() As String = plcinstrg.Split(" "c)
                If x1.Count >= 8 Then
                    If x1(6) = "02" And x1(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x1(10) & x1(9)))
                        digits1 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 1
                        '///////////////// check condition  //////////////////////
                        If digits1(0) = 1 Then
                            btnDevice1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                            btnDevice1.Tag = 1
                        Else
                            btnDevice1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                            btnDevice1.Tag = 0
                        End If

                        If digits1(1) = 1 Then
                            btnDevice2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                            btnDevice2.Tag = 1
                        Else
                            btnDevice2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                            btnDevice2.Tag = 0
                        End If

                        If digits1(2) = 1 Then
                            btnDevice3.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                            btnDevice3.Tag = 1
                        Else
                            btnDevice3.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                            btnDevice3.Tag = 0
                        End If

                        If digits1(3) = 1 Then
                            btnDevice4.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                            btnDevice4.Tag = 1
                        Else
                            btnDevice4.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                            btnDevice4.Tag = 0
                        End If

                        If digits1(4) = 1 Then
                            btnDevice5.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                            btnDevice5.Tag = 1
                        Else
                            btnDevice5.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                            btnDevice5.Tag = 0
                        End If

                        If digits1(5) = 1 Then
                            btnDevice6.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                            btnDevice6.Tag = 1
                        Else
                            btnDevice6.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                            btnDevice6.Tag = 0
                        End If

                        If digits1(6) = 1 Then
                            btnDevice7.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                            btnDevice7.Tag = 1
                        Else
                            btnDevice7.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                            btnDevice7.Tag = 0
                        End If

                        If digits1(7) = 1 Then
                            btnDevice8.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                            btnDevice8.Tag = 1
                            btnDevice8.Text = "W/F-2 Local"
                        Else
                            btnDevice8.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                            btnDevice8.Tag = 0
                            btnDevice8.Text = "W/F-2 Remote"
                        End If

                        If digits1(8) = 1 Then
                            btnDevice9.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                            btnDevice9.Tag = 1
                            btnDevice9.Text = "W/F-1 Local"
                        Else
                            btnDevice9.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                            btnDevice9.Tag = 0
                            btnDevice9.Text = "W/F-1 Remote"
                        End If

                    End If
                End If


                '//////////////   Device 1TO 10 ////////////////
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 01 00 E2 00 08", 100)
                Dim x2() As String = plcinstrg.Split(" "c)
                If x2.Count >= 8 Then
                    If x2(6) = "02" And x2(7) = "01" Then
                        Dim bin As String = ReverseString(Hex2Bin(x2(10) & x2(9)))
                        digits2 = System.Array.ConvertAll(Of Char, Integer)(bin.ToString.ToCharArray, Function(c As Char) Integer.Parse(c.ToString))
                        errno = 2

                        '///////////////// check condition  //////////////////////
                        If digits2(0) = 1 Then
                            btnWFONOFF1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.WF1ON
                            btnWFONOFF1.Tag = 1
                        Else
                            btnWFONOFF1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.WF1OFF
                            btnWFONOFF1.Tag = 0
                        End If

                        ''If digits2(1) = 1 Then
                        ''    btnWireFeedTrig1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                        ''    btnWireFeedTrig1.Tag = 1
                        ''Else
                        ''    btnWireFeedTrig1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                        ''    btnWireFeedTrig1.Tag = 0
                        ''End If

                        If digits2(2) = 1 Then
                            HWPSONOFF1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hwp1on
                            HWPSONOFF1.Tag = 1
                        Else
                            HWPSONOFF1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hwp1off
                            HWPSONOFF1.Tag = 0
                        End If

                        ''If digits2(3) = 1 Then
                        ''    btnHotWireTrig1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                        ''    btnHotWireTrig1.Tag = 1
                        ''Else
                        ''    btnHotWireTrig1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                        ''    btnHotWireTrig1.Tag = 0
                        ''End If

                        If digits2(4) = 1 Then
                            btnWFONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.WF2ON
                            btnWFONOFF2.Tag = 1
                        Else
                            btnWFONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.WF2OFF
                            btnWFONOFF2.Tag = 0
                        End If

                        ''If digits2(5) = 1 Then
                        ''    btnWireFeedTrig2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                        ''    btnWireFeedTrig2.Tag = 1
                        ''Else
                        ''    btnWireFeedTrig2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                        ''    btnWireFeedTrig2.Tag = 0
                        ''End If

                        If digits2(6) = 1 Then
                            HWPSONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hwp2on
                            HWPSONOFF2.Tag = 1
                        Else
                            HWPSONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hwp2off
                            HWPSONOFF2.Tag = 0
                        End If

                        ''If digits2(7) = 1 Then
                        ''    btnHotWireTrig2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                        ''    btnHotWireTrig2.Tag = 1
                        ''Else
                        ''    btnHotWireTrig2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                        ''    btnHotWireTrig2.Tag = 0
                        ''End If


                    End If
                End If



            End If

        Catch ex As Exception
            Dim result1 As String = MessageBoxEx.Show("Error in FrmAux Toogle read Method : " + ex.Message.ToString() + errno.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString

            ' MessageBox.Show("Error in FrmAux Toogle read Method : " + ex.Message.ToString() + errno.ToString())
        End Try
    End Sub

    Public Sub Analogread()
        Try
            errno = 0
            Dim y As Double = 0.0

            Dim y1 As Double = 0.0
            If isConnection = True Then

                '///////////////////////// W/F  1  /////////////////////
                y = 0
                y1 = 0.0
                plcinstrg = ""

                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E4 00 06", 70)
                Dim x7() As String = plcinstrg.Split(" "c)
                If x7.Count >= 8 Then
                    If x7(6) = "02" And x7(7) = "03" Then
                        y = Convert.ToInt32(x7(11) & x7(12) & x7(9) & x7(10), 16)
                        gSetWFSpeed1 = (y / 10)
                        txtWFSpeed1.Text = gSetWFSpeed1
                        y = 0
                        y = Convert.ToInt32(x7(15) & x7(16) & x7(13) & x7(14), 16)
                        gSetWFStartDelay1 = (y / 10)
                        txtWFStartDelay1.Text = gSetWFStartDelay1
                        y = 0
                        y = Convert.ToInt32(x7(19) & x7(20) & x7(17) & x7(18), 16)
                        gSetWFRetractDistance1 = (y / 10)
                        txtWFRetract1.Text = gSetWFRetractDistance1
                        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        errno = 1
                    End If
                End If

                '///////////////////////// W/F  2  /////////////////////
                y = 0
                y1 = 0.0
                plcinstrg = ""

                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 EE 00 06", 70)
                Dim x8() As String = plcinstrg.Split(" "c)
                If x8.Count >= 8 Then
                    If x8(6) = "02" And x8(7) = "03" Then
                        y = Convert.ToInt32(x8(11) & x8(12) & x8(9) & x8(10), 16)
                        gSetWFSpeed2 = (y / 10)
                        txtWFSpeed2.Text = gSetWFSpeed2
                        y = 0
                        y = Convert.ToInt32(x8(15) & x8(16) & x8(13) & x8(14), 16)
                        gSetWFStartDelay2 = (y / 10)
                        txtWFStartDelay2.Text = gSetWFStartDelay2
                        y = 0
                        y = Convert.ToInt32(x8(19) & x8(20) & x8(17) & x8(18), 16)
                        gSetWFRetractDistance2 = (y / 10)
                        txtWFRetract2.Text = gSetWFRetractDistance2
                        ' MessageBox.Show("Current from plc Y=  = " + y.ToString())
                        ' MessageBox.Show("Essc current := " + gESSCcur.ToString())
                        errno = 2
                    End If
                End If


            End If
        Catch ex As Exception
            Dim result1 As String = MessageBoxEx.Show("Error in FrmAux Analog read Method : " + ex.Message.ToString() + errno.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString

            ' MessageBox.Show("Error in Frm Aux Analog Read Method : " + ex.Message.ToString() + errno.ToString())
        End Try
    End Sub

    Private Sub btnAuxRef_Click(sender As System.Object, e As System.EventArgs)
        Dim result As String = MessageBoxEx.Show("Reset value to 0 ? ", "Confirmation", System.Windows.Forms.MessageBoxButtons.YesNo, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 10, "").ToString
        If result = "Yes" Then
            gRef = 1
        End If
    End Sub

    Private Sub btnIRHeating_Click(sender As System.Object, e As System.EventArgs) Handles btnDevice8.Click
        If e Is EventArgs.Empty Then
        Else
            If btnDevice8.Tag = 0 Then
                btnDevice8.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                btnDevice8.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 89 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                    btnDevice8.Text = "W/F-2 Local"

                End If
                If rx.Count > 8 Then

                End If
            Else
                btnDevice8.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                btnDevice8.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 89 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                    btnDevice8.Text = "W/F-2 Remote"
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If
    End Sub

    Private Sub btnFRU_Click(sender As System.Object, e As System.EventArgs) Handles btnDevice9.Click
        If e Is EventArgs.Empty Then
        Else
            If btnDevice9.Tag = 0 Then
                btnDevice9.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                btnDevice9.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 8A FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                    btnDevice9.Text = "W/F-1 Local"
                End If
                If rx.Count > 8 Then

                End If
            Else
                btnDevice9.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                btnDevice9.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 8A 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                    btnDevice9.Text = "W/F-1 Remote"
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If
    End Sub

    Private Sub btnfume_Click(sender As System.Object, e As System.EventArgs) Handles btnDevice3.Click
        If e Is EventArgs.Empty Then
        Else
            If btnDevice3.Tag = 0 Then
                btnDevice3.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                btnDevice3.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 84 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            Else
                btnDevice3.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                btnDevice3.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 84 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If
    End Sub

    Private Sub btnAc_Click(sender As System.Object, e As System.EventArgs) Handles btnDevice1.Click
        If e Is EventArgs.Empty Then
        Else
            If btnDevice1.Tag = 0 Then
                btnDevice1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                btnDevice1.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 82 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            Else
                btnDevice1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                btnDevice1.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 82 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If
    End Sub


    Private Sub btnLamp_Click(sender As System.Object, e As System.EventArgs) Handles btnDevice4.Click
        If e Is EventArgs.Empty Then
        Else
            If btnDevice4.Tag = 0 Then
                btnDevice4.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                btnDevice4.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 85 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            Else
                btnDevice4.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                btnDevice4.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 85 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If
    End Sub

    Private Sub btnFluxOven_Click(sender As Object, e As EventArgs) Handles btnDevice6.Click
        If e Is EventArgs.Empty Then
        Else
            If btnDevice6.Tag = 0 Then
                btnDevice6.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                btnDevice6.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 87 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            Else
                btnDevice6.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                btnDevice6.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 87 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If
    End Sub


    Private Sub btnWFONOFF1_Click(sender As Object, e As EventArgs) Handles btnWFONOFF1.Click
        If e Is EventArgs.Empty Then
        Else
            If btnWFONOFF1.Tag = 0 Then
                btnWFONOFF1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.WF1ON
                btnWFONOFF1.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 D5 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If

            Else
                btnWFONOFF1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.WF1OFF
                btnWFONOFF1.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""
                    tx = "00 00 00 00 00 06 02 05 00 D5 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If

            End If
        End If


    End Sub

    'Private Sub btnWFONOFF2_Click(sender As Object, e As EventArgs) Handles btnWFONOFF2.Click
    '    If e Is EventArgs.Empty Then
    '    Else
    '        If btnWFONOFF2.Tag = 0 Then
    '            btnWFONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.WF2ON
    '            btnWFONOFF2.Tag = 1
    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""

    '                tx = "00 00 00 00 00 06 02 05 00 E6 FF 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 8 Then

    '            End If
    '        Else
    '            btnWFONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.WF2OFF
    '            btnWFONOFF2.Tag = 0
    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""

    '                tx = "00 00 00 00 00 06 02 05 00 E6 00 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 8 Then

    '            End If
    '        End If

    '    End If
    'End Sub

    Private Sub HWPSONOFF1_Click(sender As Object, e As EventArgs) Handles HWPSONOFF1.Click
        If e Is EventArgs.Empty Then
        Else
            If HWPSONOFF1.Tag = 0 Then
                HWPSONOFF1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hwp1on
                HWPSONOFF1.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 E4 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            Else
                HWPSONOFF1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hwp1off
                HWPSONOFF1.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 E4 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If
    End Sub

    'Private Sub HWPSONOFF2_Click(sender As Object, e As EventArgs) Handles HWPSONOFF2.Click
    '    If e Is EventArgs.Empty Then
    '    Else
    '        If HWPSONOFF2.Tag = 0 Then
    '            HWPSONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hwp2on
    '            HWPSONOFF2.Tag = 1
    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""

    '                tx = "00 00 00 00 00 06 02 05 00 E8 FF 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 8 Then

    '            End If
    '        Else
    '            HWPSONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hwp2off
    '            HWPSONOFF2.Tag = 0
    '            If isConnection = True Then
    '                tx = ""
    '                rx = ""

    '                tx = "00 00 00 00 00 06 02 05 00 E8 00 00"
    '                rx = TCPComA(tx, 10)
    '                'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
    '            End If
    '            If rx.Count > 8 Then

    '            End If
    '        End If

    '    End If
    'End Sub

    ''Private Sub btnWireFeedTrig1_Click(sender As Object, e As EventArgs)
    ''    If e Is EventArgs.Empty Then
    ''    Else
    ''        If btnWireFeedTrig1.Tag = 0 Then
    ''            btnWireFeedTrig1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
    ''            btnWireFeedTrig1.Tag = 1
    ''            If isConnection = True Then
    'tx = ""
    ' rx = ""

    ''                tx = "00 00 00 00 00 06 02 05 00 E3 FF 00"
    ''                rx = TCPComA(tx, 10)
    ''                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
    ''            End If
    ''        Else
    ''            btnWireFeedTrig1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
    ''            btnWireFeedTrig1.Tag = 0
    ''            If isConnection = True Then
    'tx = ""
    ' rx = ""

    ''                tx = "00 00 00 00 00 06 02 05 00 E3 00 00"
    ''                rx = TCPComA(tx, 10)
    ''                'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
    ''            End If
    ''        End If

    ''    End If
    ''End Sub

    ''Private Sub btnHotWireTrig1_Click(sender As Object, e As EventArgs)
    ''    If e Is EventArgs.Empty Then
    ''    Else
    ''        If btnHotWireTrig1.Tag = 0 Then
    ''            btnHotWireTrig1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
    ''            btnHotWireTrig1.Tag = 1
    ''            If isConnection = True Then
    'tx = ""
    'rx = ""

    ''                tx = "00 00 00 00 00 06 02 05 00 E5 FF 00"
    ''                rx = TCPComA(tx, 10)
    ''                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
    ''            End If
    ''        Else
    ''            btnHotWireTrig1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
    ''            btnHotWireTrig1.Tag = 0
    ''            If isConnection = True Then
    'tx = ""
    'rx = ""

    ''                tx = "00 00 00 00 00 06 02 05 00 E5 00 00"
    ''                rx = TCPComA(tx, 10)
    ''                'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
    ''            End If
    ''        End If

    ''    End If
    ''End Sub

    ''Private Sub btnWireFeedTrig2_Click(sender As Object, e As EventArgs)
    ''    If e Is EventArgs.Empty Then
    ''    Else
    ''        If btnWireFeedTrig2.Tag = 0 Then
    ''            btnWireFeedTrig2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
    ''            btnWireFeedTrig2.Tag = 1
    ''            If isConnection = True Then
    'tx = ""
    'rx = ""

    ''                tx = "00 00 00 00 00 06 02 05 00 E7 FF 00"
    ''                rx = TCPComA(tx, 10)
    ''                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
    ''            End If
    ''        Else
    ''            btnWireFeedTrig2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
    ''            btnWireFeedTrig2.Tag = 0
    ''            If isConnection = True Then
    'tx = ""
    'rx = ""

    ''                tx = "00 00 00 00 00 06 02 05 00 E7 00 00"
    ''                rx = TCPComA(tx, 10)
    ''                'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
    ''            End If
    ''        End If

    ''    End If
    ''End Sub

    ''Private Sub btnHotWireTrig2_Click(sender As Object, e As EventArgs)
    ''    If e Is EventArgs.Empty Then
    ''    Else
    ''        If btnHotWireTrig2.Tag = 0 Then
    ''            btnHotWireTrig2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
    ''            btnHotWireTrig2.Tag = 1
    ''            If isConnection = True Then
    'tx = ""
    'rx = ""

    ''                tx = "00 00 00 00 00 06 02 05 00 E9 FF 00"
    ''                rx = TCPComA(tx, 10)
    ''                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
    ''            End If
    ''        Else
    ''            btnHotWireTrig2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
    ''            btnHotWireTrig2.Tag = 0
    ''            If isConnection = True Then
    'tx = ""
    'rx = ""

    ''                tx = "00 00 00 00 00 06 02 05 00 E9 00 00"
    ''                rx = TCPComA(tx, 10)
    ''                'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
    ''            End If
    ''        End If

    ''    End If

    '''End Sub
    Private Sub txtWFSpeed1_gotfocus(sender As Object, e As EventArgs) Handles txtWFSpeed1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtWFSpeed1
    End Sub

    Private Sub txtWFSpeed1_TextChanged(sender As Object, e As EventArgs) Handles txtWFSpeed1.TextChanged
        Dim arr As Integer = 0
        arr = txtWFSpeed1.TextLength
        Dim st As String = ""

        st = txtWFSpeed1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtWFSpeed1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtWFSpeed1.Text += ii(ht)
                    Next
                    If txtWFSpeed1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtWFSpeed1.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001E4000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)

                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E4 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetWFSpeed1 = (y / 10)
                                    txtWFSpeed1.Text = gSetWFSpeed1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtWFSpeed1.Text = gSetWFSpeed1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok

                        End Select

                    End If
                Else
                    txtWFSpeed1.Text = gSetWFSpeed1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If
    End Sub

    'Private Sub txtWFSpeed2_gotfocus(sender As Object, e As EventArgs) Handles txtWFSpeed2.GotFocus
    '    Wrkb1.Visible = True
    '    Wrkb1.CurrTextBox = txtWFSpeed2
    'End Sub

    'Private Sub txtWFSpeed2_TextChanged(sender As Object, e As EventArgs) Handles txtWFSpeed2.TextChanged
    '    Dim arr As Integer = 0
    '    arr = txtWFSpeed2.TextLength
    '    Dim st As String = ""

    '    st = txtWFSpeed2.Text
    '    Dim ii() As Char = st.ToCharArray
    '    ''''lblalarm.Text = arr
    '    If (arr > 1) Then
    '        If ii(arr - 1) = "K" Then

    '            If (arr <> 2) Then
    '                txtWFSpeed2.Text = ""
    '                For ht As Integer = 0 To (arr - 3)
    '                    txtWFSpeed2.Text += ii(ht)
    '                Next
    '                If txtWFSpeed2.Text <> "-" Then
    '                    If isConnection = True Then
    '                        Dim t01 As Integer = txtWFSpeed2.Text 
    '                        Dim t02 As String = SingleToHex(t01)
    '                        Dim h1 As String = "00000000000B021001EE000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
    ' tx = ""
    '  rx = ""

    '                        tx = h1 
    '                        Dim verticalolread As String = TCPComA(tx, 100)
    '                        'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
    '                        'If verticalolread.Length <> 24 Then
    '                        '    MessageBox.Show("Error in Communicating..")
    '                        'Else
    '                        '    gsetesscpara = 1
    '                        '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
    '                        '        Case MsgBoxResult.Ok
    '                        '    End Select
    '                        'End If
    '                        Threading.Thread.Sleep(500)
    '                        ''/////////   REad String //////////
    '                        y = 0
    '                        y1 = 0
    '                        Dim plcinstrg As String = ""
    '                        plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 EE 00 02", 50)
    '                        Dim x1() As String = plcinstrg.Split(" "c)
    '                        If x1.Count >= 8 Then
    '                            If x1(6) = "02" And x1(7) = "03" Then
    '                                y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
    '                                gSetWFSpeed2 = Convert.ToDouble(y.ToString("0.0"))
    '                                txtWFSpeed2.Text = gSetWFSpeed2.ToString()
    '                            End If
    '                        End If


    '                    End If
    '                Else
    '                    txtWFSpeed2.Text = gSetWFSpeed2.ToString()
    '                    Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
    '                        Case MsgBoxResult.Ok
    '                    End Select
    '                End If
    '            Else
    '                txtWFSpeed2.Text = gSetWFSpeed2.ToString()
    '                Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
    '                    Case MsgBoxResult.Ok
    '                End Select
    '            End If

    '        End If
    '    End If

    'End Sub
    Private Sub txtWFStartDelay1_gotfocus(sender As Object, e As EventArgs) Handles txtWFStartDelay1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtWFStartDelay1
    End Sub

    Private Sub txtWFStartDelay1_TextChanged(sender As Object, e As EventArgs) Handles txtWFStartDelay1.TextChanged
        Dim arr As Integer = 0
        arr = txtWFStartDelay1.TextLength
        Dim st As String = ""

        st = txtWFStartDelay1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtWFStartDelay1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtWFStartDelay1.Text += ii(ht)
                    Next
                    If txtWFStartDelay1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtWFStartDelay1.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001E6000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E6 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetWFStartDelay1 = (y / 10)
                                    txtWFStartDelay1.Text = gSetWFStartDelay1.ToString()
                                End If
                            End If


                        End If
                    Else
                        txtWFStartDelay1.Text = gSetWFStartDelay1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtWFStartDelay1.Text = gSetWFStartDelay1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub

    'Private Sub txtWFStartDelay2_gotfocus(sender As Object, e As EventArgs) Handles txtWFStartDelay2.GotFocus
    '    Wrkb1.Visible = True
    '    Wrkb1.CurrTextBox = txtWFStartDelay2
    'End Sub

    'Private Sub txtWFStartDelay2_TextChanged(sender As Object, e As EventArgs) Handles txtWFStartDelay2.TextChanged
    '    Dim arr As Integer = 0
    '    arr = txtWFStartDelay2.TextLength
    '    Dim st As String = ""

    '    st = txtWFStartDelay2.Text
    '    Dim ii() As Char = st.ToCharArray
    '    ''''lblalarm.Text = arr
    '    If (arr > 1) Then
    '        If ii(arr - 1) = "K" Then

    '            If (arr <> 2) Then
    '                txtWFStartDelay2.Text = ""
    '                For ht As Integer = 0 To (arr - 3)
    '                    txtWFStartDelay2.Text += ii(ht)
    '                Next
    '                If txtWFStartDelay2.Text <> "-" Then
    '                    If isConnection = True Then
    '                        Dim t01 As Integer = txtWFStartDelay2.Text 
    '                        Dim t02 As String = SingleToHex(t01)
    '                        Dim h1 As String = "00000000000B021001F0000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
    'tx = ""
    ' rx = ""

    '                        tx = h1 
    '                        Dim verticalolread As String = TCPComA(tx, 100)
    '                        'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
    '                        'If verticalolread.Length <> 24 Then
    '                        '    MessageBox.Show("Error in Communicating..")
    '                        'Else
    '                        '    gsetesscpara = 1
    '                        '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
    '                        '        Case MsgBoxResult.Ok
    '                        '    End Select
    '                        'End If
    '                        Threading.Thread.Sleep(500)
    '                        ''/////////   REad String //////////
    '                        y = 0
    '                        y1 = 0
    '                        Dim plcinstrg As String = ""
    '                        plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 F0 00 02", 50)
    '                        Dim x1() As String = plcinstrg.Split(" "c)
    '                        If x1.Count >= 8 Then
    '                            If x1(6) = "02" And x1(7) = "03" Then
    '                                y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
    '                                gSetWFStartDelay2 = Convert.ToDouble(y.ToString("0.0"))
    '                                txtWFStartDelay2.Text = gSetWFStartDelay2.ToString()
    '                            End If
    '                        End If


    '                    End If
    '                Else
    '                    txtWFStartDelay2.Text = gSetWFStartDelay2.ToString()
    '                    Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
    '                        Case MsgBoxResult.Ok
    '                    End Select
    '                End If
    '            Else
    '                txtWFStartDelay2.Text = gSetWFStartDelay2.ToString()
    '                Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
    '                    Case MsgBoxResult.Ok
    '                End Select
    '            End If

    '        End If
    '    End If

    'End Sub
    Private Sub txtWFRetract1_gotfocus(sender As Object, e As EventArgs) Handles txtWFRetract1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtWFRetract1
    End Sub
    Private Sub txtWFRetract1_TextChanged(sender As Object, e As EventArgs) Handles txtWFRetract1.TextChanged
        Dim arr As Integer = 0
        arr = txtWFRetract1.TextLength
        Dim st As String = ""

        st = txtWFRetract1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtWFRetract1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtWFRetract1.Text += ii(ht)
                    Next
                    If txtWFRetract1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtWFRetract1.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001E8000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 E8 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetWFRetractDistance1 = (y / 10)
                                    txtWFRetract1.Text = gSetWFRetractDistance1.ToString()
                                End If
                            End If


                        End If
                    Else
                        txtWFRetract1.Text = gSetWFRetractDistance1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtWFRetract1.Text = gSetWFRetractDistance1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub

    Private Sub btnSyncData_Click(sender As Object, e As EventArgs) Handles btnSyncData.Click
        If gWeldingStart Then
            MessageBox.Show("Welding is going on, Please push local data after welding is off.")
        Else
            DataSync(ProgressBar3, 2) '2 is Manual
        End If
    End Sub

    Private Sub ProgressBar3_Click(sender As Object, e As EventArgs) Handles ProgressBar3.Click

    End Sub

    Private Sub HWPSONOFF2_Click(sender As Object, e As EventArgs) Handles HWPSONOFF2.Click
        If e Is EventArgs.Empty Then
        Else
            If HWPSONOFF2.Tag = 0 Then
                HWPSONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hwp2on
                HWPSONOFF2.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 E8 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If

            Else
                HWPSONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.hwp2off
                HWPSONOFF2.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 E8 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If
    End Sub

    Private Sub btnWFONOFF2_Click(sender As Object, e As EventArgs) Handles btnWFONOFF2.Click
        If e Is EventArgs.Empty Then
        Else
            If btnWFONOFF2.Tag = 0 Then
                btnWFONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.WF2ON
                btnWFONOFF2.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 DF FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            Else
                btnWFONOFF2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.WF2OFF
                btnWFONOFF2.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 DF 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If
    End Sub
    Private Sub txtWFSpeed2_gotfocus(sender As Object, e As EventArgs) Handles txtWFSpeed2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtWFSpeed2
    End Sub

    Private Sub txtWFSpeed2_TextChanged(sender As Object, e As EventArgs) Handles txtWFSpeed2.TextChanged
        Dim arr As Integer = 0
        arr = txtWFSpeed2.TextLength
        Dim st As String = ""

        st = txtWFSpeed2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtWFSpeed2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtWFSpeed2.Text += ii(ht)
                    Next
                    If txtWFSpeed2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtWFSpeed2.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001EE000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)

                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 EE 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetWFSpeed2 = (y / 10)
                                    txtWFSpeed2.Text = gSetWFSpeed2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtWFSpeed2.Text = gSetWFSpeed2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok

                        End Select

                    End If
                Else
                    txtWFSpeed2.Text = gSetWFSpeed2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If
    End Sub

    Private Sub txtWFStartDelay2_gotfocus(sender As Object, e As EventArgs) Handles txtWFStartDelay2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtWFStartDelay2
    End Sub

    Private Sub txtWFStartDelay2_TextChanged(sender As Object, e As EventArgs) Handles txtWFStartDelay2.TextChanged
        Dim arr As Integer = 0
        arr = txtWFStartDelay2.TextLength
        Dim st As String = ""

        st = txtWFStartDelay2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtWFStartDelay2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtWFStartDelay2.Text += ii(ht)
                    Next
                    If txtWFStartDelay2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtWFStartDelay2.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001F0000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 F0 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetWFStartDelay2 = (y / 10)
                                    txtWFStartDelay2.Text = gSetWFStartDelay2.ToString()
                                End If
                            End If


                        End If
                    Else
                        txtWFStartDelay2.Text = gSetWFStartDelay2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtWFStartDelay2.Text = gSetWFStartDelay2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub

    Private Sub txtWFRetract2_gotfocus(sender As Object, e As EventArgs) Handles txtWFRetract2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtWFRetract2
    End Sub
    Private Sub txtWFRetract2_TextChanged(sender As Object, e As EventArgs) Handles txtWFRetract2.TextChanged
        Dim arr As Integer = 0
        arr = txtWFRetract2.TextLength
        Dim st As String = ""

        st = txtWFRetract2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtWFRetract2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtWFRetract2.Text += ii(ht)
                    Next
                    If txtWFRetract2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtWFRetract2.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001F2000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1
                            Dim verticalolread As String = TCPComA(tx, 100)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 F2 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSetWFRetractDistance2 = (y / 10)
                                    txtWFRetract2.Text = gSetWFRetractDistance2.ToString()
                                End If
                            End If


                        End If
                    Else
                        txtWFRetract2.Text = gSetWFRetractDistance2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtWFRetract2.Text = gSetWFRetractDistance2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub



    Private Sub btnflux_Click(sender As System.Object, e As System.EventArgs) Handles btnDevice7.Click
        If e Is EventArgs.Empty Then
        Else
            If btnDevice7.Tag = 0 Then
                btnDevice7.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                btnDevice7.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 88 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            Else
                btnDevice7.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                btnDevice7.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 88 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If

    End Sub

    Private Sub btnMagnet_Click(sender As System.Object, e As System.EventArgs) Handles btnDevice2.Click
        If e Is EventArgs.Empty Then
        Else
            If btnDevice2.Tag = 0 Then
                btnDevice2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                btnDevice2.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 83 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            Else
                btnDevice2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                btnDevice2.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 83 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If
    End Sub

    Private Sub frmAux_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        rs.ResizeAllControls(Me)


        If gclick = 1 Then
            btnDevice5.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
            btnDevice5.Enabled = False
            gclick = 0
        End If

        If gclick = 2 Then
            btnDevice5.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
            btnDevice5.Enabled = True
            gclick = 0
        End If
    End Sub

    Private Sub btnheadc_Click(sender As Object, e As EventArgs) Handles btnDevice5.Click
        If e Is EventArgs.Empty Then
        Else
            If btnDevice5.Tag = 0 Then
                btnDevice5.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btngreen
                btnDevice5.Tag = 1
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 86 FF 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            Else
                btnDevice5.BackgroundImage = Global.iotPIPECLEDING.My.Resources.btnblue
                btnDevice5.Tag = 0
                If isConnection = True Then
                    tx = ""
                    rx = ""

                    tx = "00 00 00 00 00 06 02 05 00 86 00 00"
                    rx = TCPComA(tx, 10)
                    'writeLog("|Auxlmp stop |TX:" & tx & "|RX:" & rx)
                End If
                If rx.Count > 8 Then

                End If
            End If

        End If

        gclick = 0
    End Sub

End Class