﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAxis
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.lblRAXISREVLIMIT = New System.Windows.Forms.Label()
        Me.lblXAXISFWDLIMIT = New System.Windows.Forms.Label()
        Me.lblYAXISFWDLIMIT = New System.Windows.Forms.Label()
        Me.lblTAXISFWDLIMIT = New System.Windows.Forms.Label()
        Me.lblAAXISFWDLIMIT = New System.Windows.Forms.Label()
        Me.lblRAXISFWDLIMIT = New System.Windows.Forms.Label()
        Me.lblXAXISREVLIMIT = New System.Windows.Forms.Label()
        Me.lblYAXISREVLIMIT = New System.Windows.Forms.Label()
        Me.lblTAXISREVLIMIT = New System.Windows.Forms.Label()
        Me.lblAAXISREVLIMIT = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.lblAO5 = New System.Windows.Forms.Label()
        Me.lblAO6 = New System.Windows.Forms.Label()
        Me.lblAO7 = New System.Windows.Forms.Label()
        Me.lblAO8 = New System.Windows.Forms.Label()
        Me.lblAO3 = New System.Windows.Forms.Label()
        Me.lblAO4 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lblAO2 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.lblAO1 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblAI6 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblAI8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblAI7 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblAI5 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblAI4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblAI3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblAI1 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.lblAI2 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Location = New System.Drawing.Point(11, 11)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1132, 537)
        Me.Panel1.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Location = New System.Drawing.Point(855, 499)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(91, 31)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.Panel2.Controls.Add(Me.Label42)
        Me.Panel2.Controls.Add(Me.Label40)
        Me.Panel2.Controls.Add(Me.Label39)
        Me.Panel2.Controls.Add(Me.Label38)
        Me.Panel2.Controls.Add(Me.Label37)
        Me.Panel2.Controls.Add(Me.Label36)
        Me.Panel2.Controls.Add(Me.Label35)
        Me.Panel2.Controls.Add(Me.lblRAXISREVLIMIT)
        Me.Panel2.Controls.Add(Me.lblXAXISFWDLIMIT)
        Me.Panel2.Controls.Add(Me.lblYAXISFWDLIMIT)
        Me.Panel2.Controls.Add(Me.lblTAXISFWDLIMIT)
        Me.Panel2.Controls.Add(Me.lblAAXISFWDLIMIT)
        Me.Panel2.Controls.Add(Me.lblRAXISFWDLIMIT)
        Me.Panel2.Controls.Add(Me.lblXAXISREVLIMIT)
        Me.Panel2.Controls.Add(Me.lblYAXISREVLIMIT)
        Me.Panel2.Controls.Add(Me.lblTAXISREVLIMIT)
        Me.Panel2.Controls.Add(Me.lblAAXISREVLIMIT)
        Me.Panel2.Controls.Add(Me.Label24)
        Me.Panel2.Controls.Add(Me.Label23)
        Me.Panel2.Controls.Add(Me.Label22)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Controls.Add(Me.Label20)
        Me.Panel2.Controls.Add(Me.Label19)
        Me.Panel2.Controls.Add(Me.Label18)
        Me.Panel2.Controls.Add(Me.lblAO5)
        Me.Panel2.Controls.Add(Me.lblAO6)
        Me.Panel2.Controls.Add(Me.lblAO7)
        Me.Panel2.Controls.Add(Me.lblAO8)
        Me.Panel2.Controls.Add(Me.lblAO3)
        Me.Panel2.Controls.Add(Me.lblAO4)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.lblAO2)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.lblAO1)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.lblAI6)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.lblAI8)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.lblAI7)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.lblAI5)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.lblAI4)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.lblAI3)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.lblAI1)
        Me.Panel2.Controls.Add(Me.Label41)
        Me.Panel2.Controls.Add(Me.lblAI2)
        Me.Panel2.Location = New System.Drawing.Point(12, 9)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1103, 486)
        Me.Panel2.TabIndex = 0
        '
        'Label42
        '
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(700, 64)
        Me.Label42.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(102, 20)
        Me.Label42.TabIndex = 307
        Me.Label42.Text = "X AXIS LIMIT"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label40
        '
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(700, 107)
        Me.Label40.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(102, 20)
        Me.Label40.TabIndex = 306
        Me.Label40.Text = "Y AXIS LIMIT"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label39
        '
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(700, 149)
        Me.Label39.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(102, 20)
        Me.Label39.TabIndex = 305
        Me.Label39.Text = "T AXIS LIMIT"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label38
        '
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(700, 190)
        Me.Label38.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(102, 20)
        Me.Label38.TabIndex = 304
        Me.Label38.Text = "A AXIS LIMIT"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label37
        '
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(700, 230)
        Me.Label37.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(102, 20)
        Me.Label37.TabIndex = 303
        Me.Label37.Text = "R AXIS LIMIT"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label36
        '
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Red
        Me.Label36.Location = New System.Drawing.Point(967, 36)
        Me.Label36.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(89, 20)
        Me.Label36.TabIndex = 302
        Me.Label36.Text = "FWD LIMIT"
        '
        'Label35
        '
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Red
        Me.Label35.Location = New System.Drawing.Point(816, 36)
        Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(89, 20)
        Me.Label35.TabIndex = 301
        Me.Label35.Text = "FWD LIMIT"
        '
        'lblRAXISREVLIMIT
        '
        Me.lblRAXISREVLIMIT.AutoEllipsis = True
        Me.lblRAXISREVLIMIT.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblRAXISREVLIMIT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRAXISREVLIMIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRAXISREVLIMIT.ForeColor = System.Drawing.SystemColors.Info
        Me.lblRAXISREVLIMIT.Location = New System.Drawing.Point(970, 222)
        Me.lblRAXISREVLIMIT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblRAXISREVLIMIT.Name = "lblRAXISREVLIMIT"
        Me.lblRAXISREVLIMIT.Size = New System.Drawing.Size(83, 30)
        Me.lblRAXISREVLIMIT.TabIndex = 300
        Me.lblRAXISREVLIMIT.Text = "000.0"
        Me.lblRAXISREVLIMIT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblXAXISFWDLIMIT
        '
        Me.lblXAXISFWDLIMIT.AutoEllipsis = True
        Me.lblXAXISFWDLIMIT.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblXAXISFWDLIMIT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblXAXISFWDLIMIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblXAXISFWDLIMIT.ForeColor = System.Drawing.SystemColors.Info
        Me.lblXAXISFWDLIMIT.Location = New System.Drawing.Point(818, 59)
        Me.lblXAXISFWDLIMIT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblXAXISFWDLIMIT.Name = "lblXAXISFWDLIMIT"
        Me.lblXAXISFWDLIMIT.Size = New System.Drawing.Size(83, 30)
        Me.lblXAXISFWDLIMIT.TabIndex = 299
        Me.lblXAXISFWDLIMIT.Text = "000.0"
        Me.lblXAXISFWDLIMIT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblYAXISFWDLIMIT
        '
        Me.lblYAXISFWDLIMIT.AutoEllipsis = True
        Me.lblYAXISFWDLIMIT.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblYAXISFWDLIMIT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblYAXISFWDLIMIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYAXISFWDLIMIT.ForeColor = System.Drawing.SystemColors.Info
        Me.lblYAXISFWDLIMIT.Location = New System.Drawing.Point(818, 100)
        Me.lblYAXISFWDLIMIT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblYAXISFWDLIMIT.Name = "lblYAXISFWDLIMIT"
        Me.lblYAXISFWDLIMIT.Size = New System.Drawing.Size(83, 30)
        Me.lblYAXISFWDLIMIT.TabIndex = 298
        Me.lblYAXISFWDLIMIT.Text = "000.0"
        Me.lblYAXISFWDLIMIT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTAXISFWDLIMIT
        '
        Me.lblTAXISFWDLIMIT.AutoEllipsis = True
        Me.lblTAXISFWDLIMIT.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblTAXISFWDLIMIT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTAXISFWDLIMIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTAXISFWDLIMIT.ForeColor = System.Drawing.SystemColors.Info
        Me.lblTAXISFWDLIMIT.Location = New System.Drawing.Point(818, 142)
        Me.lblTAXISFWDLIMIT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTAXISFWDLIMIT.Name = "lblTAXISFWDLIMIT"
        Me.lblTAXISFWDLIMIT.Size = New System.Drawing.Size(83, 30)
        Me.lblTAXISFWDLIMIT.TabIndex = 297
        Me.lblTAXISFWDLIMIT.Text = "000.0"
        Me.lblTAXISFWDLIMIT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAAXISFWDLIMIT
        '
        Me.lblAAXISFWDLIMIT.AutoEllipsis = True
        Me.lblAAXISFWDLIMIT.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAAXISFWDLIMIT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAAXISFWDLIMIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAAXISFWDLIMIT.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAAXISFWDLIMIT.Location = New System.Drawing.Point(818, 182)
        Me.lblAAXISFWDLIMIT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAAXISFWDLIMIT.Name = "lblAAXISFWDLIMIT"
        Me.lblAAXISFWDLIMIT.Size = New System.Drawing.Size(83, 30)
        Me.lblAAXISFWDLIMIT.TabIndex = 296
        Me.lblAAXISFWDLIMIT.Text = "000.0"
        Me.lblAAXISFWDLIMIT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblRAXISFWDLIMIT
        '
        Me.lblRAXISFWDLIMIT.AutoEllipsis = True
        Me.lblRAXISFWDLIMIT.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblRAXISFWDLIMIT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRAXISFWDLIMIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRAXISFWDLIMIT.ForeColor = System.Drawing.SystemColors.Info
        Me.lblRAXISFWDLIMIT.Location = New System.Drawing.Point(818, 222)
        Me.lblRAXISFWDLIMIT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblRAXISFWDLIMIT.Name = "lblRAXISFWDLIMIT"
        Me.lblRAXISFWDLIMIT.Size = New System.Drawing.Size(83, 30)
        Me.lblRAXISFWDLIMIT.TabIndex = 295
        Me.lblRAXISFWDLIMIT.Text = "000.0"
        Me.lblRAXISFWDLIMIT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblXAXISREVLIMIT
        '
        Me.lblXAXISREVLIMIT.AutoEllipsis = True
        Me.lblXAXISREVLIMIT.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblXAXISREVLIMIT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblXAXISREVLIMIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblXAXISREVLIMIT.ForeColor = System.Drawing.SystemColors.Info
        Me.lblXAXISREVLIMIT.Location = New System.Drawing.Point(970, 59)
        Me.lblXAXISREVLIMIT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblXAXISREVLIMIT.Name = "lblXAXISREVLIMIT"
        Me.lblXAXISREVLIMIT.Size = New System.Drawing.Size(83, 30)
        Me.lblXAXISREVLIMIT.TabIndex = 294
        Me.lblXAXISREVLIMIT.Text = "000.0"
        Me.lblXAXISREVLIMIT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblYAXISREVLIMIT
        '
        Me.lblYAXISREVLIMIT.AutoEllipsis = True
        Me.lblYAXISREVLIMIT.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblYAXISREVLIMIT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblYAXISREVLIMIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYAXISREVLIMIT.ForeColor = System.Drawing.SystemColors.Info
        Me.lblYAXISREVLIMIT.Location = New System.Drawing.Point(970, 100)
        Me.lblYAXISREVLIMIT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblYAXISREVLIMIT.Name = "lblYAXISREVLIMIT"
        Me.lblYAXISREVLIMIT.Size = New System.Drawing.Size(83, 30)
        Me.lblYAXISREVLIMIT.TabIndex = 293
        Me.lblYAXISREVLIMIT.Text = "000.0"
        Me.lblYAXISREVLIMIT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTAXISREVLIMIT
        '
        Me.lblTAXISREVLIMIT.AutoEllipsis = True
        Me.lblTAXISREVLIMIT.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblTAXISREVLIMIT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTAXISREVLIMIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTAXISREVLIMIT.ForeColor = System.Drawing.SystemColors.Info
        Me.lblTAXISREVLIMIT.Location = New System.Drawing.Point(970, 142)
        Me.lblTAXISREVLIMIT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTAXISREVLIMIT.Name = "lblTAXISREVLIMIT"
        Me.lblTAXISREVLIMIT.Size = New System.Drawing.Size(83, 30)
        Me.lblTAXISREVLIMIT.TabIndex = 292
        Me.lblTAXISREVLIMIT.Text = "000.0"
        Me.lblTAXISREVLIMIT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAAXISREVLIMIT
        '
        Me.lblAAXISREVLIMIT.AutoEllipsis = True
        Me.lblAAXISREVLIMIT.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAAXISREVLIMIT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAAXISREVLIMIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAAXISREVLIMIT.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAAXISREVLIMIT.Location = New System.Drawing.Point(970, 182)
        Me.lblAAXISREVLIMIT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAAXISREVLIMIT.Name = "lblAAXISREVLIMIT"
        Me.lblAAXISREVLIMIT.Size = New System.Drawing.Size(83, 30)
        Me.lblAAXISREVLIMIT.TabIndex = 291
        Me.lblAAXISREVLIMIT.Text = "000.0"
        Me.lblAAXISREVLIMIT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(98, 381)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(237, 20)
        Me.Label24.TabIndex = 290
        Me.Label24.Text = "AO3- TRAVEL SPEED REF"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label23
        '
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(98, 433)
        Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(192, 20)
        Me.Label23.TabIndex = 289
        Me.Label23.Text = "AO4- SPARE"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(444, 274)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(119, 20)
        Me.Label22.TabIndex = 288
        Me.Label22.Text = "AO5-  SPARE"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(444, 319)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(119, 20)
        Me.Label21.TabIndex = 287
        Me.Label21.Text = "AO6-  SPARE"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(444, 377)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(119, 20)
        Me.Label20.TabIndex = 286
        Me.Label20.Text = "AO7-  SPARE"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(444, 440)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(119, 20)
        Me.Label19.TabIndex = 285
        Me.Label19.Text = "AO8-  SPARE"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label18.Location = New System.Drawing.Point(607, 5)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(493, 24)
        Me.Label18.TabIndex = 284
        Me.Label18.Text = "Axis Software Limits"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAO5
        '
        Me.lblAO5.AutoEllipsis = True
        Me.lblAO5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO5.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO5.Location = New System.Drawing.Point(352, 269)
        Me.lblAO5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO5.Name = "lblAO5"
        Me.lblAO5.Size = New System.Drawing.Size(83, 30)
        Me.lblAO5.TabIndex = 283
        Me.lblAO5.Text = "000.0"
        Me.lblAO5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO6
        '
        Me.lblAO6.AutoEllipsis = True
        Me.lblAO6.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO6.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO6.Location = New System.Drawing.Point(352, 317)
        Me.lblAO6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO6.Name = "lblAO6"
        Me.lblAO6.Size = New System.Drawing.Size(83, 30)
        Me.lblAO6.TabIndex = 282
        Me.lblAO6.Text = "000.0"
        Me.lblAO6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO7
        '
        Me.lblAO7.AutoEllipsis = True
        Me.lblAO7.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO7.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO7.Location = New System.Drawing.Point(352, 377)
        Me.lblAO7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO7.Name = "lblAO7"
        Me.lblAO7.Size = New System.Drawing.Size(83, 30)
        Me.lblAO7.TabIndex = 281
        Me.lblAO7.Text = "000.0"
        Me.lblAO7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO8
        '
        Me.lblAO8.AutoEllipsis = True
        Me.lblAO8.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO8.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO8.Location = New System.Drawing.Point(352, 434)
        Me.lblAO8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO8.Name = "lblAO8"
        Me.lblAO8.Size = New System.Drawing.Size(83, 30)
        Me.lblAO8.TabIndex = 280
        Me.lblAO8.Text = "000.0"
        Me.lblAO8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO3
        '
        Me.lblAO3.AutoEllipsis = True
        Me.lblAO3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO3.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO3.Location = New System.Drawing.Point(11, 377)
        Me.lblAO3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO3.Name = "lblAO3"
        Me.lblAO3.Size = New System.Drawing.Size(83, 30)
        Me.lblAO3.TabIndex = 279
        Me.lblAO3.Text = "000.0"
        Me.lblAO3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO4
        '
        Me.lblAO4.AutoEllipsis = True
        Me.lblAO4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO4.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO4.Location = New System.Drawing.Point(11, 432)
        Me.lblAO4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO4.Name = "lblAO4"
        Me.lblAO4.Size = New System.Drawing.Size(83, 30)
        Me.lblAO4.TabIndex = 278
        Me.lblAO4.Text = "000.0"
        Me.lblAO4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(8, 231)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(579, 24)
        Me.Label4.TabIndex = 277
        Me.Label4.Text = "Analog Output "
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(8, 5)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(584, 24)
        Me.Label2.TabIndex = 276
        Me.Label2.Text = "Analog Input "
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(98, 324)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(237, 20)
        Me.Label17.TabIndex = 275
        Me.Label17.Text = "AO2- WELDING VOLTAGE REF"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO2
        '
        Me.lblAO2.AutoEllipsis = True
        Me.lblAO2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO2.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO2.Location = New System.Drawing.Point(11, 322)
        Me.lblAO2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO2.Name = "lblAO2"
        Me.lblAO2.Size = New System.Drawing.Size(83, 30)
        Me.lblAO2.TabIndex = 274
        Me.lblAO2.Text = "000.0"
        Me.lblAO2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(98, 272)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(237, 20)
        Me.Label15.TabIndex = 273
        Me.Label15.Text = "AO1- WELDING CURRENT REF"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAO1
        '
        Me.lblAO1.AutoEllipsis = True
        Me.lblAO1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAO1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAO1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAO1.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAO1.Location = New System.Drawing.Point(11, 267)
        Me.lblAO1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAO1.Name = "lblAO1"
        Me.lblAO1.Size = New System.Drawing.Size(83, 30)
        Me.lblAO1.TabIndex = 272
        Me.lblAO1.Text = "000.0"
        Me.lblAO1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(400, 95)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(192, 20)
        Me.Label13.TabIndex = 271
        Me.Label13.Text = "AI-6 SPARE"
        '
        'lblAI6
        '
        Me.lblAI6.AutoEllipsis = True
        Me.lblAI6.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI6.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI6.Location = New System.Drawing.Point(299, 88)
        Me.lblAI6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI6.Name = "lblAI6"
        Me.lblAI6.Size = New System.Drawing.Size(83, 30)
        Me.lblAI6.TabIndex = 270
        Me.lblAI6.Text = "000.0"
        Me.lblAI6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(395, 188)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(192, 20)
        Me.Label11.TabIndex = 269
        Me.Label11.Text = "AI8- JOB TEMPERATURE"
        '
        'lblAI8
        '
        Me.lblAI8.AutoEllipsis = True
        Me.lblAI8.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI8.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI8.Location = New System.Drawing.Point(299, 181)
        Me.lblAI8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI8.Name = "lblAI8"
        Me.lblAI8.Size = New System.Drawing.Size(83, 30)
        Me.lblAI8.TabIndex = 268
        Me.lblAI8.Text = "000.0"
        Me.lblAI8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(400, 145)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(192, 20)
        Me.Label9.TabIndex = 267
        Me.Label9.Text = "AI7- TRAVEL SPEED"
        '
        'lblAI7
        '
        Me.lblAI7.AutoEllipsis = True
        Me.lblAI7.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI7.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI7.Location = New System.Drawing.Point(299, 137)
        Me.lblAI7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI7.Name = "lblAI7"
        Me.lblAI7.Size = New System.Drawing.Size(83, 30)
        Me.lblAI7.TabIndex = 266
        Me.lblAI7.Text = "000.0"
        Me.lblAI7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(403, 44)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(192, 20)
        Me.Label7.TabIndex = 265
        Me.Label7.Text = "AI5- GAS FLOW SENSOR"
        '
        'lblAI5
        '
        Me.lblAI5.AutoEllipsis = True
        Me.lblAI5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI5.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI5.Location = New System.Drawing.Point(299, 39)
        Me.lblAI5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI5.Name = "lblAI5"
        Me.lblAI5.Size = New System.Drawing.Size(83, 30)
        Me.lblAI5.TabIndex = 264
        Me.lblAI5.Text = "000.0"
        Me.lblAI5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(96, 188)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(192, 20)
        Me.Label5.TabIndex = 263
        Me.Label5.Text = "AI4- AI-4 SPARE"
        '
        'lblAI4
        '
        Me.lblAI4.AutoEllipsis = True
        Me.lblAI4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI4.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI4.Location = New System.Drawing.Point(11, 181)
        Me.lblAI4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI4.Name = "lblAI4"
        Me.lblAI4.Size = New System.Drawing.Size(83, 30)
        Me.lblAI4.TabIndex = 262
        Me.lblAI4.Text = "000.0"
        Me.lblAI4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(96, 145)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(192, 20)
        Me.Label3.TabIndex = 261
        Me.Label3.Text = "AI3- HOT WIRE CURRENT"
        '
        'lblAI3
        '
        Me.lblAI3.AutoEllipsis = True
        Me.lblAI3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI3.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI3.Location = New System.Drawing.Point(11, 137)
        Me.lblAI3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI3.Name = "lblAI3"
        Me.lblAI3.Size = New System.Drawing.Size(83, 30)
        Me.lblAI3.TabIndex = 260
        Me.lblAI3.Text = "000.0"
        Me.lblAI3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(98, 44)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(192, 20)
        Me.Label1.TabIndex = 259
        Me.Label1.Text = "AI1- WELDING CURRENT"
        '
        'lblAI1
        '
        Me.lblAI1.AutoEllipsis = True
        Me.lblAI1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI1.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI1.Location = New System.Drawing.Point(11, 39)
        Me.lblAI1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI1.Name = "lblAI1"
        Me.lblAI1.Size = New System.Drawing.Size(83, 30)
        Me.lblAI1.TabIndex = 258
        Me.lblAI1.Text = "000.0"
        Me.lblAI1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label41
        '
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(96, 95)
        Me.Label41.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(192, 20)
        Me.Label41.TabIndex = 257
        Me.Label41.Text = "AI2- WELDING VOLTAGE"
        '
        'lblAI2
        '
        Me.lblAI2.AutoEllipsis = True
        Me.lblAI2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.lblAI2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAI2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAI2.ForeColor = System.Drawing.SystemColors.Info
        Me.lblAI2.Location = New System.Drawing.Point(11, 88)
        Me.lblAI2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAI2.Name = "lblAI2"
        Me.lblAI2.Size = New System.Drawing.Size(83, 30)
        Me.lblAI2.TabIndex = 256
        Me.lblAI2.Text = "000.0"
        Me.lblAI2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmAxis
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1348, 850)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmAxis"
        Me.Text = "frmAxis"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label42 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents lblRAXISREVLIMIT As Label
    Friend WithEvents lblXAXISFWDLIMIT As Label
    Friend WithEvents lblYAXISFWDLIMIT As Label
    Friend WithEvents lblTAXISFWDLIMIT As Label
    Friend WithEvents lblAAXISFWDLIMIT As Label
    Friend WithEvents lblRAXISFWDLIMIT As Label
    Friend WithEvents lblXAXISREVLIMIT As Label
    Friend WithEvents lblYAXISREVLIMIT As Label
    Friend WithEvents lblTAXISREVLIMIT As Label
    Friend WithEvents lblAAXISREVLIMIT As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents lblAO5 As Label
    Friend WithEvents lblAO6 As Label
    Friend WithEvents lblAO7 As Label
    Friend WithEvents lblAO8 As Label
    Friend WithEvents lblAO3 As Label
    Friend WithEvents lblAO4 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents lblAO2 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents lblAO1 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents lblAI6 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents lblAI8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents lblAI7 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lblAI5 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblAI4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblAI3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblAI1 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents lblAI2 As Label
End Class
