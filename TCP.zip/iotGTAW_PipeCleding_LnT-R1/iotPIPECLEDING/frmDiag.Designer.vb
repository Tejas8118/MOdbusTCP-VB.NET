﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDiag
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.btnLimistatus = New System.Windows.Forms.Button()
        Me.btnDigSts = New System.Windows.Forms.Button()
        Me.btnang = New System.Windows.Forms.Button()
        Me.pnlTR = New System.Windows.Forms.Panel()
        Me.txtFC5 = New System.Windows.Forms.TextBox()
        Me.txtFC4 = New System.Windows.Forms.TextBox()
        Me.txtFC3 = New System.Windows.Forms.TextBox()
        Me.txtFC2 = New System.Windows.Forms.TextBox()
        Me.txtFC1 = New System.Windows.Forms.TextBox()
        Me.btnResetAll = New System.Windows.Forms.Button()
        Me.lblAlarm = New System.Windows.Forms.Label()
        Me.lblHealthy = New System.Windows.Forms.Label()
        Me.lblFault = New System.Windows.Forms.Label()
        Me.lblYfwdlimit = New System.Windows.Forms.Label()
        Me.lblTfwdlimit = New System.Windows.Forms.Label()
        Me.lblAfwdlimit = New System.Windows.Forms.Label()
        Me.lblRfwdlimit = New System.Windows.Forms.Label()
        Me.lblYreviimit = New System.Windows.Forms.Label()
        Me.lblTrevlimit = New System.Windows.Forms.Label()
        Me.lblArevlimit = New System.Windows.Forms.Label()
        Me.lblRrevlimit = New System.Windows.Forms.Label()
        Me.lblXfwdlimit = New System.Windows.Forms.Label()
        Me.lblXrevlimit = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.lblF29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.lblF28 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.lblF27 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.lblF23 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lblF20 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblF17 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblF14 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblF11 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblF19 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.lblF25 = New System.Windows.Forms.Label()
        Me.lblF15 = New System.Windows.Forms.Label()
        Me.lblF26 = New System.Windows.Forms.Label()
        Me.lblF30 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.lblF16 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.lblF18 = New System.Windows.Forms.Label()
        Me.lblF24 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.lblF22 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.lblF21 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.lblF10 = New System.Windows.Forms.Label()
        Me.lblF12 = New System.Windows.Forms.Label()
        Me.lblF9 = New System.Windows.Forms.Label()
        Me.lblF13 = New System.Windows.Forms.Label()
        Me.DIOx7 = New System.Windows.Forms.Label()
        Me.DIOx6 = New System.Windows.Forms.Label()
        Me.DIOx5 = New System.Windows.Forms.Label()
        Me.DIOx4 = New System.Windows.Forms.Label()
        Me.DIOx3 = New System.Windows.Forms.Label()
        Me.DIOx2 = New System.Windows.Forms.Label()
        Me.DIOx1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblF2 = New System.Windows.Forms.Label()
        Me.lblF3 = New System.Windows.Forms.Label()
        Me.lblF1 = New System.Windows.Forms.Label()
        Me.lblF4 = New System.Windows.Forms.Label()
        Me.lblF5 = New System.Windows.Forms.Label()
        Me.lblF6 = New System.Windows.Forms.Label()
        Me.lblF7 = New System.Windows.Forms.Label()
        Me.lblF8 = New System.Windows.Forms.Label()
        Me.Labei1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel6.SuspendLayout()
        Me.pnlTR.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Panel6.Controls.Add(Me.Button2)
        Me.Panel6.Controls.Add(Me.btnLimistatus)
        Me.Panel6.Controls.Add(Me.btnDigSts)
        Me.Panel6.Controls.Add(Me.btnang)
        Me.Panel6.Controls.Add(Me.pnlTR)
        Me.Panel6.Controls.Add(Me.Button1)
        Me.Panel6.Location = New System.Drawing.Point(6, 11)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(1077, 650)
        Me.Panel6.TabIndex = 0
        '
        'Button2
        '
        Me.Button2.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button2.Location = New System.Drawing.Point(829, 604)
        Me.Button2.Margin = New System.Windows.Forms.Padding(2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(119, 37)
        Me.Button2.TabIndex = 18
        Me.Button2.Text = "AI/AO Delay"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'btnLimistatus
        '
        Me.btnLimistatus.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.btnLimistatus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnLimistatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLimistatus.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnLimistatus.Location = New System.Drawing.Point(727, 604)
        Me.btnLimistatus.Margin = New System.Windows.Forms.Padding(2)
        Me.btnLimistatus.Name = "btnLimistatus"
        Me.btnLimistatus.Size = New System.Drawing.Size(91, 37)
        Me.btnLimistatus.TabIndex = 17
        Me.btnLimistatus.Text = "Limitsts"
        Me.btnLimistatus.UseVisualStyleBackColor = True
        '
        'btnDigSts
        '
        Me.btnDigSts.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.btnDigSts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDigSts.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDigSts.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDigSts.Location = New System.Drawing.Point(468, 604)
        Me.btnDigSts.Margin = New System.Windows.Forms.Padding(2)
        Me.btnDigSts.Name = "btnDigSts"
        Me.btnDigSts.Size = New System.Drawing.Size(119, 37)
        Me.btnDigSts.TabIndex = 16
        Me.btnDigSts.Text = "DIDO Status"
        Me.btnDigSts.UseVisualStyleBackColor = True
        '
        'btnang
        '
        Me.btnang.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.btnang.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnang.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnang.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnang.Location = New System.Drawing.Point(593, 604)
        Me.btnang.Margin = New System.Windows.Forms.Padding(2)
        Me.btnang.Name = "btnang"
        Me.btnang.Size = New System.Drawing.Size(130, 37)
        Me.btnang.TabIndex = 15
        Me.btnang.Text = "Analog Status"
        Me.btnang.UseVisualStyleBackColor = True
        '
        'pnlTR
        '
        Me.pnlTR.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.pnlTR.Controls.Add(Me.txtFC5)
        Me.pnlTR.Controls.Add(Me.txtFC4)
        Me.pnlTR.Controls.Add(Me.txtFC3)
        Me.pnlTR.Controls.Add(Me.txtFC2)
        Me.pnlTR.Controls.Add(Me.txtFC1)
        Me.pnlTR.Controls.Add(Me.btnResetAll)
        Me.pnlTR.Controls.Add(Me.lblAlarm)
        Me.pnlTR.Controls.Add(Me.lblHealthy)
        Me.pnlTR.Controls.Add(Me.lblFault)
        Me.pnlTR.Controls.Add(Me.lblYfwdlimit)
        Me.pnlTR.Controls.Add(Me.lblTfwdlimit)
        Me.pnlTR.Controls.Add(Me.lblAfwdlimit)
        Me.pnlTR.Controls.Add(Me.lblRfwdlimit)
        Me.pnlTR.Controls.Add(Me.lblYreviimit)
        Me.pnlTR.Controls.Add(Me.lblTrevlimit)
        Me.pnlTR.Controls.Add(Me.lblArevlimit)
        Me.pnlTR.Controls.Add(Me.lblRrevlimit)
        Me.pnlTR.Controls.Add(Me.lblXfwdlimit)
        Me.pnlTR.Controls.Add(Me.lblXrevlimit)
        Me.pnlTR.Controls.Add(Me.Label3)
        Me.pnlTR.Controls.Add(Me.Label2)
        Me.pnlTR.Controls.Add(Me.Label1)
        Me.pnlTR.Controls.Add(Me.Label10)
        Me.pnlTR.Controls.Add(Me.Label30)
        Me.pnlTR.Controls.Add(Me.lblF29)
        Me.pnlTR.Controls.Add(Me.Label28)
        Me.pnlTR.Controls.Add(Me.lblF28)
        Me.pnlTR.Controls.Add(Me.Label24)
        Me.pnlTR.Controls.Add(Me.lblF27)
        Me.pnlTR.Controls.Add(Me.Label21)
        Me.pnlTR.Controls.Add(Me.lblF23)
        Me.pnlTR.Controls.Add(Me.Label17)
        Me.pnlTR.Controls.Add(Me.lblF20)
        Me.pnlTR.Controls.Add(Me.Label13)
        Me.pnlTR.Controls.Add(Me.lblF17)
        Me.pnlTR.Controls.Add(Me.Label11)
        Me.pnlTR.Controls.Add(Me.lblF14)
        Me.pnlTR.Controls.Add(Me.Label5)
        Me.pnlTR.Controls.Add(Me.lblF11)
        Me.pnlTR.Controls.Add(Me.Label7)
        Me.pnlTR.Controls.Add(Me.lblF19)
        Me.pnlTR.Controls.Add(Me.Label73)
        Me.pnlTR.Controls.Add(Me.Label104)
        Me.pnlTR.Controls.Add(Me.Label75)
        Me.pnlTR.Controls.Add(Me.Label76)
        Me.pnlTR.Controls.Add(Me.Label77)
        Me.pnlTR.Controls.Add(Me.lblF25)
        Me.pnlTR.Controls.Add(Me.lblF15)
        Me.pnlTR.Controls.Add(Me.lblF26)
        Me.pnlTR.Controls.Add(Me.lblF30)
        Me.pnlTR.Controls.Add(Me.Label43)
        Me.pnlTR.Controls.Add(Me.lblF16)
        Me.pnlTR.Controls.Add(Me.Label78)
        Me.pnlTR.Controls.Add(Me.lblF18)
        Me.pnlTR.Controls.Add(Me.lblF24)
        Me.pnlTR.Controls.Add(Me.Label79)
        Me.pnlTR.Controls.Add(Me.Label107)
        Me.pnlTR.Controls.Add(Me.lblF22)
        Me.pnlTR.Controls.Add(Me.Label16)
        Me.pnlTR.Controls.Add(Me.Label52)
        Me.pnlTR.Controls.Add(Me.lblF21)
        Me.pnlTR.Controls.Add(Me.Label106)
        Me.pnlTR.Controls.Add(Me.Label51)
        Me.pnlTR.Controls.Add(Me.Label80)
        Me.pnlTR.Controls.Add(Me.Label83)
        Me.pnlTR.Controls.Add(Me.Label84)
        Me.pnlTR.Controls.Add(Me.Label85)
        Me.pnlTR.Controls.Add(Me.lblF10)
        Me.pnlTR.Controls.Add(Me.lblF12)
        Me.pnlTR.Controls.Add(Me.lblF9)
        Me.pnlTR.Controls.Add(Me.lblF13)
        Me.pnlTR.Controls.Add(Me.DIOx7)
        Me.pnlTR.Controls.Add(Me.DIOx6)
        Me.pnlTR.Controls.Add(Me.DIOx5)
        Me.pnlTR.Controls.Add(Me.DIOx4)
        Me.pnlTR.Controls.Add(Me.DIOx3)
        Me.pnlTR.Controls.Add(Me.DIOx2)
        Me.pnlTR.Controls.Add(Me.DIOx1)
        Me.pnlTR.Controls.Add(Me.Label4)
        Me.pnlTR.Controls.Add(Me.lblF2)
        Me.pnlTR.Controls.Add(Me.lblF3)
        Me.pnlTR.Controls.Add(Me.lblF1)
        Me.pnlTR.Controls.Add(Me.lblF4)
        Me.pnlTR.Controls.Add(Me.lblF5)
        Me.pnlTR.Controls.Add(Me.lblF6)
        Me.pnlTR.Controls.Add(Me.lblF7)
        Me.pnlTR.Controls.Add(Me.lblF8)
        Me.pnlTR.Controls.Add(Me.Labei1)
        Me.pnlTR.Location = New System.Drawing.Point(15, 6)
        Me.pnlTR.Margin = New System.Windows.Forms.Padding(2)
        Me.pnlTR.Name = "pnlTR"
        Me.pnlTR.Size = New System.Drawing.Size(1037, 591)
        Me.pnlTR.TabIndex = 10
        '
        'txtFC5
        '
        Me.txtFC5.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.txtFC5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFC5.Location = New System.Drawing.Point(222, 300)
        Me.txtFC5.Name = "txtFC5"
        Me.txtFC5.Size = New System.Drawing.Size(100, 26)
        Me.txtFC5.TabIndex = 283
        Me.txtFC5.Text = "0000"
        '
        'txtFC4
        '
        Me.txtFC4.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.txtFC4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFC4.Location = New System.Drawing.Point(222, 265)
        Me.txtFC4.Name = "txtFC4"
        Me.txtFC4.Size = New System.Drawing.Size(100, 26)
        Me.txtFC4.TabIndex = 282
        Me.txtFC4.Text = "0000"
        '
        'txtFC3
        '
        Me.txtFC3.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.txtFC3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFC3.Location = New System.Drawing.Point(222, 231)
        Me.txtFC3.Name = "txtFC3"
        Me.txtFC3.Size = New System.Drawing.Size(100, 26)
        Me.txtFC3.TabIndex = 281
        Me.txtFC3.Text = "0000"
        '
        'txtFC2
        '
        Me.txtFC2.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.txtFC2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFC2.Location = New System.Drawing.Point(222, 196)
        Me.txtFC2.Name = "txtFC2"
        Me.txtFC2.Size = New System.Drawing.Size(100, 26)
        Me.txtFC2.TabIndex = 280
        Me.txtFC2.Text = "0000"
        '
        'txtFC1
        '
        Me.txtFC1.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.txtFC1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFC1.Location = New System.Drawing.Point(222, 162)
        Me.txtFC1.Multiline = True
        Me.txtFC1.Name = "txtFC1"
        Me.txtFC1.Size = New System.Drawing.Size(100, 28)
        Me.txtFC1.TabIndex = 279
        Me.txtFC1.Text = "0000"
        '
        'btnResetAll
        '
        Me.btnResetAll.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.resetb
        Me.btnResetAll.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnResetAll.FlatAppearance.BorderSize = 0
        Me.btnResetAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnResetAll.Location = New System.Drawing.Point(855, 486)
        Me.btnResetAll.Name = "btnResetAll"
        Me.btnResetAll.Size = New System.Drawing.Size(155, 63)
        Me.btnResetAll.TabIndex = 278
        Me.btnResetAll.UseVisualStyleBackColor = True
        '
        'lblAlarm
        '
        Me.lblAlarm.Image = Global.iotPIPECLEDING.My.Resources.Resources.alarmG
        Me.lblAlarm.Location = New System.Drawing.Point(752, 479)
        Me.lblAlarm.Name = "lblAlarm"
        Me.lblAlarm.Size = New System.Drawing.Size(82, 83)
        Me.lblAlarm.TabIndex = 277
        '
        'lblHealthy
        '
        Me.lblHealthy.Image = Global.iotPIPECLEDING.My.Resources.Resources.healthyG
        Me.lblHealthy.Location = New System.Drawing.Point(639, 479)
        Me.lblHealthy.Name = "lblHealthy"
        Me.lblHealthy.Size = New System.Drawing.Size(82, 83)
        Me.lblHealthy.TabIndex = 276
        '
        'lblFault
        '
        Me.lblFault.Image = Global.iotPIPECLEDING.My.Resources.Resources.faultG
        Me.lblFault.Location = New System.Drawing.Point(524, 479)
        Me.lblFault.Name = "lblFault"
        Me.lblFault.Size = New System.Drawing.Size(82, 83)
        Me.lblFault.TabIndex = 275
        '
        'lblYfwdlimit
        '
        Me.lblYfwdlimit.AutoEllipsis = True
        Me.lblYfwdlimit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblYfwdlimit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblYfwdlimit.Location = New System.Drawing.Point(918, 130)
        Me.lblYfwdlimit.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblYfwdlimit.Name = "lblYfwdlimit"
        Me.lblYfwdlimit.Size = New System.Drawing.Size(67, 19)
        Me.lblYfwdlimit.TabIndex = 274
        Me.lblYfwdlimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTfwdlimit
        '
        Me.lblTfwdlimit.AutoEllipsis = True
        Me.lblTfwdlimit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblTfwdlimit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTfwdlimit.Location = New System.Drawing.Point(918, 169)
        Me.lblTfwdlimit.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTfwdlimit.Name = "lblTfwdlimit"
        Me.lblTfwdlimit.Size = New System.Drawing.Size(67, 19)
        Me.lblTfwdlimit.TabIndex = 273
        Me.lblTfwdlimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAfwdlimit
        '
        Me.lblAfwdlimit.AutoEllipsis = True
        Me.lblAfwdlimit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblAfwdlimit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAfwdlimit.Location = New System.Drawing.Point(918, 205)
        Me.lblAfwdlimit.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAfwdlimit.Name = "lblAfwdlimit"
        Me.lblAfwdlimit.Size = New System.Drawing.Size(67, 19)
        Me.lblAfwdlimit.TabIndex = 272
        Me.lblAfwdlimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblRfwdlimit
        '
        Me.lblRfwdlimit.AutoEllipsis = True
        Me.lblRfwdlimit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblRfwdlimit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRfwdlimit.Location = New System.Drawing.Point(918, 237)
        Me.lblRfwdlimit.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblRfwdlimit.Name = "lblRfwdlimit"
        Me.lblRfwdlimit.Size = New System.Drawing.Size(67, 19)
        Me.lblRfwdlimit.TabIndex = 271
        Me.lblRfwdlimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblYreviimit
        '
        Me.lblYreviimit.AutoEllipsis = True
        Me.lblYreviimit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblYreviimit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblYreviimit.Location = New System.Drawing.Point(768, 129)
        Me.lblYreviimit.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblYreviimit.Name = "lblYreviimit"
        Me.lblYreviimit.Size = New System.Drawing.Size(67, 19)
        Me.lblYreviimit.TabIndex = 270
        Me.lblYreviimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTrevlimit
        '
        Me.lblTrevlimit.AutoEllipsis = True
        Me.lblTrevlimit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblTrevlimit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTrevlimit.Location = New System.Drawing.Point(768, 169)
        Me.lblTrevlimit.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTrevlimit.Name = "lblTrevlimit"
        Me.lblTrevlimit.Size = New System.Drawing.Size(67, 19)
        Me.lblTrevlimit.TabIndex = 269
        Me.lblTrevlimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblArevlimit
        '
        Me.lblArevlimit.AutoEllipsis = True
        Me.lblArevlimit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblArevlimit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblArevlimit.Location = New System.Drawing.Point(768, 203)
        Me.lblArevlimit.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblArevlimit.Name = "lblArevlimit"
        Me.lblArevlimit.Size = New System.Drawing.Size(67, 19)
        Me.lblArevlimit.TabIndex = 268
        Me.lblArevlimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblRrevlimit
        '
        Me.lblRrevlimit.AutoEllipsis = True
        Me.lblRrevlimit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblRrevlimit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRrevlimit.Location = New System.Drawing.Point(768, 237)
        Me.lblRrevlimit.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblRrevlimit.Name = "lblRrevlimit"
        Me.lblRrevlimit.Size = New System.Drawing.Size(67, 19)
        Me.lblRrevlimit.TabIndex = 267
        Me.lblRrevlimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblXfwdlimit
        '
        Me.lblXfwdlimit.AutoEllipsis = True
        Me.lblXfwdlimit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblXfwdlimit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblXfwdlimit.Location = New System.Drawing.Point(918, 88)
        Me.lblXfwdlimit.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblXfwdlimit.Name = "lblXfwdlimit"
        Me.lblXfwdlimit.Size = New System.Drawing.Size(67, 19)
        Me.lblXfwdlimit.TabIndex = 266
        Me.lblXfwdlimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblXrevlimit
        '
        Me.lblXrevlimit.AutoEllipsis = True
        Me.lblXrevlimit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblXrevlimit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblXrevlimit.Location = New System.Drawing.Point(768, 87)
        Me.lblXrevlimit.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblXrevlimit.Name = "lblXrevlimit"
        Me.lblXrevlimit.Size = New System.Drawing.Size(67, 19)
        Me.lblXrevlimit.TabIndex = 265
        Me.lblXrevlimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(370, 100)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(210, 18)
        Me.Label3.TabIndex = 264
        Me.Label3.Text = "F19-HB-P/S HEALTHY"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.AutoEllipsis = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.OrangeRed
        Me.Label2.Location = New System.Drawing.Point(899, 45)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(99, 19)
        Me.Label2.TabIndex = 263
        Me.Label2.Text = "FWD LIMIT"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoEllipsis = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.OrangeRed
        Me.Label1.Location = New System.Drawing.Point(752, 45)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(99, 19)
        Me.Label1.TabIndex = 262
        Me.Label1.Text = "REV LIMIT"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(639, 236)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(71, 19)
        Me.Label10.TabIndex = 261
        Me.Label10.Text = "R-AXIS"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label30
        '
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(619, 389)
        Me.Label30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(143, 18)
        Me.Label30.TabIndex = 253
        Me.Label30.Text = "F29- FAULT-29"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF29
        '
        Me.lblF29.AutoEllipsis = True
        Me.lblF29.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF29.Location = New System.Drawing.Point(591, 389)
        Me.lblF29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF29.Name = "lblF29"
        Me.lblF29.Size = New System.Drawing.Size(17, 19)
        Me.lblF29.TabIndex = 252
        Me.lblF29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(619, 353)
        Me.Label28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(143, 18)
        Me.Label28.TabIndex = 251
        Me.Label28.Text = "F28- FAULT-28"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF28
        '
        Me.lblF28.AutoEllipsis = True
        Me.lblF28.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF28.Location = New System.Drawing.Point(591, 353)
        Me.lblF28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF28.Name = "lblF28"
        Me.lblF28.Size = New System.Drawing.Size(17, 19)
        Me.lblF28.TabIndex = 250
        Me.lblF28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(619, 318)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(143, 18)
        Me.Label24.TabIndex = 249
        Me.Label24.Text = "F27- FAULT-27"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF27
        '
        Me.lblF27.AutoEllipsis = True
        Me.lblF27.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF27.Location = New System.Drawing.Point(591, 318)
        Me.lblF27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF27.Name = "lblF27"
        Me.lblF27.Size = New System.Drawing.Size(17, 19)
        Me.lblF27.TabIndex = 248
        Me.lblF27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(370, 235)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(236, 18)
        Me.Label21.TabIndex = 247
        Me.Label21.Text = "F23- HB-W/F COMMUNICATION"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF23
        '
        Me.lblF23.AutoEllipsis = True
        Me.lblF23.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF23.Location = New System.Drawing.Point(342, 235)
        Me.lblF23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF23.Name = "lblF23"
        Me.lblF23.Size = New System.Drawing.Size(17, 19)
        Me.lblF23.TabIndex = 246
        Me.lblF23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(370, 133)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(221, 18)
        Me.Label17.TabIndex = 245
        Me.Label17.Text = "F20- HB-GAS FLOW ERROR"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF20
        '
        Me.lblF20.AutoEllipsis = True
        Me.lblF20.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF20.Location = New System.Drawing.Point(342, 133)
        Me.lblF20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF20.Name = "lblF20"
        Me.lblF20.Size = New System.Drawing.Size(17, 19)
        Me.lblF20.TabIndex = 244
        Me.lblF20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(370, 36)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(236, 18)
        Me.Label13.TabIndex = 243
        Me.Label13.Text = "F17- PERAMETER SELECTION"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF17
        '
        Me.lblF17.AutoEllipsis = True
        Me.lblF17.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF17.Location = New System.Drawing.Point(342, 36)
        Me.lblF17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF17.Name = "lblF17"
        Me.lblF17.Size = New System.Drawing.Size(17, 19)
        Me.lblF17.TabIndex = 242
        Me.lblF17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(56, 486)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(239, 19)
        Me.Label11.TabIndex = 241
        Me.Label11.Text = "F14-HA- WIREFEED HEALTHY"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF14
        '
        Me.lblF14.AutoEllipsis = True
        Me.lblF14.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF14.Location = New System.Drawing.Point(23, 486)
        Me.lblF14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF14.Name = "lblF14"
        Me.lblF14.Size = New System.Drawing.Size(17, 19)
        Me.lblF14.TabIndex = 240
        Me.lblF14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(56, 379)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(217, 19)
        Me.Label5.TabIndex = 239
        Me.Label5.Text = "F11- HA-GAS FLOW ERROR"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF11
        '
        Me.lblF11.AutoEllipsis = True
        Me.lblF11.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF11.Location = New System.Drawing.Point(23, 379)
        Me.lblF11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF11.Name = "lblF11"
        Me.lblF11.Size = New System.Drawing.Size(17, 19)
        Me.lblF11.TabIndex = 238
        Me.lblF11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(535, 0)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(505, 24)
        Me.Label7.TabIndex = 217
        Me.Label7.Text = "Alarm Status"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblF19
        '
        Me.lblF19.AutoEllipsis = True
        Me.lblF19.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF19.Location = New System.Drawing.Point(342, 99)
        Me.lblF19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF19.Name = "lblF19"
        Me.lblF19.Size = New System.Drawing.Size(16, 19)
        Me.lblF19.TabIndex = 214
        Me.lblF19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label73
        '
        Me.Label73.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.Location = New System.Drawing.Point(56, 557)
        Me.Label73.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(227, 18)
        Me.Label73.TabIndex = 60
        Me.Label73.Text = "F16- HA-ARC ON F/B FAULT"
        Me.Label73.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label104
        '
        Me.Label104.AutoEllipsis = True
        Me.Label104.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.Location = New System.Drawing.Point(56, 524)
        Me.Label104.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(206, 18)
        Me.Label104.TabIndex = 151
        Me.Label104.Text = "F15- HA-HWP/S HEALTHY"
        '
        'Label75
        '
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.Location = New System.Drawing.Point(619, 425)
        Me.Label75.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(143, 18)
        Me.Label75.TabIndex = 58
        Me.Label75.Text = "F30- FAULT-30"
        Me.Label75.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label76
        '
        Me.Label76.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(619, 282)
        Me.Label76.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(143, 18)
        Me.Label76.TabIndex = 57
        Me.Label76.Text = "F26- FAULT-26"
        Me.Label76.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label77
        '
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(370, 307)
        Me.Label77.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(128, 18)
        Me.Label77.TabIndex = 56
        Me.Label77.Text = "F25- FAULT-25"
        Me.Label77.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF25
        '
        Me.lblF25.AutoEllipsis = True
        Me.lblF25.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF25.Location = New System.Drawing.Point(342, 307)
        Me.lblF25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF25.Name = "lblF25"
        Me.lblF25.Size = New System.Drawing.Size(17, 19)
        Me.lblF25.TabIndex = 52
        Me.lblF25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF15
        '
        Me.lblF15.AutoEllipsis = True
        Me.lblF15.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF15.Location = New System.Drawing.Point(23, 524)
        Me.lblF15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF15.Name = "lblF15"
        Me.lblF15.Size = New System.Drawing.Size(17, 19)
        Me.lblF15.TabIndex = 148
        '
        'lblF26
        '
        Me.lblF26.AutoEllipsis = True
        Me.lblF26.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF26.Location = New System.Drawing.Point(591, 282)
        Me.lblF26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF26.Name = "lblF26"
        Me.lblF26.Size = New System.Drawing.Size(17, 19)
        Me.lblF26.TabIndex = 54
        Me.lblF26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF30
        '
        Me.lblF30.AutoEllipsis = True
        Me.lblF30.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF30.Location = New System.Drawing.Point(591, 425)
        Me.lblF30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF30.Name = "lblF30"
        Me.lblF30.Size = New System.Drawing.Size(17, 19)
        Me.lblF30.TabIndex = 51
        Me.lblF30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label43
        '
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(370, 68)
        Me.Label43.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(236, 18)
        Me.Label43.TabIndex = 59
        Me.Label43.Text = "F18- HA-W/F COMMUNICATION"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF16
        '
        Me.lblF16.AutoEllipsis = True
        Me.lblF16.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF16.Location = New System.Drawing.Point(23, 557)
        Me.lblF16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF16.Name = "lblF16"
        Me.lblF16.Size = New System.Drawing.Size(17, 19)
        Me.lblF16.TabIndex = 55
        Me.lblF16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label78
        '
        Me.Label78.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.Location = New System.Drawing.Point(370, 271)
        Me.Label78.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(210, 18)
        Me.Label78.TabIndex = 50
        Me.Label78.Text = "F24- HB-OVER CURRENT"
        Me.Label78.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF18
        '
        Me.lblF18.AutoEllipsis = True
        Me.lblF18.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF18.Location = New System.Drawing.Point(342, 68)
        Me.lblF18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF18.Name = "lblF18"
        Me.lblF18.Size = New System.Drawing.Size(16, 19)
        Me.lblF18.TabIndex = 51
        Me.lblF18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF24
        '
        Me.lblF24.AutoEllipsis = True
        Me.lblF24.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF24.Location = New System.Drawing.Point(342, 271)
        Me.lblF24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF24.Name = "lblF24"
        Me.lblF24.Size = New System.Drawing.Size(17, 19)
        Me.lblF24.TabIndex = 49
        Me.lblF24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label79
        '
        Me.Label79.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(370, 199)
        Me.Label79.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(210, 18)
        Me.Label79.TabIndex = 48
        Me.Label79.Text = "F22-HB-HWP/S HEALTHY"
        Me.Label79.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label107
        '
        Me.Label107.AutoEllipsis = True
        Me.Label107.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label107.Location = New System.Drawing.Point(639, 87)
        Me.Label107.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(71, 19)
        Me.Label107.TabIndex = 140
        Me.Label107.Text = "X-AXIS"
        Me.Label107.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblF22
        '
        Me.lblF22.AutoEllipsis = True
        Me.lblF22.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF22.Location = New System.Drawing.Point(342, 199)
        Me.lblF22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF22.Name = "lblF22"
        Me.lblF22.Size = New System.Drawing.Size(17, 19)
        Me.lblF22.TabIndex = 47
        Me.lblF22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(370, 165)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(236, 18)
        Me.Label16.TabIndex = 46
        Me.Label16.Text = "F21- HB-WIREFEED HEALTHY"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label52
        '
        Me.Label52.AutoEllipsis = True
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(639, 129)
        Me.Label52.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(71, 19)
        Me.Label52.TabIndex = 138
        Me.Label52.Text = "- - - "
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblF21
        '
        Me.lblF21.AutoEllipsis = True
        Me.lblF21.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF21.Location = New System.Drawing.Point(342, 165)
        Me.lblF21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF21.Name = "lblF21"
        Me.lblF21.Size = New System.Drawing.Size(17, 19)
        Me.lblF21.TabIndex = 45
        Me.lblF21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label106
        '
        Me.Label106.AutoEllipsis = True
        Me.Label106.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.Location = New System.Drawing.Point(639, 204)
        Me.Label106.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(93, 19)
        Me.Label106.TabIndex = 116
        Me.Label106.Text = "AVC2-AXIS"
        Me.Label106.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label51
        '
        Me.Label51.AutoEllipsis = True
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(639, 168)
        Me.Label51.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(90, 19)
        Me.Label51.TabIndex = 87
        Me.Label51.Text = "AVC1-AXIS"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label80
        '
        Me.Label80.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(56, 450)
        Me.Label80.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(227, 19)
        Me.Label80.TabIndex = 110
        Me.Label80.Text = "F13- WATER FLOW ERROR"
        Me.Label80.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label83
        '
        Me.Label83.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(56, 414)
        Me.Label83.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(227, 19)
        Me.Label83.TabIndex = 109
        Me.Label83.Text = "F12- HA-OVER CURRENT"
        Me.Label83.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label84
        '
        Me.Label84.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(56, 343)
        Me.Label84.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(179, 19)
        Me.Label84.TabIndex = 108
        Me.Label84.Text = "F10- HA-P/S HEALTHY"
        Me.Label84.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label85
        '
        Me.Label85.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(56, 307)
        Me.Label85.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(144, 19)
        Me.Label85.TabIndex = 107
        Me.Label85.Text = "F9- R AXIS DRIVE"
        Me.Label85.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF10
        '
        Me.lblF10.AutoEllipsis = True
        Me.lblF10.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF10.Location = New System.Drawing.Point(23, 343)
        Me.lblF10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF10.Name = "lblF10"
        Me.lblF10.Size = New System.Drawing.Size(17, 19)
        Me.lblF10.TabIndex = 104
        Me.lblF10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF12
        '
        Me.lblF12.AutoEllipsis = True
        Me.lblF12.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF12.Location = New System.Drawing.Point(23, 414)
        Me.lblF12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF12.Name = "lblF12"
        Me.lblF12.Size = New System.Drawing.Size(17, 19)
        Me.lblF12.TabIndex = 106
        Me.lblF12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF9
        '
        Me.lblF9.AutoEllipsis = True
        Me.lblF9.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblF9.Location = New System.Drawing.Point(23, 307)
        Me.lblF9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF9.Name = "lblF9"
        Me.lblF9.Size = New System.Drawing.Size(17, 19)
        Me.lblF9.TabIndex = 103
        Me.lblF9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF13
        '
        Me.lblF13.AutoEllipsis = True
        Me.lblF13.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF13.Location = New System.Drawing.Point(23, 450)
        Me.lblF13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF13.Name = "lblF13"
        Me.lblF13.Size = New System.Drawing.Size(17, 19)
        Me.lblF13.TabIndex = 105
        Me.lblF13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx7
        '
        Me.DIOx7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx7.Location = New System.Drawing.Point(56, 271)
        Me.DIOx7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx7.Name = "DIOx7"
        Me.DIOx7.Size = New System.Drawing.Size(168, 19)
        Me.DIOx7.TabIndex = 74
        Me.DIOx7.Text = "F8- AVC2 AXIS DRIVE"
        Me.DIOx7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx6
        '
        Me.DIOx6.Cursor = System.Windows.Forms.Cursors.Default
        Me.DIOx6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx6.Location = New System.Drawing.Point(56, 235)
        Me.DIOx6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx6.Name = "DIOx6"
        Me.DIOx6.Size = New System.Drawing.Size(168, 19)
        Me.DIOx6.TabIndex = 73
        Me.DIOx6.Text = "F7- AVC1 AXIS DRIVE"
        Me.DIOx6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx5
        '
        Me.DIOx5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx5.Location = New System.Drawing.Point(56, 199)
        Me.DIOx5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx5.Name = "DIOx5"
        Me.DIOx5.Size = New System.Drawing.Size(144, 19)
        Me.DIOx5.TabIndex = 72
        Me.DIOx5.Text = "F6-SPARE"
        Me.DIOx5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx4
        '
        Me.DIOx4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx4.Location = New System.Drawing.Point(56, 165)
        Me.DIOx4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx4.Name = "DIOx4"
        Me.DIOx4.Size = New System.Drawing.Size(179, 19)
        Me.DIOx4.TabIndex = 71
        Me.DIOx4.Text = "F5- X AXIS DRIVE "
        Me.DIOx4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx3
        '
        Me.DIOx3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx3.Location = New System.Drawing.Point(56, 133)
        Me.DIOx3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx3.Name = "DIOx3"
        Me.DIOx3.Size = New System.Drawing.Size(189, 19)
        Me.DIOx3.TabIndex = 70
        Me.DIOx3.Text = "F4- STOKE LIMIT-AUTO"
        Me.DIOx3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx2
        '
        Me.DIOx2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx2.Location = New System.Drawing.Point(56, 99)
        Me.DIOx2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx2.Name = "DIOx2"
        Me.DIOx2.Size = New System.Drawing.Size(161, 19)
        Me.DIOx2.TabIndex = 69
        Me.DIOx2.Text = "F3- EMG PENDENT"
        Me.DIOx2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DIOx1
        '
        Me.DIOx1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DIOx1.Location = New System.Drawing.Point(56, 68)
        Me.DIOx1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DIOx1.Name = "DIOx1"
        Me.DIOx1.Size = New System.Drawing.Size(179, 19)
        Me.DIOx1.TabIndex = 68
        Me.DIOx1.Text = "F2  EMG PANEL"
        Me.DIOx1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(56, 36)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(148, 19)
        Me.Label4.TabIndex = 67
        Me.Label4.Text = "F1- PLC ERROR"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF2
        '
        Me.lblF2.AutoEllipsis = True
        Me.lblF2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF2.Location = New System.Drawing.Point(23, 68)
        Me.lblF2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF2.Name = "lblF2"
        Me.lblF2.Size = New System.Drawing.Size(17, 19)
        Me.lblF2.TabIndex = 60
        Me.lblF2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF3
        '
        Me.lblF3.AutoEllipsis = True
        Me.lblF3.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF3.Location = New System.Drawing.Point(23, 99)
        Me.lblF3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF3.Name = "lblF3"
        Me.lblF3.Size = New System.Drawing.Size(17, 19)
        Me.lblF3.TabIndex = 64
        Me.lblF3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF1
        '
        Me.lblF1.AutoEllipsis = True
        Me.lblF1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblF1.Location = New System.Drawing.Point(23, 36)
        Me.lblF1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF1.Name = "lblF1"
        Me.lblF1.Size = New System.Drawing.Size(17, 19)
        Me.lblF1.TabIndex = 59
        Me.lblF1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF4
        '
        Me.lblF4.AutoEllipsis = True
        Me.lblF4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF4.Location = New System.Drawing.Point(23, 133)
        Me.lblF4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF4.Name = "lblF4"
        Me.lblF4.Size = New System.Drawing.Size(17, 19)
        Me.lblF4.TabIndex = 62
        Me.lblF4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF5
        '
        Me.lblF5.AutoEllipsis = True
        Me.lblF5.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF5.Location = New System.Drawing.Point(23, 165)
        Me.lblF5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF5.Name = "lblF5"
        Me.lblF5.Size = New System.Drawing.Size(17, 19)
        Me.lblF5.TabIndex = 65
        Me.lblF5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF6
        '
        Me.lblF6.AutoEllipsis = True
        Me.lblF6.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF6.Location = New System.Drawing.Point(23, 199)
        Me.lblF6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF6.Name = "lblF6"
        Me.lblF6.Size = New System.Drawing.Size(17, 19)
        Me.lblF6.TabIndex = 61
        Me.lblF6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF7
        '
        Me.lblF7.AutoEllipsis = True
        Me.lblF7.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF7.Location = New System.Drawing.Point(23, 235)
        Me.lblF7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF7.Name = "lblF7"
        Me.lblF7.Size = New System.Drawing.Size(17, 19)
        Me.lblF7.TabIndex = 63
        Me.lblF7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblF8
        '
        Me.lblF8.AutoEllipsis = True
        Me.lblF8.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblF8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblF8.Location = New System.Drawing.Point(23, 271)
        Me.lblF8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblF8.Name = "lblF8"
        Me.lblF8.Size = New System.Drawing.Size(17, 19)
        Me.lblF8.TabIndex = 66
        Me.lblF8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Labei1
        '
        Me.Labei1.BackColor = System.Drawing.SystemColors.Highlight
        Me.Labei1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Labei1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Labei1.Location = New System.Drawing.Point(2, 0)
        Me.Labei1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Labei1.Name = "Labei1"
        Me.Labei1.Size = New System.Drawing.Size(529, 24)
        Me.Labei1.TabIndex = 2
        Me.Labei1.Text = "Fault Status"
        Me.Labei1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Button1
        '
        Me.Button1.BackgroundImage = Global.iotPIPECLEDING.My.Resources.Resources.btnblue
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Location = New System.Drawing.Point(956, 602)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(91, 37)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Interval = 500
        '
        'frmDiag
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1095, 672)
        Me.Controls.Add(Me.Panel6)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmDiag"
        Me.Text = "frmDiag"
        Me.Panel6.ResumeLayout(False)
        Me.pnlTR.ResumeLayout(False)
        Me.pnlTR.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents pnlTR As Panel
    Friend WithEvents lblF29 As Label
    Friend WithEvents lblF28 As Label
    Friend WithEvents lblF27 As Label
    Friend WithEvents lblF23 As Label
    Friend WithEvents lblF20 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents lblF17 As Label
    Friend WithEvents lblF14 As Label
    Friend WithEvents lblF11 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lblF19 As Label
    Friend WithEvents lblF25 As Label
    Friend WithEvents lblF15 As Label
    Friend WithEvents lblF26 As Label
    Friend WithEvents lblF30 As Label
    Friend WithEvents lblF16 As Label
    Friend WithEvents lblF18 As Label
    Friend WithEvents lblF24 As Label
    Friend WithEvents Label107 As Label
    Friend WithEvents lblF22 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents lblF21 As Label
    Friend WithEvents Label106 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents lblF10 As Label
    Friend WithEvents lblF12 As Label
    Friend WithEvents lblF9 As Label
    Friend WithEvents lblF13 As Label
    Friend WithEvents lblF2 As Label
    Friend WithEvents lblF3 As Label
    Friend WithEvents lblF1 As Label
    Friend WithEvents lblF4 As Label
    Friend WithEvents lblF5 As Label
    Friend WithEvents lblF6 As Label
    Friend WithEvents lblF7 As Label
    Friend WithEvents lblF8 As Label
    Friend WithEvents Labei1 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents btnang As Button
    Friend WithEvents Label30 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label73 As Label
    Friend WithEvents Label104 As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents Label76 As Label
    Friend WithEvents Label77 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents Label79 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents Label84 As Label
    Friend WithEvents Label85 As Label
    Friend WithEvents DIOx7 As Label
    Friend WithEvents DIOx6 As Label
    Friend WithEvents DIOx5 As Label
    Friend WithEvents DIOx4 As Label
    Friend WithEvents DIOx3 As Label
    Friend WithEvents DIOx2 As Label
    Friend WithEvents DIOx1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents btnDigSts As Button
    Friend WithEvents btnLimistatus As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblYfwdlimit As Label
    Friend WithEvents lblTfwdlimit As Label
    Friend WithEvents lblAfwdlimit As Label
    Friend WithEvents lblRfwdlimit As Label
    Friend WithEvents lblYreviimit As Label
    Friend WithEvents lblTrevlimit As Label
    Friend WithEvents lblArevlimit As Label
    Friend WithEvents lblRrevlimit As Label
    Friend WithEvents lblXfwdlimit As Label
    Friend WithEvents lblXrevlimit As Label
    Friend WithEvents lblFault As Label
    Friend WithEvents lblAlarm As Label
    Friend WithEvents lblHealthy As Label
    Friend WithEvents btnResetAll As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents txtFC5 As TextBox
    Friend WithEvents txtFC4 As TextBox
    Friend WithEvents txtFC3 As TextBox
    Friend WithEvents txtFC2 As TextBox
    Friend WithEvents txtFC1 As TextBox
End Class
