﻿Public Class frmlimit

    Dim tx As String = ""
    Dim rx As String = ""
    Dim y As Double = 0.0
    Dim y1 As Double = 0.0
    Dim errno As Integer = 0

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        Timer1.Enabled = False

    End Sub

    Public Sub Frmlimit_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        Me.WindowState = FormWindowState.Maximized
        Wrkb1.Visible = False
        Timer1.Enabled = True

        Timer2.Enabled = True
    End Sub
    Private Sub frmAngstatus_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        Panel1.Left = (Me.Width - Panel1.Width) / 2
        Panel1.Top = (Me.Height - Panel1.Height) / 2
    End Sub


    Public Sub Analogread2()
        Try
            errno = 0
            Dim y As Double = 0.0
            Dim y1 As Double
            Dim plcinstrg As String = ""
            If isConnection = True Then


                '//// Axis Calibration Factor 1  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 F4 00 0A 85 F0", 100)
                Dim x6() As String = plcinstrg.Split(" "c)
                If x6.Count >= 8 Then
                    If x6(6) = "02" And x6(7) = "03" Then
                        y = Convert.ToInt32(x6(11) & x6(12) & x6(9) & x6(10), 16)
                        gXFactorAxis1 = y
                        txtXfactor1.Text = gXFactorAxis1.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x6(15) & x6(16) & x6(13) & x6(14), 16)
                        gYFactorAxis1 = y
                        txtYfactor1.Text = gYFactorAxis1.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x6(19) & x6(20) & x6(17) & x6(18), 16)
                        gSLFwdAxis1 = (y / 100)
                        txtFwdLimit1.Text = gSLFwdAxis1.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x6(23) & x6(24) & x6(21) & x6(22), 16)
                        gSLRevAxis1 = (y / 100)
                        txtRevLimit1.Text = gSLRevAxis1.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x6(2) & x6(28) & x6(25) & x6(26), 16)
                        gHomePosAxis1 = (y / 100)
                        txtHomePos1.Text = gHomePosAxis1.ToString()

                        errno = 1
                    End If
                End If

                '//// Axis Calibration Factor 2  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 FE 00 0A", 100)
                Dim x7() As String = plcinstrg.Split(" "c)
                If x7.Count >= 8 Then
                    If x7(6) = "02" And x7(7) = "03" Then
                        y = Convert.ToInt32(x7(11) & x7(12) & x7(9) & x7(10), 16)
                        gXFactorAxis2 = y
                        txtXfactor2.Text = gXFactorAxis2.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x7(15) & x7(16) & x7(13) & x7(14), 16)
                        gYFactorAxis2 = y
                        txtYfactor2.Text = gYFactorAxis2.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x7(19) & x7(20) & x7(17) & x7(18), 16)
                        gSLFwdAxis2 = (y / 100)
                        txtFwdLimit2.Text = gSLFwdAxis2.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x7(23) & x7(24) & x7(21) & x7(22), 16)
                        gSLRevAxis2 = (y / 100)
                        txtRevLimit2.Text = gSLRevAxis2.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x7(27) & x7(28) & x7(25) & x7(26), 16)
                        gHomePosAxis2 = (y / 100)
                        txtHomePos2.Text = gHomePosAxis2.ToString()

                        errno = 2
                    End If
                End If

                '//// Axis Calibration Factor 3  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 08 00 0A", 100)
                Dim x8() As String = plcinstrg.Split(" "c)
                If x8.Count >= 8 Then
                    If x8(6) = "02" And x8(7) = "03" Then
                        y = Convert.ToInt32(x8(11) & x8(12) & x8(9) & x8(10), 16)
                        gXFactorAxis3 = y
                        txtXfactor3.Text = gXFactorAxis3.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x8(15) & x8(16) & x8(13) & x8(14), 16)
                        gYFactorAxis3 = y
                        txtYfactor3.Text = gYFactorAxis3.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x8(19) & x8(20) & x8(17) & x8(18), 16)
                        gSLFwdAxis3 = (y / 100)
                        txtFwdLimit3.Text = gSLFwdAxis3.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x8(23) & x8(24) & x8(21) & x8(22), 16)
                        gSLRevAxis3 = (y / 100)
                        txtRevLimit3.Text = gSLRevAxis3.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x8(27) & x8(28) & x8(25) & x8(26), 16)
                        gHomePosAxis3 = (y / 100)
                        txtHomePos3.Text = gHomePosAxis3.ToString()

                        errno = 3
                    End If
                End If

                '//// Axis Calibration Factor 4  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 12 00 0A", 100)
                Dim x9() As String = plcinstrg.Split(" "c)
                If x9.Count >= 8 Then
                    If x9(6) = "02" And x9(7) = "03" Then
                        y = Convert.ToInt32(x9(11) & x9(12) & x9(9) & x9(10), 16)
                        gXFactorAxis4 = y
                        txtXfactor4.Text = gXFactorAxis4.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x9(15) & x9(16) & x9(13) & x9(14), 16)
                        gYFactorAxis4 = y
                        txtYfactor4.Text = gYFactorAxis4.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x9(19) & x9(20) & x9(17) & x9(18), 16)
                        gSLFwdAxis4 = (y / 100)
                        txtFwdLimit4.Text = gSLFwdAxis4.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x9(23) & x9(24) & x9(21) & x9(22), 16)
                        gSLRevAxis4 = (y / 100)
                        txtRevLimit4.Text = gSLRevAxis4.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x9(27) & x9(28) & x9(25) & x9(26), 16)
                        gHomePosAxis4 = (y / 100)
                        txtHomePos4.Text = gHomePosAxis4.ToString()

                        errno = 4
                    End If
                End If

                '//// Axis Calibration Factor 5  /////////////
                y = 0.0
                y1 = 0
                plcinstrg = ""
                plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 1C 00 0A", 100)
                Dim x10() As String = plcinstrg.Split(" "c)
                If x10.Count >= 8 Then
                    If x10(6) = "02" And x10(7) = "03" Then
                        y = Convert.ToInt32(x10(11) & x10(12) & x10(9) & x10(10), 16)
                        gXFactorAxis5 = y
                        txtXfactor5.Text = gXFactorAxis5.ToString()
                        y = 0.0
                        y = Convert.ToInt32(x10(15) & x10(16) & x10(13) & x10(14), 16)
                        gYFactorAxis5 = y
                        txtYfactor5.Text = gYFactorAxis5.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x10(19) & x10(20) & x10(17) & x10(18), 16)
                        gSLFwdAxis5 = (y / 100)
                        txtFwdLimit5.Text = gSLFwdAxis5.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x10(23) & x10(24) & x10(21) & x10(22), 16)
                        gSLRevAxis5 = (y / 100)
                        txtRevLimit5.Text = gSLRevAxis5.ToString()

                        y = 0.0
                        y = Convert.ToInt32(x10(27) & x10(28) & x10(25) & x10(26), 16)
                        gHomePosAxis5 = (y / 100)
                        txtHomePos5.Text = gHomePosAxis5.ToString()

                        errno = 5
                    End If
                End If


            End If
        Catch ex As Exception
            Dim result1 As String = MessageBoxEx.Show("Error from Analog Input/Output Read, Error : " + ex.Message.ToString() + errno.ToString(), "Information", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.None, System.Windows.Forms.MessageBoxDefaultButton.Button1, 0, 5, "").ToString

            '  MessageBox.Show("Error from Analog Input/Output Read, Error : " + ex.Message.ToString() + errno.ToString())
        End Try

    End Sub
    Private Sub txtFwdLimit1_Tgotfocus(sender As Object, e As EventArgs) Handles txtFwdLimit1.Click
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtFwdLimit1
    End Sub
    Private Sub txtFwdLimit1_TextChanged(sender As Object, e As EventArgs) Handles txtFwdLimit1.TextChanged

        Dim arr As Integer = 0
        arr = txtFwdLimit1.TextLength
        Dim st As String = ""

        st = txtFwdLimit1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtFwdLimit1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtFwdLimit1.Text += ii(ht)
                    Next
                    If txtFwdLimit1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtFwdLimit1.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001F8000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 F8 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSLFwdAxis1 = (y / 100)
                                    txtFwdLimit1.Text = gSLFwdAxis1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtFwdLimit1.Text = gSLFwdAxis1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtFwdLimit1.Text = gSLFwdAxis1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtFwdLimit2_gotfocus(sender As Object, e As EventArgs) Handles txtFwdLimit2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtFwdLimit2
    End Sub
    Private Sub txtFwdLimit2_TextChanged(sender As Object, e As EventArgs) Handles txtFwdLimit2.TextChanged
        Dim arr As Integer = 0
        arr = txtFwdLimit2.TextLength
        Dim st As String = ""

        st = txtFwdLimit2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtFwdLimit2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtFwdLimit2.Text += ii(ht)
                    Next
                    If txtFwdLimit2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtFwdLimit2.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100202000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 02 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSLFwdAxis2 = (y / 100)
                                    txtFwdLimit2.Text = gSLFwdAxis2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtFwdLimit2.Text = gSLFwdAxis2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtFwdLimit2.Text = gSLFwdAxis2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtFwdLimit3_gotfocus(sender As Object, e As EventArgs) Handles txtFwdLimit3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtFwdLimit3
    End Sub
    Private Sub txtFwdLimit3_TextChanged(sender As Object, e As EventArgs) Handles txtFwdLimit3.TextChanged
        Dim arr As Integer = 0
        arr = txtFwdLimit3.TextLength
        Dim st As String = ""

        st = txtFwdLimit3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtFwdLimit3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtFwdLimit3.Text += ii(ht)
                    Next
                    If txtFwdLimit3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtFwdLimit3.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210020C000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 0C 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSLFwdAxis3 = (y / 100)
                                    txtFwdLimit3.Text = gSLFwdAxis3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtFwdLimit3.Text = gSLFwdAxis3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtFwdLimit3.Text = gSLFwdAxis3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtFwdLimit4_gotfocus(sender As Object, e As EventArgs) Handles txtFwdLimit4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtFwdLimit4
    End Sub
    Private Sub txtFwdLimit4_TextChanged(sender As Object, e As EventArgs) Handles txtFwdLimit4.TextChanged
        Dim arr As Integer = 0
        arr = txtFwdLimit4.TextLength
        Dim st As String = ""

        st = txtFwdLimit4.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtFwdLimit4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtFwdLimit4.Text += ii(ht)
                    Next
                    If txtFwdLimit4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtFwdLimit4.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100216000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 16 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSLFwdAxis4 = (y / 100)
                                    txtFwdLimit4.Text = gSLFwdAxis4.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtFwdLimit4.Text = gSLFwdAxis4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtFwdLimit4.Text = gSLFwdAxis4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtFwdLimit5_gotfocus(sender As Object, e As EventArgs) Handles txtFwdLimit5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtFwdLimit5
    End Sub
    Private Sub txtFwdLimit5_TextChanged(sender As Object, e As EventArgs) Handles txtFwdLimit5.TextChanged
        Dim arr As Integer = 0
        arr = txtFwdLimit5.TextLength
        Dim st As String = ""

        st = txtFwdLimit5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtFwdLimit5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtFwdLimit5.Text += ii(ht)
                    Next
                    If txtFwdLimit5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtFwdLimit5.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100220000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            '/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 20 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSLFwdAxis5 = (y / 100)
                                    txtFwdLimit5.Text = gSLFwdAxis5.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtFwdLimit5.Text = gSLFwdAxis5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtFwdLimit5.Text = gSLFwdAxis5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtRevLimit1_gotfocus(sender As Object, e As EventArgs) Handles txtRevLimit1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtRevLimit1
    End Sub
    Private Sub txtRevLimit1_TextChanged(sender As Object, e As EventArgs) Handles txtRevLimit1.TextChanged
        Dim arr As Integer = 0
        arr = txtRevLimit1.TextLength
        Dim st As String = ""

        st = txtRevLimit1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtRevLimit1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtRevLimit1.Text += ii(ht)
                    Next
                    If txtRevLimit1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtRevLimit1.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001FA000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 FA 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSLRevAxis1 = (y / 100)
                                    txtRevLimit1.Text = gSLRevAxis1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtRevLimit1.Text = gSLRevAxis1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtRevLimit1.Text = gSLRevAxis1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtRevLimit2_gotfocus(sender As Object, e As EventArgs) Handles txtRevLimit2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtRevLimit2
    End Sub
    Private Sub txtRevLimit2_TextChanged(sender As Object, e As EventArgs) Handles txtRevLimit2.TextChanged
        Dim arr As Integer = 0
        arr = txtRevLimit2.TextLength
        Dim st As String = ""

        st = txtRevLimit2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtRevLimit2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtRevLimit2.Text += ii(ht)
                    Next
                    If txtRevLimit2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtRevLimit2.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100204000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 04 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSLRevAxis2 = (y / 100)
                                    txtRevLimit2.Text = gSLRevAxis2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtRevLimit2.Text = gSLRevAxis2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtRevLimit2.Text = gSLRevAxis2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtRevLimit3_gotfocus(sender As Object, e As EventArgs) Handles txtRevLimit3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtRevLimit3
    End Sub
    Private Sub txtRevLimit3_TextChanged(sender As Object, e As EventArgs) Handles txtRevLimit3.TextChanged
        Dim arr As Integer = 0
        arr = txtRevLimit3.TextLength
        Dim st As String = ""

        st = txtRevLimit3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtRevLimit3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtRevLimit3.Text += ii(ht)
                    Next
                    If txtRevLimit3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtRevLimit3.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210020E000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 0E 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSLRevAxis3 = (y / 100)
                                    txtRevLimit3.Text = gSLRevAxis3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtRevLimit3.Text = gSLRevAxis3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtRevLimit3.Text = gSLRevAxis3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtRevLimit4_gotfocus(sender As Object, e As EventArgs) Handles txtRevLimit4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtRevLimit4
    End Sub
    Private Sub txtRevLimit4_TextChanged(sender As Object, e As EventArgs) Handles txtRevLimit4.TextChanged
        Dim arr As Integer = 0
        arr = txtRevLimit4.TextLength
        Dim st As String = ""

        st = txtRevLimit4.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtRevLimit4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtRevLimit4.Text += ii(ht)
                    Next
                    If txtRevLimit4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtRevLimit4.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100218000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 18 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSLRevAxis4 = (y / 100)
                                    txtRevLimit4.Text = gSLRevAxis4.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtRevLimit4.Text = gSLRevAxis4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtRevLimit4.Text = gSLRevAxis4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtRevLimit5_gotfocus(sender As Object, e As EventArgs) Handles txtRevLimit5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtRevLimit5
    End Sub
    Private Sub txtRevLimit5_TextChanged(sender As Object, e As EventArgs) Handles txtRevLimit5.TextChanged
        Dim arr As Integer = 0
        arr = txtRevLimit5.TextLength
        Dim st As String = ""

        st = txtRevLimit5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtRevLimit5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtRevLimit5.Text += ii(ht)
                    Next
                    If txtRevLimit5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtRevLimit5.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100222000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 22 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gSLRevAxis5 = (y / 100)
                                    txtRevLimit5.Text = gSLRevAxis5.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtRevLimit5.Text = gSLRevAxis5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtRevLimit5.Text = gSLRevAxis5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtXfactor1_gotfocus(sender As Object, e As EventArgs) Handles txtXfactor1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtXfactor1
    End Sub
    Private Sub txtXfactor1_TextChanged(sender As Object, e As EventArgs) Handles txtXfactor1.TextChanged
        Dim arr As Integer = 0
        arr = txtXfactor1.TextLength
        Dim st As String = ""

        st = txtXfactor1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtXfactor1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtXfactor1.Text += ii(ht)
                    Next
                    If txtXfactor1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtXfactor1.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001F4000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 F4 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gXFactorAxis1 = y
                                    txtXfactor1.Text = gXFactorAxis1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtXfactor1.Text = gXFactorAxis1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtXfactor1.Text = gXFactorAxis1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtXfactor2_gotfocus(sender As Object, e As EventArgs) Handles txtXfactor2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtXfactor2
    End Sub
    Private Sub txtXfactor2_TextChanged(sender As Object, e As EventArgs) Handles txtXfactor2.TextChanged
        Dim arr As Integer = 0
        arr = txtXfactor2.TextLength
        Dim st As String = ""

        st = txtXfactor2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtXfactor2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtXfactor2.Text += ii(ht)
                    Next
                    If txtXfactor2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtXfactor2.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001FE000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 FE 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gXFactorAxis2 = y
                                    txtXfactor2.Text = gXFactorAxis2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtXfactor2.Text = gXFactorAxis2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtXfactor2.Text = gXFactorAxis2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtXfactor3_gotfocus(sender As Object, e As EventArgs) Handles txtXfactor3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtXfactor3
    End Sub
    Private Sub txtXfactor3_TextChanged(sender As Object, e As EventArgs) Handles txtXfactor3.TextChanged
        Dim arr As Integer = 0
        arr = txtXfactor3.TextLength
        Dim st As String = ""

        st = txtXfactor3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtXfactor3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtXfactor3.Text += ii(ht)
                    Next
                    If txtXfactor3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtXfactor3.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100208000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 08 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gXFactorAxis3 = y
                                    txtXfactor3.Text = gXFactorAxis3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtXfactor3.Text = gXFactorAxis3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtXfactor3.Text = gXFactorAxis3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtXfactor4_gotfocus(sender As Object, e As EventArgs) Handles txtXfactor4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtXfactor4
    End Sub
    Private Sub txtXfactor4_TextChanged(sender As Object, e As EventArgs) Handles txtXfactor4.TextChanged
        Dim arr As Integer = 0
        arr = txtXfactor4.TextLength
        Dim st As String = ""

        st = txtXfactor4.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtXfactor4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtXfactor4.Text += ii(ht)
                    Next
                    If txtXfactor4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtXfactor4.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100212000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 12 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gXFactorAxis4 = y
                                    txtXfactor4.Text = gXFactorAxis4.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtXfactor4.Text = gXFactorAxis4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtXfactor4.Text = gXFactorAxis4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtXfactor5_gotfocus(sender As Object, e As EventArgs) Handles txtXfactor5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtXfactor5
    End Sub
    Private Sub txtXfactor5_TextChanged(sender As Object, e As EventArgs) Handles txtXfactor5.TextChanged
        Dim arr As Integer = 0
        arr = txtXfactor5.TextLength
        Dim st As String = ""

        st = txtXfactor5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtXfactor5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtXfactor5.Text += ii(ht)
                    Next
                    If txtXfactor5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtXfactor5.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210021C000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 1C 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gXFactorAxis5 = y
                                    txtXfactor5.Text = gXFactorAxis5.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtXfactor5.Text = gXFactorAxis5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtXfactor5.Text = gXFactorAxis5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtYfactor1_gotfocus(sender As Object, e As EventArgs) Handles txtYfactor1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtYfactor1
    End Sub
    Private Sub txtYfactor1_TextChanged(sender As Object, e As EventArgs) Handles txtYfactor1.TextChanged
        Dim arr As Integer = 0
        arr = txtYfactor1.TextLength
        Dim st As String = ""

        st = txtYfactor1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtYfactor1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtYfactor1.Text += ii(ht)
                    Next
                    If txtYfactor1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtYfactor1.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021001F6000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If

                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 F6 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gYFactorAxis1 = y
                                    txtYfactor1.Text = gYFactorAxis1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtYfactor1.Text = gYFactorAxis1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtYfactor1.Text = gYFactorAxis1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtYfactor2_gotfocus(sender As Object, e As EventArgs) Handles txtYfactor2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtYfactor2
    End Sub
    Private Sub txtYfactor2_TextChanged(sender As Object, e As EventArgs) Handles txtYfactor2.TextChanged
        Dim arr As Integer = 0
        arr = txtYfactor2.TextLength
        Dim st As String = ""

        st = txtYfactor2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtYfactor2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtYfactor2.Text += ii(ht)
                    Next
                    If txtYfactor2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtYfactor2.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100200000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 00 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gYFactorAxis2 = y
                                    txtYfactor2.Text = gYFactorAxis2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtYfactor2.Text = gYFactorAxis2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtYfactor2.Text = gYFactorAxis2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtYfactor3_gotfocus(sender As Object, e As EventArgs) Handles txtYfactor3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtYfactor3
    End Sub
    Private Sub txtYfactor3_TextChanged(sender As Object, e As EventArgs) Handles txtYfactor3.TextChanged
        Dim arr As Integer = 0
        arr = txtYfactor3.TextLength
        Dim st As String = ""

        st = txtYfactor3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtYfactor3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtYfactor3.Text += ii(ht)
                    Next
                    If txtYfactor3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtYfactor3.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210020A000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 0A 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gYFactorAxis3 = y
                                    txtYfactor3.Text = gYFactorAxis3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtYfactor3.Text = gYFactorAxis3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtYfactor3.Text = gYFactorAxis3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtYfactor4_gotfocus(sender As Object, e As EventArgs) Handles txtYfactor4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtYfactor4
    End Sub
    Private Sub txtYfactor4_TextChanged(sender As Object, e As EventArgs) Handles txtYfactor4.TextChanged
        Dim arr As Integer = 0
        arr = txtYfactor4.TextLength
        Dim st As String = ""

        st = txtYfactor4.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtYfactor4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtYfactor4.Text += ii(ht)
                    Next
                    If txtYfactor4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtYfactor4.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100214000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 14 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gYFactorAxis4 = y
                                    txtYfactor4.Text = gYFactorAxis4.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtYfactor4.Text = gYFactorAxis4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtYfactor4.Text = gYFactorAxis4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtYfactor5_gotfocus(sender As Object, e As EventArgs) Handles txtYfactor5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtYfactor5
    End Sub
    Private Sub txtYfactor5_TextChanged(sender As Object, e As EventArgs) Handles txtYfactor5.TextChanged
        Dim arr As Integer = 0
        arr = txtYfactor5.TextLength
        Dim st As String = ""

        st = txtYfactor5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtYfactor5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtYfactor5.Text += ii(ht)
                    Next
                    If txtYfactor5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtYfactor5.Text
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210021E000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 1E 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gYFactorAxis5 = y
                                    txtYfactor5.Text = gYFactorAxis5.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtYfactor5.Text = gYFactorAxis5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtYfactor5.Text = gYFactorAxis5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtHomePos1_gotfocus(sender As Object, e As EventArgs) Handles txtHomePos1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtHomePos1
    End Sub
    Private Sub txtHomePos1_TextChanged(sender As Object, e As EventArgs) Handles txtHomePos1.TextChanged
        Dim arr As Integer = 0
        arr = txtHomePos1.TextLength
        Dim st As String = ""

        st = txtHomePos1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtHomePos1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtHomePos1.Text += ii(ht)
                    Next
                    If txtHomePos1.Text <> "-" Then

                        If isConnection = True Then
                            Dim t01 As Long = txtHomePos1.Text * 100
                            Dim t02 As String = SingleToHex(t01)

                            Dim h1 As String = "00000000000B021001FC000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)


                            'tx = "00000000000B021001FC0002045FF800786DAD"
                            ' tx = "020601FC930399C27"
                            ' tx = "020601FC000190A8CA69"
                            Dim verticalolread As String = TCPComA(tx, 150)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 01 FC 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gHomePosAxis1 = (y / 100)
                                    txtHomePos1.Text = gHomePosAxis1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtHomePos1.Text = gHomePosAxis1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtHomePos1.Text = gHomePosAxis1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtHomePos2_gotfocus(sender As Object, e As EventArgs) Handles txtHomePos2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtHomePos2
    End Sub
    Private Sub txtHomePos2_TextChanged(sender As Object, e As EventArgs) Handles txtHomePos2.TextChanged
        Dim arr As Integer = 0
        arr = txtHomePos2.TextLength
        Dim st As String = ""

        st = txtHomePos2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtHomePos2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtHomePos2.Text += ii(ht)
                    Next
                    If txtHomePos2.Text <> "-" Then

                        If isConnection = True Then
                            Dim t01 As Integer = txtHomePos2.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100206000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 06 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gHomePosAxis2 = (y / 100)
                                    txtHomePos2.Text = gHomePosAxis2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtHomePos2.Text = gHomePosAxis2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtHomePos2.Text = gHomePosAxis2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtHomePos3_gotfocus(sender As Object, e As EventArgs) Handles txtHomePos3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtHomePos3
    End Sub
    Private Sub txtHomePos3_TextChanged(sender As Object, e As EventArgs) Handles txtHomePos3.TextChanged
        Dim arr As Integer = 0
        arr = txtHomePos3.TextLength
        Dim st As String = ""

        st = txtHomePos3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtHomePos3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtHomePos3.Text += ii(ht)
                    Next
                    If txtHomePos3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtHomePos3.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100210000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 10 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gHomePosAxis3 = (y / 100)
                                    txtHomePos3.Text = gHomePosAxis3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtHomePos3.Text = gHomePosAxis3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtHomePos3.Text = gHomePosAxis3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtHomePos4_gotfocus(sender As Object, e As EventArgs) Handles txtHomePos4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtHomePos4
    End Sub
    Private Sub txtHomePos4_TextChanged(sender As Object, e As EventArgs) Handles txtHomePos4.TextChanged
        Dim arr As Integer = 0
        arr = txtHomePos4.TextLength
        Dim st As String = ""

        st = txtHomePos4.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtHomePos4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtHomePos4.Text += ii(ht)
                    Next
                    If txtHomePos4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtHomePos4.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B0210021A000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 1A 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gHomePosAxis4 = (y / 100)
                                    txtHomePos4.Text = gHomePosAxis4.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtHomePos4.Text = gHomePosAxis4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtHomePos4.Text = gHomePosAxis4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtHomePos5_gotfocus(sender As Object, e As EventArgs) Handles txtHomePos5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtHomePos5
    End Sub
    Private Sub txtHomePos5_TextChanged(sender As Object, e As EventArgs) Handles txtHomePos5.TextChanged
        Dim arr As Integer = 0
        arr = txtHomePos5.TextLength
        Dim st As String = ""

        st = txtHomePos5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtHomePos5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtHomePos5.Text += ii(ht)
                    Next
                    If txtHomePos5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtHomePos5.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B02100224000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 24 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gHomePosAxis5 = (y / 100)
                                    txtHomePos5.Text = gHomePosAxis5.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtHomePos5.Text = gHomePosAxis5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtHomePos5.Text = gHomePosAxis5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtActPos1_gotfocus(sender As Object, e As EventArgs) Handles txtActPos1.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtActPos1
    End Sub
    Private Sub txtActPos1_TextChanged(sender As Object, e As EventArgs) Handles txtActPos1.TextChanged
        Dim arr As Integer = 0
        arr = txtActPos1.TextLength
        Dim st As String = ""

        st = txtActPos1.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtActPos1.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtActPos1.Text += ii(ht)
                    Next
                    If txtActPos1.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtActPos1.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021002C4000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 C4 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gPositionAxis1 = (y / 100)
                                    txtActPos1.Text = gPositionAxis1.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtActPos1.Text = gPositionAxis1.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtActPos1.Text = gPositionAxis1.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtActPos2_gotfocus(sender As Object, e As EventArgs) Handles txtActPos2.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtActPos2
    End Sub
    Private Sub txtActPos2_TextChanged(sender As Object, e As EventArgs) Handles txtActPos2.TextChanged
        Dim arr As Integer = 0
        arr = txtActPos2.TextLength
        Dim st As String = ""

        st = txtActPos2.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtActPos2.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtActPos2.Text += ii(ht)
                    Next
                    If txtActPos2.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtActPos2.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021002CE000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 CE 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gPositionAxis2 = (y / 100)
                                    txtActPos2.Text = gPositionAxis2.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtActPos2.Text = gPositionAxis2.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtActPos2.Text = gPositionAxis2.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtActPos3_gotfocus(sender As Object, e As EventArgs) Handles txtActPos3.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtActPos3
    End Sub
    Private Sub txtActPos3_TextChanged(sender As Object, e As EventArgs) Handles txtActPos3.TextChanged
        Dim arr As Integer = 0
        arr = txtActPos3.TextLength
        Dim st As String = ""

        st = txtActPos3.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtActPos3.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtActPos3.Text += ii(ht)
                    Next
                    If txtActPos3.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtActPos3.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021002D8000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 D8 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gPositionAxis3 = (y / 100)
                                    txtActPos3.Text = gPositionAxis3.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtActPos3.Text = gPositionAxis3.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtActPos3.Text = gPositionAxis3.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtActPos4_gotfocus(sender As Object, e As EventArgs) Handles txtActPos4.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtActPos4
    End Sub
    Private Sub txtActPos4_TextChanged(sender As Object, e As EventArgs) Handles txtActPos4.TextChanged
        Dim arr As Integer = 0
        arr = txtActPos4.TextLength
        Dim st As String = ""

        st = txtActPos4.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtActPos4.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtActPos4.Text += ii(ht)
                    Next
                    If txtActPos4.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtActPos4.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021002E2000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 E2 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gPositionAxis4 = (y / 100)
                                    txtActPos4.Text = gPositionAxis4.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtActPos4.Text = gPositionAxis4.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtActPos4.Text = gPositionAxis4.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub
    Private Sub txtActPos5_gotfocus(sender As Object, e As EventArgs) Handles txtActPos5.GotFocus
        Wrkb1.Visible = True
        Wrkb1.CurrTextBox = txtActPos5

    End Sub
    Private Sub txtActPos5_TextChanged(sender As Object, e As EventArgs) Handles txtActPos5.TextChanged
        Dim arr As Integer = 0
        arr = txtActPos5.TextLength
        Dim st As String = ""

        st = txtActPos5.Text
        Dim ii() As Char = st.ToCharArray
        ''''lblalarm.Text = arr
        If (arr > 1) Then
            If ii(arr - 1) = "K" Then

                If (arr <> 2) Then
                    txtActPos5.Text = ""
                    For ht As Integer = 0 To (arr - 3)
                        txtActPos5.Text += ii(ht)
                    Next
                    If txtActPos5.Text <> "-" Then
                        If isConnection = True Then
                            Dim t01 As Integer = txtActPos5.Text * 100
                            Dim t02 As String = SingleToHex(t01)
                            Dim h1 As String = "00000000000B021002EC000204" & (t02.Substring(4, 4) & (t02.Substring(0, 4)))
                            tx = ""
                            rx = ""

                            tx = h1 & ComputeCrc(h1)
                            Dim verticalolread As String = TCPComA(tx, 50)
                            'writeLog("|TRC+ |TX:" & tx & " |RX:" & esscread2)
                            'If verticalolread.Length <> 24 Then
                            '    MessageBox.Show("Error in Communicating..")
                            'Else
                            '    gsetesscpara = 1
                            '    Select Case MsgBox("Data Write Successfully..", MsgBoxStyle.OkOnly, "Message")
                            '        Case MsgBoxResult.Ok
                            '    End Select
                            'End If
                            Threading.Thread.Sleep(500)
                            ''/////////   REad String //////////
                            y = 0.0
                            y1 = 0
                            Dim plcinstrg As String = ""
                            plcinstrg = TCPComA("00 00 00 00 00 06 02 03 02 EC 00 02", 50)
                            Dim x1() As String = plcinstrg.Split(" "c)
                            If x1.Count >= 8 Then
                                If x1(6) = "02" And x1(7) = "03" Then
                                    y = Convert.ToInt32(x1(11) & x1(12) & x1(9) & x1(10), 16)
                                    gPositionAxis5 = (y / 100)
                                    txtActPos5.Text = gPositionAxis5.ToString()
                                End If
                            End If

                        End If
                    Else
                        txtActPos5.Text = gPositionAxis5.ToString()
                        Select Case MsgBox("Only Minus Is Not Valid..", MsgBoxStyle.OkOnly, "Message")
                            Case MsgBoxResult.Ok
                        End Select
                    End If
                Else
                    txtActPos5.Text = gPositionAxis5.ToString()
                    Select Case MsgBox("Please Enter the Value..", MsgBoxStyle.OkOnly, "Message")
                        Case MsgBoxResult.Ok
                    End Select
                End If

            End If
        End If

    End Sub

    Private Sub btnOPR1_Click(sender As Object, e As EventArgs) Handles btnOPR1.Click

        Try
            If isConnection = True Then
                btnOPR1.BackColor = Color.Chartreuse

                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 03 20 FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                Threading.Thread.Sleep(1000)
                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 03 20 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                btnOPR1.BackColor = Color.DarkSalmon

            End If
        Catch ex As Exception
            MessageBox.Show("Error in RS485 Communivation : " + ex.Message.ToString())
        End Try

    End Sub

    Private Sub btnOPR2_Click(sender As Object, e As EventArgs) Handles btnOPR2.Click
        Try
            If isConnection = True Then
                btnOPR2.BackColor = Color.Chartreuse

                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 03 21 FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                Threading.Thread.Sleep(1000)
                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 03 21 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)


                btnOPR2.BackColor = Color.DarkSalmon

            End If
        Catch ex As Exception
            MessageBox.Show("Error in RS485 Communivation : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub btnOPR3_Click(sender As Object, e As EventArgs) Handles btnOPR3.Click
        Try
            If isConnection = True Then
                btnOPR3.BackColor = Color.Chartreuse

                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 03 22 FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                Threading.Thread.Sleep(1000)
                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 03 22 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)


                btnOPR3.BackColor = Color.DarkSalmon

            End If
        Catch ex As Exception
            MessageBox.Show("Error in RS485 Communivation : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub btnOPR4_Click(sender As Object, e As EventArgs) Handles btnOPR4.Click
        Try
            If isConnection = True Then
                btnOPR4.BackColor = Color.Chartreuse
                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 03 23 FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                Threading.Thread.Sleep(1000)
                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 03 23 00 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)


                btnOPR4.BackColor = Color.DarkSalmon

            End If
        Catch ex As Exception
            MessageBox.Show("Error in RS485 Communivation : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub btnOPR5_Click(sender As Object, e As EventArgs) Handles btnOPR5.Click
        Try
            If isConnection = True Then
                btnOPR5.BackColor = Color.Chartreuse
                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 03 24 FF 00"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                Threading.Thread.Sleep(1000)
                tx = ""
                rx = ""

                tx = "00 00 00 00 00 06 02 05 03 24 00 00 8D B6"
                rx = TCPComA(tx, 10)
                'writeLog("|Auxlmp start |TX:" & tx & "|RX:" & rx)

                btnOPR5.BackColor = Color.DarkSalmon

            End If
        Catch ex As Exception
            MessageBox.Show("Error in RS485 Communivation : " + ex.Message.ToString())
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        txtActPos1.Text = gPositionAxis1.ToString()
        txtActPos2.Text = gPositionAxis2.ToString()
        txtActPos3.Text = gPositionAxis3.ToString()
        txtActPos4.Text = gPositionAxis4.ToString()
        txtActPos5.Text = gPositionAxis5.ToString()

    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Analogread2()
        Timer2.Enabled = False
    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub
End Class