﻿Public Class GastestB

    Dim tx As String = ""
    Dim rx As String = ""

    Private Sub B1_Click(ByVal sender As Object, ByVal e As Windows.Input.TouchEventArgs) Handles gastestB.TouchEnter
        ''b2.TouchEnter execution
        'Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/dnE.png"))
        'Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        'b2.Background = imgbrush

        'b.TouchEnter execution
        Dim imgsrc1 As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/gastest.png"))
        Dim imgbrush1 As New System.Windows.Media.ImageBrush(imgsrc1)
        gastestB.Background = imgbrush1

        If isConnection = True Then
            tx = ""
            rx = ""

            'b.TouchEnter execution
            tx = "00 00 00 00 00 06 02 05 00 DC FF 00"
            rx = TCPComA(tx, 10)
            'writeLog("|ESSCupR |TX:" & tx & " |RX:" & rx)
        End If
    End Sub
    Private Sub b1_Click1(sender As Object, e As Windows.Input.TouchEventArgs) Handles gastestB.TouchLeave
        Dim imgsrc As System.Windows.Media.ImageSource = New System.Windows.Media.Imaging.BitmapImage(New Uri("pack://siteoforigin:,,,/Resources/gastest1.png"))
        Dim imgbrush As New System.Windows.Media.ImageBrush(imgsrc)
        gastestB.Background = imgbrush

        If isConnection = True Then
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 DC 00 00"
            rx = TCPComA(tx, 10)
            'writeLog("|ESSCupR |TX:" & tx & " |RX:" & rx)

            Threading.Thread.Sleep(1000)
            tx = ""
            rx = ""

            tx = "00 00 00 00 00 06 02 05 00 DC 00 00"
            rx = TCPComA(tx, 10)
            'writeLog("|ESSCupR |TX:" & tx & " |RX:" & rx)

        End If
    End Sub

End Class
